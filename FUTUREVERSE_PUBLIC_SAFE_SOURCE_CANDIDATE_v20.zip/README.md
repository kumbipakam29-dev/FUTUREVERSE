# FUTUREVERSE × BATWAL’S VERSE AI HUB × YAGYX CHAIN

> **Tagline:** ASK ANYTHING. BUILD ANYTHING.  
> **Brand Constitution:** BUILD • CREATE • COMPUTE • EVOLVE  
> **Primary Authority:** Dhaval Chandrashekhar Batwal  
> **Canonical Co-Owners:** Hemangini Chandrashekhar Batwal, Jayshriben Chandrashekhar Batwal  

---

## 1. Overview

FUTUREVERSE is an autonomous AI creation engine, distributed compute marketplace, and Web3 ecosystem integrated with the YAGYX Chain (Chain ID: `13370` / `0x343a`). It unifies:
- **Autonomous Creation Engine:** Deconstructs natural-language prompts into specifications, components, preview sandboxes, and commits.
- **BATWAL’S VERSE AI Hub:** 20 specialized reasoning roles, 9-stage quality review gates, and multi-model routing across Google Gemini and offline deterministic fallback engines.
- **Distributed Compute Marketplace:** P2P compute settlement at a fixed 1% platform commission with integer minor unit precision.
- **YAGYX Chain Integration:** Web3 wallet connection, on-chain transaction hash verification, and replay-protected membership entitlement.
- **Creative Studios Hub:** 14 specialized creative workspaces (Music, Image, Video, Voice, Animation, 3D, Game, App, Website, Story, Podcast, POD Design, Command Center, Asset Library).
- **Strict Owner-Only Release Export:** Server-side guarded archive export with single-use nonces, cryptographic passkey verification, and anti-caching enforcement.

---

## 2. Quickstart: Local Development

### Prerequisites
- **Node.js:** v20.19.0+ or v22.12.0+ (required by the configured Vite 8 toolchain)
- **npm:** v9.0.0 or higher

### Step-by-Step Setup
1. **Clone or Extract the Archive:**
   ```bash
   cd FUTUREVERSE_FINAL_RELEASE
   ```

2. **Install Dependencies:**
   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` for local development, or use the deployment secret manager. The owner credentials have **no default** and must be three distinct, high-entropy values:
   ```env
   GEMINI_API_KEY="your-gemini-api-key-here"
   APP_URL="http://localhost:3000"
   YAGYX_RPC_URL="https://rpc.yagyx.network"
   FUTUREVERSE_OWNER_KEY="<unique-random-64-hex-character-secret>"
   FUTUREVERSE_CO_OWNER_KEY="<different-unique-random-64-hex-character-secret>"
   FUTUREVERSE_COOP_OWNER_KEY="<another-unique-random-64-hex-character-secret>"
   TRUST_PROXY_HOPS="0"
   ```
   Generate each secret independently (for example, `openssl rand -hex 32`) and replace every placeholder before deployment. Each generated value must be unique and at least 32 characters long. Do not copy the placeholder strings literally, and never commit real secrets. A release source archive is **not** a data backup; runtime transaction/authority/registration records are omitted from the distributable. Use the authenticated backup flow for protected operational data.

4. **Start the Full-Stack Application:**
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 3. Production Build & Tests

- **Run Automated Test Suite (82 defined checks across 20 groups; run with dependencies installed):**
  ```bash
  npm test
  ```

- **Run TypeScript Typecheck:**
  ```bash
  npm run lint
  ```

- **Build Production Client Bundle:**
  ```bash
  npm run build
  ```

- **Run Production Server:**
  ```bash
  npm start
  ```

---

## 4. Free-Tier Cloud Deployment Guide

The application is structured as a full-stack Node.js Express server that serves Vite-built client assets in production (`npm run build` -> `npm start`).

### Option A: Render.com (Free Tier)
1. Push this repository to GitHub.
2. Sign in to [Render](https://render.com) and click **New Web Service**.
3. Select your repository.
4. Set the following configuration:
   - **Environment:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Instance Type:** `Free`
5. Add Environment Variables:
   - `GEMINI_API_KEY`: Your Gemini API key.
   - `NODE_ENV`: `production`
6. Click **Deploy Web Service**.
   *Note: Free instances on Render spin down after 15 minutes of inactivity; initial cold starts take 30–50 seconds.*

### Option B: Railway.app (Free / Trial Tier)
1. Sign in to [Railway](https://railway.app) and create a **New Project**.
2. Connect your GitHub repository.
3. Railway detects the `package.json` scripts automatically:
   - Set Build Command: `npm run build`
   - Set Start Command: `npm start`
4. Set `PORT=3000` and add your `GEMINI_API_KEY`.
5. Deploy.

### Option C: Google Cloud Run (Free Tier)
1. Build container:
   ```bash
   gcloud run deploy futureverse \
     --source . \
     --port 3000 \
     --allow-unauthenticated \
     --region us-central1
   ```
2. Free tier includes 2 million requests per month and 360,000 GB-seconds of compute.

---

## 5. Security & Invariant Checklist

- **Strict Owner-Only Access:** Project release ZIPs are protected by server-side identity guards, 15-minute single-use download nonces, and passkey authentication.
- **Zero Exposed Secrets:** `.env` and sensitive credentials are excluded from the repository and client bundles.
- **Anti-Replay Nonce Engine:** Nonces are destroyed in server memory upon first consumption.
- **Integer Minor Unit Precision:** Financial compute calculations use integer paisa units to prevent floating-point drift.

## Chinese open-weight model catalog (v13)

The Verse model catalog now lists selected Chinese open-weight checkpoints: DeepSeek V4.1 Flash, GLM-5.3-Flash, Qwen3.8-27B, MiniCPM-V 4.7, Xiaomi MiMo-V2.6-Pro, and MiniMax-M3. These are marked `COMMUNITY_LISTED` intentionally: catalog inclusion is not proof of local validation or a live runtime integration.

**Free weights are not free inference.** Downloading weights may be free under the relevant model license, but running them needs RAM/VRAM, storage, electricity or paid hosting. License terms differ, especially for MiniMax; verify each official model card before commercial deployment. This release only adds catalog entries to `/api/verse/models`; it does not add provider adapters, download model weights, or claim that these models are active.
