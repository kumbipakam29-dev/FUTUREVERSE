import React, { useState } from 'react';
import { Wallet, Menu, X, Sparkles, Shield, ChevronDown, Download } from 'lucide-react';
import { WalletState } from '../services/web3';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  walletState: WalletState;
  onConnectWallet: () => void;
  onOpenYagyxModal: () => void;
  onOpenAuthorityModal: () => void;
  onOpenExportModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  walletState,
  onConnectWallet,
  onOpenYagyxModal,
  onOpenAuthorityModal,
  onOpenExportModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const primaryNavLinks = [
    { id: 'discovery', label: 'Discovery' },
    { id: 'yagyx', label: 'YAGYX (13370)' },
    { id: 'launch', label: '30-Day Launch' },
    { id: 'creation', label: 'Creation' },
    { id: 'compute', label: 'Compute 1%' },
    { id: 'social', label: 'Social' },
    { id: 'verse', label: 'Verse AI' },
  ];

  const secondaryNavLinks = [
    { id: 'studios', label: 'Creative Studio Hub' },
    { id: 'explore', label: 'Explore Directory' },
    { id: 'signals', label: 'Demand Intelligence (Parts 4 & 5)' },
    { id: 'workspace', label: 'Builder Workspace' },
    { id: 'evolution', label: 'Evolution Board' },
    { id: 'rewards', label: 'Contributor Bounties' },
    { id: 'membership', label: 'Membership (₹100 / $1)' },
  ];

  const handleNavClick = (tabId: string) => {
    onSelectTab(tabId);
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md overflow-x-hidden">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-1.5 sm:gap-4 lg:gap-6 px-2.5 sm:px-6 lg:px-8">
        {/* Zone 1: Brand Wordmark & Logo */}
        <button
          onClick={() => handleNavClick('discovery')}
          className="flex items-center gap-1.5 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded p-1 group shrink-0"
          title="FUTUREVERSE Home"
        >
          <img
            src="/logos/futureverse-logo.svg"
            alt="FUTUREVERSE"
            className="h-7 sm:h-9 w-auto max-w-[120px] xs:max-w-[150px] sm:max-w-[210px] object-contain transition-transform group-hover:scale-102"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
              const fallback = e.currentTarget.nextElementSibling;
              if (fallback) (fallback as HTMLElement).style.display = 'flex';
            }}
          />
          <div className="hidden items-center gap-2 font-bold tracking-tight text-white text-base sm:text-lg">
            <img src="/logos/futureverse-icon.svg" alt="FV" className="w-5 h-5 sm:w-6 sm:h-6" />
            <span>FUTUREVERSE</span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden xl:flex items-center gap-3 2xl:gap-5 text-xs font-medium text-slate-300 min-w-0">
          {primaryNavLinks.map((link) => {
            const isActive = currentTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`transition-all whitespace-nowrap shrink-0 text-left cursor-pointer ${
                  isActive
                    ? 'text-cyan-300 font-bold border-b-2 border-cyan-400 shadow-[0_4px_12px_rgba(0,240,255,0.3)] pb-1'
                    : 'text-slate-300 hover:text-cyan-200'
                }`}
              >
                {link.label}
              </button>
            );
          })}

          {/* More menu dropdown for secondary sections */}
          <div className="relative shrink-0">
            <button
              onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
              className="flex items-center gap-1 text-slate-400 hover:text-slate-200 cursor-pointer whitespace-nowrap shrink-0"
            >
              <span>Ecosystem</span>
              <ChevronDown className="h-3.5 w-3.5" />
            </button>

            {moreDropdownOpen && (
              <div className="absolute top-8 left-0 z-50 w-52 rounded-xl border border-slate-800 bg-slate-950 p-2 shadow-2xl space-y-1">
                {secondaryNavLinks.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`block w-full text-left px-3 py-1.5 text-xs rounded transition-colors cursor-pointer ${
                      currentTab === item.id
                        ? 'bg-indigo-950 text-indigo-200 font-semibold'
                        : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </nav>

        {/* Zone 3: Action & Utility Controls */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* Export Project ZIP Button (HTTP 403-proof) */}
          {onOpenExportModal && (
            <button
              onClick={onOpenExportModal}
              className="inline-flex items-center gap-1 px-2 py-1.5 sm:px-2.5 sm:py-1.5 text-xs font-mono text-cyan-300 bg-cyan-950/40 hover:bg-cyan-950/80 border border-cyan-800/60 rounded-md transition-colors cursor-pointer"
              title="Download verified FUTUREVERSE project archive ZIP (HTTP 403-proof)"
            >
              <Download className="h-3.5 w-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Export ZIP</span>
            </button>
          )}

          {/* Permanent Authority & Ownership Inspector Button */}
          <button
            onClick={onOpenAuthorityModal}
            className="inline-flex items-center gap-1 px-2 py-1.5 sm:px-2.5 sm:py-1.5 text-xs font-mono text-amber-300 bg-amber-950/40 hover:bg-amber-950/80 border border-amber-800/60 rounded-md transition-colors cursor-pointer"
            title="Protected Authority & Ownership Governance"
          >
            <Shield className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Authority</span>
          </button>

          {/* Web3 Wallet status button */}
          <button
            onClick={walletState.isConnected ? onOpenYagyxModal : onConnectWallet}
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg border transition-all cursor-pointer ${
              walletState.isConnected
                ? walletState.isCorrectNetwork
                  ? 'border-emerald-600/50 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/50 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                  : 'border-amber-600/50 bg-amber-950/40 text-amber-300 hover:bg-amber-900/50 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                : 'border-cyan-500/50 bg-gradient-to-r from-cyan-500/20 via-indigo-600/30 to-purple-600/20 hover:from-cyan-500/30 hover:to-purple-600/30 text-cyan-200 shadow-[0_0_16px_rgba(0,240,255,0.25)]'
            }`}
            title={walletState.isConnected ? 'Inspect YAGYX Chain state' : 'Connect Web3 Wallet'}
          >
            <Wallet className="h-3.5 w-3.5" />
            <span className="whitespace-nowrap font-semibold">
              {walletState.isConnected && walletState.address
                ? `${walletState.address.slice(0, 6)}...${walletState.address.slice(-4)}`
                : 'Connect'}
            </span>
          </button>

          {/* Primary Action Button (Create) */}
          <button
            onClick={() => handleNavClick('creation')}
            className="inline-flex items-center gap-1 px-3 py-1.5 sm:px-4 sm:py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 hover:from-amber-200 hover:to-yellow-100 rounded-lg shadow-[0_0_16px_rgba(245,158,11,0.35)] transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Create</span>
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="inline-flex xl:hidden p-1.5 sm:p-2 text-slate-400 hover:text-white rounded-md border border-slate-800 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-4 w-4 sm:h-5 sm:w-5" /> : <Menu className="h-4 w-4 sm:h-5 sm:w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-b border-slate-800 bg-slate-950 px-4 py-4 space-y-1.5 max-h-[85vh] overflow-y-auto">
          <div className="text-[11px] font-mono text-slate-500 uppercase px-3 pt-1">Primary Modules</div>
          {primaryNavLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`block w-full text-left px-3 py-2 text-xs rounded-md transition-colors cursor-pointer ${
                currentTab === link.id
                  ? 'bg-indigo-950 text-white font-semibold'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
            >
              {link.label}
            </button>
          ))}

          <div className="text-[11px] font-mono text-slate-500 uppercase px-3 pt-3">Ecosystem & Governance</div>
          {secondaryNavLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`block w-full text-left px-3 py-2 text-xs rounded-md transition-colors cursor-pointer ${
                currentTab === link.id
                  ? 'bg-indigo-950 text-white font-semibold'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
            >
              {link.label}
            </button>
          ))}

          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenAuthorityModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-mono rounded-md border border-amber-800/60 text-amber-300 bg-amber-950/40"
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Permanent Authority</span>
            </button>

            <button
              onClick={() => {
                if (walletState.isConnected) onOpenYagyxModal();
                else onConnectWallet();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-mono rounded-md border border-slate-800 text-slate-300 bg-slate-900"
            >
              <Wallet className="h-3.5 w-3.5" />
              <span>
                {walletState.isConnected && walletState.address
                  ? `${walletState.address.slice(0, 8)}... (YAGYX 13370)`
                  : 'Connect Wallet (Chain ID 13370)'}
              </span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
