import React, { useState, useEffect } from 'react';
import { Cpu, Plus, ShieldCheck, CheckCircle2, ArrowRight, Zap, Smartphone, Laptop, Server, Award } from 'lucide-react';
import { ComputeJob, ComputeProvider, WorkloadType, DeviceTier } from '../types';
import { api } from '../services/api';

export const ComputeMarketplaceView: React.FC = () => {
  const [jobs, setJobs] = useState<ComputeJob[]>([]);
  const [providers, setProviders] = useState<ComputeProvider[]>([]);
  const [loading, setLoading] = useState(true);

  // Job creation modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [jobTitle, setJobTitle] = useState('');
  const [workloadType, setWorkloadType] = useState<WorkloadType>('AI_INFERENCE');
  const [deviceTier, setDeviceTier] = useState<DeviceTier>('GPU_WORKSTATION');
  const [budgetInr, setBudgetInr] = useState(1000);
  const [isSubmittingJob, setIsSubmittingJob] = useState(false);

  // Provider registration modal
  const [isRegisterProviderOpen, setIsRegisterProviderOpen] = useState(false);
  const [providerName, setProviderName] = useState('');
  const [providerDevice, setProviderDevice] = useState<DeviceTier>('LAPTOP_PC');
  const [deviceModel, setDeviceModel] = useState('');
  const [isSubmittingProvider, setIsSubmittingProvider] = useState(false);

  // Settlement modal
  const [selectedJobForSettlement, setSelectedJobForSettlement] = useState<ComputeJob | null>(null);
  const [resultProof, setResultProof] = useState('');
  const [isSettling, setIsSettling] = useState(false);

  const loadMarketplaceData = async () => {
    try {
      const [jobRes, provRes] = await Promise.all([
        api.getComputeJobs(),
        api.getComputeProviders(),
      ]);
      setJobs(jobRes.jobs);
      setProviders(provRes.providers);
    } catch (err) {
      console.error('Failed to load compute marketplace:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMarketplaceData();
  }, []);

  // 1% Commission calculation demo
  const commissionPreview = Math.round(budgetInr * 0.01 * 100) / 100;
  const settlementPreview = budgetInr - commissionPreview;

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobTitle.trim()) return;

    setIsSubmittingJob(true);
    try {
      await api.createComputeJob({
        title: jobTitle.trim(),
        workloadType,
        deviceTier,
        grossAmountInr: budgetInr,
        customerName: 'Ecosystem Developer',
      });
      setIsCreateModalOpen(false);
      setJobTitle('');
      loadMarketplaceData();
    } catch (err: any) {
      alert(`Job creation error: ${err.message}`);
    } finally {
      setIsSubmittingJob(false);
    }
  };

  const handleRegisterProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!providerName.trim()) return;

    setIsSubmittingProvider(true);
    try {
      await api.registerComputeProvider({
        ownerName: providerName.trim(),
        deviceType: providerDevice,
        deviceModel: deviceModel.trim() || 'Standard Node',
      });
      setIsRegisterProviderOpen(false);
      setProviderName('');
      setDeviceModel('');
      loadMarketplaceData();
    } catch (err: any) {
      alert(`Registration error: ${err.message}`);
    } finally {
      setIsSubmittingProvider(false);
    }
  };

  const handleClaimJob = async (job: ComputeJob) => {
    try {
      await api.claimComputeJob(job.id, 'My Active Provider Node');
      loadMarketplaceData();
      alert(`Claimed job "${job.title}". You can now execute and submit verification.`);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleSettleJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJobForSettlement || !resultProof.trim()) return;

    setIsSettling(true);
    try {
      await api.submitComputeResult(selectedJobForSettlement.id, resultProof.trim());
      setSelectedJobForSettlement(null);
      setResultProof('');
      loadMarketplaceData();
      alert(`Demo settlement recorded. The 1% commission and provider amount are illustrative ledger values only; no funds were transferred and compute output was not independently verified.`);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSettling(false);
    }
  };

  return (
    <div className="space-y-10 pb-20 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase text-indigo-400">
            <span>DECENTRALIZED RESOURCE GRID</span>
            <span>·</span>
            <span>1% PLATFORM COMMISSION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            Compute Marketplace & Mining Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Coordinate verified computing tasks across Android devices, PCs, GPU workstations, and servers. Earn YGO and YAGYX token rewards for validated work.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsRegisterProviderOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
          >
            <Smartphone className="h-3.5 w-3.5" />
            <span>Opt-in as Provider Node</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded transition-all cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Create Compute Job</span>
          </button>
        </div>
      </div>

      {/* 1% Commission Policy Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-5 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/40">
          <div className="text-slate-400 uppercase text-[10px]">Strict Platform Fee</div>
          <div className="text-xl font-bold text-amber-300 mt-1">1.0% Commission</div>
          <p className="text-[11px] text-slate-500 mt-1 font-sans">
            Applies strictly to paid transactions; free compute contributions incur zero customer fee.
          </p>
        </div>

        <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/40">
          <div className="text-slate-400 uppercase text-[10px]">Example Settlement Breakdown</div>
          <div className="text-slate-200 mt-1 font-sans">
            Customer payment: <strong className="text-white">₹1,000</strong>
            <br />
            1% FUTUREVERSE fee: <strong className="text-amber-300">₹10</strong>
            <br />
            Provider payout: <strong className="text-emerald-400">₹990</strong>
          </div>
        </div>

        <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/40">
          <div className="text-slate-400 uppercase text-[10px]">Device Safeguards</div>
          <div className="text-slate-200 mt-1 font-sans">
            Android opt-in with strict battery & thermal protections. Zero secret background mining.
          </div>
        </div>
      </div>

      {/* Compute Jobs Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-lg font-bold text-white">Active Compute Jobs</h2>
          <span className="text-xs text-slate-400 font-mono">{jobs.length} Available Workloads</span>
        </div>

        <div className="space-y-3">
          {jobs.map((job) => (
            <div
              key={job.id}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-slate-700 transition-all shadow-sm"
            >
              <div className="space-y-1.5 max-w-xl">
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-indigo-400">{job.workloadType}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-400">Target Tier: {job.deviceTier}</span>
                  <span className="text-slate-600">·</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] ${
                      job.status === 'OPEN'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                        : job.status === 'SETTLED'
                        ? 'bg-slate-800 text-slate-300'
                        : 'bg-amber-950 text-amber-300 border border-amber-800/60'
                    }`}
                  >
                    {job.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white">{job.title}</h3>
                <p className="text-xs text-slate-400">
                  Customer: <span className="text-slate-300">{job.customerName}</span> · Verification: {job.verificationMethod}
                </p>

                {job.resultPayload && (
                  <div className="p-2.5 rounded bg-slate-950/70 border border-slate-800 text-[11px] text-slate-300 font-mono">
                    Output: {job.resultPayload}
                  </div>
                )}
              </div>

              {/* Financial settlement breakdown & actions */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-xs font-mono shrink-0">
                <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-0.5 text-right sm:text-left">
                  <div>
                    Gross: <span className="font-bold text-white">₹{job.grossAmountInr}</span>
                  </div>
                  <div className="text-[11px] text-amber-300">
                    1% Fee: -₹{job.commissionAmountInr}
                  </div>
                  <div className="text-emerald-400 font-bold">
                    Payout: ₹{job.providerSettlementInr}
                  </div>
                </div>

                <div className="flex sm:flex-col gap-2">
                  {job.status === 'OPEN' && (
                    <button
                      onClick={() => handleClaimJob(job)}
                      className="px-3.5 py-1.5 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                    >
                      Claim Job
                    </button>
                  )}

                  {job.status === 'ASSIGNED' && (
                    <button
                      onClick={() => setSelectedJobForSettlement(job)}
                      className="px-3.5 py-1.5 font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer"
                    >
                      Submit Proof & Settle
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Provider Nodes Registry & Mining Rewards */}
      <div className="space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-lg font-bold text-white">Registered Provider Nodes & Mining Rewards</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Providers contributing hardware compute to the network earn settlement in INR plus verified YGO & YAGYX token incentives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {providers.map((prov) => (
            <div
              key={prov.id}
              className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 space-y-3"
            >
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-indigo-400 flex items-center gap-1">
                  {prov.deviceType === 'ANDROID' && <Smartphone className="h-3.5 w-3.5" />}
                  {prov.deviceType === 'LAPTOP_PC' && <Laptop className="h-3.5 w-3.5" />}
                  {prov.deviceType === 'GPU_WORKSTATION' && <Cpu className="h-3.5 w-3.5" />}
                  {prov.deviceType === 'SERVER_CLUSTER' && <Server className="h-3.5 w-3.5" />}
                  <span>{prov.deviceType}</span>
                </span>
                <span className="text-emerald-400 font-semibold">{prov.reputationScore}% Rep</span>
              </div>

              <div>
                <h4 className="text-sm font-bold text-white">{prov.ownerName}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{prov.deviceModel}</p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 text-[10px] block">Settled Payouts</span>
                  <span className="text-white font-bold">₹{prov.earnedInr.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Mined Rewards</span>
                  <span className="text-amber-300 font-bold">
                    {prov.rewardTokensEarned.YAGYX} YAGYX · {prov.rewardTokensEarned.YGO} YGO
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Compute Job Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Create Compute Job</h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateJob} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Job Title / Task Objective</label>
                <input
                  type="text"
                  placeholder="e.g. Model Evaluation & Invariant Testing"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300">Workload Type</label>
                  <select
                    value={workloadType}
                    onChange={(e) => setWorkloadType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="AI_INFERENCE">AI Inference</option>
                    <option value="DATA_SYNTHESIS">Data Synthesis</option>
                    <option value="GRAPH_TRAVERSAL">Graph Traversal</option>
                    <option value="VERIFICATION_PROOF">Verification Proof</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300">Required Device Tier</label>
                  <select
                    value={deviceTier}
                    onChange={(e) => setDeviceTier(e.target.value as any)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="GPU_WORKSTATION">GPU Workstation</option>
                    <option value="SERVER_CLUSTER">Server Cluster</option>
                    <option value="LAPTOP_PC">PC / Laptop</option>
                    <option value="ANDROID">Android Micro-Compute</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Gross Budget (₹ INR)</label>
                <input
                  type="number"
                  min={100}
                  step={50}
                  value={budgetInr}
                  onChange={(e) => setBudgetInr(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                  required
                />
              </div>

              {/* Real 1% Commission Calculation Card */}
              <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/60 font-mono space-y-1">
                <div className="text-[11px] text-slate-400">Commission Ledger Calculation:</div>
                <div className="flex justify-between text-slate-200">
                  <span>Gross Customer Payment:</span>
                  <span className="font-bold">₹{budgetInr.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-amber-300">
                  <span>1.0% FUTUREVERSE Commission:</span>
                  <span className="font-bold">₹{commissionPreview.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-emerald-400 border-t border-slate-800 pt-1 font-bold">
                  <span>Net Provider Settlement:</span>
                  <span>₹{settlementPreview.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingJob}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  {isSubmittingJob ? 'Broadcasting Job...' : 'Authorize & Broadcast Job'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Register Provider Modal */}
      {isRegisterProviderOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Opt-In as Compute Provider</h3>
              <button onClick={() => setIsRegisterProviderOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterProvider} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Provider Handle / Node Name</label>
                <input
                  type="text"
                  placeholder="e.g. Alex (Node 01)"
                  value={providerName}
                  onChange={(e) => setProviderName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Device Hardware Tier</label>
                <select
                  value={providerDevice}
                  onChange={(e) => setProviderDevice(e.target.value as any)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                >
                  <option value="LAPTOP_PC">PC / Laptop</option>
                  <option value="GPU_WORKSTATION">GPU Workstation</option>
                  <option value="SERVER_CLUSTER">Dedicated Server</option>
                  <option value="ANDROID">Android Mobile (Safeguards enforced)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Hardware Specification Model</label>
                <input
                  type="text"
                  placeholder="e.g. RTX 4080, Ryzen 9, Pixel 9 Pro"
                  value={deviceModel}
                  onChange={(e) => setDeviceModel(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/40 text-slate-400 text-[11px] leading-relaxed">
                ✓ Thermal and battery throttle guards active.
                <br />
                ✓ Workloads isolated from host system.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsRegisterProviderOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingProvider}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  {isSubmittingProvider ? 'Registering...' : 'Register Node'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Settle Job Proof Modal */}
      {selectedJobForSettlement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Submit Proof of Execution</h3>
              <button onClick={() => setSelectedJobForSettlement(null)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleSettleJob} className="space-y-4 text-xs">
              <div>
                <span className="text-slate-400">Job:</span> <strong className="text-white">{selectedJobForSettlement.title}</strong>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Execution Output / Proof Hash</label>
                <textarea
                  rows={3}
                  placeholder="Paste execution output or cryptographic proof string..."
                  value={resultProof}
                  onChange={(e) => setResultProof(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono"
                  required
                />
              </div>

              <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60 font-mono text-[11px] space-y-0.5">
                <div>Payout upon verification: <strong className="text-emerald-400">₹{selectedJobForSettlement.providerSettlementInr}</strong></div>
                <div>1% Platform commission: <strong className="text-amber-300">₹{selectedJobForSettlement.commissionAmountInr}</strong></div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedJobForSettlement(null)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSettling}
                  className="px-4 py-2 font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors cursor-pointer"
                >
                  {isSettling ? 'Verifying Proof...' : 'Verify & Settle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
