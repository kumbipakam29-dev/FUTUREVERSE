import React from 'react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
  onOpenExportModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenExportModal }) => {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 text-slate-400 py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-2 space-y-3">
          <div className="text-white font-bold text-base tracking-tight">FUTUREVERSE</div>
          <p className="text-xs text-slate-400 max-w-md leading-relaxed">
            ASK ANYTHING. BUILD ANYTHING.
            <br />
            Built with the community, not just for the community.
          </p>
          <div className="text-xs text-slate-500 font-mono pt-1">
            Owner identities are private · Core governance is access-controlled
          </div>
          <div className="text-xs text-slate-600 font-mono">
            Journey: Ask · Explore · Create · Share · Improve · Build Together
          </div>
        </div>

        <div>
          <div className="text-xs font-semibold text-slate-200 tracking-wider uppercase mb-3">Platform & Engine</div>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onSelectTab('discovery')} className="hover:text-white transition-colors cursor-pointer">
                Discovery & Home
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('launch')} className="hover:text-white transition-colors cursor-pointer text-amber-300 font-medium">
                30-Day Mystery Launch
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('creation')} className="hover:text-white transition-colors cursor-pointer">
                AI Creation Engine
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('explore')} className="hover:text-white transition-colors cursor-pointer">
                Explore Creations
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('workspace')} className="hover:text-white transition-colors cursor-pointer">
                Builder Workspace
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('studios')} className="hover:text-cyan-200 transition-colors cursor-pointer text-cyan-300 font-medium">
                Creative Studio Hub & Asset Library
              </button>
            </li>
            {onOpenExportModal && (
              <li>
                <button
                  onClick={onOpenExportModal}
                  className="hover:text-emerald-300 text-emerald-400 font-medium transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <span>📦 Export Project (.ZIP)</span>
                </button>
              </li>
            )}
          </ul>
        </div>

        <div>
          <div className="text-xs font-semibold text-slate-200 tracking-wider uppercase mb-3">Ecosystem & Intelligence</div>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onSelectTab('verse')} className="hover:text-white transition-colors cursor-pointer text-indigo-300 font-medium">
                BATWAL'S VERSE AI & SARATHI
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('compute')} className="hover:text-white transition-colors cursor-pointer">
                Compute Marketplace (1% Fee)
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('social')} className="hover:text-white transition-colors cursor-pointer">
                Social Hub & Official Channels
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('evolution')} className="hover:text-white transition-colors cursor-pointer">
                Evolution Board
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('rewards')} className="hover:text-white transition-colors cursor-pointer">
                Contributor Bounties
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('yagyx')} className="hover:text-white transition-colors cursor-pointer">
                YAGYX Chain (ID: 13370)
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('membership')} className="hover:text-white transition-colors cursor-pointer">
                Membership (₹100 / $1)
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div className="mx-auto max-w-7xl border-t border-slate-900 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div>&copy; {new Date().getFullYear()} FUTUREVERSE & BATWAL'S VERSE AI. All rights reserved.</div>
        <div className="flex items-center gap-6 text-slate-500 font-mono">
          <span>YAGYX Chain ID: 13370</span>
          <span>·</span>
          <span>EIP-1193 Verified</span>
          <span>·</span>
          <span>1% Platform Commission</span>
        </div>
      </div>
    </footer>
  );
};
