import React, { useState, useEffect } from 'react';
import { Shield, ShieldAlert, CheckCircle2, UserCheck, Key, History, Lock, X } from 'lucide-react';
import { OwnershipRegistry, PermanentAuthorityProfile, AuditLogEvent } from '../types';
import { api } from '../services/api';

const redactOwnerIdentity = (_value: string | null | undefined) => 'Private';

interface OwnershipAuthorityModalProps {
  onClose: () => void;
}

export const OwnershipAuthorityModal: React.FC<OwnershipAuthorityModalProps> = ({ onClose }) => {
  const [ownership, setOwnership] = useState<OwnershipRegistry | null>(null);
  const [profile, setProfile] = useState<PermanentAuthorityProfile | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogEvent[]>([]);
  const [loading, setLoading] = useState(true);

  // Designation update state
  const [newDesignation, setNewDesignation] = useState('Founder & Chairman');
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const [authRes, logsRes] = await Promise.all([
        api.getAuthorityProfile(),
        api.getAuditLogs(),
      ]);
      setOwnership(authRes.ownership);
      setProfile(authRes.dhavalProfile);
      setAuditLogs(logsRes.logs);
      if (authRes.dhavalProfile) {
        setNewDesignation(authRes.dhavalProfile.currentDesignation);
      }
    } catch (err) {
      console.error('Failed to load authority profile:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUpdateDesignation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDesignation.trim()) return;

    setIsUpdating(true);
    setUpdateMessage(null);
    try {
      const res = await api.updateDhavalDesignation(newDesignation.trim());
      setProfile(res.profile);
      setUpdateMessage(res.message);
      loadData();
    } catch (err: any) {
      alert(`Update error: ${err.message}`);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl overflow-hidden my-auto">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800/80 px-6 py-4 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-amber-400" />
            <span className="text-xs font-mono uppercase tracking-wider text-amber-300 font-bold">
              PERMANENT AUTHORITY & OWNERSHIP GOVERNANCE (SECTION 17)
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Declared Ownership Box */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-3">
            <div className="text-xs font-mono uppercase text-slate-400 tracking-wider">
              Declared Project Ownership
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/70">
                <span className="text-slate-500 text-[10px] uppercase font-mono block">Owner</span>
                <span className="font-bold text-white text-sm">
                  {'Identity private'}
                </span>
              </div>
              <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/70">
                <span className="text-slate-500 text-[10px] uppercase font-mono block">Co-Owner</span>
                <span className="font-bold text-white text-sm">
                  {'Identity private'}
                </span>
              </div>
              <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/70">
                <span className="text-slate-500 text-[10px] uppercase font-mono block">Co-Operational Owner</span>
                <span className="font-bold text-white text-sm">
                  {'Identity private'}
                </span>
              </div>
            </div>
          </div>

          {/* Dhaval Permanent Authority Profile & Anti-Lockout Policy */}
          {profile && (
            <div className="rounded-xl border border-amber-900/60 bg-gradient-to-b from-amber-950/20 to-slate-950 p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white">Protected Authority Holder</h2>
                    <span className="text-xs font-mono text-amber-300 bg-amber-950 border border-amber-800 px-2.5 py-0.5 rounded font-bold">
                      Current: {profile.currentDesignation}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    Account ID: {profile.userId} · Protected Authority: Permanent & Immutable
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Anti-Lockout Safeguard Active</span>
                </div>
              </div>

              {/* Designation Changer Form */}
              <form onSubmit={handleUpdateDesignation} className="space-y-3 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                <div className="text-xs font-semibold text-slate-200">
                  Switch Displayed Designation (Permanent Capabilities Preserved by Rule):
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <select
                    value={newDesignation}
                    onChange={(e) => setNewDesignation(e.target.value)}
                    className="flex-1 px-3 py-2 text-xs rounded bg-slate-950 border border-slate-700 text-slate-100 font-medium"
                  >
                    <option value="Owner">Owner</option>
                    <option value="Super Admin">Super Admin</option>
                    <option value="Director">Director</option>
                    <option value="Founder">Founder</option>
                    <option value="Chairman">Chairman</option>
                    <option value="Chief Systems Architect">Chief Systems Architect</option>
                  </select>

                  <button
                    type="submit"
                    disabled={isUpdating}
                    className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {isUpdating ? 'Applying Policy...' : 'Update Designation'}
                  </button>
                </div>

                <p className="text-[11px] text-slate-400 leading-snug">
                  Rule Verification: the protected authority holder can switch between approved designations. The underlying capability matrix and anti-lockout protection never revoke or degrade.
                </p>

                {updateMessage && (
                  <div className="p-2.5 rounded bg-emerald-950/50 border border-emerald-800 text-emerald-300 text-xs">
                    ✓ {redactOwnerIdentity(updateMessage)}
                  </div>
                )}
              </form>

              {/* Effective Permission Matrix */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300">Effective Permanent Permissions:</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                  {profile.effectivePermissions.map((perm) => (
                    <div key={perm} className="p-2 rounded bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                      <span className="truncate">{perm}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Designation History Audit Log */}
              <div className="space-y-2 pt-2">
                <div className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <History className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Designation Update Audit History:</span>
                </div>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {profile.designationHistory.map((dh, i) => (
                    <div key={i} className="p-2 rounded bg-slate-950/80 border border-slate-800 text-[11px] font-mono flex items-center justify-between">
                      <span className="text-slate-300">
                        "{dh.previousDesignation}" → <strong className="text-amber-300">"{dh.newDesignation}"</strong>
                      </span>
                      <span className="text-slate-500">{new Date(dh.changedAt).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* System Security & Audit Log Stream */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Auditable System Security Events</span>
              <span className="text-slate-500 font-mono text-[11px]">{auditLogs.length} Events Logged</span>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/40 text-xs font-mono space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-indigo-400 font-bold">{log.action}</span>
                    <span className="text-slate-500">{new Date(log.timestamp).toLocaleString()}</span>
                  </div>
                  <div className="text-slate-300">
                    <span className="text-slate-400">Actor:</span> {redactOwnerIdentity(log.actor)} · <span className="text-slate-400">Target:</span> {redactOwnerIdentity(log.target)}
                  </div>
                  <p className="text-[11px] text-slate-400">{redactOwnerIdentity(log.details)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
