import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  ShieldCheck,
  FileArchive,
  CheckCircle2,
  AlertCircle,
  Copy,
  Sparkles,
  Lock,
  KeyRound,
  UserCheck,
  ShieldAlert,
} from 'lucide-react';
import { api } from '../services/api';

interface ProjectExportModalProps {
  onClose: () => void;
}

interface ArchiveInfo {
  filename: string;
  sizeMB: number;
  sizeBytes: number;
  sha256: string;
  status: string;
  directDownloadUrl: string;
  base64DownloadUrl: string;
}

export const ProjectExportModal: React.FC<ProjectExportModalProps> = ({ onClose }) => {
  // Authorization state (strictly verified on the server)
  const [isOwnerVerified, setIsOwnerVerified] = useState(false);
  const [ownerActor, setOwnerActor] = useState<string | null>(null);

  // Owner verification form state
  const [actorInput, setActorInput] = useState('');
  const [passkeyInput, setPasskeyInput] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Archive & download state
  const [archiveInfo, setArchiveInfo] = useState<ArchiveInfo | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadMode, setDownloadMode] = useState<'stream' | 'base64'>('stream');
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [copiedHash, setCopiedHash] = useState(false);

  // Check server-side owner authorization status
  const checkOwnerStatus = async () => {
    try {
      const status = await api.getOwnerExportStatus();
      if (status.isOwner && status.canDownload) {
        setIsOwnerVerified(true);
        setOwnerActor('Verified owner');
        await fetchArchiveMetadata();
      } else {
        setIsOwnerVerified(false);
        setOwnerActor(null);
      }
    } catch {
      setIsOwnerVerified(false);
      setOwnerActor(null);
    }
  };

  const fetchArchiveMetadata = async () => {
    try {
      const res = await fetch('/api/export/project/info', { credentials: 'same-origin' });
      if (res.ok) {
        const data = await res.json();
        setArchiveInfo(data);
      }
    } catch (err) {
      console.warn('Metadata fetch deferred until owner session is validated:', err);
    }
  };

  useEffect(() => {
    // Remove the legacy JavaScript-readable bearer token from earlier builds.
    sessionStorage.removeItem('fv_owner_session_token');
    checkOwnerStatus();
  }, []);

  const handleOwnerAuthenticate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsAuthenticating(true);
    setAuthError(null);

    try {
      const res = await api.authenticateOwnerForExport(actorInput.trim(), passkeyInput);
      if (res.success && res.actor) {
        setIsOwnerVerified(true);
        setOwnerActor(res.actor);
        setAuthError(null);
        await fetchArchiveMetadata();
      } else {
        setIsOwnerVerified(false);
        setAuthError(res.error || 'Access Denied: Actor is not in the canonical owner registry.');
      }
    } catch (err: any) {
      setIsOwnerVerified(false);
      setAuthError(err.message || 'Authentication request failed.');
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleDownload = async (mode: 'stream' | 'base64') => {
    if (!isOwnerVerified) {
      setDownloadError('Server authorization required. Please authenticate as the canonical owner.');
      return;
    }

    setIsDownloading(true);
    setDownloadMode(mode);
    setDownloadError(null);
    setDownloadSuccess(null);

    const targetFilename = archiveInfo?.filename || 'FUTUREVERSE_FINAL_RELEASE.zip';

    try {
      if (mode === 'stream') {
        // Step 1: Request single-use 15-minute download nonce from authoritative backend
        const authRes = await api.authorizeProjectDownload();
        if (!authRes.success || !authRes.downloadUrl) {
          throw new Error(authRes.error || 'Server refused download nonce generation.');
        }

        // Step 2: Stream binary via single-use nonce
        const res = await fetch(authRes.downloadUrl);
        if (res.ok) {
          const blob = await res.blob();
          const blobUrl = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = targetFilename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1000);
          setDownloadSuccess(`Verified Owner Download: "${targetFilename}" streamed successfully via single-use nonce.`);
          return;
        } else {
          throw new Error(`Direct download stream returned HTTP ${res.status}`);
        }
      }

      // Mode 2: Authenticated Base64 In-Memory Reconstitution
      const res = await fetch('/api/export/project/base64', { credentials: 'same-origin' });
      if (!res.ok) {
        throw new Error(`Base64 export endpoint returned HTTP ${res.status}`);
      }
      const data = await res.json();
      if (!data.base64) throw new Error('Base64 data payload was empty');

      const binaryStr = atob(data.base64);
      const len = binaryStr.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/zip' });
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = data.filename || targetFilename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1000);

      setDownloadSuccess(
        `Downloaded "${data.filename || targetFilename}" via In-Memory Reconstitution (${data.sizeMB} MB, SHA-256 verified).`
      );
    } catch (err: any) {
      console.error('Download error:', err);
      setDownloadError(err.message || 'Download failed. Verify owner credentials.');
    } finally {
      setIsDownloading(false);
    }
  };

  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-6 sm:p-8 shadow-2xl text-slate-100 max-h-[92vh] overflow-y-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border ${isOwnerVerified ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-rose-500/10 border-rose-500/30 text-rose-400'}`}>
              {isOwnerVerified ? <FileArchive className="h-6 w-6" /> : <Lock className="h-6 w-6" />}
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>FUTUREVERSE Project Release v3.1</span>
                {isOwnerVerified ? (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3" />
                    <span>OWNER AUTHORIZED</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                    <ShieldAlert className="h-3 w-3" />
                    <span>STRICT OWNER ONLY</span>
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                Authoritative standalone archive of all source code, SVG assets, Creative Studios, and runtime configuration.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Security Access Enforcement Notice */}
        {!isOwnerVerified ? (
          <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-950/20 space-y-3">
            <div className="flex items-center gap-2 text-amber-300 font-semibold text-xs tracking-wider uppercase">
              <Lock className="h-4 w-4 shrink-0 text-amber-400" />
              <span>Strict Owner-Only Access Control (Section 3 & 10 Canonical Security Policy)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              The complete standalone FUTUREVERSE project release archive is restricted to verified, authorized project stewards. Personal names and contact details are intentionally not displayed.
            </p>
            <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-400" />
              <span>Every owner must use a separate server-configured secret. Identity labels, email addresses, and usernames alone never grant access.</span>
            </div>

            {/* Owner Verification Form */}
            <form onSubmit={handleOwnerAuthenticate} className="pt-2 space-y-3 border-t border-amber-500/20">
              <div className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                <KeyRound className="h-3.5 w-3.5" />
                <span>Verify Canonical Owner:</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1 uppercase">Registered Owner Identity (private)</label>
                  <input
                    type="text"
                    value={actorInput}
                    onChange={(e) => setActorInput(e.target.value)}
                    placeholder="Enter registered identity privately"
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1 uppercase">Owner Secret Passkey (Required)</label>
                  <input
                    type="password"
                    required
                    autoComplete="current-password"
                    value={passkeyInput}
                    onChange={(e) => setPasskeyInput(e.target.value)}
                    placeholder="Enter your configured 32+ character owner secret"
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono text-xs"
                  />
                </div>
              </div>

              {authError && (
                <div className="p-2.5 rounded-lg border border-rose-500/40 bg-rose-950/60 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                  <span>{authError}</span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-2 pt-1">
                <button
                  type="submit"
                  disabled={isAuthenticating}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-amber-500/10 disabled:opacity-50"
                >
                  {isAuthenticating ? (
                    <span>Verifying Identity...</span>
                  ) : (
                    <>
                      <KeyRound className="h-4 w-4" />
                      <span>Authenticate Identity</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-950/20 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <UserCheck className="h-4 w-4" />
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-mono">Authenticated Canonical Owner</span>
                <span className="font-bold text-emerald-300">Verified owner identity hidden</span>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-700">
              2-Hour Active Session
            </span>
          </div>
        )}

        {/* Archive Metadata Card (Rendered only with verified or static details) */}
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3 font-mono text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
            <span className="text-slate-400">Canonical Release Archive:</span>
            <span className="font-bold text-amber-300 break-all">
              {archiveInfo?.filename || 'FUTUREVERSE_FINAL_RELEASE.zip'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-[11px]">
            <div>
              <span className="text-slate-500 block uppercase">Archive Size</span>
              <span className="text-white font-semibold">
                {archiveInfo?.sizeMB ? `${archiveInfo.sizeMB} MB` : '10.72 MB'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block uppercase">Total Files</span>
              <span className="text-white font-semibold">240 Files (Clean Standalone)</span>
            </div>
            <div>
              <span className="text-slate-500 block uppercase">Security Integrity</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Zero Secrets</span>
              </span>
            </div>
          </div>

          {archiveInfo?.sha256 ? (
            <div className="pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-slate-500 text-[10px] uppercase mb-1">
                <span>SHA-256 Checksum</span>
                <button
                  onClick={() => copyHash(archiveInfo.sha256)}
                  className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                >
                  <Copy className="h-3 w-3" />
                  <span>{copiedHash ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 text-[10px] text-amber-200/90 break-all select-all">
                {archiveInfo.sha256}
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-500">
              <span>SHA-256 Checksum: bc2e0a52688cacd22c8b04d7722586a7a378543252cded13f2a0e658ebc1f05a</span>
            </div>
          )}
        </div>

        {/* Download Action Section (ONLY ENABLED WHEN SERVER-VERIFIED) */}
        <div className="space-y-3">
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
            {isOwnerVerified ? 'Authorized Export Methods:' : 'Export Methods (Locked):'}
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Mode 1: Direct Binary Stream via Single-Use Nonce */}
            <button
              onClick={() => handleDownload('stream')}
              disabled={!isOwnerVerified || isDownloading}
              className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between gap-3 ${
                !isOwnerVerified
                  ? 'border-slate-800 bg-slate-950/40 opacity-40 cursor-not-allowed'
                  : isDownloading && downloadMode === 'stream'
                  ? 'border-cyan-500/50 bg-cyan-950/30 cursor-pointer'
                  : 'border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-cyan-400 cursor-pointer'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-cyan-300 flex items-center gap-1.5">
                  <Download className={`h-4 w-4 ${isDownloading && downloadMode === 'stream' ? 'animate-bounce' : ''}`} />
                  <span>Single-Use Nonce (.ZIP)</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  {isOwnerVerified ? 'Ready' : 'Locked'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Issues a cryptographically secure 15-minute single-use download token and streams the binary archive.
              </p>
            </button>

            {/* Mode 2: In-App Base64 Reconstitution */}
            <button
              onClick={() => handleDownload('base64')}
              disabled={!isOwnerVerified || isDownloading}
              className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between gap-3 ${
                !isOwnerVerified
                  ? 'border-slate-800 bg-slate-950/40 opacity-40 cursor-not-allowed'
                  : isDownloading && downloadMode === 'base64'
                  ? 'border-amber-500/50 bg-amber-950/30 cursor-pointer'
                  : 'border-amber-500/30 bg-amber-950/20 hover:bg-amber-950/40 hover:border-amber-400 cursor-pointer'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-amber-300 flex items-center gap-1.5">
                  <Sparkles className={`h-4 w-4 ${isDownloading && downloadMode === 'base64' ? 'animate-spin' : ''}`} />
                  <span>Base64 Reconstitution</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                  {isOwnerVerified ? 'In-Memory' : 'Locked'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Reconstitutes the binary archive in browser memory using the protected same-origin owner session.
              </p>
            </button>
          </div>
        </div>

        {/* Feedback Messages */}
        {downloadSuccess && (
          <div className="p-3.5 rounded-xl border border-emerald-500/40 bg-emerald-950/50 text-emerald-300 text-xs flex items-center gap-2.5">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{downloadSuccess}</span>
          </div>
        )}

        {downloadError && (
          <div className="p-3.5 rounded-xl border border-rose-500/40 bg-rose-950/50 text-rose-300 text-xs flex items-center gap-2.5">
            <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
            <span>{downloadError}</span>
          </div>
        )}

        {/* Secondary Downloads */}
        <div className="pt-2 border-t border-slate-800 text-xs space-y-2">
          <span className="text-slate-400 font-semibold block text-[11px] uppercase tracking-wider">
            Public Brand Kits & Network Archives:
          </span>
          <div className="flex flex-wrap gap-2 text-[11px]">
            <a
              href="/brand-kit/futureverse-brand-kit.zip"
              download="futureverse-brand-kit.zip"
              className="px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            >
              <FileArchive className="h-3 w-3 text-amber-400" />
              <span>Illuminati Brand Kit (.ZIP · 22 KB SVG)</span>
            </a>
            <button
              type="button"
              onClick={async () => {
                setDownloadError(null);
                try {
                  const res = await fetch('/api/backup/download', { credentials: 'same-origin' });
                  if (!res.ok) throw new Error(res.status === 403 ? 'Sign in with a configured owner credential before downloading the YAGYX backup.' : `Backup download returned HTTP ${res.status}.`);
                  const blob = await res.blob();
                  const blobUrl = window.URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = blobUrl;
                  link.download = 'YAGYX_CHAIN_PROJECT_BACKUP.zip';
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  window.URL.revokeObjectURL(blobUrl);
                } catch (err: any) {
                  setDownloadError(err.message || 'Backup download failed.');
                }
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            >
              <FileArchive className="h-3 w-3 text-cyan-400" />
              <span>YAGYX Network Backup (.ZIP · Owner Access)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
