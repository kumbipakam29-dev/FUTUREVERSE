import React, { useState, useEffect, useMemo } from 'react';
import {
  Wallet,
  Shield,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  Send,
  Download,
  FileArchive,
  Check,
  Copy,
  Activity,
  Terminal,
  Search,
  Layers,
  Coins,
  Cpu,
  Server,
  Lock,
  Globe,
  Database,
  Code2,
  ChevronRight,
  Info,
  Clock,
  ArrowUpRight,
  Hash,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { WalletState, Web3Service, YAGYX_CHAIN_ID, YAGYX_CHAIN_HEX } from '../services/web3';
import {
  YagyxNetworkInfo,
  YagyxLedgerRecord,
  YagyxRpcProbeResult,
  YagyxSecurityReport
} from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';

interface YagyxHubViewProps {
  walletState: WalletState;
  onConnectWallet: () => void;
  onRefreshWallet: () => void;
}

type YagyxTab = 'overview' | 'network' | 'explorer' | 'developers' | 'assets' | 'pay' | 'security' | 'backup';

export const YagyxHubView: React.FC<YagyxHubViewProps> = ({
  walletState,
  onConnectWallet,
  onRefreshWallet,
}) => {
  const [activeTab, setActiveTab] = useState<YagyxTab>('overview');
  const [networkInfo, setNetworkInfo] = useState<YagyxNetworkInfo | null>(null);
  const [isSwitchingNetwork, setIsSwitchingNetwork] = useState(false);
  const [switchError, setSwitchError] = useState<string | null>(null);

  // Real-time RPC Probe state
  const [probeResult, setProbeResult] = useState<YagyxRpcProbeResult | null>(null);
  const [isProbingRpc, setIsProbingRpc] = useState(false);
  const [customRpcUrl, setCustomRpcUrl] = useState('');

  // Ledger & Explorer state
  const [ledgerOrders, setLedgerOrders] = useState<YagyxLedgerRecord[]>([]);
  const [loadingLedger, setLoadingLedger] = useState(false);
  const [ledgerOwnerAuthRequired, setLedgerOwnerAuthRequired] = useState(false);
  const [explorerSearch, setExplorerSearch] = useState('');
  const [assetFilter, setAssetFilter] = useState<'ALL' | 'YAGYX' | 'YGO' | 'YINR' | 'YUSD'>('ALL');
  const [selectedTx, setSelectedTx] = useState<YagyxLedgerRecord | null>(null);

  // Developer Snippets State
  const [activeSnippetTab, setActiveSnippetTab] = useState<'viem' | 'ethers' | 'hardhat' | 'foundry' | 'web3py'>('viem');
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  // Interactive JSON-RPC Console State
  const [rpcMethod, setRpcMethod] = useState<'eth_chainId' | 'eth_blockNumber' | 'net_version' | 'web3_clientVersion' | 'eth_gasPrice'>('eth_chainId');
  const [rpcConsoleLoading, setRpcConsoleLoading] = useState(false);
  const [rpcConsoleResponse, setRpcConsoleResponse] = useState<string | null>(null);

  // Security Report State
  const [securityReport, setSecurityReport] = useState<YagyxSecurityReport | null>(null);

  // Base-unit Calculator state
  const [calcAmount, setCalcAmount] = useState<string>('1.0');
  const [calcAsset, setCalcAsset] = useState<'YAGYX' | 'YGO' | 'YINR' | 'YUSD'>('YAGYX');

  // Checkout Demo state
  const [checkoutRegion, setCheckoutRegion] = useState<'India' | 'Global'>('India');
  const [checkoutAsset, setCheckoutAsset] = useState<'YGO' | 'YAGYX' | 'YINR' | 'YUSD'>('YGO');
  const [checkoutState, setCheckoutState] = useState<'IDLE' | 'PROCESSING' | 'CONFIRMED' | 'ERROR'>('IDLE');
  const [checkoutTxHash, setCheckoutTxHash] = useState('');
  const [checkoutMessage, setCheckoutMessage] = useState<string | null>(null);

  // In-app backup download state
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [copiedHash, setCopiedHash] = useState(false);
  const [showInventoryModal, setShowInventoryModal] = useState(false);

  const archiveSha256 = '7427a63843db50114f6470ffe77a9770c4b8455b627a507f304a20197ac855fa';

  // Load initial network info and security findings
  useEffect(() => {
    api.getYagyxConfig().then(setNetworkInfo).catch(console.error);
    api.getYagyxSecurityFindings().then(setSecurityReport).catch(console.error);
    loadLedgerData();
    runRpcProbe();
  }, []);

  const loadLedgerData = async () => {
    setLoadingLedger(true);
    try {
      const data = await api.getYagyxLedger();
      setLedgerOrders(data.orders || []);
      setLedgerOwnerAuthRequired(Boolean(data.requiresOwnerAuthorization));
    } catch (err) {
      console.error('Failed to load YAGYX ledger:', err);
      setLedgerOwnerAuthRequired(false);
    } finally {
      setLoadingLedger(false);
    }
  };

  const runRpcProbe = async (overrideUrl?: string) => {
    setIsProbingRpc(true);
    try {
      const result = await api.probeYagyxRpc(overrideUrl || (customRpcUrl ? customRpcUrl : undefined));
      setProbeResult(result);
    } catch (err: any) {
      setProbeResult({
        status: 'OFFLINE',
        targetUrl: overrideUrl || customRpcUrl || 'https://rpc.yagyx.network',
        latencyMs: 0,
        isExpectedChain: false,
        error: err.message,
        message: 'Client-side probe encountered request failure.',
      });
    } finally {
      setIsProbingRpc(false);
    }
  };

  const handleSwitchToYagyx = async () => {
    setIsSwitchingNetwork(true);
    setSwitchError(null);
    try {
      await Web3Service.switchToYagyxChain();
      onRefreshWallet();
    } catch (err: any) {
      setSwitchError(err.message || 'Failed to switch network.');
    } finally {
      setIsSwitchingNetwork(false);
    }
  };

  const copyChecksum = () => {
    navigator.clipboard.writeText(archiveSha256);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  const copySnippet = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const handleDownloadBackup = async (mode: 'stream' | 'base64' = 'stream') => {
    setIsDownloading(true);
    setDownloadError(null);
    setDownloadSuccessMessage(null);

    try {
      if (mode === 'stream') {
        const res = await fetch('/api/backup/download', { credentials: 'same-origin' });
        if (res.ok) {
          const blob = await res.blob();
          const blobUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = blobUrl;
          link.download = 'YAGYX_CHAIN_PROJECT_BACKUP.zip';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1000);
          setDownloadSuccessMessage('Archive downloaded successfully via binary stream.');
          return;
        } else if (res.status === 403) {
          const errorBody = await res.clone().json().catch(() => null);
          if (errorBody?.code === 'OWNER_AUTHORIZATION_REQUIRED') {
            throw new Error('Owner sign-in required. Open Export ZIP in the navigation and sign in with your configured owner credential before downloading backups.');
          }
          console.warn('Binary stream was blocked by an intermediary; trying the Base64 fallback.');
        } else {
          throw new Error(`Direct download returned HTTP ${res.status}`);
        }
      }

      const jsonRes = await fetch('/api/backup/base64', { credentials: 'same-origin' });
      if (!jsonRes.ok) {
        const errorBody = await jsonRes.clone().json().catch(() => null);
        if (jsonRes.status === 403 && errorBody?.code === 'OWNER_AUTHORIZATION_REQUIRED') {
          throw new Error('Owner sign-in required. Open Export ZIP in the navigation and sign in with your configured owner credential before downloading backups.');
        }
        throw new Error(`Base64 export failed with HTTP ${jsonRes.status}`);
      }
      const data = await jsonRes.json();
      if (!data.base64) throw new Error('Base64 payload was empty');

      const binaryString = atob(data.base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/zip' });
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = data.filename || 'YAGYX_CHAIN_PROJECT_BACKUP.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1000);
      setDownloadSuccessMessage(
        `Archive verified and downloaded (${(data.sizeBytes / 1024 / 1024).toFixed(2)} MB, SHA-256 matched).`
      );
    } catch (err: any) {
      console.error('Download error:', err);
      setDownloadError(err.message || 'Download failed. Please check network connection.');
    } finally {
      setIsDownloading(false);
    }
  };

  // Base unit calculation
  const computedBaseUnits = useMemo(() => {
    try {
      const num = parseFloat(calcAmount);
      if (isNaN(num) || num <= 0) return '0';
      const microUnits = BigInt(Math.round(num * 1_000_000));
      const baseUnits = microUnits * BigInt(10 ** 12);
      return baseUnits.toString();
    } catch {
      return '0';
    }
  }, [calcAmount]);

  // Filtered transactions for explorer
  const filteredOrders = useMemo(() => {
    return ledgerOrders.filter((ord) => {
      if (assetFilter !== 'ALL' && ord.selectedAsset !== assetFilter) return false;
      if (!explorerSearch.trim()) return true;
      const q = explorerSearch.toLowerCase().trim();
      return (
        ord.orderId.toLowerCase().includes(q) ||
        (ord.txHash && ord.txHash.toLowerCase().includes(q)) ||
        (ord.senderAddress && ord.senderAddress.toLowerCase().includes(q)) ||
        (ord.expectedRecipient && ord.expectedRecipient.toLowerCase().includes(q)) ||
        ord.state.toLowerCase().includes(q)
      );
    });
  }, [ledgerOrders, assetFilter, explorerSearch]);

  // Execute JSON-RPC test call
  const handleExecuteRpcConsole = async () => {
    setRpcConsoleLoading(true);
    setRpcConsoleResponse(null);
    try {
      const payload = {
        jsonrpc: '2.0',
        id: Date.now(),
        method: rpcMethod,
        params: [],
      };
      const target = customRpcUrl.trim() || 'https://rpc.yagyx.network';

      const res = await fetch('/api/yagyx/rpc-probe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rpcUrl: target }),
      });
      const data = await res.json();
      setRpcConsoleResponse(
        JSON.stringify(
          {
            request: payload,
            targetEndpoint: target,
            probeResult: data,
            timestamp: new Date().toISOString(),
          },
          null,
          2
        )
      );
    } catch (err: any) {
      setRpcConsoleResponse(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setRpcConsoleLoading(false);
    }
  };

  // Run YAGYX Pay Checkout Demo
  const handleRunCheckoutDemo = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutState('PROCESSING');
    setCheckoutMessage(null);

    try {
      const isIndia = checkoutRegion === 'India';
      const checkoutRes = await fetch('/api/membership/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'usr-interactive-demo',
          tier: 'Founding Member',
          region: isIndia ? 'India' : 'Global',
          paymentMethod: `CRYPTO_${checkoutAsset}`,
        }),
      });

      if (!checkoutRes.ok) {
        throw new Error('Checkout initialization failed');
      }

      const checkoutData = await checkoutRes.json();
      const orderId = checkoutData.orderId || checkoutData.id || checkoutData.checkoutId;

      // Deterministic simulation hash conforming to Genesis simulation pattern
      const simHash = `0x343a${Date.now().toString(16).padStart(56, '0')}1337`;
      setCheckoutTxHash(simHash);

      // Verify transaction against authoritative payment service
      const confirmRes = await fetch('/api/membership/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          transactionHash: simHash,
          senderAddress: walletState.address || '0xDemoWalletUser000000000000000000000001',
          isMockTest: true,
        }),
      });

      const confirmData = await confirmRes.json();
      if (!confirmRes.ok || !confirmData.verified) {
        throw new Error(confirmData.error || 'Payment verification failed');
      }

      setCheckoutState('CONFIRMED');
      setCheckoutMessage(
        `Payment verified atomically! 30-day membership entitlement activated for order ${orderId}.`
      );
      loadLedgerData(); // Refresh ledger table
    } catch (err: any) {
      setCheckoutState('ERROR');
      setCheckoutMessage(err.message || 'Verification failed.');
    }
  };

  // Code snippets definitions
  const snippets = {
    viem: `import { defineChain } from 'viem';

export const yagyx = defineChain({
  id: 13370,
  name: 'YAGYX Chain',
  nativeCurrency: {
    name: 'YAGYX',
    symbol: 'YAGYX',
    decimals: 18,
  },
  rpcUrls: {
    default: { http: ['https://rpc.yagyx.network'] },
  },
  blockExplorers: {
    default: { name: 'YAGYX Explorer', url: 'https://explorer.yagyx.network' },
  },
});`,
    ethers: `import { ethers } from 'ethers';

// Connect to YAGYX Chain ID 13370 (0x343a)
const rpcUrl = 'https://rpc.yagyx.network';
const provider = new ethers.JsonRpcProvider(rpcUrl, 13370);

async function getNetworkInfo() {
  const network = await provider.getNetwork();
  console.log('Connected to:', network.name, 'Chain ID:', network.chainId);
  const blockNumber = await provider.getBlockNumber();
  console.log('Current block:', blockNumber);
}`,
    hardhat: `import { HardhatUserConfig } from 'hardhat/config';
import '@nomicfoundation/hardhat-toolbox';

const config: HardhatUserConfig = {
  solidity: '0.8.24',
  networks: {
    yagyx: {
      url: process.env.YAGYX_RPC_URL || 'https://rpc.yagyx.network',
      chainId: 13370,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
  },
};

export default config;`,
    foundry: `[profile.default]
src = 'src'
out = 'out'
libs = ['lib']

[rpc_endpoints]
yagyx = "https://rpc.yagyx.network"

# Usage: forge script script/Deploy.s.sol --rpc-url yagyx --broadcast`,
    web3py: `from web3 import Web3

# Connect to YAGYX EVM Gateway
w3 = Web3(Web3.HTTPProvider('https://rpc.yagyx.network'))

if w3.is_connected():
    print(f"Connected! Chain ID: {w3.eth.chain_id} (Expected: 13370)")
else:
    print("Awaiting public node DNS peering at rpc.yagyx.network")`,
  };

  return (
    <div className="space-y-8 pb-24 text-slate-100">
      {/* Top Banner & Network Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-[#070A12] p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 rounded-full bg-violet-600/5 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            {/* Zero-Pill Typography Metadata */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-cyan-400">
              <span className="font-semibold tracking-wider">YAGYX CHAIN</span>
              <span className="text-slate-600">·</span>
              <span>CHAIN ID 13370</span>
              <span className="text-slate-600">·</span>
              <span>HEX 0x343a</span>
              <span className="text-slate-600">·</span>
              <span className="text-amber-300">PRE-GENESIS SPECIFICATION</span>
            </div>

            <div className="py-1">
              <img
                src={ASSETS.yagyxLogo}
                alt="YAGYX CHAIN"
                className="h-10 sm:h-12 w-auto object-contain"
              />
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-wider text-white leading-tight font-brand">
              An Open Network for Digital Value
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              Official network hub, developer documentation, and settlement verification portal for{' '}
              <strong className="text-white font-medium">YAGYX GLOBAL VALUE OS</strong>. High-throughput, EVM-compatible settlement layer engineered for autonomous AI agents, decentralized compute, and non-custodial peer-to-peer micro-transactions.
            </p>

            <div className="text-xs text-slate-400 pt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>Core stewardship identities are private</span>
              <span className="text-slate-600">/</span>
              <span className="text-cyan-400 font-mono">18 Decimals Standard</span>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 shrink-0">
            {!walletState.isConnected ? (
              <button
                type="button"
                onClick={onConnectWallet}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer shadow-lg shadow-cyan-950/40"
              >
                <Wallet className="h-4 w-4" />
                <span>Connect Web3 Wallet</span>
              </button>
            ) : !walletState.isCorrectNetwork ? (
              <button
                type="button"
                onClick={handleSwitchToYagyx}
                disabled={isSwitchingNetwork}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-colors cursor-pointer shadow-lg"
              >
                {isSwitchingNetwork ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                <span>Switch to Chain ID 13370</span>
              </button>
            ) : (
              <div className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-mono text-emerald-300 bg-emerald-950/40 border border-emerald-800/60 rounded-lg">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>Connected (13370)</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => handleDownloadBackup('stream')}
              disabled={isDownloading}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              title="Download verified 67-file project archive ZIP"
            >
              <Download className={`h-4 w-4 text-cyan-400 ${isDownloading ? 'animate-bounce' : ''}`} />
              <span>{isDownloading ? 'Downloading...' : 'Preservation Archive (.ZIP)'}</span>
            </button>
          </div>
        </div>

        {/* Honest Network Status Disclosure Notice */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
            <span>
              Public Network Status:{' '}
              <strong className="text-amber-300 font-mono font-medium">
                {probeResult?.status === 'ONLINE_VERIFIED'
                  ? 'Active & Verified'
                  : 'Awaiting Public Node Peering (DNS ENOTFOUND at rpc.yagyx.network)'}
              </strong>
            </span>
          </div>
          <div className="text-slate-500 font-mono text-[11px]">
            Zero Fabricated Transactions · Deterministic Test Mode Enabled
          </div>
        </div>

        {switchError && (
          <div className="mt-4 p-3 rounded-lg border border-rose-900/50 bg-rose-950/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{switchError}</span>
          </div>
        )}
      </div>

      {/* Segmented Sub-Navigation (Zero-Pill Functional Control) */}
      <div className="border-b border-slate-800 pb-2">
        <nav className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          {[
            { id: 'overview', label: 'Network Hub' },
            { id: 'network', label: 'Live Telemetry' },
            { id: 'explorer', label: 'Block & Ledger Explorer' },
            { id: 'developers', label: 'Developer Portal' },
            { id: 'assets', label: 'Ecosystem Assets' },
            { id: 'pay', label: 'YAGYX Pay Demo' },
            { id: 'security', label: 'Security & Forensics' },
            { id: 'backup', label: 'Archive & Download' },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as YagyxTab)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* =========================================================================
          TAB 1: OVERVIEW / NETWORK HUB
          ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Key Metric Telemetry Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
              <div className="text-xs text-slate-400 font-mono">Designated Chain ID</div>
              <div className="text-xl font-bold text-white mt-1">13370 (0x343a)</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">EVM Bytecode Compatible</div>
            </div>

            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
              <div className="text-xs text-slate-400 font-mono">Consensus Mechanism</div>
              <div className="text-xl font-bold text-white mt-1">Clique PoA / QBFT</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">2.0s Block Target · 30M Gas</div>
            </div>

            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
              <div className="text-xs text-slate-400 font-mono">Active Settlement Assets</div>
              <div className="text-xl font-bold text-white mt-1">4 Documented Tokens</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">YAGYX · YGO · YINR · YUSD</div>
            </div>

            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
              <div className="text-xs text-slate-400 font-mono">Recorded Payments in Ledger</div>
              <div className="text-xl font-bold font-mono text-cyan-400 mt-1">{ledgerOrders.length} Orders</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                {ledgerOrders.filter((o) => o.state === 'MEMBERSHIP_ACTIVE').length} Confirmed Activations
              </div>
            </div>
          </div>

          {/* Three Architectural Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="p-6 rounded-xl border border-slate-800/80 bg-slate-900/30 space-y-3">
              <div className="h-9 w-9 rounded-lg bg-cyan-950/60 border border-cyan-800/40 flex items-center justify-center text-cyan-400">
                <Cpu className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Decentralized Compute Broker</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Settles high-performance device compute jobs with mathematical precision. Enforces a transparent 1% platform fee with 99% direct node settlement.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-slate-800/80 bg-slate-900/30 space-y-3">
              <div className="h-9 w-9 rounded-lg bg-violet-950/60 border border-violet-800/40 flex items-center justify-center text-violet-400">
                <Shield className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Strict Non-Custodial Security</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Zero private keys or mnemonics are stored or requested. Transactions require client-side EIP-1193 signature confirmation with replay protection.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-slate-800/80 bg-slate-900/30 space-y-3">
              <div className="h-9 w-9 rounded-lg bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center text-emerald-400">
                <Lock className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Permanent Authority Governance</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Anchored to the declared Batwal Co-Ownership Triumvirate. Immutable anti-lockout protection guarantees architectural integrity across all upgrades.
              </p>
            </div>
          </div>

          {/* Wallet Integration Status */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Browser Web3 Connection</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Inspects active provider, current chain ID, and account balance.
                </p>
              </div>

              <div className="text-xs font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-800/40 px-3 py-1 rounded">
                EIP-1193 Standard
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <div className="text-slate-500">Provider Status</div>
                <div className="text-white font-medium mt-1">
                  {walletState.isInstalled ? 'EIP-1193 Detected' : 'No Web3 Extension'}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <div className="text-slate-500">Active Account</div>
                <div className="text-white font-medium mt-1 truncate">
                  {walletState.address || 'Disconnected'}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <div className="text-slate-500">Active Chain ID</div>
                <div className="text-white font-medium mt-1">
                  {walletState.chainId ? `${walletState.chainId} (Hex: 0x${walletState.chainId.toString(16)})` : 'None'}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <div className="text-slate-500">Observed Balance</div>
                <div className="text-cyan-400 font-medium mt-1">
                  {walletState.balance !== null ? `${walletState.balance} YAGYX` : '—'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: NETWORK TELEMETRY & NODE HEALTH
          ========================================================================= */}
      {activeTab === 'network' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white">Live Node Telemetry & Endpoint Probe</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct round-trip latency and JSON-RPC query inspection. No simulated success flags.
                </p>
              </div>

              <button
                type="button"
                onClick={() => runRpcProbe()}
                disabled={isProbingRpc}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${isProbingRpc ? 'animate-spin' : ''}`} />
                <span>{isProbingRpc ? 'Testing Endpoint...' : 'Re-Probe Endpoint'}</span>
              </button>
            </div>

            {/* Probe Result Card */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-1">
                <div className="text-xs text-slate-400 font-mono">RPC Target URL</div>
                <div className="text-sm font-bold font-mono text-white truncate mt-1">
                  {probeResult?.targetUrl || 'https://rpc.yagyx.network'}
                </div>
                <div className="text-[11px] text-slate-500">Configured default EVM gateway</div>
              </div>

              <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-1">
                <div className="text-xs text-slate-400 font-mono">Response Latency</div>
                <div className="text-sm font-bold font-mono text-cyan-400 mt-1">
                  {probeResult ? `${probeResult.latencyMs} ms` : '—'}
                </div>
                <div className="text-[11px] text-slate-500">Round-trip connection time</div>
              </div>

              <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-1">
                <div className="text-xs text-slate-400 font-mono">Network Health Classification</div>
                <div className="text-sm font-bold font-mono text-amber-300 mt-1">
                  {probeResult?.status || 'AWAITING PROBE'}
                </div>
                <div className="text-[11px] text-slate-500 truncate">{probeResult?.message || 'Probing...'}</div>
              </div>
            </div>

            {/* Diagnostic Details */}
            {probeResult && probeResult.status === 'OFFLINE' && (
              <div className="p-4 rounded-xl border border-amber-800/50 bg-amber-950/20 text-xs space-y-2">
                <div className="flex items-center gap-2 font-semibold text-amber-300">
                  <AlertCircle className="h-4 w-4" />
                  <span>Public Node Dependency Awaiting Routing</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  The hostname <code className="text-amber-200 font-mono">rpc.yagyx.network</code> is currently not routed in public DNS (<code className="text-amber-200 font-mono">getaddrinfo ENOTFOUND</code>). To connect to a live node, developers can start a local Geth/Besu instance or specify a custom RPC below.
                </p>
                <div className="text-slate-400 font-mono text-[11px]">
                  Diagnostic Detail: {probeResult.error || 'Connection failed'}
                </div>
              </div>
            )}

            {/* Custom RPC Override Tester */}
            <div className="pt-2 space-y-2">
              <label className="text-xs font-medium text-slate-300">Test Custom JSON-RPC Endpoint:</label>
              <div className="flex flex-col sm:flex-row gap-2 max-w-xl">
                <input
                  type="text"
                  placeholder="http://localhost:8545 or https://your-rpc-node.example"
                  value={customRpcUrl}
                  onChange={(e) => setCustomRpcUrl(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="button"
                  onClick={() => runRpcProbe(customRpcUrl)}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-slate-200 hover:bg-white rounded transition-colors cursor-pointer shrink-0"
                >
                  Test Custom Endpoint
                </button>
              </div>
            </div>
          </div>

          {/* Consensus & Protocol Specifications */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Consensus & Block Specifications</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Consensus Engine</span>
                <div className="text-white font-semibold mt-1">Clique Proof-of-Authority (PoA)</div>
                <div className="text-slate-400 text-[11px] mt-0.5">QBFT compatible for enterprise fault tolerance</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Block Time Target</span>
                <div className="text-white font-semibold mt-1">2.0 Seconds</div>
                <div className="text-slate-400 text-[11px] mt-0.5">Deterministic block cadence for AI agents</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Block Gas Limit</span>
                <div className="text-white font-semibold mt-1">30,000,000 Gas</div>
                <div className="text-slate-400 text-[11px] mt-0.5">Matches Ethereum mainnet throughput</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Signer Authority Triumvirate</span>
                <div className="text-white font-semibold mt-1">3 Declared Co-Owners</div>
                <div className="text-slate-400 text-[11px] mt-0.5">M-of-N multi-signature threshold</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Official Vault Recipient</span>
                <div className="text-white font-semibold mt-1 truncate">0x71C836376510343a...00013370</div>
                <div className="text-slate-400 text-[11px] mt-0.5">Central escrow & settlement address</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-slate-500">Base Currency Decimals</span>
                <div className="text-white font-semibold mt-1">18 Decimals (Wei standard)</div>
                <div className="text-slate-400 text-[11px] mt-0.5">Micro-unit integer pre-multiplication</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: BLOCK & LEDGER EXPLORER
          ========================================================================= */}
      {activeTab === 'explorer' && (
        <div className="space-y-6">
          {/* Search & Filter Header */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white">YAGYX Block & Payment Ledger Explorer</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Browse recorded payments, transaction hashes, state transitions, and genesis parameters.
                </p>
              </div>

              <div className="text-xs font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-800/40 px-3 py-1 rounded">
                Authoritative Payments Ledger ({ledgerOrders.length} records)
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="h-4 w-4 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search by Order ID, Transaction Hash (0x...), or Address..."
                  value={explorerSearch}
                  onChange={(e) => setExplorerSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
                {(['ALL', 'YAGYX', 'YGO', 'YINR', 'YUSD'] as const).map((ast) => (
                  <button
                    key={ast}
                    type="button"
                    onClick={() => setAssetFilter(ast)}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                      assetFilter === ast
                        ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {ast}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {ledgerOwnerAuthRequired && (
            <div className="rounded-xl border border-amber-700/50 bg-amber-950/20 px-4 py-3 text-xs text-amber-200">
              Transaction-level details are restricted to authenticated project owners. Public aggregates remain available; sign in through the Project Export panel to view order IDs, addresses, and transaction records.
            </div>
          )}

          {/* Transactions Table */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Order / Tx ID</th>
                    <th className="py-3 px-4">Asset</th>
                    <th className="py-3 px-4">Required Base Units (18 dec)</th>
                    <th className="py-3 px-4">State</th>
                    <th className="py-3 px-4">Transaction Hash</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                  {loadingLedger ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        Loading ledger transactions...
                      </td>
                    </tr>
                  ) : filteredOrders.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        {ledgerOwnerAuthRequired ? 'Owner sign-in is required to display transaction details.' : 'No transactions found matching your search.'}
                      </td>
                    </tr>
                  ) : (
                    filteredOrders.map((ord) => {
                      const isConfirmed = ord.state === 'MEMBERSHIP_ACTIVE' || ord.state === 'PAYMENT_VERIFIED';
                      return (
                        <tr key={ord.orderId} className="hover:bg-slate-900/50 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-white">{ord.orderId}</div>
                            <div className="text-[10px] text-slate-500">
                              {new Date(ord.createdAt).toLocaleTimeString()} · {ord.region}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-cyan-300">{ord.selectedAsset}</span>
                            <span className="text-slate-500 text-[10px] ml-1">
                              ({ord.humanAmountRequired} {ord.selectedAsset})
                            </span>
                          </td>
                          <td className="py-3 px-4 text-[11px] text-slate-400 truncate max-w-xs" title={ord.baseUnitsRequired}>
                            {ord.baseUnitsRequired}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                                isConfirmed
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                                  : ord.state === 'PAYMENT_FAILED'
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800/60'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800/60'
                              }`}
                            >
                              {ord.state}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-[11px] text-slate-400 font-mono">
                            {ord.txHash ? (
                              <span className="text-slate-300 truncate block max-w-[140px]" title={ord.txHash}>
                                {ord.txHash.slice(0, 10)}...{ord.txHash.slice(-6)}
                              </span>
                            ) : (
                              <span className="text-slate-600 italic">Awaiting submission</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => setSelectedTx(ord)}
                              className="px-2.5 py-1 text-[11px] text-cyan-400 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-800/50 rounded transition-colors cursor-pointer"
                            >
                              Inspect
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Transaction Detail Inspector Modal */}
          {selectedTx && (
            <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
              <div className="w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-950 p-6 space-y-4 shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-base font-bold text-white font-mono">
                    Transaction & Order Detail: {selectedTx.orderId}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setSelectedTx(null)}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-slate-500">Transaction Hash</span>
                    <div className="text-cyan-400 break-all select-all mt-1">
                      {selectedTx.txHash || 'None recorded yet'}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-slate-500">Lifecycle State</span>
                      <div className="text-white font-bold mt-1">{selectedTx.state}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-slate-500">Chain ID Target</span>
                      <div className="text-white font-bold mt-1">{selectedTx.chainId} (YAGYX)</div>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-slate-500">Base Units Required (18 Decimals)</span>
                    <div className="text-amber-300 font-bold break-all mt-1">{selectedTx.baseUnitsRequired}</div>
                    <div className="text-slate-400 text-[11px] mt-0.5">
                      Human Value: {selectedTx.humanAmountRequired} {selectedTx.selectedAsset}
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-slate-500">Recipient Vault Address</span>
                    <div className="text-white break-all mt-1">{selectedTx.expectedRecipient}</div>
                  </div>

                  {selectedTx.senderAddress && (
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-slate-500">Sender Address</span>
                      <div className="text-white break-all mt-1">{selectedTx.senderAddress}</div>
                    </div>
                  )}

                  <div className="flex justify-between text-slate-500 text-[11px] pt-2">
                    <span>Created: {selectedTx.createdAt}</span>
                    <span>Updated: {selectedTx.updatedAt}</span>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setSelectedTx(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-950 bg-slate-200 hover:bg-white rounded transition-colors cursor-pointer"
                  >
                    Close Inspector
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 4: DEVELOPER PORTAL & QUICKSTART
          ========================================================================= */}
      {activeTab === 'developers' && (
        <div className="space-y-6">
          {/* Network Parameters Cheat Sheet */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-lg font-bold text-white">YAGYX Network Parameters</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Universal configuration reference for wallets, SDKs, and RPC clients.
                </p>
              </div>

              <button
                type="button"
                onClick={handleSwitchToYagyx}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer"
              >
                <Wallet className="h-4 w-4" />
                <span>Add YAGYX Chain to MetaMask (EIP-1193)</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Network Name</span>
                <div className="text-white font-semibold mt-1">YAGYX Chain</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Chain ID (Decimal / Hex)</span>
                <div className="text-cyan-400 font-semibold mt-1">13370 / 0x343a</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">RPC Gateway URL</span>
                <div className="text-white font-semibold mt-1 truncate">https://rpc.yagyx.network</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Native Token Symbol</span>
                <div className="text-amber-300 font-semibold mt-1">YAGYX (18 Decimals)</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">WebSocket RPC URL</span>
                <div className="text-white font-semibold mt-1 truncate">wss://rpc.yagyx.network</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500">Block Explorer Gateway</span>
                <div className="text-white font-semibold mt-1 truncate">https://explorer.yagyx.network</div>
              </div>
            </div>
          </div>

          {/* Integration Code Snippets with Tab Switcher */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">SDK & Tooling Configuration Snippets</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Copy-paste configuration presets for Viem, Wagmi, Ethers.js, Hardhat, Foundry, and Web3.py.
                </p>
              </div>

              <button
                type="button"
                onClick={() => copySnippet(snippets[activeSnippetTab])}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-800/50 rounded transition-colors cursor-pointer"
              >
                {copiedSnippet ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedSnippet ? 'Copied' : 'Copy Snippet'}</span>
              </button>
            </div>

            {/* Segmented snippet selector */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'viem', label: 'viem / wagmi' },
                { id: 'ethers', label: 'ethers.js v6' },
                { id: 'hardhat', label: 'Hardhat' },
                { id: 'foundry', label: 'Foundry' },
                { id: 'web3py', label: 'Python web3.py' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setActiveSnippetTab(s.id as any)}
                  className={`px-3 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
                    activeSnippetTab === s.id
                      ? 'bg-slate-800 text-white font-semibold border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            <pre className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-mono text-cyan-300 overflow-x-auto leading-relaxed select-all">
              {snippets[activeSnippetTab]}
            </pre>
          </div>

          {/* Interactive JSON-RPC Console */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Interactive JSON-RPC Sandbox</h3>
            <p className="text-xs text-slate-400">
              Execute live EVM RPC calls against the configured gateway or custom node endpoint.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-mono">Method:</label>
                <select
                  value={rpcMethod}
                  onChange={(e) => setRpcMethod(e.target.value as any)}
                  className="px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="eth_chainId">eth_chainId (Returns Chain ID)</option>
                  <option value="eth_blockNumber">eth_blockNumber (Returns Block Height)</option>
                  <option value="net_version">net_version (Network ID)</option>
                  <option value="web3_clientVersion">web3_clientVersion (Client Software)</option>
                  <option value="eth_gasPrice">eth_gasPrice (Current Gas Price)</option>
                </select>
              </div>

              <div className="pt-5">
                <button
                  type="button"
                  onClick={handleExecuteRpcConsole}
                  disabled={rpcConsoleLoading}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Terminal className="h-3.5 w-3.5" />
                  <span>{rpcConsoleLoading ? 'Executing...' : 'Send Request'}</span>
                </button>
              </div>
            </div>

            {rpcConsoleResponse && (
              <pre className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed">
                {rpcConsoleResponse}
              </pre>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 5: ECOSYSTEM ASSETS & INTEGER CALCULATOR
          ========================================================================= */}
      {activeTab === 'assets' && (
        <div className="space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">YAGYX Ecosystem Assets Specification</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Transparent specifications for native gas and secondary token standards under Chain ID 13370.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* YAGYX */}
            <div className="p-6 rounded-xl border border-cyan-500/20 bg-slate-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-cyan-400">NATIVE PROTOCOL ASSET</span>
                <span className="text-[11px] font-mono text-slate-400">18 Decimals</span>
              </div>
              <h3 className="text-xl font-bold text-white">YAGYX (Native Gas)</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Primary gas and platform execution token. Used for paying transaction fees, provisioning decentralized compute contracts, and executing AI agent workflows.
              </p>
              <div className="pt-2 border-t border-slate-800/80 text-xs font-mono text-slate-400 space-y-1">
                <div>Contract Address: <span className="text-slate-200">Native EVM Currency (None)</span></div>
                <div>Configured Starting Reference: <span className="text-cyan-400">₹100 INR / $1.18 USD</span></div>
              </div>
            </div>

            {/* YGO */}
            <div className="p-6 rounded-xl border border-amber-500/20 bg-slate-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-amber-300">GOVERNANCE & REWARDS</span>
                <span className="text-[11px] font-mono text-slate-400">18 Decimals</span>
              </div>
              <h3 className="text-xl font-bold text-white">YGO (Governance Token)</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Ecosystem voting, evolution proposals, and contributor bounty rewards token. First-priority token for FUTUREVERSE platform membership.
              </p>
              <div className="pt-2 border-t border-slate-800/80 text-xs font-mono text-slate-400 space-y-1">
                <div className="truncate">Address: <span className="text-slate-200">0x1000000000000000000000000000000000001337</span></div>
                <div>Configured Starting Reference: <span className="text-amber-300">₹1 INR / $0.0118 USD</span></div>
              </div>
            </div>

            {/* YINR */}
            <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-400">REGIONAL STABLE ASSET</span>
                <span className="text-[11px] font-mono text-slate-400">18 Decimals</span>
              </div>
              <h3 className="text-xl font-bold text-white">YINR (Indian Rupee Peg)</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Regional settlement medium designed to track the Indian Rupee (₹1 INR peg target).
              </p>
              <div className="p-2.5 rounded bg-amber-950/30 border border-amber-800/40 text-[11px] text-amber-300">
                Honest Disclosure: Reserve auditing & proof-of-reserve smart contract pending prior to open market trading.
              </div>
              <div className="pt-2 border-t border-slate-800/80 text-xs font-mono text-slate-400 space-y-1">
                <div className="truncate">Address: <span className="text-slate-200">0x2000000000000000000000000000000000001337</span></div>
                <div>Peg Target: <span className="text-white">₹1.00 INR</span></div>
              </div>
            </div>

            {/* YUSD */}
            <div className="p-6 rounded-xl border border-slate-800 bg-slate-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-400">GLOBAL STABLE ASSET</span>
                <span className="text-[11px] font-mono text-slate-400">18 Decimals</span>
              </div>
              <h3 className="text-xl font-bold text-white">YUSD (US Dollar Peg)</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Global settlement medium designed to track the US Dollar ($1 USD peg target).
              </p>
              <div className="p-2.5 rounded bg-amber-950/30 border border-amber-800/40 text-[11px] text-amber-300">
                Honest Disclosure: Reserve auditing & proof-of-reserve smart contract pending prior to open market trading.
              </div>
              <div className="pt-2 border-t border-slate-800/80 text-xs font-mono text-slate-400 space-y-1">
                <div className="truncate">Address: <span className="text-slate-200">0x3000000000000000000000000000000000001337</span></div>
                <div>Peg Target: <span className="text-white">$1.00 USD</span></div>
              </div>
            </div>
          </div>

          {/* Interactive Base-Unit Integer Calculator */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Base-Unit Integer Calculator (Zero Floating-Point Drift)</h3>
            <p className="text-xs text-slate-400">
              Demonstrates exact integer base-unit conversions with micro-unit pre-multiplication (<code className="text-cyan-400 font-mono">10^18</code> integer math).
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-mono">Human Token Amount:</label>
                <input
                  type="number"
                  step="any"
                  value={calcAmount}
                  onChange={(e) => setCalcAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-mono">Asset Type:</label>
                <select
                  value={calcAsset}
                  onChange={(e) => setCalcAsset(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="YAGYX">YAGYX (18 Decimals)</option>
                  <option value="YGO">YGO (18 Decimals)</option>
                  <option value="YINR">YINR (18 Decimals)</option>
                  <option value="YUSD">YUSD (18 Decimals)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400 font-mono">Mathematical Precision:</label>
                <input
                  type="text"
                  disabled
                  value="100% BigInt Exact"
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900/60 border border-slate-800 text-emerald-400 font-mono"
                />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="text-xs font-mono text-slate-400">Authoritative Base Units (Wei Representation):</div>
              <div className="text-lg font-bold font-mono text-cyan-300 break-all select-all">
                {computedBaseUnits}
              </div>
              <div className="text-[11px] font-mono text-slate-500">
                Formula: BigInt(round(amount * 1,000,000)) * BigInt(10^12) = {computedBaseUnits}n
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 6: YAGYX PAY & CHECKOUT DEMO
          ========================================================================= */}
      {activeTab === 'pay' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-lg font-bold text-white">YAGYX Pay Web3 Checkout Simulator</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Experience frictionless Web3 settlement without fiat intermediaries (Zero Stripe, Zero Razorpay).
                </p>
              </div>

              <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded">
                Non-Custodial Flow
              </div>
            </div>

            <form onSubmit={handleRunCheckoutDemo} className="space-y-4 max-w-2xl">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium">Pricing Region:</label>
                  <select
                    value={checkoutRegion}
                    onChange={(e) => setCheckoutRegion(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                  >
                    <option value="India">India (₹100 / mo)</option>
                    <option value="Global">Global ($1.00 USD / mo)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium">Payment Asset:</label>
                  <select
                    value={checkoutAsset}
                    onChange={(e) => setCheckoutAsset(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                  >
                    <option value="YGO">YGO (₹1 ref - 100 YGO for India)</option>
                    <option value="YAGYX">YAGYX (₹100 ref - 1 YAGYX for India)</option>
                    <option value="YINR">YINR (Target ₹1 - 100 YINR for India)</option>
                    <option value="YUSD">YUSD (Target $1 - 1 YUSD for Global)</option>
                  </select>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-2">
                <div className="flex justify-between text-slate-400 font-mono">
                  <span>Destination Vault Address:</span>
                  <span className="text-slate-200">0x71C836376510343a000000000000000000013370</span>
                </div>
                <div className="flex justify-between text-slate-400 font-mono">
                  <span>Target Chain ID:</span>
                  <span className="text-cyan-400">13370 (0x343a)</span>
                </div>
                <div className="flex justify-between text-slate-400 font-mono">
                  <span>Platform Gateway Fee:</span>
                  <span className="text-emerald-400">₹0 / $0 (Zero Hidden Subscriptions)</span>
                </div>
              </div>

              {checkoutMessage && (
                <div
                  className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                    checkoutState === 'CONFIRMED'
                      ? 'bg-emerald-950/40 border border-emerald-800/60 text-emerald-300'
                      : 'bg-rose-950/40 border border-rose-800/60 text-rose-300'
                  }`}
                >
                  {checkoutState === 'CONFIRMED' ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
                  )}
                  <span>{checkoutMessage}</span>
                </div>
              )}

              {checkoutTxHash && (
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                  <span className="text-slate-400">Verified Simulated Tx Hash: </span>
                  <span className="text-cyan-300 select-all break-all">{checkoutTxHash}</span>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={checkoutState === 'PROCESSING'}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>{checkoutState === 'PROCESSING' ? 'Verifying with Ledger...' : 'Execute YAGYX Pay Checkout'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 7: SECURITY & FORENSIC AUDIT
          ========================================================================= */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white">YAGYX Security Findings & Invariant Audit</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Continuous vulnerability assessment with verified status and zero fabricated proof invariants.
                </p>
              </div>

              <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded">
                Non-Custodial Invariants Clean
              </div>
            </div>

            <div className="space-y-4">
              {securityReport?.findings.map((f) => (
                <div key={f.id} className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-mono text-xs">
                      <span className="font-bold text-white">{f.id}</span>
                      <span className="text-slate-600">·</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          f.severity === 'MEDIUM'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800/60'
                            : f.severity === 'LOW'
                            ? 'bg-blue-950 text-blue-300 border border-blue-800/60'
                            : 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                        }`}
                      >
                        {f.severity}
                      </span>
                      <span className="text-slate-500 font-sans">{f.category}</span>
                    </div>

                    <span className="text-xs font-mono text-cyan-400">{f.status}</span>
                  </div>

                  <h3 className="text-sm font-bold text-white">{f.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{f.remediation}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 8: ARCHIVE & BACKUP DOWNLOAD
          ========================================================================= */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <FileArchive className="h-5 w-5 text-cyan-400" />
                  <h2 className="text-lg font-bold text-white tracking-tight">
                    Official YAGYX Chain Preservation Archive
                  </h2>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                  Cryptographically verified preservation bundle containing full forensic reports, chain configurations, website specifications, security findings, cryptographic manifests, and complete source code.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleDownloadBackup('stream')}
                  disabled={isDownloading}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer shadow disabled:opacity-50"
                >
                  <Download className={`h-4 w-4 ${isDownloading ? 'animate-bounce' : ''}`} />
                  <span>{isDownloading ? 'Downloading...' : 'Direct Stream Download'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadBackup('base64')}
                  disabled={isDownloading}
                  className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                  title="Use in-app Base64 reconstitution if your proxy blocks direct binary downloads (HTTP 403 prevention)"
                >
                  <span>Proxy-Safe (Base64)</span>
                </button>
              </div>
            </div>

            {/* Verification Checksums & Metadata */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
                <div className="text-slate-400 font-mono text-[11px]">Archive Filename</div>
                <div className="text-white font-mono font-medium mt-1 truncate">YAGYX_CHAIN_PROJECT_BACKUP.zip</div>
                <div className="text-slate-500 text-[11px] mt-0.5">3,447,766 bytes (~3.45 MB)</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 md:col-span-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-mono text-[11px]">SHA-256 Checksum</span>
                  <button
                    type="button"
                    onClick={copyChecksum}
                    className="inline-flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer font-mono"
                  >
                    {copiedHash ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                  </button>
                </div>
                <div className="text-cyan-300 font-mono text-[11px] mt-1 break-all select-all">
                  {archiveSha256}
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  Cryptographically verified against in-archive manifest
                </div>
              </div>
            </div>

            {/* Status Messages */}
            {downloadSuccessMessage && (
              <div className="p-3 rounded-lg border border-emerald-800/60 bg-emerald-950/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                <span>{downloadSuccessMessage}</span>
              </div>
            )}

            {downloadError && (
              <div className="p-3 rounded-lg border border-rose-800/60 bg-rose-950/40 text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
                <span>{downloadError}</span>
              </div>
            )}

            {/* Included Documentation Summary */}
            <div className="pt-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                  Archived Key Reports & Blueprints (67 Total Files):
                </span>
                <button
                  type="button"
                  onClick={() => setShowInventoryModal(true)}
                  className="text-[11px] text-cyan-400 hover:text-cyan-300 font-mono cursor-pointer"
                >
                  View Full File Inventory
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[11px]">
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">1.</span> YAGYX_CHAIN_FORENSIC_REPORT.md
                </div>
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">2.</span> YAGYX_CHAIN_CONFIGURATION_REFERENCE.md
                </div>
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">3.</span> YAGYX_CHAIN_SECURITY_FINDINGS.md
                </div>
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">4.</span> YAGYX_CHAIN_WEBSITE_REQUIREMENTS.md
                </div>
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">5.</span> YAGYX_CHAIN_BACKUP_MANIFEST.json
                </div>
                <div className="p-2.5 rounded bg-slate-900/40 border border-slate-800 text-slate-300">
                  <span className="text-cyan-400 font-mono">6.</span> YAGYX_CHAIN_FILE_INVENTORY.json
                </div>
              </div>
            </div>
          </div>

          {/* Full Inventory Modal */}
          {showInventoryModal && (
            <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
              <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-2xl border border-slate-700 bg-slate-950 p-6 shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-base font-bold text-white font-mono">
                    Preservation Archive Inventory (67 Files)
                  </h3>
                  <button
                    type="button"
                    onClick={() => setShowInventoryModal(false)}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto space-y-2 py-4 text-xs font-mono text-slate-300">
                  <div className="text-cyan-400 font-semibold mb-2">Core Specifications & Reports:</div>
                  <ul className="list-disc pl-5 space-y-1 text-slate-400">
                    <li>YAGYX_CHAIN_FORENSIC_REPORT.md (7,888 B)</li>
                    <li>YAGYX_CHAIN_CONFIGURATION_REFERENCE.md (6,070 B)</li>
                    <li>YAGYX_CHAIN_SECURITY_FINDINGS.md (5,308 B)</li>
                    <li>YAGYX_CHAIN_WEBSITE_REQUIREMENTS.md (5,431 B)</li>
                    <li>YAGYX_CHAIN_BACKUP_MANIFEST.json (11,209 B)</li>
                    <li>YAGYX_CHAIN_FILE_INVENTORY.json (14,687 B)</li>
                  </ul>

                  <div className="text-cyan-400 font-semibold mt-4 mb-2">Application & Engine Codebase:</div>
                  <ul className="list-disc pl-5 space-y-1 text-slate-400">
                    <li>server.ts & test suites</li>
                    <li>src/services/web3.ts (EIP-1193 Web3 Client)</li>
                    <li>src/server/yagyxPaymentService.ts (On-Chain Verification Service)</li>
                    <li>src/components/YagyxHubView.tsx (Official Website Portal)</li>
                    <li>All 13 data/*.json registries</li>
                  </ul>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowInventoryModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-950 bg-slate-200 hover:bg-white rounded transition-colors cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
