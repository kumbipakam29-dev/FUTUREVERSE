import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type { OwnershipRegistry, PermanentAuthorityProfile, AuditLogEvent } from '../types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const AUTHORITY_FILE = path.join(DATA_DIR, 'ownership_authority.json');

export const CANONICAL_OWNERSHIP_REGISTRY: OwnershipRegistry = {
  owner: 'Dhaval Chandrashekhar Batwal',
  coOwner: 'Hemangini Chandrashekhar Batwal',
  coOperationalOwner: 'Jayshriben Chandrashekhar Batwal',
  ownerEmail: 'aibabayaga0@gmail.com',
};

const DEFAULT_PERMANENT_AUTHORITY: PermanentAuthorityProfile = {
  userId: 'usr-dhaval-canonical-001',
  canonicalName: 'Dhaval Chandrashekhar Batwal',
  email: 'aibabayaga0@gmail.com',
  currentDesignation: 'Owner',
  protectedAuthority: true,
  effectivePermissions: [
    'PERMANENT_SUPREME_AUTHORITY',
    'PLATFORM_GLOBAL_ADMINISTRATION',
    'COMMISSION_POLICY_OVERSIGHT',
    'SECURITY_CORE_OVERRIDE',
    'YAGYX_CHAIN_INTEGRATION_MANAGEMENT',
    'EMERGENCY_ANTI_LOCKOUT_RECOVERY',
    'DAY_30_CORE_REVEAL_GATEKEEPER',
    'MODEL_AND_AGENT_PRODUCTION_RELEASE_APPROVAL',
  ],
  antiLockoutActive: true,
  designationHistory: [
    {
      previousDesignation: 'Founder',
      newDesignation: 'Owner',
      changedAt: '2026-10-01T00:00:00Z',
      actor: 'Dhaval Chandrashekhar Batwal',
      antiLockoutPreserved: true,
    },
  ],
};

type CanonicalOwnerRole = 'OWNER' | 'CO_OWNER' | 'CO_OPERATIONAL_OWNER';

interface CanonicalOwnerIdentity {
  canonicalName: string;
  userId: string;
  role: CanonicalOwnerRole;
  secretEnvName: 'FUTUREVERSE_OWNER_KEY' | 'FUTUREVERSE_CO_OWNER_KEY' | 'FUTUREVERSE_COOP_OWNER_KEY';
}

interface ActiveOwnerSession {
  token: string;
  actor: string;
  userId: string;
  role: CanonicalOwnerRole;
  createdAt: number;
  expiresAt: number;
}

interface SingleUseDownloadNonce {
  nonce: string;
  actor: string;
  userId: string;
  expiresAt: number;
}

export class AuthorityService {
  private registry: OwnershipRegistry;
  private dhavalProfile: PermanentAuthorityProfile;
  private auditLogs: AuditLogEvent[] = [];
  private activeSessions: Map<string, ActiveOwnerSession> = new Map();
  private singleUseDownloadNonces: Map<string, SingleUseDownloadNonce> = new Map();

  constructor() {
    const loaded = this.loadState();
    this.registry = loaded.registry;
    this.dhavalProfile = loaded.dhavalProfile;
    this.auditLogs = loaded.auditLogs;
  }

  /** All owner sign-ins require a server-configured credential; no identity is exempt. */
  public isOwnerSecretRequired(_actorNameOrId?: string): boolean {
    return true;
  }

  private loadState() {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      if (fs.existsSync(AUTHORITY_FILE)) {
        const raw = fs.readFileSync(AUTHORITY_FILE, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('Could not read authority file, using canonical defaults:', err);
    }
    const init = {
      registry: CANONICAL_OWNERSHIP_REGISTRY,
      dhavalProfile: DEFAULT_PERMANENT_AUTHORITY,
      auditLogs: [
        {
          id: `aud-auth-001`,
          timestamp: '2026-10-01T00:00:00Z',
          actor: 'Dhaval Chandrashekhar Batwal',
          action: 'PERMANENT_AUTHORITY_INITIALIZED',
          target: 'FUTUREVERSE Governance Registry',
          details: 'Supreme administrative permissions and anti-lockout protection locked to canonical identity.',
          outcome: 'SUCCESS' as const,
        },
      ],
    };
    this.saveDirect(init);
    return init;
  }

  private saveDirect(data: any): void {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(AUTHORITY_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to save authority state:', err);
    }
  }

  public save(): void {
    this.saveDirect({
      registry: this.registry,
      dhavalProfile: this.dhavalProfile,
      auditLogs: this.auditLogs,
    });
  }

  public getRegistry(): OwnershipRegistry {
    return this.registry;
  }

  public getOwnership(): OwnershipRegistry {
    return this.registry;
  }

  public getDhavalProfile(): PermanentAuthorityProfile {
    return this.dhavalProfile;
  }

  public getAuditLogs(limit?: number): AuditLogEvent[] {
    if (limit && limit > 0) return this.auditLogs.slice(0, limit);
    return this.auditLogs;
  }

  /**
   * Section 17.2: Dhaval's Designation & Protected Authority Separation
   * Allowed display designations: 'Owner', 'Super Admin', 'Director', 'Founder', 'Chairman', 'Chief Architect'
   * Changing displayed designation MUST NOT alter or revoke underlying protected effective permissions.
   */
  public updateDesignation(
    actorName: string,
    newDesignation: string
  ): { success: boolean; message: string; profile?: PermanentAuthorityProfile } {
    // 1. Strict verification: Only Dhaval's verified identity can change this designation
    const identity = this.resolveCanonicalOwner(actorName);
    const isDhaval = identity?.role === 'OWNER';

    if (!isDhaval) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorName,
        action: 'UNAUTHORIZED_DESIGNATION_CHANGE_ATTEMPT',
        target: 'Permanent Authority Profile',
        details: `Actor "${actorName}" attempted to modify Dhaval Chandrashekhar Batwal designation to "${newDesignation}". Access blocked.`,
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        message: 'Security Violation: Only Dhaval Chandrashekhar Batwal can update this designation.',
      };
    }

    const ALLOWED_LABELS = ['Owner', 'Super Admin', 'Director', 'Founder', 'Chairman', 'Chief Architect'];
    if (!ALLOWED_LABELS.includes(newDesignation)) {
      return {
        success: false,
        message: `Invalid designation label. Allowed: ${ALLOWED_LABELS.join(', ')}.`,
      };
    }

    const prev = this.dhavalProfile.currentDesignation;
    this.dhavalProfile.currentDesignation = newDesignation;

    // Enforce invariant: Effective permissions and anti-lockout CANNOT be diminished!
    this.dhavalProfile.protectedAuthority = true;
    this.dhavalProfile.antiLockoutActive = true;

    this.dhavalProfile.designationHistory.unshift({
      previousDesignation: prev,
      newDesignation,
      changedAt: new Date().toISOString(),
      actor: 'Dhaval Chandrashekhar Batwal',
      antiLockoutPreserved: true,
    });

    const successEvent: AuditLogEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: 'Dhaval Chandrashekhar Batwal',
      action: 'DESIGNATION_UPDATED',
      target: 'Dhaval Chandrashekhar Batwal Profile',
      details: `Display designation updated from "${prev}" to "${newDesignation}". Effective permissions and anti-lockout permanently preserved.`,
      outcome: 'SUCCESS',
    };
    this.auditLogs.unshift(successEvent);
    this.save();

    return {
      success: true,
      message: `Designation updated to "${newDesignation}". Protected authority and anti-lockout remain fully active.`,
      profile: this.dhavalProfile,
    };
  }

  /** Resolve only exact, known owner identifiers. Substring identity matches are never accepted. */
  private resolveCanonicalOwner(actorNameOrId?: string): CanonicalOwnerIdentity | null {
    if (!actorNameOrId || typeof actorNameOrId !== 'string') return null;
    const clean = actorNameOrId.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ');
    if (!clean) return null;

    const dhavalAliases = new Set([
      'dhaval chandrashekhar batwal',
      'usr-dhaval-canonical',
      'usr-dhaval-canonical-001',
      'aibabayaga0',
      'aibabayaga0@gmail.com',
    ]);
    const hemanginiAliases = new Set([
      CANONICAL_OWNERSHIP_REGISTRY.coOwner.toLowerCase(),
      'hemangini chandrashekhar batwal',
      'hemangini chandraswkhar batwal', // legacy variant without the inserted h
      'hemangini chandrashwkhar batwal', // exact spelling preserved in historical registry/audit records
      'usr-hemangini-canonical-002',
    ]);
    const jayshribenAliases = new Set([
      'jayshriben chandrashekhar batwal',
      'usr-jayshriben-canonical-003',
    ]);

    if (dhavalAliases.has(clean)) {
      return {
        canonicalName: 'Dhaval Chandrashekhar Batwal',
        userId: 'usr-dhaval-canonical-001',
        role: 'OWNER',
        secretEnvName: 'FUTUREVERSE_OWNER_KEY',
      };
    }
    if (hemanginiAliases.has(clean)) {
      return {
        canonicalName: CANONICAL_OWNERSHIP_REGISTRY.coOwner,
        userId: 'usr-hemangini-canonical-002',
        role: 'CO_OWNER',
        secretEnvName: 'FUTUREVERSE_CO_OWNER_KEY',
      };
    }
    if (jayshribenAliases.has(clean)) {
      return {
        canonicalName: 'Jayshriben Chandrashekhar Batwal',
        userId: 'usr-jayshriben-canonical-003',
        role: 'CO_OPERATIONAL_OWNER',
        secretEnvName: 'FUTUREVERSE_COOP_OWNER_KEY',
      };
    }
    return null;
  }

  public isCanonicalOwner(actorNameOrId?: string): boolean {
    return this.resolveCanonicalOwner(actorNameOrId) !== null;
  }

  /** Authenticates an exact canonical identity using that person's server-side secret. */
  public authenticateOwner(
    actorNameOrId: string,
    providedKey?: string
  ): { success: boolean; sessionToken?: string; actor?: string; userId?: string; role?: CanonicalOwnerRole; error?: string } {
    const identity = this.resolveCanonicalOwner(actorNameOrId);
    if (!identity) {
      this.recordAuditLog(
        typeof actorNameOrId === 'string' ? actorNameOrId.slice(0, 120) : 'Anonymous / Guest',
        'UNAUTHORIZED_OWNER_AUTH_ATTEMPT',
        'Owner Sign-in',
        'Access denied because the submitted identifier is not an exact registered owner identifier.',
        'BLOCKED',
      );
      return { success: false, error: 'Invalid owner credentials.' };
    }

    const configuredSecret = process.env[identity.secretEnvName];
    const suppliedSecret = typeof providedKey === 'string' ? providedKey : '';
    if (!configuredSecret || !suppliedSecret || configuredSecret.length < 32) {
      this.recordAuditLog(
        identity.canonicalName,
        'OWNER_AUTHENTICATION_REJECTED',
        'Owner Sign-in',
        !configuredSecret
          ? `Sign-in denied because ${identity.secretEnvName} is not configured on the server.`
          : configuredSecret.length < 32
            ? `Sign-in denied because ${identity.secretEnvName} does not meet the 32-character minimum.`
            : 'Sign-in denied because a required owner secret was not supplied.',
        'BLOCKED',
      );
      return { success: false, error: 'Owner credentials are invalid or not configured. Configure a unique server-side secret of at least 32 characters.' };
    }

    // Prevent a deployment misconfiguration from reusing one shared secret for multiple owners.
    const ownerSecretEnvNames = [
      'FUTUREVERSE_OWNER_KEY',
      'FUTUREVERSE_CO_OWNER_KEY',
      'FUTUREVERSE_COOP_OWNER_KEY',
    ] as const;
    const configuredDigest = crypto.createHash('sha256').update(configuredSecret, 'utf8').digest();
    const reusedCredential = ownerSecretEnvNames.some((envName) => {
      if (envName === identity.secretEnvName) return false;
      const otherSecret = process.env[envName];
      if (!otherSecret) return false;
      const otherDigest = crypto.createHash('sha256').update(otherSecret, 'utf8').digest();
      return crypto.timingSafeEqual(configuredDigest, otherDigest);
    });
    if (reusedCredential) {
      this.recordAuditLog(
        identity.canonicalName,
        'OWNER_AUTH_CONFIGURATION_REJECTED',
        'Owner Sign-in',
        'Sign-in denied because owner-specific credentials are not unique across the registered owner roles.',
        'BLOCKED',
      );
      return { success: false, error: 'Owner sign-in is disabled until each registered owner has a distinct server-side secret.' };
    }

    const suppliedDigest = crypto.createHash('sha256').update(suppliedSecret, 'utf8').digest();
    const expectedDigest = configuredDigest;
    const secretMatches = crypto.timingSafeEqual(suppliedDigest, expectedDigest);
    if (!secretMatches) {
      this.recordAuditLog(
        identity.canonicalName,
        'OWNER_PASSKEY_REJECTED',
        'Owner Sign-in',
        'Registered owner identifier supplied but secret verification failed.',
        'BLOCKED',
      );
      return { success: false, error: 'Invalid owner credentials.' };
    }

    const token = `fv-owner-${crypto.randomBytes(32).toString('hex')}`;
    const session: ActiveOwnerSession = {
      token,
      actor: identity.canonicalName,
      userId: identity.userId,
      role: identity.role,
      createdAt: Date.now(),
      expiresAt: Date.now() + 2 * 60 * 60 * 1000,
    };
    this.activeSessions.set(token, session);

    this.recordAuditLog(
      identity.canonicalName,
      'OWNER_SESSION_ESTABLISHED',
      'Owner Sign-in',
      `A verified ${identity.role} session was established using the configured server-side credential.`,
      'SUCCESS',
    );

    return {
      success: true,
      sessionToken: token,
      actor: identity.canonicalName,
      userId: identity.userId,
      role: identity.role,
    };
  }

  /**
   * Validates an active owner session token.
   */
  public verifyOwnerSession(token?: string): { valid: boolean; actor?: string; userId?: string; role?: CanonicalOwnerRole } {
    if (!token || !token.trim()) return { valid: false };
    const session = this.activeSessions.get(token.trim());
    if (!session) return { valid: false };
    if (Date.now() > session.expiresAt) {
      this.activeSessions.delete(token.trim());
      return { valid: false };
    }
    return { valid: true, actor: session.actor, userId: session.userId, role: session.role };
  }

  /**
   * Issues a short-lived (15-minute) single-use download nonce for direct browser file streaming.
   * STRICTLY requires a verified active owner session token. Client-supplied names or IDs are rejected.
   */
  public createSingleUseDownloadToken(sessionToken: string): { success: boolean; downloadNonce?: string; error?: string } {
    const sessionCheck = this.verifyOwnerSession(sessionToken);

    if (!sessionCheck.valid) {
      return { success: false, error: 'Unauthorized: Active authenticated owner session required.' };
    }

    const actor = sessionCheck.actor!;
    const nonce = `dl-${crypto.randomBytes(24).toString('hex')}`;
    this.singleUseDownloadNonces.set(nonce, {
      nonce,
      actor,
      userId: sessionCheck.userId || this.dhavalProfile.userId,
      expiresAt: Date.now() + 15 * 60 * 1000, // 15-minute window for download completion
    });

    return { success: true, downloadNonce: nonce };
  }

  /**
   * Validates download nonce without consuming (used for HEAD and OPTIONS pre-flight checks).
   */
  public peekDownloadNonce(nonce?: string): { valid: boolean; actor?: string } {
    if (!nonce || !nonce.trim()) return { valid: false };
    const clean = nonce.trim();
    const entry = this.singleUseDownloadNonces.get(clean);
    if (!entry) return { valid: false };
    if (Date.now() > entry.expiresAt) return { valid: false };
    return { valid: true, actor: entry.actor };
  }

  /**
   * Validates and immediately consumes a single-use download nonce.
   */
  public consumeDownloadNonce(nonce?: string): { valid: boolean; actor?: string } {
    if (!nonce || !nonce.trim()) return { valid: false };
    const clean = nonce.trim();
    const entry = this.singleUseDownloadNonces.get(clean);
    if (!entry) return { valid: false };
    this.singleUseDownloadNonces.delete(clean); // strictly single-use
    if (Date.now() > entry.expiresAt) return { valid: false };

    // Record audit event for successful download
    const event: AuditLogEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: entry.actor,
      action: 'PROJECT_ZIP_EXPORT_DOWNLOADED',
      target: 'FUTUREVERSE_FINAL_RELEASE.zip',
      details: `Project release ZIP downloaded by verified owner (${entry.actor}) via single-use authorization nonce.`,
      outcome: 'SUCCESS',
    };
    this.auditLogs.unshift(event);
    this.save();

    return { valid: true, actor: entry.actor };
  }

  /**
   * Record security audit log directly.
   */
  public recordAuditLog(actor: string, action: string, target: string, details: string, outcome: 'SUCCESS' | 'BLOCKED' | 'FLAGGED'): void {
    const event: AuditLogEvent = {
      id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      target,
      details,
      outcome,
    };
    this.auditLogs.unshift(event);
    this.save();
  }
}

export const authorityService = new AuthorityService();
