/** In-process AI generation admission control and aggregate latency accounting.
 * This is a per-process safeguard, not a distributed queue or durable metrics store.
 */
export type AIRequestOutcome = 'success' | 'error';

type Waiter = { resolve: (release: () => void) => void; reject: (error: Error) => void; timer: ReturnType<typeof setTimeout> };

export class AIRequestScheduler {
  private active = 0;
  private queue: Waiter[] = [];
  private totals = { accepted: 0, succeeded: 0, failed: 0, rejected: 0, totalLatencyMs: 0, lastLatencyMs: 0, maxLatencyMs: 0 };
  constructor(private readonly maxConcurrent = 4, private readonly maxQueued = 12, private readonly queueTimeoutMs = 10_000) {}

  async acquire(): Promise<() => void> {
    if (this.active < this.maxConcurrent) {
      this.active += 1;
      this.totals.accepted += 1;
      return this.makeRelease();
    }
    if (this.queue.length >= this.maxQueued) {
      this.totals.rejected += 1;
      throw new Error('AI_QUEUE_FULL');
    }
    return new Promise<() => void>((resolve, reject) => {
      const waiter: Waiter = {
        resolve: (release) => { clearTimeout(waiter.timer); this.totals.accepted += 1; resolve(release); },
        reject: (error) => { clearTimeout(waiter.timer); this.totals.rejected += 1; reject(error); },
        timer: setTimeout(() => {
          const index = this.queue.indexOf(waiter);
          if (index >= 0) this.queue.splice(index, 1);
          waiter.reject(new Error('AI_QUEUE_TIMEOUT'));
        }, this.queueTimeoutMs),
      };
      this.queue.push(waiter);
    });
  }

  record(outcome: AIRequestOutcome, latencyMs: number): void {
    const safeLatency = Number.isFinite(latencyMs) ? Math.max(0, Math.round(latencyMs)) : 0;
    if (outcome === 'success') this.totals.succeeded += 1;
    else this.totals.failed += 1;
    this.totals.lastLatencyMs = safeLatency;
    this.totals.maxLatencyMs = Math.max(this.totals.maxLatencyMs, safeLatency);
    this.totals.totalLatencyMs += safeLatency;
  }

  snapshot() {
    const completed = this.totals.succeeded + this.totals.failed;
    return {
      maxConcurrent: this.maxConcurrent,
      active: this.active,
      queued: this.queue.length,
      maxQueued: this.maxQueued,
      accepted: this.totals.accepted,
      succeeded: this.totals.succeeded,
      failed: this.totals.failed,
      rejected: this.totals.rejected,
      averageLatencyMs: completed ? Math.round(this.totals.totalLatencyMs / completed) : 0,
      lastLatencyMs: this.totals.lastLatencyMs,
      maxLatencyMs: this.totals.maxLatencyMs,
      scope: 'current-process-only',
    };
  }

  private makeRelease(): () => void {
    let released = false;
    return () => {
      if (released) return;
      released = true;
      const next = this.queue.shift();
      if (next) {
        // Transfer the occupied slot directly to the next FIFO waiter.
        next.resolve(this.makeRelease());
      } else {
        this.active = Math.max(0, this.active - 1);
      }
    };
  }
}

export const aiRequestScheduler = new AIRequestScheduler(
  boundedInteger(process.env.VERSE_AI_MAX_CONCURRENT, 4, 1, 32),
  boundedInteger(process.env.VERSE_AI_MAX_QUEUED, 12, 0, 200),
  boundedInteger(process.env.VERSE_AI_QUEUE_TIMEOUT_MS, 10_000, 500, 60_000),
);

function boundedInteger(value: string | undefined, fallback: number, min: number, max: number): number {
  if (!value || !/^\d+$/.test(value)) return fallback;
  return Math.min(max, Math.max(min, Number(value)));
}
