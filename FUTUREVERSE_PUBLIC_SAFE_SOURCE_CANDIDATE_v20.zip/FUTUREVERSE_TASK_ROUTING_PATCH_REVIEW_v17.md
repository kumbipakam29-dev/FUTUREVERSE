# FUTUREVERSE v17 — Task-Based AI Routing and Safe Fallback Review

## Scope
- Built as an isolated source candidate from the v16 candidate. Earlier ZIPs were not modified.
- Added task categories `general`, `reasoning`, `coding`, and `creative`, plus conservative prompt-text task inference when a task is not explicitly supplied.
- Added ordered local-model routing preferences. Only catalog IDs with an explicit `VERSE_LOCAL_MODEL_MAP` entry are eligible; each candidate is attempted in preference order and routing continues after a model-specific failure.
- Local routing is a heuristic priority policy, not a performance benchmark or a claim that any checkpoint is superior.
- By default, after local inference fails, FUTUREVERSE uses its deterministic fallback rather than forwarding that prompt to Gemini. Remote fallback is allowed only when `allowRemoteFallback: true` is explicitly provided.
- Direct generation rejects model IDs outside the verified catalog and task categories outside the supported text router.
- Hardened `POST /api/ai/generate`: 15 requests/minute per in-process IP/route key, no-store response headers, 20,000-character prompt bound, system-instruction bound, explicit model/task allowlists, temperature/token/timeout bounds, and generic error output.
- Added static and runtime tests for model preference order, candidate failure recovery, prompt privacy during local failure, explicit remote fallback, and rejection of unknown models/tasks.

## Verification performed
- AI provider health static checks: PASS (9 assertions).
- AI provider inference smoke-test static checks: PASS (10 assertions).
- Task-routing static checks: PASS (17 assertions).
- Task-routing runtime tests with mocked local/Gemini providers: PASS (12 assertions).
- Compute route hardening check: PASS.
- Public owner-name privacy check: PASS (53 public assets scanned).
- Owner authority smoke test: PASS (separate credentials, role assignment, session checks, single-use download nonce, duplicate/short secret rejection).
- v16 source candidate checksum matched its provided SHA-256 and `unzip -t` passed before patching.

## Not verified
- These runtime tests use mocked endpoints; no real local runtime, Chinese model weights, remote Gemini API, or live HTTP server was exercised.
- A full TypeScript project typecheck/build and browser/end-to-end test suite were not established. Project dependencies are not installed in this working environment; isolated TypeScript transpilation and provider-routing tests do not replace a production build.
- Provider preference labels are policy heuristics. They must be benchmarked on the user's actual installed model versions and hardware before being treated as quality rankings.
- The in-process rate limiter is not a distributed limiter; production deployments need correct trusted-proxy configuration and a shared rate limiter if multiple instances are used.

## Privacy and release safety
- Local model mappings accept only IDs on the service's fixed catalog allowlist and use the loopback-only URL validator already present in the project.
- No prompt is sent to Gemini after a local-model failure unless remote fallback is explicitly opted into. Without a configured local candidate, existing default Gemini behavior is retained when a valid key is configured.
- Original input archives were not modified. No deployment or GitHub push was performed. Keep source archives private because server-side authority implementation and internal configuration are part of the source.
