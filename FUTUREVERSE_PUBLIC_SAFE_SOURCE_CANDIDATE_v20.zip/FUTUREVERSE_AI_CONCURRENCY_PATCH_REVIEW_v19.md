# FUTUREVERSE v19 — AI concurrency, queueing and latency review

## Scope

This is a separate source candidate based on the v18 workspace. Earlier source ZIPs are not modified. No deployment or GitHub push was performed.

## Changes

1. Added `src/server/aiRequestScheduler.ts`, a process-local FIFO admission controller with configurable bounded concurrency, bounded queue length and queue timeout.
2. Wrapped `/api/ai/generate` with scheduler admission and release in `finally`, and aggregate success/error latency recording.
3. Over-capacity requests return retryable `429 AI_QUEUE_FULL`; queue wait timeouts return retryable `503 AI_QUEUE_TIMEOUT`.
4. Added owner-authorized `GET /api/ai/runtime-metrics`. It exposes aggregate counts and latency only; it does not expose prompts, model tags, credentials or per-user request history.
5. Added environment settings and an isolated scheduler test to the `security:check` script.

## Verification performed

- `node test/ai_request_scheduler_test.mjs`: PASS (13 assertions) using an isolated compiled module.
- TypeScript transpilation of the scheduler source: PASS with no syntax diagnostics.
- Full release/security suite and production build: not yet rerun for this candidate; the project environment has previously lacked Vite/`vite/client` and `tsx` dependencies. Do not treat this report as a production certification.
- Real local-model or live Gemini inference: not run.

## Operational limitations

- Queue and counters are in-memory and per Node.js process. They reset on restart and do not coordinate across multiple replicas. For multi-instance production, use a shared queue/limiter and metrics backend.
- A queue slot bounds concurrent requests but does not guarantee that provider billing stops when a client disconnects.
- Defaults: 4 concurrent requests, 12 queued requests, 10-second queue timeout. Values are bounded at startup by the scheduler module.

## Release safety

- Existing archives were not overwritten.
- The public release generator excludes private runtime JSON according to its existing whitelist.
- No deployment or GitHub push was performed.
