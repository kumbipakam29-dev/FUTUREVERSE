# Runtime data handling

This folder contains both system seed/configuration data and mutable runtime state. Do not commit or publish live user records, payment ledgers, owner audit history, campaign registrations, or agent execution logs.

The public release generator has an explicit whitelist for reviewed seed JSON files. It excludes all other `data/*.json` records and writes a sanitized campaign schedule plus published project examples into the generated archive. Those omissions apply only to the generated distributable; they do not delete or rewrite the local data files.

For an operational migration or disaster recovery, use a protected backup process and store the resulting backup outside the public repository. Never treat the public source ZIP as a complete data backup.
