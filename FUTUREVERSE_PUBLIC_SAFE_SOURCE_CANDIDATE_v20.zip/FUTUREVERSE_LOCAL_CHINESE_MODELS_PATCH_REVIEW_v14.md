# FUTUREVERSE v14 — Local Open-Weight Inference Patch Review

## Scope
- Based on the v13 candidate ZIP; generated a separate v14 candidate. The input ZIP was not modified.
- Added an optional local OpenAI-compatible inference path in `src/server/aiProviderService.ts`.
- The six Chinese model IDs in the registry can be mapped to exact locally installed tags through `VERSE_LOCAL_MODEL_MAP`.
- `VERSE_LOCAL_OPENAI_BASE_URL` defaults to `http://127.0.0.1:11434/v1`; the adapter rejects non-loopback URLs to prevent arbitrary remote prompt forwarding.
- Existing Gemini behavior and deterministic fallback remain in place. Community model IDs do not silently get sent to Gemini.

## Usage
Example only; the model tag must be installed and supported by the local runtime:

```env
VERSE_LOCAL_OPENAI_BASE_URL=http://127.0.0.1:11434/v1
VERSE_LOCAL_MODEL_MAP={"model-qwen3-8-27b-open":"qwen3:8b"}
```

## Verification
- ZIP archive integrity: checked.
- `package.json` and all JSON files: parse checks passed.
- Static source assertions: checked for loopback-only URL guard, explicit model mapping, provider route, and fallback.
- Full TypeScript build: not run / not verified.
- Live Ollama request: not run / not verified.
- Hardware compatibility and exact model-tag availability: not verified.

## Limitations / honesty
- This does not download or install model weights and does not activate models without local setup.
- “Free” means no per-token hosted API fee from this local adapter; hardware, power, storage and hosting still cost money.
- The 27B and very large MoE entries may not run on common Android phones or low-memory laptops. Choose a quantized model appropriate for available hardware.
- No production deployment, GitHub push, or payment/chain changes were made.
