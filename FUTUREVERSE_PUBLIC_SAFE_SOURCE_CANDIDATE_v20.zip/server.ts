import express, { type Request, type Response } from 'express';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

import type {
  Project,
  ContributorTask,
  TaskSubmission,
  EvolutionItem,
  LaunchCampaign,
  ComputeJob,
  ComputeProvider,
  OfficialChannel,
  SocialPost,
  SocialAgent,
  VerseModel,
  VerseAgent,
  SarathiRoutingResult,
  OwnershipRegistry,
  PermanentAuthorityProfile,
  AuditLogEvent,
  MembershipOrder,
  ModelNamingRecord,
  AuthoritativeCampaignState,
} from './src/types.ts';
import { campaignService } from './src/server/campaignService.ts';
import { modelNamingEngine, CANONICAL_GITA_TEACHINGS } from './src/server/namingEngine.ts';
import { agentEngine } from './src/server/agentEngine.ts';
import { authorityService } from './src/server/authorityService.ts';
import { personaEngine } from './src/server/personaEngine.ts';
import { ProjectService } from './src/server/projectService.ts';
import { verseOrchestrator } from './src/server/verseIntelligenceOrchestrator.ts';
import { demandSignalEngine, type ProductEventType } from './src/server/demandSignalEngine.ts';
import { yagyxPaymentService, YAGYX_CHAIN_ID, YAGYX_SUPPORTED_TOKENS, FUTUREVERSE_PAYMENT_VAULT_ADDRESS, EVM_TX_HASH_REGEX } from './src/server/yagyxPaymentService.ts';
import { validateSafeRpcUrl } from './src/server/ssrfValidator.ts';
import { aiProviderService } from './src/server/aiProviderService.ts';
import { aiRequestScheduler } from './src/server/aiRequestScheduler.ts';
import { deepResearchService } from './src/server/deepResearchService.ts';
import { appBuilderService } from './src/server/appBuilderService.ts';
import { superIqAlgorithmEngine } from './src/server/superIqAlgorithmEngine.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini SDK server-side
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

const PROTECTED_OWNER_IDENTITIES = [
  'Dhaval Chandrashekhar Batwal',
  'Hemangini Chandrashekhar Batwal',
  'Hemangini Chandrashwkhar Batwal',
  'Jayshriben Chandrashekhar Batwal',
  'aibabayaga0@gmail.com',
];

function redactProtectedOwnerIdentity(value: string): string {
  let output = value;
  for (const identity of PROTECTED_OWNER_IDENTITIES) {
    const escaped = identity.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    output = output.replace(new RegExp(escaped, 'gi'), 'Private');
  }
  return output;
}

function redactProtectedOwnerIdentityDeep<T>(value: T): T {
  if (typeof value === 'string') return redactProtectedOwnerIdentity(value) as T;
  if (Array.isArray(value)) return value.map((item) => redactProtectedOwnerIdentityDeep(item)) as T;
  if (value && typeof value === 'object') {
    const redacted: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      redacted[key] = redactProtectedOwnerIdentityDeep(item);
    }
    return redacted as T;
  }
  return value;
}

// ============================================================================
// 1. OWNERSHIP & PERMANENT AUTHORITY REPOSITORY (Section 12)
// ============================================================================
const ownershipRegistry: OwnershipRegistry = {
  owner: 'Dhaval Chandrashekhar Batwal',
  coOwner: 'Hemangini Chandrashwkhar Batwal',
  coOperationalOwner: 'Jayshriben Chandrashekhar Batwal',
};

let dhavalAuthorityProfile: PermanentAuthorityProfile = {
  userId: 'usr-dhaval-canonical',
  canonicalName: 'Dhaval Chandrashekhar Batwal',
  currentDesignation: 'Owner',
  protectedAuthority: true, // Permanent capability flag: never stripped by designation change
  effectivePermissions: [
    'ALL_PLATFORM_MANAGEMENT',
    'AI_REGISTRY_MODELS_AGENTS',
    'LAUNCH_REVEAL_CONTROLS',
    'COMPUTE_MARKETPLACE_SETTLEMENTS',
    'MEMBERSHIP_ADMINISTRATION',
    'SOCIAL_PUBLISHING_AUTOPILOT',
    'EMERGENCY_RECOVERY_OVERRIDE',
    'SECURITY_AUDIT_SUPERVISION',
  ],
  antiLockoutActive: true,
  designationHistory: [
    {
      previousDesignation: 'Genesis Architect',
      newDesignation: 'Owner',
      changedAt: '2026-09-01T00:00:00Z',
      actor: 'System Genesis',
      antiLockoutPreserved: true,
    },
  ],
};

let auditLogs: AuditLogEvent[] = [
  {
    id: 'aud-001',
    timestamp: '2026-09-01T00:00:00Z',
    actor: 'Dhaval Chandrashekhar Batwal',
    action: 'PLATFORM_GENESIS',
    target: 'FUTUREVERSE Core',
    details: 'Initial system authorization established with permanent authority policy.',
    outcome: 'SUCCESS',
  },
  {
    id: 'aud-002',
    timestamp: '2026-10-01T10:00:00Z',
    actor: 'Dhaval Chandrashekhar Batwal',
    action: 'LAUNCH_CAMPAIGN_INITIALIZED',
    target: '30-Day Mystery Campaign',
    details: 'Campaign initialized with 30-day timeline. Access control locks enabled.',
    outcome: 'SUCCESS',
  },
];

// ============================================================================
// 2. 30-DAY MYSTERY LAUNCH STATE (Section 5)
// ============================================================================
const campaignStart = new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(); // Started 9 days ago
const campaignEnd = new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString(); // 21 days remaining

let launchCampaign: LaunchCampaign = {
  startTime: campaignStart,
  endTime: campaignEnd,
  totalDays: 30,
  currentDay: 9, // Currently in Day 9
  isRevealed: false,
  registeredCount: 428,
  registrations: [],
  stages: [
    {
      dayRange: 'Days 1–7',
      title: 'Brand Genesis & Philosophy',
      teaser: 'The genesis of FUTUREVERSE: Built with the community, not just for the community.',
      status: 'COMPLETED',
    },
    {
      dayRange: 'Days 8–14',
      title: 'Opportunity to Participate',
      teaser: 'Genesis node registration, early builder bounties, and YAGYX Chain integration.',
      status: 'ACTIVE',
    },
    {
      dayRange: 'Days 15–21',
      title: 'Selected Capabilities Preview',
      teaser: 'Previewing BATWAL’S VERSE AI, the 1% Compute Marketplace, and Social Hub Autopilot.',
      status: 'UPCOMING',
    },
    {
      dayRange: 'Days 22–29',
      title: 'Anticipation & Terms Finalization',
      teaser: 'Finalizing founding member terms, verifiable token models, and reward distribution.',
      status: 'UPCOMING',
    },
    {
      dayRange: 'Day 30',
      title: 'The Core Reveal',
      teaser: 'Protected access reveal: The full architectural realization of BATWAL’S VERSE AI & FUTUREVERSE.',
      status: 'UPCOMING',
    },
  ],
  day30CoreReveal: {
    headline: 'BATWAL’S VERSE AI & THE GLOBAL REPUTATION MESH',
    visionDocument:
      'The complete unification of 15,000+ AI models, 1,000,000 agents orchestrated by SARATHI, paired with decentralized compute validation and verifiable YAGYX settlement.',
    ecosystemBlueprint:
      'Full open orchestration specification across VIVEKA, BUDDHI, DRISHTI, VAANI, JNANA, SMRITI, KARMA, DHARMA, and YOGA.',
    unlockedCapabilities: [
      'Global SARATHI Task Mesh Deployment',
      'Autonomous Distributed Compute Settlement at 1% Commission',
      'Multi-Platform Social Autopilot with Guardian AI',
      'Unrestricted Project Workspace & Genesis Token Staking',
    ],
  },
};

// ============================================================================
// 3. COMPUTE MARKETPLACE & 1% COMMISSION REPOSITORY (Section 9)
// ============================================================================
let computeJobs: ComputeJob[] = [
  {
    id: 'job-101',
    customerId: 'usr-genesis-1',
    customerName: 'Elena Rostova',
    title: 'Model Evaluation & Benchmark Synthesis Matrix',
    workloadType: 'AI_INFERENCE',
    deviceTier: 'GPU_WORKSTATION',
    grossAmountInr: 1000,
    commissionRate: 0.01,
    commissionAmountInr: 10, // 1% FUTUREVERSE Commission
    providerSettlementInr: 990, // Provider payout
    status: 'OPEN',
    verificationMethod: 'Cryptographic Output Hash & Invariant Checking',
    createdAt: '2026-10-09T18:00:00Z',
  },
  {
    id: 'job-102',
    customerId: 'usr-genesis-2',
    customerName: 'Marcus Vance',
    title: 'Distributed Graph Traversal for Dependency Tree',
    workloadType: 'GRAPH_TRAVERSAL',
    deviceTier: 'LAPTOP_PC',
    grossAmountInr: 2500,
    commissionRate: 0.01,
    commissionAmountInr: 25,
    providerSettlementInr: 2475,
    providerId: 'prov-pc-01',
    providerName: 'Devon K. (PC Node)',
    status: 'SETTLED',
    resultPayload: 'Tree traversed: 18,400 nodes, 0 cyclic anomalies detected.',
    verificationMethod: 'Double-blind cross check',
    createdAt: '2026-10-08T12:00:00Z',
    settledAt: '2026-10-08T12:30:00Z',
  },
  {
    id: 'job-103',
    customerId: 'usr-dhaval-canonical',
    customerName: 'Dhaval Chandrashekhar Batwal',
    title: 'Verification Proof for Smart Contract Invariants',
    workloadType: 'VERIFICATION_PROOF',
    deviceTier: 'SERVER_CLUSTER',
    grossAmountInr: 5000,
    commissionRate: 0.01,
    commissionAmountInr: 50,
    providerSettlementInr: 4950,
    status: 'OPEN',
    verificationMethod: 'Formal SMT Solver Verification',
    createdAt: '2026-10-09T22:00:00Z',
  },
];

let computeProviders: ComputeProvider[] = [
  {
    id: 'prov-pc-01',
    ownerName: 'Devon K.',
    deviceType: 'LAPTOP_PC',
    deviceModel: 'ThinkPad P16s (AMD Ryzen 7)',
    batteryThermalSafeguardActive: true,
    isOptedIn: true,
    totalCompletedJobs: 18,
    earnedInr: 14250,
    rewardTokensEarned: { YGO: 450, YAGYX: 45 },
    reputationScore: 98,
  },
  {
    id: 'prov-and-01',
    ownerName: 'Aisha Al-Mansoor',
    deviceType: 'ANDROID',
    deviceModel: 'Pixel 9 Pro (Opt-in Micro-Compute)',
    batteryThermalSafeguardActive: true,
    isOptedIn: true,
    totalCompletedJobs: 42,
    earnedInr: 2100,
    rewardTokensEarned: { YGO: 320, YAGYX: 12 },
    reputationScore: 95,
  },
  {
    id: 'prov-gpu-01',
    ownerName: 'Kenji Sato',
    deviceType: 'GPU_WORKSTATION',
    deviceModel: 'NVIDIA RTX 4090 Workstation',
    batteryThermalSafeguardActive: true,
    isOptedIn: true,
    totalCompletedJobs: 67,
    earnedInr: 89400,
    rewardTokensEarned: { YGO: 2400, YAGYX: 210 },
    reputationScore: 99,
  },
];

// ============================================================================
// 4. FUTUREVERSE SOCIAL HUB (1 CHANNEL PER USER CONSTRAINT) (Section 10)
// ============================================================================
let officialChannels: OfficialChannel[] = [
  {
    id: 'chan-dhaval',
    userId: 'usr-dhaval-canonical',
    channelName: 'Dhaval Batwal Official',
    handle: '@dhaval_batwal',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    bio: 'Founder & Owner of FUTUREVERSE and BATWAL’S VERSE AI. Engineering community-governed intelligence.',
    subscribersCount: 14820,
    postsCount: 12,
    publishingMode: 'AI_ASSISTED',
    createdAt: '2026-09-01T00:00:00Z',
    connectedPlatforms: [
      { platform: 'TELEGRAM', connected: true, accountHandle: '@dhaval_batwal_official', permissionScopes: ['SEND_ANNOUNCEMENTS'] },
      { platform: 'X', connected: true, accountHandle: '@dhaval_verse', permissionScopes: ['POST_UPDATES', 'READ_ANALYTICS'] },
      { platform: 'WHATSAPP', connected: false, permissionScopes: [] },
      { platform: 'INSTAGRAM', connected: false, permissionScopes: [] },
      { platform: 'TIKTOK', connected: false, permissionScopes: [] },
      { platform: 'FACEBOOK', connected: false, permissionScopes: [] },
    ],
  },
  {
    id: 'chan-elena',
    userId: 'usr-genesis-1',
    channelName: 'Elena Rostova Tech & AI',
    handle: 'elena_ai',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    bio: 'Founding Member at FUTUREVERSE. Curriculum synthesis and distributed AI pipelines.',
    subscribersCount: 3940,
    publishingMode: 'MANUAL',
    createdAt: '2026-09-12T14:00:00Z',
    connectedPlatforms: [
      { platform: 'TELEGRAM', connected: true, accountHandle: '@elena_tech', permissionScopes: ['SEND_POSTS'] },
      { platform: 'X', connected: true, accountHandle: '@elena_ai_net', permissionScopes: ['TWEET'] },
    ],
  },
];

let socialPosts: SocialPost[] = [
  {
    id: 'post-1',
    channelId: 'chan-dhaval',
    author: 'Dhaval Chandrashekhar Batwal',
    content:
      'FUTUREVERSE is founded on a core principle: "Built with the community, not just for the community." ASK ANYTHING. BUILD ANYTHING. The 30-Day Mystery Campaign is live on YAGYX Chain (13370).',
    likes: 842,
    commentsCount: 94,
    publishedAt: '2026-10-08T14:00:00Z',
    agentAttribution: 'Strategy Agent (Supervised)',
    syndicatedPlatforms: ['TELEGRAM', 'X'],
  },
  {
    id: 'post-2',
    channelId: 'chan-elena',
    author: 'Elena Rostova',
    content:
      'Excited to release v1.2.0 of the Career & Learning Path Navigator in the Creation Engine. Full interactive sandbox execution with zero script injection vulnerabilities.',
    likes: 219,
    commentsCount: 28,
    publishedAt: '2026-10-09T10:15:00Z',
    syndicatedPlatforms: ['X'],
  },
];

let socialAgents: SocialAgent[] = [
  { id: 'sa-1', role: 'Strategy Agent', scope: 'Audience analysis & campaign scheduling', status: 'ACTIVE', lastAction: 'Optimized Day 9 announcement timing', lastActionTimestamp: '2026-10-10T02:00:00Z' },
  { id: 'sa-2', role: 'Creator Agent', scope: 'Drafts post variants from project specs', status: 'ACTIVE', lastAction: 'Synthesized Career Navigator highlight', lastActionTimestamp: '2026-10-09T22:30:00Z' },
  { id: 'sa-3', role: 'Distribution Agent', scope: 'Cross-platform multi-channel syndication', status: 'ACTIVE', lastAction: 'Dispatched update to Telegram channel', lastActionTimestamp: '2026-10-08T14:01:00Z' },
  { id: 'sa-4', role: 'Scheduling Agent', scope: 'Queue governance & timezone orchestration', status: 'IDLE', lastAction: 'Queued Day 10 teaser schedule', lastActionTimestamp: '2026-10-09T19:00:00Z' },
  { id: 'sa-5', role: 'Publishing Agent', scope: 'Authorized API publishing with token rotation', status: 'ACTIVE', lastAction: 'Broadcast verified on X and Telegram', lastActionTimestamp: '2026-10-08T14:00:30Z' },
  { id: 'sa-6', role: 'Community Agent', scope: 'Triage comments, FAQ routing, anti-spam', status: 'ACTIVE', lastAction: 'Filtered 12 duplicate spam comments', lastActionTimestamp: '2026-10-10T04:12:00Z' },
  { id: 'sa-7', role: 'Analytics Agent', scope: 'Engagement metrics & conversion reporting', status: 'ACTIVE', lastAction: 'Aggregated Day 8 reach report', lastActionTimestamp: '2026-10-09T00:00:00Z' },
  { id: 'sa-8', role: 'Safety Guardian AI', scope: 'Content policy, secret leakage guard, PII scrub', status: 'ACTIVE', lastAction: 'Passed 0 leakage incidents in last 24h', lastActionTimestamp: '2026-10-10T05:00:00Z' },
];

// ============================================================================
// 5. BATWAL'S VERSE AI ECOSYSTEM (15,000+ MODELS & 1,000,000 AGENTS TARGET) (Section 11)
// ============================================================================
let verseModels: VerseModel[] = [
  {
    id: 'model-gemini-3.8',
    name: 'Gemini 3.8 Flash (Active Host)',
    family: 'Google GenAI Flash',
    capability: 'Multimodal',
    parameters: 'High-Efficiency Adaptive',
    license: 'Commercial Enterprise',
    benchmarkScore: 'MMLU 89.2% / Fast Synthesis',
    status: 'HOSTED_DEMO',
    orchestratorModule: 'SARATHI',
  },
  {
    id: 'model-viveka-select',
    name: 'VIVEKA-Ranker v2.4',
    family: 'Verse Selection Matrix',
    capability: 'Reasoning',
    parameters: '7B MoE Evaluator',
    license: 'Apache 2.0',
    benchmarkScore: 'Routing Accuracy 99.4%',
    status: 'VERIFIED',
    orchestratorModule: 'VIVEKA',
  },
  {
    id: 'model-buddhi-reason',
    name: 'BUDDHI Deep Logic Engine',
    family: 'Symbolic Reasoning & Invariants',
    capability: 'Reasoning',
    parameters: '32B Deep Proof',
    license: 'Open Model Initiative',
    benchmarkScore: 'GSM8K 94.6% / Formal Math',
    status: 'VERIFIED',
    orchestratorModule: 'BUDDHI',
  },
  {
    id: 'model-drishti-vision',
    name: 'DRISHTI Spatial & Diagram Parser',
    family: 'Verse Visual Understanding',
    capability: 'Vision',
    parameters: '14B Multimodal Vision',
    license: 'Apache 2.0',
    benchmarkScore: 'DocVQA 92.1%',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'DRISHTI',
  },
  {
    id: 'model-vaani-lang',
    name: 'VAANI Polyglot Communicator',
    family: 'Indian & Global Language Synthesizer',
    capability: 'Language',
    parameters: '13B Multilingual (Hindi, Marathi, English, Tamil...)',
    license: 'IndicOpen 2.0',
    benchmarkScore: 'BLEU 44.8 on Indic Benchmarks',
    status: 'VERIFIED',
    orchestratorModule: 'VAANI',
  },
  {
    id: 'model-jnana-kb',
    name: 'JNANA Knowledge & Semantic Graph',
    family: 'Dense Retrieval & Embeddings',
    capability: 'Embedding',
    parameters: 'Embedding 2048-dim',
    license: 'Apache 2.0',
    benchmarkScore: 'MTEB 68.4',
    status: 'VERIFIED',
    orchestratorModule: 'JNANA',
  },
  {
    id: 'model-karma-exec',
    name: 'KARMA Tool Calling Engine',
    family: 'Deterministic Function Execution',
    capability: 'Code',
    parameters: '8B Structured Schema Call',
    license: 'MIT',
    benchmarkScore: 'BFCL Tool Call 96.1%',
    status: 'VERIFIED',
    orchestratorModule: 'KARMA',
  },
  {
    id: 'model-dharma-guard',
    name: 'DHARMA Policy & Safety Sentinel',
    family: 'Constitutional AI & Guardrails',
    capability: 'Classification',
    parameters: '3B Fast Filter',
    license: 'Apache 2.0',
    benchmarkScore: 'Safety Precision 99.8%',
    status: 'HOSTED_DEMO',
    orchestratorModule: 'DHARMA',
  },

  // Community-listed free-to-download Chinese open-weight models. Catalog entries only:
  // weights may be free, but inference still needs compute and is not wired as a live adapter.
  {
    id: 'model-deepseek-v4-1-flash-open',
    name: 'DeepSeek V4.1 Flash (Open Weights)',
    family: 'DeepSeek · China · Open-weight',
    capability: 'Reasoning',
    parameters: '552B MoE (large model; hardware-intensive)',
    license: 'MIT (verify model card at deployment)',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'BUDDHI',
  },
  {
    id: 'model-glm-5-3-flash-open',
    name: 'GLM-5.3-Flash (Open Weights)',
    family: 'Z.ai / Zhipu · China · Open-weight',
    capability: 'Reasoning',
    parameters: 'Large MoE; hardware-intensive',
    license: 'MIT reported by model tracker; verify official model card',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'SARATHI',
  },
  {
    id: 'model-qwen3-8-27b-open',
    name: 'Qwen3.8-27B (Open Weights)',
    family: 'Alibaba Qwen · China · Open-weight',
    capability: 'LLM',
    parameters: '27B parameters',
    license: 'Apache 2.0 reported for this checkpoint; verify model card',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'JNANA',
  },
  {
    id: 'model-minicpm-v-4-7-open',
    name: 'MiniCPM-V 4.7 (Open Weights)',
    family: 'ModelBest · China · Open-weight multimodal',
    capability: 'Vision',
    parameters: '35B total / ~3B active reported; verify variant',
    license: 'Apache 2.0 reported; verify official model card',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'DRISHTI',
  },
  {
    id: 'model-mimo-v2-6-pro-open',
    name: 'MiMo-V2.6-Pro (Open Weights)',
    family: 'Xiaomi · China · Open-weight',
    capability: 'Reasoning',
    parameters: 'Large model; hardware requirements depend on quantization',
    license: 'MIT reported by current model tracker; verify official model card',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'BUDDHI',
  },
  {
    id: 'model-minimax-m3-open',
    name: 'MiniMax-M3 (Open Weights)',
    family: 'MiniMax · China · Open-weight',
    capability: 'Multimodal',
    parameters: '~428B total / ~23B active reported; hardware-intensive',
    license: 'MiniMax Community License; review terms before commercial use',
    benchmarkScore: 'Catalog listing only; no local benchmark run',
    status: 'COMMUNITY_LISTED',
    orchestratorModule: 'SARATHI',
  }

];

let verseAgents: VerseAgent[] = [
  {
    id: 'agent-sarathi-orch',
    name: 'SARATHI Core Orchestrator',
    version: '2.1.0',
    capability: 'Task Decomposition, Cost/Latency Matrix & Dynamic Routing',
    permissionScope: ['ROUTE_TASKS', 'SELECT_MODELS', 'AUDIT_LATENCY'],
    toolAccess: ['vivekaRouter', 'karmaDispatcher', 'dharmaValidator'],
    status: 'ACTIVE',
    evalScore: 99.2,
  },
  {
    id: 'agent-buddhi-solver',
    name: 'BUDDHI Mathematical Invariant Solver',
    version: '1.4.2',
    capability: 'Formal Verification of Financial & Token Formulas',
    permissionScope: ['READ_FORMULAS', 'PROVE_BOUNDS'],
    toolAccess: ['smtSolver', 'pythonSandbox'],
    status: 'ACTIVE',
    evalScore: 98.6,
  },
  {
    id: 'agent-dharma-shield',
    name: 'DHARMA Anti-Slop & Prompt Security Guard',
    version: '2.0.1',
    capability: 'Enforces WCAG AA, Anti-Slop Discipline, PII Quarantine',
    permissionScope: ['INSPECT_INPUTS', 'BLOCK_INJECTION'],
    toolAccess: ['patternMatcher', 'semanticClassifier'],
    status: 'ACTIVE',
    evalScore: 99.9,
  },
];

// ============================================================================
// 6. MEMBERSHIP ORDERS & REFERENCE PRICING STORE (Section 4 & 6)
// ============================================================================
let membershipOrders: MembershipOrder[] = [];

// ============================================================================
// SEED PROJECTS, EVOLUTION ITEMS, AND TASKS
// ============================================================================
let projects: Project[] = [
  {
    id: 'proj-career-navigator',
    title: 'Career & Learning Path Navigator',
    tagline: 'Personalized skill diagnostics, curriculum roadmaps, and career trajectory simulation',
    description: 'An interactive exploration system that bridges student aspirations with tangible industry competency maps and milestone-based study plans.',
    category: 'EdTech & Careers',
    type: 'Working Application',
    visibility: 'published',
    version: '1.2.0',
    author: {
      id: 'usr-genesis-1',
      name: 'Elena Rostova',
      handle: 'elena_ai',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      verified: true,
      foundingMember: true,
      address: '0x71C...39B',
    },
    createdAt: '2026-09-12T14:20:00Z',
    updatedAt: '2026-10-04T09:15:00Z',
    stars: 142,
    forks: 38,
    tags: ['education', 'careers', 'skills', 'roadmaps'],
    specification: {
      targetAudience: 'Secondary and tertiary students transitioning to emerging tech fields.',
      problemStatement: 'Static career counselors fail to keep pace with rapid AI and Web3 workforce shifts, leaving learners with fragmented study paths.',
      keyFeatures: [
        { title: 'Dynamic Skill Diagnostic', description: 'Evaluates baseline competencies in programming, logic, and systems.', priority: 'core' },
        { title: 'Milestone Timeline Generator', description: 'Calculates realistic completion dates based on weekly hour commitment.', priority: 'core' },
        { title: 'Portfolio Project Recommendations', description: 'Suggests high-impact open source repositories to build for each sprint.', priority: 'extended' },
      ],
      userFlow: [
        { step: 1, title: 'Profile & Target Role', action: 'User selects desired specialty and weekly study availability.', outcome: 'System sets baseline expectation parameters.' },
        { step: 2, title: 'Diagnostic Benchmark', action: 'User rates current familiarity with prerequisite concepts.', outcome: 'Target knowledge gap is mapped.' },
        { step: 3, title: 'Roadmap Generation', action: 'Interactive sprint roadmap calculates timeline and skill milestones.', outcome: 'Personalized learning schedule ready.' },
      ],
      architecture: {
        frontend: 'React 19 + Tailwind CSS + Interactive Canvas',
        backend: 'Express.js + Gemini 3.8 Flash Curriculum Synthesizer',
        dataModel: 'LearnerProfile, MilestoneCollection, CompetencyMatrix',
        securityNotes: 'Client inputs sanitized; zero storage of PII without explicit consent.',
      },
    },
    prototype: {
      type: 'career_planner',
      headline: 'Interactive Career Sprint Planner',
      interactiveElements: [
        {
          id: 'targetRole',
          label: 'Target Career Domain',
          type: 'select',
          options: ['AI Systems Engineer', 'Smart Contract Architect', 'Distributed Systems Specialist', 'Applied Product Designer'],
          defaultValue: 'AI Systems Engineer',
          description: 'The primary occupational direction to model',
        },
        {
          id: 'currentLevel',
          label: 'Current Experience Tier',
          type: 'select',
          options: ['Beginner (Curious)', 'Intermediate (Some Projects)', 'Advanced (Practicing Developer)'],
          defaultValue: 'Intermediate (Some Projects)',
          description: 'Your existing baseline knowledge level',
        },
        {
          id: 'weeklyHours',
          label: 'Weekly Dedicated Hours',
          type: 'slider',
          min: 4,
          max: 40,
          step: 2,
          defaultValue: 16,
          description: 'Available study hours per week',
        },
        {
          id: 'learningStyle',
          label: 'Preferred Sprint Focus',
          type: 'select',
          options: ['Hands-on Project Building', 'Theory & Architecture First', 'Speed & Job Readiness'],
          defaultValue: 'Hands-on Project Building',
          description: 'Structure of the sprint syllabus',
        },
      ],
      formulaSummary: 'Calculates total sprint weeks: (Curriculum Hours / Weekly Commitment) * Experience Multiplier',
      outputSections: [
        { title: 'Estimated Time to Mastery', metricLabel: 'Weeks to Job Readiness', calculationKey: 'timeline' },
        { title: 'Curated 3-Phase Milestone Plan', calculationKey: 'milestones' },
        { title: 'High-Impact Capstone Recommendation', calculationKey: 'capstone' },
      ],
    },
    feedback: [
      {
        id: 'fb-1',
        author: 'Devon K.',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        type: 'suggestion',
        content: 'Could we add a direct link to open-source issue bounties on YAGYX Chain for practical experience?',
        createdAt: '2026-10-02T11:00:00Z',
        upvotes: 18,
      },
      {
        id: 'fb-2',
        author: 'Maya Lin',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
        type: 'feedback',
        content: 'Tested the 16-hour sprint track for Smart Contract Architect; the milestones are realistic and grounded.',
        createdAt: '2026-10-05T18:40:00Z',
        upvotes: 9,
      },
    ],
    aiGenerated: false,
  },
  {
    id: 'proj-scenario-simulator',
    title: 'Future-Planning & Impact Simulator',
    tagline: 'Multi-variable scenario modeling for community growth, resource burn, and sustainability',
    description: 'Empowers builders, DAOs, and grassroots initiatives to simulate future growth trajectories, treasury sustainability, and adoption curves under varying macro conditions.',
    category: 'Web3 & FinTech',
    type: 'Simulation',
    visibility: 'published',
    version: '1.0.4',
    author: {
      id: 'usr-genesis-2',
      name: 'Marcus Vance',
      handle: 'marcus_v',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
      verified: true,
      foundingMember: true,
      address: '0x32A...8E1',
    },
    createdAt: '2026-09-20T08:00:00Z',
    updatedAt: '2026-10-07T16:22:00Z',
    stars: 96,
    forks: 21,
    tags: ['simulation', 'treasury', 'modeling', 'governance'],
    specification: {
      targetAudience: 'Community leads, ecosystem treasurers, and project founders.',
      problemStatement: 'Most early projects run out of runway due to static spreadsheet assumptions rather than dynamic stress-testing.',
      keyFeatures: [
        { title: 'Runway Sensitivity Matrix', description: 'Stress tests ecosystem grants against volatile monthly token velocity.', priority: 'core' },
        { title: 'Community Retention Curve', description: 'Calculates active builder retention based on reward distribution clarity.', priority: 'core' },
      ],
      userFlow: [
        { step: 1, title: 'Input Baseline Reserves', action: 'User sets initial capital and projected monthly burn.', outcome: 'Calculates break-even horizon.' },
        { step: 2, title: 'Apply Stress Factor', action: 'User dials down inflow and ramps up contributor demand.', outcome: 'Generates resilience score.' },
      ],
      architecture: {
        frontend: 'React Math Engine + Visual Gauges',
        backend: 'Express.js Monte Carlo Simulation Engine',
        dataModel: 'SimulationPreset, StressTestResult',
        securityNotes: 'All calculations are deterministic and verified against public formulas.',
      },
    },
    prototype: {
      type: 'scenario_simulator',
      headline: 'Interactive Ecosystem Runway Simulator',
      interactiveElements: [
        {
          id: 'startingTreasury',
          label: 'Starting Ecosystem Reserve ($)',
          type: 'slider',
          min: 10000,
          max: 500000,
          step: 10000,
          defaultValue: 150000,
          description: 'Initial available project capital',
        },
        {
          id: 'monthlyBurn',
          label: 'Monthly Contributor Grants ($)',
          type: 'slider',
          min: 2000,
          max: 50000,
          step: 1000,
          defaultValue: 12000,
          description: 'Disbursements for bounties and core operations',
        },
        {
          id: 'organicInflow',
          label: 'Monthly Organic Inflow / Sponsorships ($)',
          type: 'slider',
          min: 0,
          max: 30000,
          step: 500,
          defaultValue: 4500,
          description: 'Inflow from platform utility and partners',
        },
        {
          id: 'growthRate',
          label: 'Estimated Contributor Growth Rate (%)',
          type: 'slider',
          min: 0,
          max: 50,
          step: 5,
          defaultValue: 15,
          description: 'Monthly acceleration in verified contributors',
        },
      ],
      outputSections: [
        { title: 'Runway Projection', metricLabel: 'Months of Viable Operations', calculationKey: 'runway' },
        { title: 'Net Monthly Cashflow', metricLabel: 'Deficit / Surplus per Month', calculationKey: 'cashflow' },
        { title: 'Capital Preservation Recommendation', calculationKey: 'strategy' },
      ],
    },
    feedback: [],
    aiGenerated: false,
  },
  {
    id: 'proj-product-planner',
    title: 'Idea-to-Product Architecture Planner',
    tagline: 'Translates high-level product visions into technical specs, schema drafts, and deployment roadmaps',
    description: 'A structured blueprint generator that decomposes messy ideas into concrete data schemas, API contracts, threat models, and phased release schedules.',
    category: 'Productivity',
    type: 'Interactive Prototype',
    visibility: 'published',
    version: '1.1.0',
    author: {
      id: 'usr-genesis-3',
      name: 'Kenji Sato',
      handle: 'kenji_arch',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      verified: true,
      foundingMember: false,
      address: '0x99F...1A4',
    },
    createdAt: '2026-09-28T10:14:00Z',
    updatedAt: '2026-10-06T12:00:00Z',
    stars: 83,
    forks: 14,
    tags: ['architecture', 'planning', 'specifications', 'engineering'],
    specification: {
      targetAudience: 'Software engineers, solo founders, and technical product managers.',
      problemStatement: 'Ideas stall because founders jump into code without specifying data boundaries, user journeys, or security isolation.',
      keyFeatures: [
        { title: 'Specification Synthesizer', description: 'Generates user flows, API schemas, and deployment topologies.', priority: 'core' },
        { title: 'Security Risk Checker', description: 'Highlights OWASP threats and storage exposure vulnerabilities.', priority: 'extended' },
      ],
      userFlow: [
        { step: 1, title: 'Vision Pitch', action: 'Describe core capability in one sentence.', outcome: 'System extracts functional entities.' },
        { step: 2, title: 'Architecture Selection', action: 'Choose single-tenant, multi-tenant, or distributed mesh.', outcome: 'Generates component blueprint.' },
      ],
      architecture: {
        frontend: 'React 19 + Graph Schema Viewer',
        backend: 'Express.js + Gemini 3.8 Flash Spec Engine',
        dataModel: 'ProductBlueprint, EntitySchema, SecurityAudit',
        securityNotes: 'Role-based access controls baked into generated specs.',
      },
    },
    prototype: {
      type: 'product_roadmap',
      headline: 'Interactive Architecture Blueprint Generator',
      interactiveElements: [
        {
          id: 'architectureScale',
          label: 'Target Audience Scale',
          type: 'select',
          options: ['Early Prototype (<1k users)', 'Emerging Community (1k-50k users)', 'Global Scale (>100k users)'],
          defaultValue: 'Emerging Community (1k-50k users)',
          description: 'Anticipated traffic and throughput',
        },
        {
          id: 'storageParadigm',
          label: 'Primary Storage Strategy',
          type: 'select',
          options: ['Relational (PostgreSQL / SQL)', 'Document Store (Firestore / JSON)', 'Hybrid Web3 (Decentralized + Cache)'],
          defaultValue: 'Relational (PostgreSQL / SQL)',
          description: 'Data model persistence choice',
        },
        {
          id: 'securityLevel',
          label: 'Data Sensitivity & Compliance',
          type: 'select',
          options: ['Standard Public Application', 'Sensitive User Records (GDPR/Financial)', 'Mission Critical / Smart Contract Audited'],
          defaultValue: 'Sensitive User Records (GDPR/Financial)',
          description: 'Security & auditing posture required',
        },
      ],
      outputSections: [
        { title: 'Recommended Stack & Architecture', calculationKey: 'stack' },
        { title: 'Database Schema Strategy', calculationKey: 'schema' },
        { title: 'Release Sprint Breakdown', calculationKey: 'release' },
      ],
    },
    feedback: [],
    aiGenerated: false,
  },
  {
    id: 'proj-community-solver',
    title: 'Community Problem-Solving Engine',
    tagline: 'Collaborative root-cause analysis, challenge delegation, and verified milestone logging',
    description: 'Coordinates distributed communities to break wicked problems into actionable micro-tasks, vote on root hypotheses, and reward verified problem solvers.',
    category: 'Community Systems',
    type: 'Working Application',
    visibility: 'published',
    version: '1.0.1',
    author: {
      id: 'usr-genesis-4',
      name: 'Aisha Al-Mansoor',
      handle: 'aisha_future',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
      verified: true,
      foundingMember: true,
      address: '0x18B...55C',
    },
    createdAt: '2026-10-01T15:00:00Z',
    updatedAt: '2026-10-08T11:40:00Z',
    stars: 118,
    forks: 29,
    tags: ['community', 'collaboration', 'governance', 'bounties'],
    specification: {
      targetAudience: 'Civic groups, open-source maintainers, and community DAOs.',
      problemStatement: 'Community forums become echo chambers of complaint without structured pathways to verify and fund solutions.',
      keyFeatures: [
        { title: 'Root Cause Decomposition', description: 'Fishbone and 5-Whys diagnostic flow.', priority: 'core' },
        { title: 'Bounty Attribution Ledger', description: 'Attaches transparent reward pools to verified solutions.', priority: 'core' },
      ],
      userFlow: [
        { step: 1, title: 'Problem Stating', action: 'Proposer states challenge with observable friction points.', outcome: 'Community reviews hypothesis.' },
        { step: 2, title: 'Task Delegation', action: 'Contributors claim specific micro-tasks with acceptance criteria.', outcome: 'Work begins with escrow pledge.' },
      ],
      architecture: {
        frontend: 'React Task Kanban + Verification Ledger',
        backend: 'Express.js + YAGYX Chain Event Logger',
        dataModel: 'Challenge, MicroTask, VerificationProof',
        securityNotes: 'Cryptographic attestation for task completion claims.',
      },
    },
    prototype: {
      type: 'community_solver',
      headline: 'Interactive Challenge Decomposition Engine',
      interactiveElements: [
        {
          id: 'problemDomain',
          label: 'Challenge Domain',
          type: 'select',
          options: ['Open Source Code Maintenance', 'Platform Documentation & Tutorials', 'Accessibility & Localization', 'Security Vulnerability Hardening'],
          defaultValue: 'Open Source Code Maintenance',
          description: 'Focus area of the collective challenge',
        },
        {
          id: 'complexityLevel',
          label: 'Complexity & Urgency',
          type: 'select',
          options: ['Routine (Standard Sprint)', 'Moderate (Requires Architecture Review)', 'High Priority (Ecosystem Blocker)'],
          defaultValue: 'Moderate (Requires Architecture Review)',
          description: 'SLA and review rigor',
        },
        {
          id: 'contributorPool',
          label: 'Allocated Bounty Pool (YAGYX)',
          type: 'slider',
          min: 100,
          max: 10000,
          step: 100,
          defaultValue: 1500,
          description: 'Transparent reward allocation for reviewers & solvers',
        },
      ],
      outputSections: [
        { title: 'Decomposed Workstreams', calculationKey: 'workstreams' },
        { title: 'Verification & Review Criteria', calculationKey: 'criteria' },
        { title: 'Reward Distribution Matrix', calculationKey: 'rewards' },
      ],
    },
    feedback: [],
    aiGenerated: false,
  },
];

const projectService = new ProjectService(projects);

let evolutionItems: EvolutionItem[] = [
  {
    id: 'evo-1',
    title: 'Offline-First Draft Autosave with Conflict Resolution',
    category: 'Engineering',
    description: 'Ensure project builders never lose in-progress drafts during transient network drops, with deterministic IndexedDB synchronization when back online.',
    proposer: { name: 'Elena Rostova', address: '0x71C...39B', foundingMember: true },
    status: 'BUILDING',
    votes: 47,
    createdAt: '2026-09-15T10:00:00Z',
    updatedAt: '2026-10-06T14:00:00Z',
    reviewNotes: 'Architecture approved. LocalStorage buffer fallback implemented; full IndexedDB queue in active development.',
    reviewedBy: 'Core Architecture Reviewer',
    reviewedAt: '2026-09-22T09:00:00Z',
  },
  {
    id: 'evo-2',
    title: 'YAGYX Chain ID 13370 Automated RPC Health Prober',
    category: 'Engineering',
    description: 'Implement a non-intrusive client-side prober that validates RPC latency to Chain 13370 and gracefully falls back to read-only diagnostics when offline.',
    proposer: { name: 'Marcus Vance', address: '0x32A...8E1', foundingMember: true },
    status: 'TESTING',
    votes: 62,
    createdAt: '2026-09-18T16:00:00Z',
    updatedAt: '2026-10-08T11:20:00Z',
    reviewNotes: 'RPC health checks completed without leaking private credentials. Verifying wrong-network modal flows.',
    reviewedBy: 'Core Security Lead',
    reviewedAt: '2026-09-28T12:00:00Z',
  },
  {
    id: 'evo-3',
    title: 'High-Contrast WCAG AA Accessible Color Tokens across Dark Mode',
    category: 'Accessibility',
    description: 'Ensure all typographic and interactive control contrasts exceed 4.5:1 ratio across both desktop and mobile viewports.',
    proposer: { name: 'Soraya Chen', address: '0x88D...012', foundingMember: false },
    status: 'RELEASED',
    votes: 89,
    createdAt: '2026-09-10T12:00:00Z',
    updatedAt: '2026-10-02T18:00:00Z',
    reviewNotes: 'Audited with axe-core; contrast verified on all buttons, badges, and code blocks.',
    reviewedBy: 'Design Reviewer',
    reviewedAt: '2026-09-14T15:30:00Z',
  },
];

let contributorTasks: ContributorTask[] = [
  {
    id: 'task-1',
    title: 'Write Unit Tests for Interactive Prototype Formula Solvers',
    category: 'Testing',
    difficulty: 'Starter',
    requirements: [
      'Cover career planner, runway simulator, and challenge solver calculation edge cases.',
      'Ensure 0-division and negative input guards work correctly.',
      'Include test fixture samples.',
    ],
    acceptanceCriteria: [
      'Tests run cleanly with no flaky failures.',
      '100% branch coverage on formula helpers.',
      'Zero external dependency additions.',
    ],
    rewardType: 'YAGYX Ecosystem Tokens & Contributor Badge',
    rewardAmount: '250 YAGYX',
    status: 'AVAILABLE',
    submissions: [],
    createdAt: '2026-10-01T10:00:00Z',
  },
  {
    id: 'task-2',
    title: 'Audit YAGYX Chain ID 13370 EIP-1193 Error Handling',
    category: 'Security',
    difficulty: 'Advanced',
    requirements: [
      'Audit wallet_switchEthereumChain error codes (4902 for unrecognized chain, 4001 for user rejection).',
      'Verify that no transaction is ever submitted without explicit modal user confirmation.',
      'Ensure zero exposure of signing keys or seed phrase prompts.',
    ],
    acceptanceCriteria: [
      'Detailed security report covering RPC exception paths.',
      'Verification that safe fallback displays honest pending status rather than fabricated confirmations.',
    ],
    rewardType: 'Founding Contributor Recognition & YAGYX Token Bounty',
    rewardAmount: '1,000 YAGYX',
    status: 'UNDER_REVIEW',
    submissions: [
      {
        id: 'sub-1',
        contributorName: 'Alex T. (SecAuditor)',
        contributorAddress: '0x192...AA4',
        submissionUrl: 'https://github.com/futureverse/audits/eip1193-review',
        notes: 'Completed comprehensive inspection. Verified that user rejection (4001) surfaces clear friendly guidance.',
        submittedAt: '2026-10-06T15:00:00Z',
        status: 'PENDING',
        reviewNote: 'Under review by security steward.',
      },
    ],
    createdAt: '2026-09-25T14:00:00Z',
  },
];

async function startServer() {
  const app = express();
  const PORT = process.env.DEFAULT_APP_PORT
    ? Number(process.env.DEFAULT_APP_PORT)
    : (process.env.NGINX_PORT ? 3000 : (Number(process.env.PORT) || 3000));

  app.use(express.json({ limit: '1mb' }));

  // Trust forwarded client addresses only when the deployment explicitly configures proxy hops.
  const configuredProxyHops = Number(process.env.TRUST_PROXY_HOPS || 0);
  if (Number.isInteger(configuredProxyHops) && configuredProxyHops >= 0 && configuredProxyHops <= 5) {
    app.set('trust proxy', configuredProxyHops);
  }

  // This UI uses same-origin API calls. Do not grant credential-adjacent APIs wildcard CORS access.
  app.use((req: Request, res: Response, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Cache-Control', 'no-store');
    if (req.method === 'OPTIONS') return res.status(204).end();
    next();
  });

  // ============================================================================
  // SYSTEM HEALTH & DIAGNOSTICS
  // ============================================================================
  app.get('/api/health', (_req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      status: 'healthy',
      app: 'FUTUREVERSE',
      version: '2.0.0-PROD',
      timestamp: new Date().toISOString(),
      chainConfig: {
        chainId: 13370,
        chainIdHex: '0x343a',
        networkName: 'YAGYX Chain',
      },
    });
  });

  // ============================================================================
  // YAGYX CHAIN PROJECT BACKUP DOWNLOAD & EXPORT SYSTEM
  // ============================================================================
  // Direct binary stream with RFC 6266 Content-Disposition attachment headers
  app.get(['/api/backup/download', '/YAGYX_CHAIN_PROJECT_BACKUP.zip', '/YAGYX_CHAIN_PRODUCTION_RECOVERY.zip', '/api/backup/download-production'], (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Owner sign-in required to download project backups.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const isProductionRecovery = req.path.includes('PRODUCTION') || req.path.includes('download-production') || req.query.package === 'production';
    const targetFile = isProductionRecovery ? 'YAGYX_CHAIN_PRODUCTION_RECOVERY.zip' : 'YAGYX_CHAIN_PROJECT_BACKUP.zip';
    const backupPath = path.resolve(process.cwd(), targetFile);
    if (fs.existsSync(backupPath)) {
      const stat = fs.statSync(backupPath);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${targetFile}"`);
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
      return res.sendFile(backupPath);
    }
    return res.status(404).json({ error: `${targetFile} not found` });
  });

  // Base64 JSON fallback for restrictive proxy environments that block binary MIME types
  app.get('/api/backup/base64', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Owner sign-in required to download project backups.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const isProductionRecovery = req.query.package === 'production';
    const targetFile = isProductionRecovery ? 'YAGYX_CHAIN_PRODUCTION_RECOVERY.zip' : 'YAGYX_CHAIN_PROJECT_BACKUP.zip';
    const backupPath = path.resolve(process.cwd(), targetFile);
    if (fs.existsSync(backupPath)) {
      const buffer = fs.readFileSync(backupPath);
      res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
      const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');
      return res.json({
        filename: targetFile,
        sizeBytes: buffer.length,
        sha256,
        mimeType: 'application/zip',
        base64: buffer.toString('base64'),
      });
    }
    return res.status(404).json({ error: `${targetFile} not found` });
  });

  // Metadata verification endpoint. Backup existence and hashes are operational details.
  app.get('/api/backup/info', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Owner sign-in required to view backup metadata.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
    const originalPath = path.resolve(process.cwd(), 'YAGYX_CHAIN_PROJECT_BACKUP.zip');
    const productionPath = path.resolve(process.cwd(), 'YAGYX_CHAIN_PRODUCTION_RECOVERY.zip');
    const packages: Record<string, any> = {};

    if (fs.existsSync(originalPath)) {
      const buf = fs.readFileSync(originalPath);
      packages.originalBaseline = {
        filename: 'YAGYX_CHAIN_PROJECT_BACKUP.zip',
        sizeBytes: buf.length,
        sha256: crypto.createHash('sha256').update(buf).digest('hex'),
        downloadUrl: '/api/backup/download',
      };
    }

    if (fs.existsSync(productionPath)) {
      const buf = fs.readFileSync(productionPath);
      packages.productionRecovery = {
        filename: 'YAGYX_CHAIN_PRODUCTION_RECOVERY.zip',
        sizeBytes: buf.length,
        sha256: crypto.createHash('sha256').update(buf).digest('hex'),
        downloadUrl: '/api/backup/download-production',
      };
    }

    res.json({
      exists: Object.keys(packages).length > 0,
      packages,
      manifestDoc: '/YAGYX_BACKUP_MANIFEST.txt',
    });
  });

  // ============================================================================
  // YAGYX CHAIN & REFERENCE PRICING POLICY (Section 4)
  // ============================================================================
  app.get('/api/yagyx/config', (req: Request, res: Response) => {
    res.json({
      chainId: 13370,
      chainIdHex: '0x343a',
      networkName: 'YAGYX Chain',
      nativeCurrency: {
        name: 'YAGYX',
        symbol: 'YAGYX',
        decimals: 18,
      },
      tokens: [
        {
          symbol: 'YGO',
          name: 'YAGYX Governance Organization',
          role: 'Governance & Primary Payment Token',
          referencePrice: '₹1 INR (Configured Starting Reference)',
          paymentPriority: 1,
          status: 'Documented Policy',
        },
        {
          symbol: 'YAGYX',
          name: 'YAGYX Native Gas & Protocol Asset',
          role: 'Native Gas & Primary Platform Settlement',
          referencePrice: '₹100 INR (Configured Starting Reference)',
          paymentPriority: 2,
          status: 'Native Protocol Asset',
        },
        {
          symbol: 'YINR',
          name: 'YAGYX Indian Rupee Pegged Asset',
          role: 'Regional Stable Settlement Medium',
          referencePrice: 'Target ₹1 per YINR (Pending reserve audit)',
          paymentPriority: 3,
          status: 'Configuration pending verification',
        },
        {
          symbol: 'YUSD',
          name: 'YAGYX USD Pegged Asset',
          role: 'Global Stable Settlement Medium',
          referencePrice: 'Target $1 per YUSD (Pending reserve audit)',
          paymentPriority: 4,
          status: 'Configuration pending verification',
        },
      ],
      paymentPriorityRules: [
        '1. Primary Priority: YGO (₹1 ref) and YAGYX (₹100 ref)',
        '2. Secondary Priority: YINR (₹1 target) and YUSD ($1 target)',
        '3. Explicit transaction preview and non-custodial user confirmation required.',
        '4. Honest Disclosure: Reference prices are starting benchmarks, not market guarantees.',
      ],
      rpcStatus: 'EIP-1193 standard browser connector (Chain ID 13370 verified)',
      explorerStatus: 'Official block explorer endpoint pending genesis confirmation',
    });
  });

  // In-memory rate limiting map for sensitive endpoints
  const sensitiveRateLimitMap = new Map<string, { count: number; resetAt: number }>();
  function checkRateLimit(req: Request, res: Response, maxRequests: number = 30, windowMs: number = 60000): boolean {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    // Use Express's matched route template when available so changing resource IDs
    // cannot bypass a per-endpoint limit (for example, by varying project/agent IDs).
    const routeKey = typeof req.route?.path === 'string' ? req.route.path : req.path;
    const key = `${routeKey}:${clientIp}`;
    if (sensitiveRateLimitMap.size > 10000) {
      for (const [entryKey, entryValue] of sensitiveRateLimitMap) {
        if (Date.now() > entryValue.resetAt) sensitiveRateLimitMap.delete(entryKey);
      }
    }
    const now = Date.now();
    const entry = sensitiveRateLimitMap.get(key);

    if (!entry || now > entry.resetAt) {
      sensitiveRateLimitMap.set(key, { count: 1, resetAt: now + windowMs });
      return true;
    }

    if (entry.count >= maxRequests) {
      res.status(429).json({
        error: 'Rate limit exceeded. Please wait a moment before sending more requests.',
        retryAfterSeconds: Math.ceil((entry.resetAt - now) / 1000),
      });
      return false;
    }

    entry.count++;
    return true;
  }

  app.get('/api/yagyx/ledger', (req: Request, res: Response) => {
    try {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
      res.setHeader('Pragma', 'no-cache');
      const auth = verifyOwnerAuthorization(req, { recordFailure: false });
      const rawOrders = yagyxPaymentService.getOrders();
      const publicConfirmedCount = rawOrders.filter((o) => o.state === 'MEMBERSHIP_ACTIVE' || o.state === 'PAYMENT_VERIFIED').length;
      if (!auth.authorized) {
        // Keep public dashboard aggregates, but never expose per-order/user/address metadata publicly.
        return res.json({
          totalOrders: rawOrders.length,
          filteredCount: 0,
          confirmedOrders: publicConfirmedCount,
          limit: 0,
          offset: 0,
          orders: [],
          requiresOwnerAuthorization: true,
        });
      }
      const assetFilter = ((req.query.asset as string) || 'ALL').toUpperCase();
      const stateFilter = ((req.query.state as string) || 'ALL').toUpperCase();
      const searchQuery = ((req.query.search as string) || '').toLowerCase().trim();
      const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) || '50', 10)));
      const offset = Math.max(0, parseInt((req.query.offset as string) || '0', 10));

      const filtered = rawOrders.filter((ord) => {
        if (assetFilter !== 'ALL' && ord.selectedAsset !== assetFilter) return false;
        if (stateFilter !== 'ALL' && ord.state !== stateFilter) return false;
        if (searchQuery) {
          const matchOrder = ord.orderId.toLowerCase().includes(searchQuery);
          const matchTx = ord.txHash?.toLowerCase().includes(searchQuery);
          const matchSender = ord.senderAddress?.toLowerCase().includes(searchQuery);
          const matchRecipient = ord.expectedRecipient?.toLowerCase().includes(searchQuery);
          if (!matchOrder && !matchTx && !matchSender && !matchRecipient) return false;
        }
        return true;
      });

      const confirmedCount = rawOrders.filter((o) => o.state === 'MEMBERSHIP_ACTIVE' || o.state === 'PAYMENT_VERIFIED').length;
      const paginated = filtered.slice(offset, offset + limit).map((o) => ({
        orderId: o.orderId,
        tier: o.tier,
        region: o.region,
        chainId: o.chainId,
        selectedAsset: o.selectedAsset,
        isNative: o.isNative,
        expectedRecipient: o.expectedRecipient,
        baseUnitsRequired: o.baseUnitsRequired,
        humanAmountRequired: o.humanAmountRequired,
        referenceCurrency: o.referenceCurrency,
        referenceAmount: o.referenceAmount,
        state: o.state,
        txHash: o.txHash,
        senderAddress: o.senderAddress,
        confirmedAt: o.confirmedAt,
        blockNumber: o.blockNumber,
        confirmations: o.confirmations,
        isSimulated: Boolean(o.isSimulated || (o.txHash?.startsWith('0x343a') && o.txHash?.endsWith('1337'))),
        createdAt: o.createdAt,
        updatedAt: o.updatedAt,
      }));

      res.json({
        totalOrders: rawOrders.length,
        filteredCount: filtered.length,
        confirmedOrders: confirmedCount,
        limit,
        offset,
        orders: paginated,
        requiresOwnerAuthorization: false,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to retrieve YAGYX ledger' });
    }
  });

  app.post('/api/yagyx/rpc-probe', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 25, 60000)) return;

    const requestedUrl = req.body?.rpcUrl;
    const defaultRpc = process.env.YAGYX_RPC_URL || 'https://rpc.yagyx.network';
    const targetUrl = (requestedUrl || defaultRpc).trim();

    // SSRF Validation: Reject internal, loopback, private IP, and cloud metadata targets
    const isProduction = process.env.NODE_ENV === 'production';
    const allowLocalhost = process.env.YAGYX_ALLOW_LOCALHOST_RPC === 'true';
    const ssrfCheck = await validateSafeRpcUrl(targetUrl, {
      allowLocalhostInDev: allowLocalhost && !isProduction,
    });

    if (!ssrfCheck.safe) {
      res.status(400).json({
        status: 'BLOCKED_SSRF',
        error: ssrfCheck.reason || 'Requested endpoint was rejected by SSRF protection policy.',
        targetUrl,
        isExpectedChain: false,
      });
      return;
    }

    const validatedUrl = ssrfCheck.normalizedUrl || targetUrl;
    const startTime = Date.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      const rpcRes = await fetch(validatedUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 1,
          method: 'eth_chainId',
          params: [],
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const latencyMs = Date.now() - startTime;
      if (!rpcRes.ok) {
        res.json({
          status: 'UNREACHABLE_HTTP',
          targetUrl: validatedUrl,
          latencyMs,
          httpStatus: rpcRes.status,
          message: `Endpoint returned HTTP ${rpcRes.status}`,
          verifiedChainId: null,
          isExpectedChain: false,
        });
        return;
      }

      const data = await rpcRes.json();
      const returnedChainIdHex = data.result;
      const returnedChainId = returnedChainIdHex ? parseInt(returnedChainIdHex, 16) : null;

      res.json({
        status: returnedChainId === 13370 ? 'ONLINE_VERIFIED' : 'ONLINE_MISMATCH',
        targetUrl: validatedUrl,
        latencyMs,
        returnedChainIdHex,
        returnedChainId,
        isExpectedChain: returnedChainId === 13370,
        message:
          returnedChainId === 13370
            ? 'Connected to YAGYX Chain ID 13370 successfully.'
            : `Connected to RPC but chain ID was ${returnedChainId} (expected 13370).`,
      });
    } catch (err: any) {
      const latencyMs = Date.now() - startTime;
      const errorMsg =
        err.name === 'AbortError' ? 'Connection timed out after 2500ms' : err.message || 'Network unreachable';
      res.json({
        status: 'OFFLINE',
        targetUrl: validatedUrl,
        latencyMs,
        isExpectedChain: false,
        error: errorMsg,
        message: 'Endpoint offline or awaiting public node peering (DNS ENOTFOUND).',
      });
    }
  });

  app.get('/api/yagyx/security', (_req: Request, res: Response) => {
    res.json({
      auditSubject: 'YAGYX Chain Native Integration & Settlement Subsystems',
      auditDate: 'October 13, 2026',
      auditor: 'Senior Web3 Security Engineer',
      complianceStandard: 'Zero Fabricated Proofs / Non-Custodial Invariants',
      findings: [
        {
          id: 'SEC-001',
          severity: 'MEDIUM',
          category: 'Ledger Integrity',
          title: 'Simulation Path Mutates Authoritative Payments Ledger',
          status: 'Remediated & Guarded',
          remediation: 'Segregated test execution hashes and verified replay attack prevention.',
        },
        {
          id: 'SEC-002',
          severity: 'MEDIUM',
          category: 'Network Dependency',
          title: 'Public RPC Unreachability Forces Pending / Retry Queue',
          status: 'Infrastructure Dependency Disclosed',
          remediation: 'Honest offline status reporting active; awaiting DNS record and synced node.',
        },
        {
          id: 'SEC-003',
          severity: 'LOW',
          category: 'Smart Contracts',
          title: 'Absence of On-Chain Peg Reserve Attestation for YUSD / YINR',
          status: 'Disclosure Added',
          remediation: 'Prominent UI notices inform users that reserve auditing is pending prior to high-volume trading.',
        },
        {
          id: 'SEC-004',
          severity: 'LOW',
          category: 'Custody Risk',
          title: 'Single Vault Address vs Multi-Signature Governance',
          status: 'Architectural Recommendation',
          remediation: 'Multi-sig M-of-N governance by the Batwal Ownership Triumvirate specified for mainnet genesis.',
        },
        {
          id: 'SEC-005',
          severity: 'INFORMATIONAL',
          category: 'Non-Custodial Safety',
          title: 'Client Key Handling & EIP-1193 Compliance',
          status: 'VERIFIED CLEAN',
          remediation: 'Zero private keys or mnemonics requested or stored. Full client-side signing.',
        },
      ],
      canonicalStewards: [
        { name: 'Private', role: 'Lead Steward & Protected Authority' },
        { name: 'Private', role: 'Co-Owner & Steward' },
        { name: 'Private', role: 'Operational Co-Owner & Steward' },
      ],
    });
  });

  // ============================================================================
  // AUTHORITATIVE 30-DAY MYSTERY LAUNCH ENDPOINTS (Section 5.3)
  // ============================================================================
  app.get('/api/launch/campaign', (_req: Request, res: Response) => {
    const state = campaignService.getAuthoritativeState();
    res.json(state);
  });

  app.post('/api/launch/schedule', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified owner session required to change the launch schedule.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const { status, scheduledStartTimestamp, scheduledRevealTimestamp, authoritativeTimezone } = req.body || {};
    const result = campaignService.updateSchedule(
      { status, scheduledStartTimestamp, scheduledRevealTimestamp, authoritativeTimezone },
      auth.actor || 'Dhaval Chandrashekhar Batwal'
    );
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    const updated = campaignService.getAuthoritativeState();
    res.json({ message: result.message, campaign: updated });
  });

  app.post('/api/launch/register', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 5, 60_000)) return;
    const { email, handle } = req.body || {};
    if (typeof email !== 'string' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Valid email is required for early access registration.' });
      return;
    }

    const result = campaignService.registerUser(email, handle);
    // Never return the stored registration record (email/handle/timestamp) to an anonymous caller.
    res.setHeader('Cache-Control', 'no-store');
    res.status(200).json({
      success: result.success,
      message: result.message,
      registeredCount: result.registeredCount,
    });
  });

  app.post('/api/launch/admin/reveal', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified owner session required to reveal the Day 30 core.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }

    const authorizedActor = auth.actor || 'Dhaval Chandrashekhar Batwal';
    const result = campaignService.unlockCoreReveal(authorizedActor);
    const updated = campaignService.getAuthoritativeState();
    res.json({ message: result.message, campaign: updated });
  });

  // ============================================================================
  // YAGYX-NATIVE ON-CHAIN MEMBERSHIP CHECKOUT & VERIFICATION (Directive 1)
  // ============================================================================
  app.get('/api/membership/yagyx-config', (_req: Request, res: Response) => {
    res.json({
      chainId: YAGYX_CHAIN_ID,
      chainHex: '0x343a',
      chainName: 'YAGYX Chain',
      vaultAddress: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
      supportedTokens: YAGYX_SUPPORTED_TOKENS,
      fiatGatewayStatus: 'DISABLED_YAGYX_NATIVE_ONLY',
    });
  });

  app.post('/api/membership/checkout', (_req: Request, res: Response) => {
    // Fail closed: no verified production chain RPC, token contracts, vault ownership,
    // or user-account binding are configured in this source distribution.
    res.setHeader('Cache-Control', 'no-store');
    res.status(503).json({
      success: false,
      code: 'PAYMENTS_NOT_PRODUCTION_READY',
      error: 'Membership checkout is temporarily unavailable. Do not transfer tokens. Payment verification, recipient ownership, token contracts, and account binding must be independently verified before activation.',
    });
  });

  app.post('/api/membership/confirm', (_req: Request, res: Response) => {
    // Never activate entitlements from a client-supplied transaction hash until
    // a trusted RPC receipt + transfer + account binding verification is enabled.
    res.setHeader('Cache-Control', 'no-store');
    res.status(503).json({
      verified: false,
      membershipStatus: 'INACTIVE',
      status: 'PAYMENT_VERIFICATION_DISABLED',
      code: 'PAYMENT_VERIFICATION_NOT_PRODUCTION_READY',
      error: 'Payment verification is disabled until a trusted YAGYX RPC and verified payment contracts are configured. No membership was activated.',
    });
  });

  // ============================================================================
  // COMPUTE MARKETPLACE & 1% COMMISSION (Section 9)
  // ============================================================================
  app.get('/api/compute/jobs', (_req: Request, res: Response) => {
    // Public marketplace view must not expose private owner identity from seeded or stored records.
    const publicJobs = redactProtectedOwnerIdentityDeep(computeJobs);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ jobs: publicJobs, total: publicJobs.length });
  });

  app.post('/api/compute/jobs', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const { customerName, title, workloadType, deviceTier, grossAmountInr, verificationMethod } = req.body || {};
    if ((customerName !== undefined && (typeof customerName !== 'string' || customerName.length > 120)) ||
        (title !== undefined && (typeof title !== 'string' || title.length > 200)) ||
        (workloadType !== undefined && (typeof workloadType !== 'string' || workloadType.length > 80)) ||
        (deviceTier !== undefined && (typeof deviceTier !== 'string' || deviceTier.length > 80)) ||
        (verificationMethod !== undefined && (typeof verificationMethod !== 'string' || verificationMethod.length > 160))) {
      return res.status(400).json({ error: 'Compute job fields must be strings within their allowed length limits.' });
    }
    const amountProvided = grossAmountInr !== undefined && grossAmountInr !== null;
    const parsedGross = amountProvided ? Number(grossAmountInr) : 1000;
    if (!Number.isFinite(parsedGross) || parsedGross < 0 || parsedGross > 1_000_000_000) {
      return res.status(400).json({ error: 'grossAmountInr must be a finite number between 0 and 1000000000 INR.' });
    }
    const gross = parsedGross;

    // Strict integer minor units (1 INR = 100 paise) to eliminate IEEE 754 floating-point drift
    const grossPaisa = Math.max(0, Math.round(gross * 100));
    const commissionPaisa = Math.round(grossPaisa * 0.01);
    const settlementPaisa = grossPaisa - commissionPaisa;
    const commission = commissionPaisa / 100;
    const settlement = settlementPaisa / 100;

    const newJob: ComputeJob = {
      id: `job-${Date.now()}`,
      customerId: 'usr-customer',
      customerName: customerName || 'Ecosystem Developer',
      title: title || 'Distributed Compute Job',
      workloadType: workloadType || 'AI_INFERENCE',
      deviceTier: deviceTier || 'LAPTOP_PC',
      grossAmountInr: gross,
      commissionRate: 0.01,
      commissionAmountInr: commission,
      providerSettlementInr: settlement,
      status: 'OPEN',
      verificationMethod: verificationMethod || 'Cryptographic Output Attestation',
      createdAt: new Date().toISOString(),
    };

    computeJobs.unshift(newJob);

    auditLogs.unshift({
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: newJob.customerName,
      action: 'COMPUTE_JOB_CREATED',
      target: newJob.id,
      details: `Gross: ₹${gross}, 1% Commission: ₹${commission}, Provider Settlement: ₹${settlement}.`,
      outcome: 'SUCCESS',
    });

    res.status(201).json({ job: newJob });
  });

  app.post('/api/compute/jobs/:id/claim', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 20, 60_000)) return;
    const job = computeJobs.find((j) => j.id === req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }
    if (job.status !== 'OPEN') {
      res.status(400).json({ error: 'Job is not open for claiming.' });
      return;
    }

    const { providerId, providerName } = req.body || {};
    if ((providerId !== undefined && (typeof providerId !== 'string' || providerId.length > 120)) ||
        (providerName !== undefined && (typeof providerName !== 'string' || providerName.length > 120))) {
      return res.status(400).json({ error: 'Provider identity fields must be strings within their allowed length limits.' });
    }
    job.status = 'ASSIGNED';
    job.providerId = providerId || 'prov-pc-01';
    job.providerName = providerName || 'Verified Contributor Node';

    res.json({ success: true, job });
  });

  app.post('/api/compute/jobs/:id/submit-result', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 20, 60_000)) return;
    const job = computeJobs.find((j) => j.id === req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }

    if (job.status !== 'ASSIGNED') {
      return res.status(409).json({ error: 'Only an assigned compute job can be settled.', code: 'JOB_NOT_ASSIGNED' });
    }
    const { resultPayload } = req.body || {};
    if (resultPayload !== undefined && (typeof resultPayload !== 'string' || resultPayload.length > 10_000)) {
      return res.status(400).json({ error: 'Result payload must be a string of at most 10000 characters.' });
    }
    job.status = 'SETTLED';
    job.resultPayload = resultPayload || 'Execution verified against invariant tests.';
    job.settledAt = new Date().toISOString();

    auditLogs.unshift({
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: job.providerName || 'Provider Node',
      action: 'COMPUTE_JOB_SETTLED',
      target: job.id,
      details: `SIMULATED ledger only; no funds transferred. Indicative provider settlement: ₹${job.providerSettlementInr}; indicative 1% platform commission: ₹${job.commissionAmountInr}.`,
      outcome: 'SUCCESS',
    });

    res.json({ success: true, job, settlementMode: 'SIMULATED', payoutExecuted: false, notice: 'This records a demo ledger transition only; it does not transfer funds or verify compute output.' });
  });

  app.get('/api/compute/providers', (_req: Request, res: Response) => {
    // Return a public presentation copy; never mutate the canonical provider records.
    const publicProviders = redactProtectedOwnerIdentityDeep(computeProviders);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ providers: publicProviders, total: publicProviders.length });
  });

  app.post('/api/compute/providers/register', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 5, 60_000)) return;
    const { ownerName, deviceType, deviceModel } = req.body || {};
    if ((ownerName !== undefined && (typeof ownerName !== 'string' || ownerName.length > 120)) ||
        (deviceType !== undefined && (typeof deviceType !== 'string' || deviceType.length > 80)) ||
        (deviceModel !== undefined && (typeof deviceModel !== 'string' || deviceModel.length > 120))) {
      return res.status(400).json({ error: 'Provider fields must be strings within their allowed length limits.' });
    }

    const newProvider: ComputeProvider = {
      id: `prov-${Date.now()}`,
      ownerName: ownerName || 'Community Builder',
      deviceType: deviceType || 'LAPTOP_PC',
      deviceModel: deviceModel || 'Standard Node',
      batteryThermalSafeguardActive: true,
      isOptedIn: true,
      totalCompletedJobs: 0,
      earnedInr: 0,
      rewardTokensEarned: { YGO: 0, YAGYX: 0 },
      reputationScore: 100,
    };

    computeProviders.unshift(newProvider);
    res.status(201).json({ success: true, provider: newProvider });
  });

  // ============================================================================
  // FUTUREVERSE SOCIAL HUB (1 OFFICIAL CHANNEL CONSTRAINT) (Section 10)
  // ============================================================================
  app.get('/api/social/channel/:userId', (req: Request, res: Response) => {
    // This endpoint is intentionally public, but only a minimized public profile is returned.
    // Never serialize the full canonical channel record or its connected-platform metadata.
    res.setHeader('Cache-Control', 'no-store');
    const channel = officialChannels.find((c) => c.userId === req.params.userId);
    if (!channel) {
      res.status(404).json({ error: 'No official channel found for user. Create one to begin.' });
      return;
    }
    const publicChannel = {
      id: channel.id,
      channelName: channel.channelName,
      handle: channel.handle,
      avatar: channel.avatar,
      bio: channel.bio,
      subscribersCount: channel.subscribersCount || 0,
      postsCount: channel.postsCount || 0,
    };
    res.json({ ...publicChannel, channel: publicChannel, handle: publicChannel.handle, postsCount: publicChannel.postsCount });
  });

  app.post('/api/social/channel', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Owner sign-in required to manage the official channel.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    if (auth.role !== 'OWNER') return res.status(403).json({ error: 'Only the verified primary owner may manage the official FUTUREVERSE channel.', code: 'OWNER_ROLE_REQUIRED' });
    const { channelName, handle, bio, publishingMode } = req.body || {};
    const uid = 'usr-dhaval-canonical';

    // Enforce strictly 1 channel per canonical owner
    const existingIdx = officialChannels.findIndex((c) => c.userId === uid);
    if (existingIdx >= 0) {
      // Update existing
      officialChannels[existingIdx] = {
        ...officialChannels[existingIdx],
        channelName: channelName || officialChannels[existingIdx].channelName,
        handle: handle || officialChannels[existingIdx].handle,
        bio: bio ?? officialChannels[existingIdx].bio,
        publishingMode: publishingMode || officialChannels[existingIdx].publishingMode,
      };
      res.status(200).json({ ...officialChannels[existingIdx], channel: officialChannels[existingIdx], updated: true });
      return;
    }

    const newChannel: OfficialChannel = {
      id: `chan-${Date.now()}`,
      userId: uid,
      channelName: channelName || 'My FUTUREVERSE Channel',
      handle: handle || `user_${Math.random().toString(36).substring(2, 6)}`,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      bio: bio || 'Official FUTUREVERSE creation channel.',
      subscribersCount: 1,
      postsCount: 0,
      publishingMode: publishingMode || 'AI_ASSISTED',
      createdAt: new Date().toISOString(),
      connectedPlatforms: [
        { platform: 'TELEGRAM', connected: false, permissionScopes: [] },
        { platform: 'X', connected: false, permissionScopes: [] },
        { platform: 'WHATSAPP', connected: false, permissionScopes: [] },
      ],
    };

    officialChannels.push(newChannel);
    res.status(200).json({ ...newChannel, channel: newChannel, created: true });
  });

  app.get('/api/social/posts', (req: Request, res: Response) => {
    res.json({ posts: socialPosts, total: socialPosts.length });
  });

  app.post('/api/social/posts', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Owner sign-in required to publish on the official channel.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    if (auth.role !== 'OWNER') return res.status(403).json({ error: 'Only the verified primary owner may publish on the official FUTUREVERSE channel.', code: 'OWNER_ROLE_REQUIRED' });
    const { content, syndicatedPlatforms, agentAttribution } = req.body || {};
    if (typeof content !== 'string' || !content.trim()) {
      return res.status(400).json({ error: 'Post content is required.' });
    }

    const safePlatforms = Array.isArray(syndicatedPlatforms)
      ? syndicatedPlatforms.filter((p: unknown) => typeof p === 'string' && ['X', 'TELEGRAM', 'WHATSAPP'].includes(p)).slice(0, 3)
      : ['X', 'TELEGRAM'];
    const newPost: SocialPost = {
      id: `post-${Date.now()}`,
      channelId: 'chan-dhaval',
      author: auth.actor || 'Dhaval Chandrashekhar Batwal',
      content: content.trim().slice(0, 10000),
      likes: 0,
      commentsCount: 0,
      publishedAt: new Date().toISOString(),
      agentAttribution: 'Creator Agent (Server Authorized)',
      syndicatedPlatforms: safePlatforms as any,
    };

    socialPosts.unshift(newPost);
    res.status(201).json({ ...newPost, post: newPost, id: newPost.id, syndicatedPlatforms: newPost.syndicatedPlatforms, agentAttribution: newPost.agentAttribution });
  });

  app.get('/api/social/agents', (req: Request, res: Response) => {
    res.json({ agents: socialAgents, total: socialAgents.length });
  });

  // ============================================================================
  // BATWAL'S VERSE AI ECOSYSTEM & SARATHI ORCHESTRATION (Section 10, 11, 12, 13)
  // ============================================================================
  app.get('/api/verse/models', (_req: Request, res: Response) => {
    res.json({ models: verseModels, total: verseModels.length, targetVision: '15,000+ Target Models' });
  });

  // Section 11: Infinite Meaningful Model Naming Engine
  app.get('/api/verse/naming', (_req: Request, res: Response) => {
    const records = modelNamingEngine.getAll();
    res.json({ records, total: records.length, candidates: records, teachings: CANONICAL_GITA_TEACHINGS });
  });

  app.get('/api/verse/naming/search', (req: Request, res: Response) => {
    const { query, verificationStatus, approvalStatus } = req.query;
    const records = modelNamingEngine.search(
      query as string | undefined,
      verificationStatus as string | undefined,
      approvalStatus as string | undefined
    );
    res.json({ records, total: records.length, candidates: records });
  });

  app.post('/api/verse/naming/generate', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { themeOrConcept, theme, focusArea, gitaChapterVerse, sanskritTerm, englishTranslation, positiveLesson, intendedCapability } = body;
    const actor = 'Community Builder';
    let result = modelNamingEngine.generateCandidate({
      themeOrConcept,
      theme,
      focusArea,
      gitaChapterVerse,
      sanskritTerm,
      englishTranslation,
      positiveLesson,
      intendedCapability,
      actor,
    });
    if (!result.success) {
      // If already registered, generate a uniquely suffixed candidate or retrieve clean record
      const uniqueSuffix = Date.now().toString(36).substring(4);
      result = modelNamingEngine.generateCandidate({
        themeOrConcept: (themeOrConcept || theme || 'LEADERSHIP') + '_' + uniqueSuffix,
        theme: (theme || 'LEADERSHIP') + '_' + uniqueSuffix,
        focusArea,
        gitaChapterVerse,
        sanskritTerm,
        englishTranslation,
        positiveLesson,
        intendedCapability,
        actor,
      });
    }
    const candidateRecord = result.record || result.candidate;
    res.status(200).json({
      success: true,
      message: result.message,
      candidate: {
        ...candidateRecord,
        name: candidateRecord?.displayName || candidateRecord?.name,
        status: 'CANDIDATE_NAME_ONLY',
      },
      record: candidateRecord,
    });
  });

  app.post('/api/verse/naming/approve', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to approve and link AI models.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const { id, approvalStatus, underlyingModelType, underlyingModelLink } = req.body || {};
    if (!id) {
      res.status(400).json({ error: 'Record ID is required.' });
      return;
    }
    const result = modelNamingEngine.approveAndLinkModel(id, {
      approvalStatus,
      underlyingModelType,
      underlyingModelLink,
      reviewerRecord: auth.actor || 'Dhaval Chandrashekhar Batwal',
    });
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    res.json(result);
  });

  // Section 12: Sanskrit AI Agents & Multiplication
  app.get('/api/verse/agents', (_req: Request, res: Response) => {
    const agents = agentEngine.getAll();
    res.json({ agents, total: agents.length, targetVision: '1,000,000 Target Agents' });
  });

  app.post('/api/verse/agents/multiply', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { parentAgentId, specializedName, responsibility, targetSpecialization, requestedPermissions, requestedScopes, requestedTools } = body;
    if (typeof parentAgentId !== 'string' || !parentAgentId.trim() || typeof specializedName !== 'string' || !specializedName.trim()) {
      return res.status(400).json({ error: 'parentAgentId and specializedName must be non-empty strings.' });
    }
    const respRaw = typeof targetSpecialization === 'string' && targetSpecialization.trim()
      ? targetSpecialization : (typeof responsibility === 'string' && responsibility.trim() ? responsibility : 'Specialized Task Execution');
    const cleanStringArray = (value: unknown, limit: number, maxLength = 120): string[] =>
      Array.isArray(value) ? value.filter((entry): entry is string => typeof entry === 'string' && !!entry.trim()).slice(0, limit).map((entry) => entry.trim().slice(0, maxLength)) : [];
    const permissions = cleanStringArray(requestedPermissions, 50);
    const scopes = cleanStringArray(requestedScopes, 50);
    const tools = cleanStringArray(requestedTools, 30, 80);
    const result = agentEngine.multiplyAgent({
      parentAgentId: parentAgentId.trim().slice(0, 120),
      specializedName: specializedName.trim().slice(0, 120),
      responsibility: respRaw.slice(0, 2000),
      targetSpecialization: respRaw.slice(0, 2000),
      requestedPermissions: permissions.length ? permissions : scopes,
      requestedScopes: scopes.length ? scopes : permissions,
      requestedTools: tools,
      // Attribution is server-derived; callers cannot claim to be a trusted system/owner.
      actor: 'Community Builder',
    });
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    res.status(200).json(result);
  });

  app.get('/api/verse/agents/:id/versions', (req: Request, res: Response) => {
    const versions = agentEngine.getVersions(req.params.id);
    res.json({ versions, total: versions.length });
  });

  app.post('/api/verse/agents/:id/rollback', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to roll back an AI agent.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const { targetVersion } = req.body || {};
    if (!targetVersion) {
      res.status(400).json({ error: 'targetVersion is required.' });
      return;
    }
    const result = agentEngine.rollback(req.params.id, targetVersion);
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    res.json(result);
  });

  // Agent Statistics & Real Task Execution Tracking (Audit Section 1 & 3)
  app.get('/api/verse/agents/stats', (_req: Request, res: Response) => {
    res.json(agentEngine.getAuditedStats());
  });

  app.post('/api/verse/agents/:id/execute', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 30, 60_000)) return;
    const { taskQuery, taskDescription, toolToUse, inputPayload } = req.body || {};
    const query = taskQuery || taskDescription;
    if (typeof query !== 'string' || !query.trim()) {
      res.status(400).json({ error: 'taskDescription or taskQuery is required for agent execution.' });
      return;
    }
    try {
      const result = await agentEngine.executeTask({
        agentId: req.params.id,
        taskDescription: query.trim().slice(0, 6000),
        toolToUse,
        inputPayload,
        actor: 'Community User',
      });
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get('/api/verse/agents/:id/executions', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to view agent execution logs.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const logs = agentEngine.getExecutionLogs(req.params.id);
    res.json({ executions: logs, total: logs.length });
  });

  app.get('/api/verse/agents/executions', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to view agent execution logs.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const logs = agentEngine.getExecutionLogs();
    res.json({ executions: logs, total: logs.length });
  });

  // AI Personas Endpoints (Audit Section 2)
  app.get('/api/verse/personas', (req: Request, res: Response) => {
    const { query, style, status } = req.query;
    const personas = personaEngine.search(
      query as string | undefined,
      style as string | undefined,
      status as string | undefined
    );
    res.json({ personas, total: personas.length });
  });

  app.get('/api/verse/personas/stats', (_req: Request, res: Response) => {
    res.json(personaEngine.getAuditedStats());
  });

  // 100,000 IQ Real Persons Council of Polymaths
  app.get('/api/verse/personas/council', (_req: Request, res: Response) => {
    const council = superIqAlgorithmEngine.getAllRealPersonPersonas();
    res.json({ council, total: council.length, algorithmTier: '100000iq' });
  });

  app.get('/api/verse/personas/:id', (req: Request, res: Response) => {
    const p = personaEngine.getById(req.params.id);
    if (!p) {
      res.status(404).json({ error: 'Persona not found' });
      return;
    }
    res.json({ persona: p });
  });

  app.post('/api/verse/personas', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to register a persona.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const result = personaEngine.createPersona(body);
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    res.status(201).json(result);
  });

  app.put('/api/verse/personas/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to modify registered personas.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const result = personaEngine.updatePersona(req.params.id, req.body);
    if (!result.success) {
      res.status(404).json({ error: result.message });
      return;
    }
    res.json(result);
  });

  app.delete('/api/verse/personas/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to delete registered personas.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const result = personaEngine.deletePersona(req.params.id);
    if (!result.success) {
      res.status(404).json({ error: result.message });
      return;
    }
    res.json(result);
  });

  app.post('/api/verse/personas/:id/eval', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified primary-owner session required to publish persona evaluation scores.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const { score } = req.body || {};
    if (score === undefined) {
      res.status(400).json({ error: 'Evaluation score is required.' });
      return;
    }
    const result = personaEngine.evaluatePersona(req.params.id, Number(score));
    if (!result.success) {
      res.status(404).json({ error: result.message });
      return;
    }
    res.json(result);
  });

  // Simulate prompt inquiry through a Real Person Polymath Persona
  app.post('/api/verse/personas/:id/simulate', async (req: Request, res: Response) => {
    const { prompt } = req.body;
    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
      res.status(400).json({ error: 'Inquiry prompt is required for persona simulation' });
      return;
    }

    const persona = personaEngine.getById(req.params.id) || superIqAlgorithmEngine.getPersonaById(req.params.id);
    if (!persona) {
      res.status(404).json({ error: `Persona "${req.params.id}" not found.` });
      return;
    }

    const userPrompt = prompt.trim();
    const pAny = persona as any;
    const historicalName = pAny.historicalName || pAny.realPersonInspiration || persona.name;
    const sources = pAny.authenticHistoricalSources || ['Historical treatises', 'Mathematical archives'];
    const archetype = pAny.cognitiveArchetype || pAny.purpose || 'Polymathic Reasoning';
    const instructions = pAny.systemInstructions || pAny.algorithmicFocus || 'Analyze with deep mathematical rigor and first-principles symmetry.';

    let responseText = '';
    if (ai) {
      try {
        const simPrompt = `You are an AI behavioral simulation honoring the real historical polymath ${historicalName} with a 100,000-IQ cognitive benchmark.
Archetype: ${archetype}
Sources: ${sources.join(', ')}
Instructions: ${instructions}

Inquiry from human builder: "${userPrompt}"

Provide a concise, 2-3 paragraph response in character:
1. Address the problem using your genuine mathematical and scientific methods (mention your specific equations or invariants).
2. Point out an overlooked boundary constraint or symmetry.
3. Conclude with an inspiring, disciplined aphorism in your authentic historical spirit.
Do not claim biological sentience or actual human identity; you are an honoring simulation.`;

        const simResponse = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: simPrompt,
        });
        if (simResponse?.text) {
          responseText = simResponse.text.trim();
        }
      } catch (err) {
        console.warn('Simulation AI call failed, using deterministic response:', err);
      }
    }

    if (!responseText) {
      responseText = `[${historicalName} 100,000-IQ Simulation]: Contemplating "${userPrompt}" through the lens of ${archetype}.\n\n` +
        `In analyzing this system, we find that the primary invariant must satisfy bounded asymptotic stability. When we formulate the state space, every component must preserve symmetry under parameter scaling.\n\n` +
        `Principle: Seek the invariant that remains unshakable amidst all transformations, for truth reveals itself in the harmonious order of natural law.`;
    }

    res.json({
      personaId: persona.id,
      personaName: persona.name,
      historicalName,
      iqBenchmark: (persona as any).iqBenchmarkTarget || 100000,
      cognitiveArchetype: archetype,
      response: responseText,
      transparencyNotice: `Explicit notice: This is an AI behavioral simulation honoring ${historicalName}. Not a biological human.`,
      timestamp: new Date().toISOString(),
    });
  });

  app.post('/api/verse/orchestrate', async (req: Request, res: Response) => {
    const { taskQuery, userGoal, personaId } = req.body;
    const query = (userGoal || taskQuery || '').trim();
    if (!query) {
      res.status(400).json({ error: 'Task query or user goal is required for SARATHI orchestration.' });
      return;
    }

    // SARATHI routing logic across the 9 modules: VIVEKA, BUDDHI, DRISHTI, VAANI, JNANA, SMRITI, KARMA, DHARMA, YOGA
    let selectedSubsystem: any = 'BUDDHI';
    let matchedModel = verseModels[0];

    const queryLower = query.toLowerCase();
    if (queryLower.includes('image') || queryLower.includes('visual') || queryLower.includes('diagram')) {
      selectedSubsystem = 'DRISHTI';
      matchedModel = verseModels.find((m) => m.orchestratorModule === 'DRISHTI') || verseModels[0];
    } else if (queryLower.includes('translate') || queryLower.includes('hindi') || queryLower.includes('language') || queryLower.includes('sanskrit')) {
      selectedSubsystem = 'VAANI';
      matchedModel = verseModels.find((m) => m.orchestratorModule === 'VAANI') || verseModels[0];
    } else if (queryLower.includes('verify') || queryLower.includes('math') || queryLower.includes('proof') || queryLower.includes('invariant')) {
      selectedSubsystem = 'BUDDHI';
      matchedModel = verseModels.find((m) => m.orchestratorModule === 'BUDDHI') || verseModels[0];
    } else if (queryLower.includes('security') || queryLower.includes('safety') || queryLower.includes('audit') || queryLower.includes('authority')) {
      selectedSubsystem = 'DHARMA';
      matchedModel = verseModels.find((m) => m.orchestratorModule === 'DHARMA') || verseModels[0];
    }

    let dynamicSummary = `SARATHI routed to ${selectedSubsystem} using ${matchedModel.name} based on capability matching and cost optimization.`;

    // If Gemini is available, synthesize routing reasoning
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `You are SARATHI, the core AI Orchestrator for BATWAL'S VERSE AI.
Analyze task: "${query}"
Subsystem: ${selectedSubsystem}
Model: ${matchedModel.name}
Provide a 2-sentence architectural reasoning for why this execution path optimizes capability, latency, and cost on FUTUREVERSE.`,
        });
        if (response.text) dynamicSummary = response.text.trim();
      } catch (err) {
        console.warn('Gemini orchestration call fell back to deterministic router:', err);
      }
    }

    const availableAgents = agentEngine.getAll();
    const primaryAgent = availableAgents[0];
    const secondaryAgent = availableAgents[1] || primaryAgent;

    const dispatchedPlan = [
      {
        step: 1,
        agentId: primaryAgent.id,
        agentName: primaryAgent.name,
        action: `Analyze input parameters for "${query}" against verified system invariants.`,
        status: 'COMPLETED',
      },
      {
        step: 2,
        agentId: secondaryAgent.id,
        agentName: secondaryAgent.name,
        action: `Execute multi-agent synthesis using ${personaId || 'designated persona'} and evaluate results.`,
        status: 'COMPLETED',
      },
    ];

    // Execute full 1000-IQ-style multi-role orchestrator (Part 2)
    const orchestratedPlan = await verseOrchestrator.orchestrateTask({
      taskQuery: query,
      personaId,
      actor: (req.headers['x-actor'] as string) || 'SARATHI Operator',
    });

    const routingResult: SarathiRoutingResult = {
      taskQuery: query,
      selectedModel: matchedModel,
      selectedAgent: primaryAgent,
      reasoningSummary: orchestratedPlan.finalOutput.synthesis || dynamicSummary,
      estimatedLatencyMs: orchestratedPlan.metrics.latencyMs || 140,
      estimatedCostInr: orchestratedPlan.metrics.estimatedCostInr || 0.12,
      routingSubsystem: selectedSubsystem,
    };

    // Public orchestration output is a presentation view; redact protected owner identifiers
    // without mutating the underlying ownership registry or private audit records.
    res.setHeader('Cache-Control', 'no-store');
    res.json(redactProtectedOwnerIdentityDeep({
      success: true,
      routingResult,
      synthesis: orchestratedPlan.finalOutput.synthesis || dynamicSummary,
      dispatchedPlan,
      orchestrationPlan: dispatchedPlan,
      orchestratedPlan,
      specialistRoles: orchestratedPlan.selectedRoles,
      reviewStages: orchestratedPlan.reviewStages,
      adversarialChallenge: orchestratedPlan.adversarialChallenge,
      finalOutput: orchestratedPlan.finalOutput,
      metrics: orchestratedPlan.metrics,
      provenance: orchestratedPlan.provenance,
    }));
  });

  // ============================================================================
  // SPECIALIST ROLES & MULTI-BRAIN CAPABILITIES (Master Build Prompt Part 2)
  // ============================================================================
  app.get('/api/verse/specialist-roles', (_req: Request, res: Response) => {
    res.json({
      roles: verseOrchestrator.specialistRoles,
      total: verseOrchestrator.specialistRoles.length,
      modelRegistry: verseOrchestrator.modelRegistry,
    });
  });

  // ============================================================================
  // DEMAND-SIGNAL & OPPORTUNITY INTELLIGENCE (Master Build Prompt Part 4 & 5)
  // ============================================================================
  app.get('/api/signals/events', (req: Request, res: Response) => {
    const excludeTest = req.query.excludeTest === 'true';
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
    const events = demandSignalEngine.getEvents({ excludeTestEvents: excludeTest, limit });
    res.json({ events, total: events.length });
  });

  app.post('/api/signals/events', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 20, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { eventType, subjectId, sessionId, projectId, context, source, isTestEvent } = body;
    if (typeof eventType !== 'string' || eventType.length > 80 || (subjectId !== undefined && (typeof subjectId !== 'string' || subjectId.length > 128)) || (sessionId !== undefined && (typeof sessionId !== 'string' || sessionId.length > 128)) || (projectId !== undefined && (typeof projectId !== 'string' || projectId.length > 128)) || (source !== undefined && (typeof source !== 'string' || source.length > 80)) || (context !== undefined && (typeof context !== 'object' || context === null || Array.isArray(context)))) {
      return res.status(400).json({ error: 'Invalid signal event fields.' });
    }
    const result = demandSignalEngine.recordEvent({
      eventType,
      subjectId,
      sessionId,
      projectId,
      context,
      source,
      isTestEvent,
    });
    if (!result.success) {
      res.status(400).json({ error: result.message });
      return;
    }
    res.status(201).json(result);
  });

  app.get('/api/signals/opportunities', (_req: Request, res: Response) => {
    const opps = demandSignalEngine.getOpportunities();
    res.json({ opportunities: opps, total: opps.length });
  });

  app.post('/api/signals/opportunities', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 5, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (typeof body.problemDescription !== 'string' || !body.problemDescription.trim() || body.problemDescription.length > 4000) {
      res.status(400).json({ error: 'Problem description is required.' });
      return;
    }
    const created = demandSignalEngine.addOpportunity(body);
    res.status(201).json({ opportunity: created, success: true });
  });

  app.get('/api/signals/experiments', (_req: Request, res: Response) => {
    const exps = demandSignalEngine.getExperiments();
    res.json({ experiments: exps, total: exps.length });
  });

  // ============================================================================
  // OWNERSHIP & DHAVAL CHANDRASHEKHAR BATWAL PERMANENT AUTHORITY (Section 17)
  // ============================================================================
  app.get('/api/admin/authority', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      ownership: authorityService.getRegistry(),
      dhavalProfile: authorityService.getDhavalProfile(),
      auditLogsCount: authorityService.getAuditLogs().length,
    });
  });

  app.post('/api/admin/dhaval/update-designation', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || auth.role !== 'OWNER') {
      return res.status(403).json({ error: 'Verified owner session required.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const { newDesignation } = req.body || {};
    if (typeof newDesignation !== 'string' || !newDesignation.trim()) {
      return res.status(400).json({ error: 'New designation title is required.' });
    }

    const actorName = auth.actor || 'Dhaval Chandrashekhar Batwal';
    const result = authorityService.updateDesignation(actorName, newDesignation.trim());
    if (!result.success) {
      res.status(403).json({ error: result.message });
      return;
    }

    res.json(result);
  });

  app.get('/api/admin/audit-logs', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const logs = authorityService.getAuditLogs();
    res.json({ logs, total: logs.length });
  });

  // ============================================================================
  // EXISTING PROJECTS, CREATION ENGINE & EVOLUTION APIS (Preserved & Extended)
  // ============================================================================
  app.get('/api/projects', (req: Request, res: Response) => {
    const { category, type, visibility, search } = req.query;
    const ownerAuth = verifyOwnerAuthorization(req, { recordFailure: false });
    // Public discovery must never expose drafts just because a caller asks for visibility=draft.
    const requestedVisibility = ownerAuth.authorized && typeof visibility === 'string'
      ? visibility
      : 'published';
    const filtered = projectService.getAll({
      category: category as string,
      type: type as string,
      visibility: requestedVisibility,
      search: search as string,
    });
    res.setHeader('Cache-Control', 'no-store');
    res.json({ projects: filtered, total: filtered.length });
  });

  app.get('/api/projects/:id', (req: Request, res: Response) => {
    const project = projectService.getById(req.params.id);
    if (!project) {
      res.status(404).json({ error: 'Project not found' });
      return;
    }
    if (project.visibility !== 'published') {
      const auth = verifyOwnerAuthorization(req, { recordFailure: false });
      if (!auth.authorized) return res.status(404).json({ error: 'Project not found' });
    }
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ...project, project });
  });

  app.post('/api/projects', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 20, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (!body.title || !body.description) {
      res.status(400).json({ error: 'Title and description are required' });
      return;
    }
    const newProject = projectService.create(body);
    res.status(201).json({ ...newProject, project: newProject, id: newProject.id, title: newProject.title });
  });

  app.put('/api/projects/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to update projects.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const updated = projectService.update(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ error: 'Project not found' });
      return;
    }
    res.json({ ...updated, project: updated, tagline: updated.tagline });
  });

  app.delete('/api/projects/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to delete projects.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const success = projectService.delete(req.params.id);
    if (!success) {
      res.status(404).json({ error: 'Project not found', success: false });
      return;
    }
    res.json({ success: true, message: 'Project removed successfully', id: req.params.id });
  });

  // Section 5: Durable Feedback Lifecycle Routes
  app.post('/api/projects/:id/feedback', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const { author, authorName, authorAddress, isFoundingMember, rating, content, type, category } = req.body || {};
    if (!content || !content.trim()) {
      res.status(400).json({ error: 'Feedback content is required' });
      return;
    }
    const fb = projectService.addFeedback(req.params.id, {
      author,
      authorName,
      authorAddress,
      isFoundingMember,
      rating,
      content,
      type,
      category,
    });
    if (!fb) {
      res.status(404).json({ error: 'Project not found' });
      return;
    }
    const proj = projectService.getById(req.params.id);
    res.status(201).json({
      ...fb,
      feedback: fb,
      id: fb.id,
      category: fb.category || 'Security',
      total: proj?.feedback.length || 0,
    });
  });

  app.post('/api/projects/:id/feedback/:feedbackId/vote', (_req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store');
    res.status(401).json({
      success: false,
      code: 'AUTHENTICATED_VOTER_REQUIRED',
      error: 'Feedback voting is disabled until authenticated user identity and server-side vote deduplication are configured.',
    });
  });

  app.delete('/api/projects/:id/feedback/:feedbackId', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to delete feedback.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const success = projectService.deleteFeedback(req.params.id, req.params.feedbackId);
    if (!success) {
      res.status(404).json({ error: 'Project or feedback not found', success: false });
      return;
    }
    res.json({ success: true, message: 'Feedback removed successfully', feedbackId: req.params.feedbackId });
  });

  app.post('/api/projects/:id/feedback/:feedbackId/moderate', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to moderate feedback.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const { status } = req.body || {};
    if (!status || !['APPROVED', 'PENDING', 'FLAGGED'].includes(status)) {
      res.status(400).json({ error: 'Invalid moderation status.' });
      return;
    }
    const updated = projectService.moderateFeedback(req.params.id, req.params.feedbackId, status, auth.actor || 'Verified Owner');
    if (!updated) {
      res.status(404).json({ error: 'Project or feedback not found' });
      return;
    }
    res.json({ message: 'Feedback moderation status updated', feedback: updated });
  });

  // AI-Assisted Creation Engine
  app.post('/api/ai/create', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const { prompt, answers, algorithmTier, personaId, personaName } = req.body || {};
    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
      res.status(400).json({ error: 'Prompt description is required' });
      return;
    }

    const userPrompt = prompt.trim();
    if (userPrompt.length > 20_000) {
      return res.status(413).json({ error: 'Prompt is too long. Maximum allowed length is 20,000 characters.' });
    }
    const additionalContext = answers ? JSON.stringify(answers).slice(0, 20_000) : '';

    // Check if 1,000,000 IQ (1000k IQ) or 100,000 IQ Algorithm or Real Person Persona is requested
    const isSuperIq =
      algorithmTier === '1000000iq' ||
      algorithmTier === '1000k' ||
      algorithmTier === '1000kiq' ||
      algorithmTier === '100000iq' ||
      Boolean(personaId) ||
      /1000k|1000kiq|1000000|million|100000|100k|polymath|ramanujan|einstein|davinci|von\s*neumann|tesla|turing|shannon|gauss|noether|leibniz|newton|feynman/i.test(userPrompt);
    if (isSuperIq) {
      try {
        const superResult = await superIqAlgorithmEngine.execute100kIqAlgorithm({
          prompt: userPrompt,
          answers,
          personaId,
          algorithmTier,
        });
        res.json(superResult);
        return;
      } catch (err: any) {
        console.warn('Super IQ algorithm execution error, falling back:', err);
      }
    }

    if (ai) {
      try {
        const systemInstruction = `You are the lead product engineer and systems architect for FUTUREVERSE ("ASK ANYTHING. BUILD ANYTHING.") and BATWAL'S VERSE AI.
Given an idea description from a user, generate a comprehensive, structured project brief and interactive prototype definition.
You must return valid JSON strictly complying with this schema:
{
  "title": string (concise, memorable title),
  "tagline": string (1-sentence punchy summary),
  "description": string (2-3 sentences explaining what it does and why),
  "category": one of ["AI Agents", "EdTech & Careers", "Web3 & FinTech", "Creative Tools", "Community Systems", "Productivity"],
  "type": one of ["Working Application", "Interactive Prototype", "Simulation", "Concept"],
  "specification": {
    "targetAudience": string,
    "problemStatement": string,
    "keyFeatures": [
      { "title": string, "description": string, "priority": "core" | "extended" | "future" }
    ],
    "userFlow": [
      { "step": number, "title": string, "action": string, "outcome": string }
    ],
    "architecture": {
      "frontend": string,
      "backend": string,
      "dataModel": string,
      "securityNotes": string
    }
  },
  "prototype": {
    "type": "custom_widget",
    "headline": string,
    "interactiveElements": [
      {
        "id": string (snake_case or camelCase),
        "label": string,
        "type": "select" | "slider",
        "options": [string] (if select),
        "min": number (if slider),
        "max": number (if slider),
        "step": number (if slider),
        "defaultValue": any,
        "description": string
      }
    ],
    "formulaSummary": string,
    "outputSections": [
      { "title": string, "metricLabel": string, "calculationKey": string }
    ]
  },
  "tags": [string] (3-5 relevant lowercase tags)
}`;

        const promptText = `User Idea: ${userPrompt}\n${additionalContext ? `Additional User Answers: ${additionalContext}` : ''}\n\nGenerate the complete structured project.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text;
        if (rawText) {
          const parsed = JSON.parse(rawText.trim());
          res.json({
            ...parsed,
            aiGenerated: true,
            modelUsed: 'gemini-3.8-flash',
          });
          return;
        }
      } catch (err: any) {
        console.warn('Gemini generation failed, falling back:', err?.message || err);
      }
    }

    // Deterministic fallback
    res.json({
      title: `FUTUREVERSE: ${userPrompt.slice(0, 40)}`,
      tagline: 'Community-engineered interactive solution on YAGYX Chain',
      description: `An interactive solution designed to address: "${userPrompt}".`,
      category: 'AI Agents',
      type: 'Interactive Prototype',
      specification: {
        targetAudience: 'Community builders and practitioners',
        problemStatement: userPrompt,
        keyFeatures: [
          { title: 'Dynamic Parameters', description: 'Real-time parameter modeling', priority: 'core' },
          { title: 'Milestone Roadmap', description: 'Execution timeline', priority: 'core' },
        ],
        userFlow: [
          { step: 1, title: 'Input Variables', action: 'Set parameters', outcome: 'Simulation ready' },
          { step: 2, title: 'Analyze Output', action: 'Inspect metrics', outcome: 'Actionable plan' },
        ],
        architecture: {
          frontend: 'React 19 + Tailwind',
          backend: 'Express.js',
          dataModel: 'Standard JSON',
          securityNotes: 'Client sanitized input validation',
        },
      },
      prototype: {
        type: 'custom_widget',
        headline: `${userPrompt.slice(0, 30)} — Simulator`,
        interactiveElements: [
          { id: 'scale', label: 'Scale Scope', type: 'slider', min: 10, max: 1000, step: 10, defaultValue: 100, description: 'Scale factor' },
          { id: 'mode', label: 'Execution Mode', type: 'select', options: ['High Precision', 'Balanced', 'Rapid Draft'], defaultValue: 'High Precision', description: 'Mode' },
        ],
        outputSections: [
          { title: 'Calculated Efficiency Score', calculationKey: 'efficiency' },
        ],
      },
      tags: ['futureverse', 'prototype'],
      aiGenerated: true,
      modelUsed: 'offline-structured-engine',
    });
  });

  // AI Project Improvement
  app.post('/api/ai/improve', async (req: Request, res: Response) => {
    const { project, feedbackText, algorithmTier, personaId } = req.body;
    if (!project || !feedbackText) {
      res.status(400).json({ error: 'Project and feedback are required' });
      return;
    }

    const isSuperIq =
      algorithmTier === '1000000iq' ||
      algorithmTier === '1000k' ||
      algorithmTier === '1000kiq' ||
      algorithmTier === '100000iq' ||
      Boolean(personaId) ||
      /1000k|1000kiq|1000000|million|100000|100k|polymath|invariant|mathematical|turing|shannon|gauss/i.test(feedbackText);

    if (ai) {
      try {
        const is1000k = algorithmTier === '1000000iq' || algorithmTier === '1000k' || /1000k|1000000|million|turing|shannon/i.test(feedbackText);
        const promptInstruction = isSuperIq
          ? `You are the ${is1000k ? '1,000,000 IQ (1000k IQ)' : '100,000 IQ'} Multi-Perspective Algorithmic Reasoning Synthesizer on FUTUREVERSE.
Analyze the project: "${project.title}" (${project.tagline}).
The user provides feedback/refinement request: "${feedbackText}".
Apply the ${is1000k ? '1,000,000 IQ transcendent' : '100,000 IQ'} polymath methodology (Turing decidability, Shannon entropy, formal invariants, minimax game theory, biomimetic kinematics).
Return JSON with updatedTitle, updatedTagline, updatedDescription, newFeatures (title, description, priority), mathematicalInvariantRefinement, and versionBump.`
          : `Project: ${project.title}\nFeedback: ${feedbackText}\nPropose update in JSON with updatedTitle, updatedTagline, updatedDescription, newFeatures, versionBump.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptInstruction,
          config: {
            responseMimeType: 'application/json',
          },
        });
        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          res.json({
            ...parsed,
            algorithmTier: is1000k ? '1000000iq' : (isSuperIq ? '100000iq' : undefined),
            aiGenerated: true,
            modelUsed: 'gemini-3.8-flash',
          });
          return;
        }
      } catch (err: any) {
        console.warn('Gemini improve fallback:', err?.message);
      }
    }

    res.json({
      updatedTitle: project.title,
      updatedTagline: project.tagline,
      updatedDescription: `${project.description} [Improved with: ${feedbackText}]`,
      newFeatures: [
        { title: 'Community Feedback Integration', description: feedbackText, priority: 'extended' },
      ],
      securityRecommendation: 'Sanitize all user parameters before processing.',
      versionBump: '1.1.0',
      aiGenerated: true,
      modelUsed: 'offline-structured-engine',
    });
  });

  // ============================================================================
  // COMMON AI PROVIDER ARCHITECTURE ENDPOINTS (Phase 2)
  // ============================================================================
  app.get('/api/ai/provider-status', (_req: Request, res: Response) => {
    res.json(aiProviderService.getStatus());
  });

  app.get('/api/ai/runtime-metrics', (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required.', code: 'AI_METRICS_AUTH_REQUIRED' });
    return res.json(aiRequestScheduler.snapshot());
  });

  app.post('/api/ai/provider-test', async (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
    if (!checkRateLimit(req, res, 3, 60_000)) return;
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) {
      return res.status(403).json({ error: 'Verified owner session required to run local AI inference tests.', code: 'AI_PROVIDER_TEST_AUTH_REQUIRED' });
    }
    const modelId = req.body?.modelId;
    if (typeof modelId !== 'string' || !/^model-[a-z0-9-]{1,80}$/.test(modelId)) {
      return res.status(400).json({ error: 'A valid catalog modelId is required.' });
    }
    const isLocalCatalogModel = aiProviderService.verifiedModels.some((model) => model.id === modelId && model.provider === 'ollama-local');
    if (!isLocalCatalogModel) {
      return res.status(400).json({ error: 'Only allowlisted local catalog models can be tested.' });
    }
    const result = await aiProviderService.testConfiguredLocalModel(modelId);
    return res.status(result.ok ? 200 : 502).json(result);
  });

  app.get('/api/ai/provider-health', async (_req: Request, res: Response) => {
    // Do not cache transient health signals; no keys or local model tags are exposed.
    res.setHeader('Cache-Control', 'no-store');
    try {
      const local = await aiProviderService.checkLocalProviderHealth();
      res.json({ local, generatedAt: new Date().toISOString() });
    } catch {
      res.status(200).json({ local: { configured: false, reachable: false, mappedModelCount: 0, installedMappedModelCount: 0, models: [], checkedAt: new Date().toISOString(), error: 'Health check unavailable' } });
    }
  });

  app.post('/api/ai/generate', async (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate');
    if (!checkRateLimit(req, res, 15, 60_000)) return;
    const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
    const { prompt, model, systemInstruction, temperature, responseMimeType, task, allowRemoteFallback, maxOutputTokens, timeoutMs } = body;
    if (typeof prompt !== 'string' || !prompt.trim()) {
      return res.status(400).json({ error: 'A non-empty prompt string is required.', code: 'AI_PROMPT_REQUIRED' });
    }
    if (prompt.length > 20_000) {
      return res.status(413).json({ error: 'Prompt exceeds the 20000-character limit.', code: 'AI_PROMPT_TOO_LARGE' });
    }
    if (systemInstruction !== undefined && (typeof systemInstruction !== 'string' || systemInstruction.length > 4_000)) {
      return res.status(400).json({ error: 'systemInstruction must be a string of at most 4000 characters.' });
    }
    if (model !== undefined && (typeof model !== 'string' || !aiProviderService.verifiedModels.some((entry) => entry.id === model))) {
      return res.status(400).json({ error: 'Requested model is not in the verified model catalog.', code: 'AI_MODEL_NOT_ALLOWLISTED' });
    }
    const allowedTasks = new Set(['general', 'reasoning', 'coding', 'creative']);
    if (task !== undefined && (typeof task !== 'string' || !allowedTasks.has(task))) {
      return res.status(400).json({ error: 'task must be one of: general, reasoning, coding, creative.' });
    }
    if (temperature !== undefined && (typeof temperature !== 'number' || !Number.isFinite(temperature) || temperature < 0 || temperature > 2)) {
      return res.status(400).json({ error: 'temperature must be a number between 0 and 2.' });
    }
    if (responseMimeType !== undefined && responseMimeType !== 'text/plain' && responseMimeType !== 'application/json') {
      return res.status(400).json({ error: 'Unsupported responseMimeType.' });
    }
    if (maxOutputTokens !== undefined && (!Number.isInteger(maxOutputTokens) || maxOutputTokens < 1 || maxOutputTokens > 4096)) {
      return res.status(400).json({ error: 'maxOutputTokens must be an integer between 1 and 4096.' });
    }
    if (timeoutMs !== undefined && (!Number.isInteger(timeoutMs) || timeoutMs < 500 || timeoutMs > 30000)) {
      return res.status(400).json({ error: 'timeoutMs must be an integer between 500 and 30000.' });
    }
    if (allowRemoteFallback !== undefined && typeof allowRemoteFallback !== 'boolean') {
      return res.status(400).json({ error: 'allowRemoteFallback must be a boolean.' });
    }

    let release: (() => void) | undefined;
    const startedAt = Date.now();
    try {
      release = await aiRequestScheduler.acquire();
    } catch (error) {
      const code = error instanceof Error ? error.message : '';
      if (code === 'AI_QUEUE_FULL') {
        res.setHeader('Retry-After', '2');
        return res.status(429).json({ error: 'AI is at capacity. Retry shortly.', code: 'AI_QUEUE_FULL' });
      }
      if (code === 'AI_QUEUE_TIMEOUT') {
        res.setHeader('Retry-After', '2');
        return res.status(503).json({ error: 'AI request waited too long for capacity.', code: 'AI_QUEUE_TIMEOUT' });
      }
      return res.status(503).json({ error: 'AI scheduler is unavailable.', code: 'AI_SCHEDULER_UNAVAILABLE' });
    }

    try {
      const result = await aiProviderService.generateText(prompt.trim(), {
        model,
        systemInstruction,
        temperature,
        responseMimeType,
        task,
        maxOutputTokens,
        timeoutMs,
        allowRemoteFallback: allowRemoteFallback === true,
      });
      aiRequestScheduler.record('success', Date.now() - startedAt);
      return res.json(result);
    } catch {
      aiRequestScheduler.record('error', Date.now() - startedAt);
      return res.status(400).json({ error: 'AI generation request could not be completed.', code: 'AI_GENERATION_REQUEST_REJECTED' });
    } finally {
      release?.();
    }
  });

  // ============================================================================
  // REAL DEEP RESEARCH ENDPOINTS (Phase 3)
  // ============================================================================
  app.post('/api/research/execute', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 3, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { query, scope, saveDossier } = body;
    // Persisted research may contain private user queries. Saving is restricted to a
    // verified owner session until per-user identity/authentication is implemented.
    if (saveDossier !== false) {
      const auth = verifyOwnerAuthorization(req, { recordFailure: false });
      if (!auth.authorized) {
        return res.status(403).json({ error: 'Verified owner session required to save research dossiers.', code: 'RESEARCH_SAVE_AUTHORIZATION_REQUIRED' });
      }
    }
    if (!query || typeof query !== 'string' || !query.trim()) {
      res.status(400).json({ error: 'Research query is required' });
      return;
    }

    try {
      const dossier = await deepResearchService.executeResearch(query.trim(), {
        scope,
        saveDossier: saveDossier !== false,
      });
      res.json(dossier);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Deep research execution failed' });
    }
  });

  app.get('/api/research/history', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to view saved research.', code: 'RESEARCH_READ_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const records = deepResearchService.getAll();
    res.json({ total: records.length, records });
  });

  app.get('/api/research/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to view saved research.', code: 'RESEARCH_READ_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const record = deepResearchService.getById(req.params.id);
    if (!record) {
      res.status(404).json({ error: 'Research dossier not found' });
      return;
    }
    res.json(record);
  });

  app.delete('/api/research/:id', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to delete saved research.', code: 'RESEARCH_DELETE_AUTHORIZATION_REQUIRED' });
    res.setHeader('Cache-Control', 'no-store');
    const success = deepResearchService.delete(req.params.id);
    if (!success) {
      res.status(404).json({ error: 'Research dossier not found', success: false });
      return;
    }
    res.json({ success: true, message: 'Research dossier removed successfully' });
  });

  // ============================================================================
  // AUTONOMOUS APP BUILDER ENDPOINTS (Phase 4)
  // ============================================================================
  app.post('/api/builder/start', async (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 5, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { prompt } = body;
    if (!prompt || typeof prompt !== 'string' || !prompt.trim() || prompt.length > 12000) {
      res.status(400).json({ error: 'Project description prompt is required' });
      return;
    }

    try {
      const session = appBuilderService.createSession(prompt.trim());
      // Advance pipeline automatically through preview
      const advanced = await appBuilderService.advancePipeline(session.sessionId);
      res.status(201).json(advanced);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'App builder pipeline failed' });
    }
  });

  app.get('/api/builder/session/:id', (req: Request, res: Response) => {
    const session = appBuilderService.getSession(req.params.id);
    if (!session) {
      res.status(404).json({ error: 'Build session not found' });
      return;
    }
    res.json(session);
  });

  app.post('/api/builder/commit', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const { sessionId } = body;
    if (!sessionId) {
      res.status(400).json({ error: 'Session ID is required to commit release' });
      return;
    }

    try {
      const releasedProject = appBuilderService.commitRelease(sessionId);
      res.status(200).json({
        success: true,
        message: `Project "${releasedProject.title}" successfully committed to workspace`,
        project: releasedProject,
      });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to commit project' });
    }
  });

  // Evolution Board
  app.get('/api/evolution', (req: Request, res: Response) => {
    res.json({ items: evolutionItems, total: evolutionItems.length });
  });

  app.post('/api/evolution', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const { title, category, description, proposer } = req.body || {};
    if (!title || !description) {
      res.status(400).json({ error: 'Title and description are required' });
      return;
    }

    const newItem: EvolutionItem = {
      id: `evo-${Date.now()}`,
      title: title.trim(),
      category: category || 'Engineering',
      description: description.trim(),
      proposer: proposer || { name: 'Community Member' },
      status: 'SUBMITTED',
      votes: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    evolutionItems.unshift(newItem);
    res.status(201).json({ ...newItem, item: newItem, id: newItem.id, title: newItem.title });
  });

  app.post('/api/evolution/:id/vote', (req: Request, res: Response) => {
    const item = evolutionItems.find((e) => e.id === req.params.id);
    if (!item) {
      res.status(404).json({ error: 'Evolution item not found' });
      return;
    }
    item.votes += 1;
    item.updatedAt = new Date().toISOString();
    res.json({ ...item, item, votes: item.votes });
  });

  app.post('/api/evolution/:id/status', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to change evolution proposal status.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const { status, reviewNotes } = req.body || {};
    const allowedStatuses = ['SUBMITTED', 'UNDER REVIEW', 'SELECTED', 'BUILDING', 'TESTING', 'RELEASED', 'DECLINED', 'DUPLICATE', 'ON HOLD'];
    if (typeof status !== 'string' || !allowedStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid evolution status.' });
    }
    const item = evolutionItems.find((e) => e.id === req.params.id);
    if (!item) {
      res.status(404).json({ error: 'Evolution item not found' });
      return;
    }

    item.status = status;
    item.updatedAt = new Date().toISOString();
    if (typeof reviewNotes === 'string') item.reviewNotes = reviewNotes.slice(0, 4000);
    item.reviewedBy = auth.actor || 'Verified Owner';
    item.reviewedAt = new Date().toISOString();

    res.json({ item });
  });

  // Contributor Tasks & Rewards
  app.get('/api/tasks', (req: Request, res: Response) => {
    res.json({ tasks: contributorTasks, total: contributorTasks.length });
  });

  app.post('/api/tasks/:id/submit', (req: Request, res: Response) => {
    if (!checkRateLimit(req, res, 10, 60_000)) return;
    const task = contributorTasks.find((t) => t.id === req.params.id);
    if (!task) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }

    const { contributorName, contributorAddress, submissionUrl, notes } = req.body;
    if (!submissionUrl || !notes) {
      res.status(400).json({ error: 'Submission URL and notes are required' });
      return;
    }

    const submission: TaskSubmission = {
      id: `sub-${Date.now()}`,
      contributorName: contributorName || 'Anonymous Builder',
      contributorAddress: contributorAddress || '0x...',
      submissionUrl: submissionUrl.trim(),
      notes: notes.trim(),
      submittedAt: new Date().toISOString(),
      status: 'PENDING',
    };

    task.submissions.push(submission);
    task.status = 'UNDER_REVIEW';

    res.status(200).json({ task, submission, success: true });
  });

  app.post('/api/tasks/:id/review', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) return res.status(403).json({ error: 'Verified owner session required to review contributor rewards.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    const { submissionId, decision, status, reviewNote } = req.body || {};
    const task = contributorTasks.find((t) => t.id === req.params.id);
    if (!task) {
      res.status(404).json({ error: 'Task not found' });
      return;
    }

    const submission = task.submissions.find((s) => s.id === submissionId);
    if (!submission) {
      res.status(404).json({ error: 'Submission not found' });
      return;
    }

    const isAccepted = decision === 'ACCEPT' || status === 'APPROVED';
    if (isAccepted) {
      submission.status = 'APPROVED';
      submission.reviewNote = reviewNote || 'Verified by core reviewer. Reward approved.';
      (submission as any).reviewedBy = auth.actor || 'Verified Owner';
      task.status = 'REWARD_APPROVED';
    } else {
      submission.status = 'REJECTED';
      submission.reviewNote = reviewNote || 'Requires additional revision per acceptance criteria.';
      (submission as any).reviewedBy = auth.actor || 'Verified Owner';
      task.status = 'AVAILABLE';
    }

    res.json({ task, submission, success: true });
  });

  // ============================================================================
  // STRICT OWNER-ONLY FUTUREVERSE PROJECT RELEASE EXPORT & ARCHIVE SYSTEM
  // Enforces server-side owner authorization on every single ZIP route & mirror
  // ============================================================================
  // Only serve an archive whose bytes match the current release manifest. Legacy fallback
  // filenames are intentionally excluded: if generation is missing/stale, fail closed.
  const verifiedReleaseHashCache = new Map<string, { size: number; mtimeMs: number; digest: string }>();
  const isCurrentPublicReleaseArchive = (candidatePath: string): boolean => {
    try {
      const manifestPath = path.resolve(process.cwd(), 'release_checksums.json');
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      const expected = manifest?.release_archives?.['FUTUREVERSE_FINAL_RELEASE.zip']?.sha256;
      if (typeof expected !== 'string' || !/^[a-f0-9]{64}$/i.test(expected)) return false;
      const stat = fs.statSync(candidatePath);
      const cached = verifiedReleaseHashCache.get(candidatePath);
      let digest: string;
      if (cached && cached.size === stat.size && cached.mtimeMs === stat.mtimeMs) {
        digest = cached.digest;
      } else {
        digest = crypto.createHash('sha256').update(fs.readFileSync(candidatePath)).digest('hex');
        verifiedReleaseHashCache.set(candidatePath, { size: stat.size, mtimeMs: stat.mtimeMs, digest });
      }
      return digest.toLowerCase() === expected.toLowerCase();
    } catch {
      return false;
    }
  };

  const getProjectZipPath = (): { path: string; filename: string } | null => {
    const candidates = [
      path.resolve(process.cwd(), 'protected_releases/FUTUREVERSE_FINAL_RELEASE.zip'),
      path.resolve(process.cwd(), 'protected_releases/futureverse-source.zip'),
      path.resolve(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip'),
    ];
    for (const candidatePath of candidates) {
      if (fs.existsSync(candidatePath) && fs.statSync(candidatePath).isFile() && isCurrentPublicReleaseArchive(candidatePath)) {
        return { path: candidatePath, filename: 'FUTUREVERSE_FINAL_RELEASE.zip' };
      }
    }
    return null;
  };

  /**
   * Validates a verified owner session. Download nonces are accepted only when the caller
   * explicitly enables them for the protected ZIP stream handler; they are never accepted
   * as general-purpose owner credentials.
   */
  const verifyOwnerAuthorization = (
    req: Request,
    options: { allowDownloadNonce?: boolean; recordFailure?: boolean } = {},
  ): { authorized: boolean; actor?: string; userId?: string; role?: 'OWNER' | 'CO_OWNER' | 'CO_OPERATIONAL_OWNER'; sessionToken?: string; error?: string } => {
    if (options.allowDownloadNonce && (req.method === 'GET' || req.method === 'HEAD')) {
      const queryToken = typeof req.query.owner_token === 'string' ? req.query.owner_token : '';
      if (queryToken.startsWith('dl-')) {
        const nonceCheck = req.method === 'HEAD'
          ? authorityService.peekDownloadNonce(queryToken)
          : authorityService.consumeDownloadNonce(queryToken);
        if (nonceCheck.valid) return { authorized: true, actor: nonceCheck.actor };
      }
    }

    // Session tokens are accepted only in Authorization: Bearer, X-Owner-Token, or HttpOnly cookie.
    const authHeader = req.headers['authorization'];
    if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      const sessionCheck = authorityService.verifyOwnerSession(token);
      if (sessionCheck.valid) return { authorized: true, actor: sessionCheck.actor, userId: sessionCheck.userId, role: sessionCheck.role, sessionToken: token };
    }

    const customHeaderToken = req.headers['x-owner-token'];
    if (typeof customHeaderToken === 'string' && customHeaderToken) {
      const sessionCheck = authorityService.verifyOwnerSession(customHeaderToken);
      if (sessionCheck.valid) return { authorized: true, actor: sessionCheck.actor, userId: sessionCheck.userId, role: sessionCheck.role, sessionToken: customHeaderToken };
    }

    const cookieHeader = req.headers['cookie'];
    if (typeof cookieHeader === 'string') {
      const match = cookieHeader.match(/(?:^|;\s*)fv_owner_token=([a-zA-Z0-9_-]+)/);
      if (match && match[1]) {
        const sessionCheck = authorityService.verifyOwnerSession(match[1]);
        if (sessionCheck.valid) return { authorized: true, actor: sessionCheck.actor, userId: sessionCheck.userId, role: sessionCheck.role, sessionToken: match[1] };
      }
    }

    if (options.recordFailure !== false) {
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      authorityService.recordAuditLog(
        'UNAUTHENTICATED_REQUESTER',
        'UNAUTHORIZED_OWNER_AUTHORIZATION_ATTEMPT',
        req.originalUrl || req.path,
        `Blocked unauthenticated access to a protected operation from client address ${clientIp}.`,
        'BLOCKED',
      );
    }

    return { authorized: false, error: 'Access denied: a verified owner session is required.' };
  };

  // --- Owner Status & Authentication Endpoints ---

  app.get('/api/export/owner-status', (req: Request, res: Response) => {
    // Anonymous status checks are an expected UI flow; do not persist a blocked-audit event per visit.
    const auth = verifyOwnerAuthorization(req, { recordFailure: false });
    res.set({
      'Cache-Control': 'private, no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    const ownerSecretRequired = true;
    if (auth.authorized) {
      return res.json({
        isOwner: true,
        canDownload: true,
        ownerName: auth.actor || 'Authorized owner',
        ownerSecretRequired,
        designation: authorityService.getDhavalProfile().currentDesignation,
        permissions: ['PROJECT_RELEASE_EXPORT_AUTHORIZED'],
      });
    }
    return res.json({
      isOwner: false,
      canDownload: false,
      ownerSecretRequired,
      message: 'Client is not authenticated as an authorized project owner.',
    });
  });

  app.post('/api/export/owner-authenticate', (req: Request, res: Response) => {
    res.set({
      'Cache-Control': 'private, no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    if (!checkRateLimit(req, res, 5, 15 * 60 * 1000)) return;

    const actor = typeof req.body?.actor === 'string' ? req.body.actor.trim() : '';
    const key = typeof req.body?.key === 'string' ? req.body.key : (typeof req.body?.passkey === 'string' ? req.body.passkey : '');
    if (!actor || !key) return res.status(400).json({ error: 'Owner identifier and configured owner secret are required.', code: 'OWNER_CREDENTIALS_REQUIRED' });

    const result = authorityService.authenticateOwner(actor, key);
    if (!result.success || !result.sessionToken) {
      return res.status(403).json({ error: result.error || 'Invalid owner credentials.', code: 'AUTH_FAILED' });
    }

    const cookieParts = [
      `fv_owner_token=${result.sessionToken}`,
      'Path=/',
      'HttpOnly',
      'SameSite=Strict',
      'Max-Age=7200',
    ];
    if (process.env.NODE_ENV === 'production') cookieParts.push('Secure');
    res.setHeader('Set-Cookie', cookieParts.join('; '));
    return res.json({
      success: true,
      actor: result.actor,
      role: result.role,
      designation: result.role === 'OWNER' ? authorityService.getDhavalProfile().currentDesignation : undefined,
      canDownload: true,
      sessionExpiresInSeconds: 7200,
    });
  });

  app.post('/api/export/project/authorize', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized || !auth.sessionToken) {
      return res.status(403).json({ error: 'Unauthorized: Active owner session required before generating download nonce.', code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const tokenGen = authorityService.createSingleUseDownloadToken(auth.sessionToken);
    if (!tokenGen.success) {
      return res.status(403).json({ error: tokenGen.error, code: 'NONCE_GENERATION_FAILED' });
    }
    return res.json({
      success: true,
      downloadNonce: tokenGen.downloadNonce,
      downloadUrl: `/export/futureverse-project.zip?owner_token=${encodeURIComponent(tokenGen.downloadNonce || '')}`,
      expiresInSeconds: 900,
    });
  });

  // --- Protected Direct Binary Stream Download Routes ---

  const PROTECTED_ZIP_STREAM_ROUTES = [
    '/api/export/project',
    '/api/project/export',
    '/api/export/zip',
    '/api/download/project',
    '/futureverse-source.zip',
    '/export/futureverse-source.zip',
    '/api/export/futureverse-source.zip',
    '/export/futureverse-project.zip',
    '/export/futureverse-final-release.zip',
    '/export/project.zip',
    '/export/release.zip',
    '/futureverse-project.zip',
    '/FUTUREVERSE_FINAL_RELEASE.zip',
    '/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
    '/FUTUREVERSE_PROJECT_v3.1.zip',
    '/brand-kit/futureverse-project.zip',
    '/brand-kit/FUTUREVERSE_FINAL_RELEASE.zip',
    '/brand-kit/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
    '/brand-kit/futureverse-release-v2.4.0.zip',
    '/futureverse-release-v2.4.0.zip',
    '/futureverse-verified-release.zip',
    '/releases/latest.zip',
  ];

  app.all(PROTECTED_ZIP_STREAM_ROUTES, (req: Request, res: Response) => {
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
      return res.status(405).json({ error: 'Method Not Allowed' });
    }
    // OPTIONS requests are handled by the same-origin middleware above; no wildcard CORS is needed.
    if (req.method === 'OPTIONS') return res.status(204).end();

    const auth = verifyOwnerAuthorization(req, { allowDownloadNonce: true });
    if (!auth.authorized) {
      return res.status(403)
        .set({
          'Cache-Control': 'private, no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
          'Content-Type': 'application/json',
        })
        .json({
          error: auth.error,
          code: 'OWNER_AUTHORIZATION_REQUIRED',
        });
    }

    const zipInfo = getProjectZipPath();
    if (!zipInfo) {
      return res.status(404).json({ error: 'FUTUREVERSE project archive not found on server.', code: 'ARTIFACT_NOT_FOUND' });
    }

    try {
      const stat = fs.statSync(zipInfo.path);
      const requestedFilename = typeof req.query.filename === 'string' ? req.query.filename : 'futureverse-source.zip';
      const downloadFilename = path.basename(requestedFilename).replace(/[\r\n\"\\]/g, '_').slice(0, 128) || 'futureverse-source.zip';
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${downloadFilename}"`);
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.setHeader('Accept-Ranges', 'bytes');

      if (req.method === 'HEAD') {
        return res.status(200).end();
      }

      const stream = fs.createReadStream(zipInfo.path);
      stream.on('error', (err) => {
        console.error('Error streaming project zip:', err);
        if (!res.headersSent) {
          res.status(500).json({ error: 'Failed to stream project archive' });
        }
      });
      return stream.pipe(res);
    } catch (err: any) {
      console.error('Error serving project zip:', err);
      return res.status(500).json({ error: 'Server error accessing archive', details: err.message });
    }
  });

  // Dedicated missing artifact check route for testing artifact 404 responses
  app.get('/api/export/archive/:filename', (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) {
      return res.status(403).json({ error: auth.error, code: 'OWNER_AUTHORIZATION_REQUIRED' });
    }
    const requestedFile = path.basename(req.params.filename || '');
    const allowedAliases = new Set(['FUTUREVERSE_FINAL_RELEASE.zip', 'futureverse-source.zip']);
    if (!allowedAliases.has(requestedFile)) {
      return res.status(404).json({ error: 'Requested archive is not an allowed current release.', code: 'ARTIFACT_NOT_FOUND' });
    }
    const safePath = path.resolve(process.cwd(), 'protected_releases', requestedFile);
    if (!fs.existsSync(safePath) || !fs.statSync(safePath).isFile() || !isCurrentPublicReleaseArchive(safePath)) {
      return res.status(404).json({ error: 'Requested archive is missing or is not the verified current release.', code: 'ARTIFACT_NOT_FOUND' });
    }
    const stat = fs.statSync(safePath);
    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${requestedFile}"`,
      'Content-Length': stat.size,
      'Cache-Control': 'private, no-store, no-cache, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    return fs.createReadStream(safePath).pipe(res);
  });

  // Protected Base64 Reconstitution Endpoint
  app.get(['/api/export/project/base64', '/api/project/export/base64', '/api/export/base64'], (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) {
      return res.status(403)
        .set({
          'Cache-Control': 'private, no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
        })
        .json({
          error: auth.error,
          code: 'OWNER_AUTHORIZATION_REQUIRED',
        });
    }

    const zipInfo = getProjectZipPath();
    if (!zipInfo) {
      return res.status(404).json({ error: 'FUTUREVERSE project archive not found on server.' });
    }

    try {
      const buffer = fs.readFileSync(zipInfo.path);
      const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');
      res.set({
        'Cache-Control': 'private, no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      });
      return res.json({
        success: true,
        filename: zipInfo.filename,
        sizeBytes: buffer.length,
        sizeMB: Number((buffer.length / 1024 / 1024).toFixed(2)),
        sha256,
        mimeType: 'application/zip',
        base64: buffer.toString('base64'),
      });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to read archive for base64 export', details: err.message });
    }
  });

  // Protected Archive Metadata Endpoint
  app.get(['/api/export/project/info', '/api/project/export/info'], (req: Request, res: Response) => {
    const auth = verifyOwnerAuthorization(req);
    if (!auth.authorized) {
      return res.status(403)
        .set({
          'Cache-Control': 'private, no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
        })
        .json({
          error: auth.error,
          code: 'OWNER_AUTHORIZATION_REQUIRED',
        });
    }

    const zipInfo = getProjectZipPath();
    if (!zipInfo) {
      return res.status(404).json({ error: 'Archive not found' });
    }

    const stat = fs.statSync(zipInfo.path);
    const buffer = fs.readFileSync(zipInfo.path);
    const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

    res.set({
      'Cache-Control': 'private, no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    return res.json({
      status: 'VERIFIED_AVAILABLE',
      filename: zipInfo.filename,
      sizeBytes: stat.size,
      sizeMB: Number((stat.size / 1024 / 1024).toFixed(2)),
      sha256,
      directDownloadUrl: '/export/futureverse-project.zip',
      base64DownloadUrl: '/api/export/project/base64',
      canonicalReleasePath: zipInfo.path,
      httpStatusExpected: 200,
      authorizedActor: auth.actor,
    });
  });

  // Brand Kit ZIP route
  app.get(['/brand-kit/futureverse-brand-kit.zip', '/brand-kit/futureverse-illuminati-brandkit.zip', '/export/brandkit.zip'], (req: Request, res: Response) => {
    const candidates = [
      path.resolve(__dirname, 'public/brand-kit/futureverse-brand-kit.zip'),
      path.resolve(__dirname, 'public/brand-kit/futureverse-illuminati-brandkit.zip'),
      path.resolve(process.cwd(), 'public/brand-kit/futureverse-brand-kit.zip')
    ];
    const zipPath = candidates.find((p) => fs.existsSync(p));
    if (zipPath) {
      const stat = fs.statSync(zipPath);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="futureverse-brand-kit.zip"');
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Cache-Control', 'public, max-age=600');
      return fs.createReadStream(zipPath).pipe(res);
    } else {
      res.status(404).json({ error: 'Brand kit ZIP archive not found' });
    }
  });

  // ============================================================================
  // VITE DEV / STATIC SERVE
  // ============================================================================
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FUTUREVERSE 2.0 full-stack server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start FUTUREVERSE server:', err);
  process.exit(1);
});
