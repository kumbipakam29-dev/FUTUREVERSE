"""Compatibility wrapper for the old archive-generator command.

The historical implementation recursively packaged runtime JSON and stale nested
archives. This script now delegates to the privacy-reviewed public source generator.
It does not create the historical v3.1 archive name or sweep private runtime state.
"""
from pathlib import Path
import runpy

if __name__ == "__main__":
    safe_generator = Path(__file__).with_name("generate_final_release_zip.py")
    if not safe_generator.is_file():
        raise SystemExit("Safe release generator is missing; refusing to create an archive.")
    runpy.run_path(str(safe_generator), run_name="__main__")
