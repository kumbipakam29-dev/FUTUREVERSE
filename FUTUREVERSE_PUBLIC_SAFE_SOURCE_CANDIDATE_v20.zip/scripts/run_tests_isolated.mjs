/**
 * Run the project suite against a disposable copy so service-level tests cannot mutate
 * the developer's working data or overwrite their release artifacts.
 *
 * Runtime data outside the reviewed seed allowlist, environment secrets, generated ZIPs,
 * dependency folders, backups and deployment artifacts are not copied into the sandbox.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const projectRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'futureverse-tests-'));
const skipDirs = new Set([
  'node_modules', '.git', 'dist', '.vite', 'coverage', 'build', '.cache', '__pycache__',
  'protected_releases', 'test-runtime', 'temp_test_extracted', 'temp_test_download',
  'audit', 'reports', 'forensics', 'releases',
]);
const safeDataFiles = new Set([
  'data/verse_agents.json',
  'data/verse_agent_versions.json',
  'data/verse_personas.json',
  'data/model_naming_registry.json',
  'data/projects.json',
  'data/campaign_schedule.json',
]);
const skipBasenames = new Set([
  'release_checksums.json', 'release_manifest.json', 'CURRENT_RELEASE_CHECKSUMS.json',
  'CURRENT_RELEASE_VERIFICATION.json', 'OUTER_DELIVERY_VERIFICATION.json',
]);
const skipExtensions = new Set(['.zip', '.pem', '.key', '.p12', '.pfx', '.log', '.sqlite', '.db', '.bak', '.backup']);

function shouldCopy(sourcePath) {
  const absolute = path.resolve(sourcePath);
  const rel = path.relative(projectRoot, absolute).split(path.sep).join('/');
  const basename = path.basename(absolute);
  let stat;
  try { stat = fs.lstatSync(absolute); } catch { return false; }
  if (stat.isSymbolicLink()) return false;
  const parts = rel.split('/');
  if (parts.some((part) => skipDirs.has(part))) return false;
  if (skipBasenames.has(basename)) return false;
  if (basename.startsWith('.env') && basename !== '.env.example') return false;
  if (skipExtensions.has(path.extname(basename).toLowerCase())) return false;
  if (basename.endsWith('.tar.gz') || basename.endsWith('.tgz')) return false;
  if (rel.startsWith('data/')) {
    if (stat.isDirectory()) return rel === 'data';
    return safeDataFiles.has(rel) || rel === 'data/README.md';
  }
  return true;
}

function run(command, args, cwd, env) {
  console.log(`\n[isolated-test] ${command} ${args.join(' ')}`);
  const result = spawnSync(command, args, { cwd, env, stdio: 'inherit', shell: false });
  if (result.error) {
    console.error(`[isolated-test] Could not start ${command}: ${result.error.message}`);
    return result.error.code === 'ENOENT' ? 127 : 1;
  }
  return typeof result.status === 'number' ? result.status : 1;
}

let exitCode = 1;
try {
  fs.cpSync(projectRoot, tempRoot, { recursive: true, filter: shouldCopy });

  // Remove registrant/audit PII and author contact details even from the disposable copy.
  // Tests need schedule/count and project fixtures, not personal contact records.
  const campaignPath = path.join(tempRoot, 'data', 'campaign_schedule.json');
  if (fs.existsSync(campaignPath)) {
    const campaign = JSON.parse(fs.readFileSync(campaignPath, 'utf8'));
    if (campaign && typeof campaign === 'object' && !Array.isArray(campaign)) {
      campaign.registrations = [];
      campaign.auditHistory = [];
      fs.writeFileSync(campaignPath, `${JSON.stringify(campaign, null, 2)}\n`, 'utf8');
    }
  }
  const projectsPath = path.join(tempRoot, 'data', 'projects.json');
  if (fs.existsSync(projectsPath)) {
    const projects = JSON.parse(fs.readFileSync(projectsPath, 'utf8'));
    if (Array.isArray(projects)) {
      for (const project of projects) {
        if (!project || typeof project !== 'object' || !project.author || typeof project.author !== 'object') continue;
        for (const field of ['email', 'phone', 'address', 'walletAddress', 'wallet_address']) delete project.author[field];
      }
      fs.writeFileSync(projectsPath, `${JSON.stringify(projects, null, 2)}\n`, 'utf8');
    }
  }

  // Reuse installed dependencies through a directory symlink; source and sanitized data remain a copy.
  const dependenciesPath = path.join(projectRoot, 'node_modules');
  if (fs.existsSync(dependenciesPath) && !fs.existsSync(path.join(tempRoot, 'node_modules'))) {
    fs.symlinkSync(dependenciesPath, path.join(tempRoot, 'node_modules'), process.platform === 'win32' ? 'junction' : 'dir');
  }

  const env = { ...process.env };
  const originalBin = path.join(projectRoot, 'node_modules', '.bin');
  env.PATH = `${originalBin}${path.delimiter}${env.PATH || ''}`;
  // Never pass configured deployment owner credentials to the isolated test process.
  for (const key of ['FUTUREVERSE_OWNER_KEY', 'FUTUREVERSE_CO_OWNER_KEY', 'FUTUREVERSE_COOP_OWNER_KEY', 'TEST_OWNER_SECRET']) {
    delete env[key];
  }
  env.NODE_ENV = 'test';

  const steps = [
    ['python3', ['scripts/generate_final_release_zip.py']],
    [process.execPath, ['test/security_release_check.mjs']],
    [process.execPath, ['test/security_hardening_smoke.mjs']],
    [process.execPath, ['test/compute_route_hardening_check.mjs']],
    ['tsx', ['test/run_tests.ts']],
  ];
  for (const [command, args] of steps) {
    const status = run(command, args, tempRoot, env);
    if (status !== 0) {
      exitCode = status;
      break;
    }
    exitCode = 0;
  }
} catch (error) {
  console.error(`[isolated-test] Failed to prepare sandbox: ${error instanceof Error ? error.message : String(error)}`);
  exitCode = 1;
} finally {
  fs.rmSync(tempRoot, { recursive: true, force: true });
  console.log('[isolated-test] Disposable test directory removed. Original data/source files were not used as test working files.');
}

process.exitCode = exitCode;
