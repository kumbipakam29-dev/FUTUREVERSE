"""Create a public-safe FUTUREVERSE source release without changing runtime state files.

The archive is a source distribution, not an operational data backup. Private runtime
records are intentionally excluded; a small, reviewed whitelist of public seed/config
JSON is included. Use the authenticated backup endpoint for private operational data.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile

ROOT = Path.cwd().resolve()
ZIP_NAME = "FUTUREVERSE_FINAL_RELEASE.zip"
ZIP_PATH = ROOT / ZIP_NAME

EXCLUDE_DIRS = {
    "node_modules", ".git", "dist", ".aistudio", "__pycache__", ".vite",
    "coverage", ".cache", "protected_releases", "test-runtime",
    "temp_test_extracted", "temp_test_download", "audit", "reports", "forensics", "releases",
}
EXCLUDE_NAMES = {
    ZIP_NAME, "server.js", "temp_test_download.zip", "futureverse-source.zip",
    # These manifests describe earlier archive snapshots and would be false metadata here.
    "release_checksums.json", "release_manifest.json", "CURRENT_RELEASE_CHECKSUMS.json",
    "CURRENT_RELEASE_VERIFICATION.json", "OUTER_DELIVERY_VERIFICATION.json",
    # Historic verification documents contain claims tied to different archives/runs.
    "YAGYX_TEST_RESULTS.md", "YAGYX_BACKUP_MANIFEST.txt", "ZIP_EXPORT_403_FIX_REPORT.md",
    "accessibility_audit_report.md", "backup_recovery_report.md", "baseline_test_results.md",
    "forensic_audit_report.md", "futureverse-forensic-audit-report.md", "futureverse-test-results.md",
    "performance_audit_report.md", "responsive_audit_report.md", "test_results.md", "security_audit.md",
    "SECURITY_PATCH_CANDIDATE_REPORT.md", "FUTUREVERSE_FINAL_RELEASE_REPORT.md",
    # Internal forensic inventories and historical reports are not release documentation.
    # Several are tied to earlier source snapshots and contain stale/overstated status labels.
    "SECURITY_HARDENING_REVIEW_REPORT.md", "KNOWN_LIMITATIONS.md", "known_limitations.md",
    "YAGYX_CHAIN_FORENSIC_REPORT.md", "YAGYX_CHAIN_SECURITY_FINDINGS.md",
    "YAGYX_CHAIN_BACKUP_MANIFEST.json", "YAGYX_CHAIN_FILE_INVENTORY.json",
    "route_inventory.json", "security_findings.json", "repository_inventory.json",
    "feature_traceability.json", "implementation_status.json", "feature_status_matrix.csv",
    "generate_v31_reports.py",
    # Unverified dependency claims and legacy live-audit runner with obsolete auth assumptions.
    "dependency_inventory.json", "generate_100_tests_audit.ts",
}
EXCLUDE_EXTS = {".pyc", ".log", ".pem", ".key", ".p12", ".pfx"}
# Only static/system seed data belongs in a public source distribution. Runtime state,
# personal registrations, payment records, authority history and execution logs are not.
SAFE_DATA_JSON = {
    "data/verse_agents.json",
    "data/verse_agent_versions.json",
    "data/verse_personas.json",
    "data/model_naming_registry.json",
    "data/projects.json",             # filtered to published examples below
    "data/campaign_schedule.json",    # registration and audit details redacted below
}


def make_brand_kit() -> None:
    """Create the tiny public brand-kit ZIP referenced by the UI from reviewed public files."""
    source_dir = ROOT / "public" / "brand-kit"
    target = source_dir / "futureverse-brand-kit.zip"
    if not source_dir.exists():
        return
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for item in sorted(source_dir.rglob("*")):
            if not item.is_file() or item == target or item.suffix.lower() == ".zip":
                continue
            # This historic report claims a "100% empirical forensic pass" from a
            # different snapshot and has not been reproduced for this candidate.
            if item.name.lower() in {"verification-report.md", "forensic-verification-report.md"}:
                continue
            if item.is_symlink():
                continue
            # Deterministic inner ZIP metadata keeps the outer release hash stable
            # across fresh checkouts and disposable test copies.
            info = zipfile.ZipInfo(item.relative_to(source_dir).as_posix(), date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100644 & 0xFFFF) << 16
            archive.writestr(info, item.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    if target.stat().st_size > 500 * 1024:
        target.unlink(missing_ok=True)
        raise RuntimeError("Generated public brand kit exceeds the 500 KiB safety limit.")
    with zipfile.ZipFile(target, "r") as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Generated public brand kit failed ZIP integrity validation.")
        if any(Path(name).name.lower() in {"verification-report.md", "forensic-verification-report.md"} for name in archive.namelist()):
            raise RuntimeError("Unverified historical verification report must not ship inside the brand kit.")


def safe_json_bytes(rel: str, source: Path) -> bytes | None:
    """Return a privacy-reviewed public seed representation or None to omit the file."""
    if rel not in SAFE_DATA_JSON:
        return None
    data = json.loads(source.read_text(encoding="utf-8"))
    if rel == "data/projects.json":
        if not isinstance(data, list):
            raise RuntimeError("data/projects.json must be a JSON array")
        published = []
        for project in data:
            if not isinstance(project, dict) or str(project.get("visibility", "")).lower() != "published":
                continue
            item = dict(project)
            author = item.get("author")
            if isinstance(author, dict):
                author = dict(author)
                # Public examples do not need personal/contact or wallet/address fields.
                for key in ("email", "phone", "address", "walletAddress", "wallet_address"):
                    author.pop(key, None)
                item["author"] = author
            published.append(item)
        data = published
    elif rel == "data/campaign_schedule.json":
        if not isinstance(data, dict):
            raise RuntimeError("data/campaign_schedule.json must be a JSON object")
        # Preserve the authoritative campaign timing, stages and aggregate count, but do
        # not publish email addresses, handles, individual registration times or audit logs.
        data = dict(data)
        data["registrations"] = []
        if not isinstance(data.get("registeredCount"), int):
            data["registeredCount"] = 0
        data["auditHistory"] = []
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def should_skip(rel: str, source: Path) -> bool:
    parts = Path(rel).parts
    if any(part in EXCLUDE_DIRS for part in parts):
        return True
    name = source.name
    if rel == "public/preview/audit_report.json":
        return True
    # These are internal AI Studio prompt exports, not application assets; no source references them.
    if rel.startswith("public/assets/aistudio/"):
        return True
    if name in EXCLUDE_NAMES:
        return True
    if rel == "public/brand-kit/verification-report.md":
        return True
    if name.startswith(".env") and name != ".env.example":
        return True
    if any(name.endswith(ext) for ext in EXCLUDE_EXTS):
        return True
    if source.is_symlink():
        return True
    if len(parts) >= 2 and parts[0] == "data" and source.suffix.lower() == ".json":
        return rel not in SAFE_DATA_JSON
    if source.suffix.lower() == ".zip":
        # The only permitted nested archive is the tiny, generated public brand kit.
        return rel != "public/brand-kit/futureverse-brand-kit.zip"
    return False


def main() -> None:
    make_brand_kit()
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()

    included: list[str] = []
    total_uncompressed = 0
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source in sorted(ROOT.rglob("*")):
            if not source.is_file():
                continue
            rel = source.relative_to(ROOT).as_posix()
            if should_skip(rel, source):
                continue
            payload = safe_json_bytes(rel, source) if rel in SAFE_DATA_JSON else None
            if rel in SAFE_DATA_JSON and payload is None:
                continue
            if payload is None:
                payload = source.read_bytes()
            # Stable ZIP entry metadata makes the archive reproducible when source bytes
            # are unchanged; this keeps release hashes useful for integrity verification.
            info = zipfile.ZipInfo(rel, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100644 & 0xFFFF) << 16
            archive.writestr(info, payload, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
            included.append(rel)
            total_uncompressed += len(payload)

    with zipfile.ZipFile(ZIP_PATH, "r") as archive:
        corrupt = archive.testzip()
        if corrupt is not None:
            raise RuntimeError(f"ZIP integrity failed at {corrupt}")
        entries = archive.namelist()
        if "server.ts" not in entries or "package.json" not in entries or "src/server/authorityService.ts" not in entries:
            raise RuntimeError("Archive is missing required application source files")
        forbidden = {
            "server.js",
            "data/ownership_authority.json",
            "data/yagyx_payments_ledger.json",
            "data/test_yagyx_payments_ledger.json",
            "data/verse_agent_executions.json",
            "data/deep_research_records.json",
            "data/demand_signals.json",
            "data/opportunities.json",
            "data/growth_experiments.json",
        }
        leaked = sorted(forbidden.intersection(entries))
        if leaked:
            raise RuntimeError(f"Private runtime files unexpectedly included: {leaked}")
        if any(name.startswith("public/") and name.lower().endswith(".zip") and name != "public/brand-kit/futureverse-brand-kit.zip" for name in entries):
            raise RuntimeError("Unexpected nested ZIP found under public/")
        if "public/brand-kit/verification-report.md" in entries:
            raise RuntimeError("Unverified historical brand-kit report must not ship in the source release.")
        if "dependency_inventory.json" in entries or "public/preview/audit_report.json" in entries:
            raise RuntimeError("Unverified/stale audit metadata must not ship in the public source release.")
        if "test/generate_100_tests_audit.ts" in entries or any(name.startswith("public/assets/aistudio/") for name in entries):
            raise RuntimeError("Legacy audit runner or internal AI Studio prompt exports must not ship in the public source release.")
        campaign_name = "data/campaign_schedule.json"
        if campaign_name in entries:
            campaign = json.loads(archive.read(campaign_name))
            if campaign.get("registrations") != [] or campaign.get("auditHistory") != []:
                raise RuntimeError("Campaign personal registration/audit data was not redacted")

    digest = hashlib.sha256(ZIP_PATH.read_bytes()).hexdigest()
    size = ZIP_PATH.stat().st_size
    print(f"SUCCESS: {ZIP_NAME} created")
    print(f"Files included: {len(included)}")
    print(f"Uncompressed: {total_uncompressed / 1024 / 1024:.2f} MiB")
    print(f"Archive size: {size} bytes ({size / 1024 / 1024:.2f} MiB)")
    print(f"SHA-256: {digest}")
    print("ZIP integrity: PASS")
    print("Private runtime state exclusion: PASS")
    print("Campaign registration redaction: PASS")

    # Keep only the protected server-side mirror. No public nested copy is created.
    protected_dir = ROOT / "protected_releases"
    protected_dir.mkdir(exist_ok=True)
    shutil.copyfile(ZIP_PATH, protected_dir / ZIP_NAME)
    # The server's preferred direct-download mirror must be refreshed from this same
    # privacy-reviewed archive; never leave a stale legacy ZIP at the preferred path.
    shutil.copyfile(ZIP_PATH, protected_dir / "futureverse-source.zip")

    manifest_path = ROOT / "release_checksums.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            manifest = {}
    else:
        manifest = {}
    manifest.setdefault("release_archives", {})[ZIP_NAME] = {
        "sha256": digest,
        "size": size,
        "fileCount": len(included),
        "publicRuntimeDataPolicy": "privacy-reviewed seed whitelist; private runtime records omitted",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
