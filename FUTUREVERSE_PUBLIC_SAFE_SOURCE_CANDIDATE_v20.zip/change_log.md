# FUTUREVERSE CHANGE LOG

**Version:** v2.4.0  
**Date:** 2026-10-20  

### Added
- 1,000,000 IQ (1000k IQ) Transcendent Algorithmic Synthesizer in `superIqAlgorithmEngine.ts`.
- Real World Historical Polymath Personas (Alan Turing, Claude Shannon, Carl Friedrich Gauss, Emmy Noether, Gottfried Leibniz, Sir Isaac Newton, Richard Feynman).
- Mathematical invariant synthesis: Turing configuration tuples & halting boundaries, Shannon entropy bounds, Gaussian surface curvature, Noether continuous symmetry currents.
- 1000k IQ mode toggle & selection in `CreationEngineView.tsx` with dynamic prototype generation.
- Static download routes `/brand-kit/futureverse-illuminati-brandkit.zip` and `/brand-kit/futureverse-brand-kit.zip`.
- Comprehensive automated test suite Group 17 verifying 1000k IQ algorithm and personas.

### Verified & Preserved
- Canonical Ownership Registry with permanent authority for Dhaval, Hemangini, and Jayshriben Batwal.
- YAGYX Chain ID 13370 (0x343a) network adapter and replay-proof integer verification.
- Compute Marketplace 1% commission calculation across all tiers.
- Server-authoritative 30-day launch countdown.
- All 17 responsive screen layouts across 8 device viewports with zero horizontal overflow.


## v13 — Chinese open-weight model catalog
- Added six community-listed Chinese open-weight model entries to `/api/verse/models` (DeepSeek V4.1 Flash, GLM-5.3-Flash, Qwen3.8-27B, MiniCPM-V 4.7, MiMo-V2.6-Pro, MiniMax-M3).
- Entries are explicitly marked COMMUNITY_LISTED; no runtime provider adapter or local model download is claimed.
- Added licensing / compute-cost caveat to README.


## v17 — Task-based AI routing and safe fallback
- Added conservative task inference for general, reasoning, coding, and creative prompts.
- Added task-specific preference lists over configured local Chinese open-weight catalog IDs; only explicitly mapped models are attempted.
- Failed local candidates are skipped in order. Default behavior uses deterministic fallback after local failure; sending the prompt to Gemini requires explicit remote-fallback opt-in.
- Hardened `/api/ai/generate` with IP/route rate limiting, no-store headers, prompt/system-instruction bounds, allowlisted model/task validation, and numeric option bounds.
- Added static and mocked runtime regression tests. Real model execution and full build remain unverified.

## v18 — Provider verification and timeout hardening
- Forwarded the generation timeout's AbortSignal to the Google Gen AI SDK call; previously the timer could abort an unconnected controller.
- Tightened local-model smoke tests: a pass requires the local provider and the fixed `FUTUREVERSE_LOCAL_TEST_OK` marker, not arbitrary non-empty output.
- Added mocked runtime verification for local provider model-list health results, private raw model tags, and Gemini timeout-signal handling.
- Static provider checks and mocked runtime tests pass. Real Ollama/Gemini calls and full production build remain unverified. SDK client abort does not guarantee cancellation of service-side work or billing.

## v19 — AI concurrency, queueing and aggregate latency

- Added an in-process FIFO scheduler for `/api/ai/generate`, with bounded active generation slots, a bounded queue and queue timeout. Over-capacity requests receive retryable 429/503 responses instead of accumulating without limit.
- Added owner-authorized `/api/ai/runtime-metrics` with aggregate active/queued counts and latency summaries; no prompt, token, model-tag, or user-level records are returned.
- Added bounded environment settings: `VERSE_AI_MAX_CONCURRENT`, `VERSE_AI_MAX_QUEUED`, and `VERSE_AI_QUEUE_TIMEOUT_MS`. Defaults are 4 active requests, 12 queued requests and a 10-second queue timeout.
- Added isolated scheduler tests for queue admission, capacity rejection, slot transfer, and aggregate latency counters.
- Limitation: queue and metrics are process-local/in-memory; they reset on restart and do not coordinate multiple server instances.
