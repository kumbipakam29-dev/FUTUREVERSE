# FUTUREVERSE v18 — local Chinese open-weight inference and provider verification

This patch adds an optional OpenAI-compatible **loopback-only** adapter for locally hosted models (for example, Ollama). It does not claim hosted inference is free or that any model is installed, downloaded, benchmarked, or currently running. The six registry entries remain `COMMUNITY_LISTED`; the local adapter is only marked available when an explicit local model mapping is configured.

## Prerequisites

1. Install Ollama on the same machine/container where the FUTUREVERSE server runs.
2. Pull a model supported by your hardware and Ollama build. Large MoE models listed in the catalog may not fit ordinary PCs or phones.
3. Confirm Ollama's OpenAI-compatible API is available locally at `http://127.0.0.1:11434/v1`.
4. Set `VERSE_LOCAL_MODEL_MAP` to a JSON object mapping FUTUREVERSE model IDs to exact installed local model tags. Example only (replace tags with names shown by `ollama list`):

```env
VERSE_LOCAL_OPENAI_BASE_URL=http://127.0.0.1:11434/v1
VERSE_LOCAL_MODEL_MAP={"model-qwen3-8-27b-open":"qwen3:8b"}
```

The model tag must exist locally; the example is not a guarantee that this exact tag is available. The endpoint is intentionally restricted to HTTP loopback hosts to avoid SSRF and accidental prompt forwarding to arbitrary remote endpoints. The adapter sends prompts to the server's local Ollama instance, not to a visitor's Android phone or laptop.

## Costs and privacy

Local inference has no per-token hosted API fee from this adapter, but hardware, electricity, RAM/VRAM, and hosting have costs. The returned cost estimate of zero means **API fee estimate only**, not total operating cost. Do not map an external hosted endpoint here. If local inference fails, the service falls back to the deterministic rule engine and reports degraded behavior.

## Validation limits

The v17 task router tries configured local models in task-specific priority order (general, reasoning, coding, creative). The priorities are heuristics, not benchmark results. If all configured local candidates fail, the deterministic rule engine is used by default; the prompt is not sent to Gemini unless `allowRemoteFallback: true` is explicitly supplied. If no local candidate is configured, the existing Gemini primary path remains in effect when a key is configured.

Static checks and mocked provider-routing, health-probe, smoke-marker, and timeout-signal runtime tests passed for v18. Those tests do not prove that a real Ollama/model installation works. A full TypeScript project build and live inference request were not run in this environment. Before production, test each exact model tag, timeout behavior, JSON output mode, model quality, and concurrency on the target server. Gemini timeout handling passes the SDK AbortSignal to the client call, but client-side abort does not guarantee cancellation of service-side work or applicable billing.
