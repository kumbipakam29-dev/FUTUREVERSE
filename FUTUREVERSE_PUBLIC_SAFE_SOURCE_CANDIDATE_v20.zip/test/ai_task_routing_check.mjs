import assert from 'node:assert/strict';
import fs from 'node:fs';

const service = fs.readFileSync(new URL('../src/server/aiProviderService.ts', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.ts', import.meta.url), 'utf8');

assert.match(service, /export type AITextTask = 'general' \| 'reasoning' \| 'coding' \| 'creative'/, 'supported text-task categories are explicit');
assert.match(service, /const LOCAL_TASK_PREFERENCES: Record<AITextTask, string\[\]> = \{/, 'task routing priorities exist');
assert.match(service, /general: \['model-qwen3-8-27b-open'/, 'general tasks prefer mapped Qwen family');
assert.match(service, /reasoning: \['model-deepseek-v4-1-flash-open'/, 'reasoning tasks prioritize mapped DeepSeek family');
assert.match(service, /coding: \['model-qwen3-8-27b-open'/, 'coding tasks prioritize mapped Qwen family');
assert.match(service, /creative: \['model-minimax-m3-open'/, 'creative tasks prioritize mapped MiniMax family');
assert.match(service, /private inferTextTask\(prompt: string\): AITextTask/, 'task inference helper exists');
assert.match(service, /getConfiguredLocalCandidates\(task: AITextTask\): string\[\]/, 'only configured model mappings are eligible');
assert.match(service, /for \(const localModelId of configuredLocalCandidates\)/, 'router tries configured local candidates in priority order');
assert.match(service, /options\.allowRemoteFallback !== true/, 'remote fallback is denied by default after local failure');
assert.match(service, /Requested model is not in the verified model catalog/, 'unknown model IDs are rejected');
assert.match(service, /Requested task is not supported by the text inference router/, 'unsupported task categories are rejected');
assert.match(service, /finally \{\s*clearTimeout\(timer\);\s*\}/, 'local inference timer is cleaned up');
assert.match(server, /app\.post\('\/api\/ai\/generate'/, 'generation endpoint exists');
assert.match(server, /checkRateLimit\(req, res, 15, 60_000\)/, 'generation endpoint is rate limited');
assert.match(server, /prompt\.length > 20_000/, 'prompt size is bounded');
assert.match(server, /AI_MODEL_NOT_ALLOWLISTED/, 'HTTP endpoint rejects unknown models');
assert.match(server, /allowRemoteFallback === true/, 'remote prompt forwarding requires explicit opt-in');
console.log('AI task routing static checks: PASS (17 assertions)');
