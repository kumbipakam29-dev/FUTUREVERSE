import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const forbidden = [
  /Dhaval\s+Chandrashekhar\s+Batwal/i,
  /Hemangini\s+Chandrashekhar\s+Batwal/i,
  /Hemangini\s+Chandrashwkhar\s+Batwal/i,
  /Jayshriben\s+Chandrashekhar\s+Batwal/i,
  /aibabayaga0@gmail\.com/i,
];
const publicRoot = path.resolve('public');
const files = [];
function walk(dir) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) walk(full);
    else if (item.isFile()) files.push(full);
  }
}
if (fs.existsSync(publicRoot)) walk(publicRoot);
const leaks = [];
for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  for (const pattern of forbidden) {
    if (pattern.test(content)) leaks.push(`${path.relative(process.cwd(), file)} contains protected identity data`);
  }
}
const server = fs.readFileSync('server.ts', 'utf8');
if (!server.includes('redactProtectedOwnerIdentityDeep(computeJobs)')) {
  leaks.push('Public compute jobs response does not redact protected customer identities');
}
if (!server.includes('res.json(redactProtectedOwnerIdentityDeep({')) {
  leaks.push('Public orchestration response does not apply recursive protected identity redaction');
}
if (!server.includes('function redactProtectedOwnerIdentityDeep')) {
  leaks.push('Recursive public identity redaction helper is missing');
}
const publicStewardSection = server.match(/canonicalStewards:\s*\[([\s\S]*?)\]/)?.[1] || '';
if (forbidden.some(pattern => pattern.test(publicStewardSection))) leaks.push('Public steward diagnostic response contains protected identity data');
for (const phrase of [
  'Verified Dhaval owner session required',
  'Only Dhaval Chandrashekhar Batwal can update',
]) {
  if (server.includes(phrase)) leaks.push(`Public-facing server response contains identity phrase: ${phrase}`);
}

const launchRegisterStart = server.indexOf("app.post('/api/launch/register'");
const launchRegisterEnd = server.indexOf("app.post('/api/launch/admin/reveal'", launchRegisterStart);
const launchRegisterBlock = server.slice(launchRegisterStart, launchRegisterEnd);
if (!launchRegisterBlock.includes('registeredCount: result.registeredCount') || launchRegisterBlock.includes('json(result)')) {
  leaks.push('Public campaign registration response may expose the stored registration record');
}
const providerRouteStart = server.indexOf("app.get('/api/compute/providers'");
const providerRouteEnd = server.indexOf("app.post('/api/compute/providers/register'", providerRouteStart);
const providerRouteBlock = server.slice(providerRouteStart, providerRouteEnd);
if (!providerRouteBlock.includes('redactProtectedOwnerIdentityDeep(computeProviders)') || !providerRouteBlock.includes("Cache-Control', 'no-store")) {
  leaks.push('Public compute provider response does not redact protected identities and disable caching');
}
const computeJobsStart = server.indexOf("app.get('/api/compute/jobs'");
const computeJobsEnd = server.indexOf("app.post('/api/compute/jobs'", computeJobsStart);
const computeJobsBlock = server.slice(computeJobsStart, computeJobsEnd);
if (!computeJobsBlock.includes('redactProtectedOwnerIdentityDeep(computeJobs)')) {
  leaks.push('Public compute jobs response does not recursively redact protected identity strings');
}

if (leaks.length) {
  console.error(leaks.join('\n'));
  process.exit(1);
}
console.log(`UI_OWNER_NAME_PRIVACY_CHECK=PASS (${files.length} public assets scanned; no protected names/email found)`);
