import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import assert from 'assert';

interface TestResult {
  id: number;
  name: string;
  verdict: 'PASS' | 'FAIL' | 'BLOCKED';
  evidence: string;
  details?: string;
}

const results: TestResult[] = [];
// Target either local port 3000 or the environment URL
const LOCAL_URL = 'http://127.0.0.1:3000';

async function httpRequest(
  urlPath: string,
  options: {
    method?: string;
    headers?: Record<string, string>;
    baseUrl?: string;
  } = {}
): Promise<{ status: number; headers: Headers; body: Buffer }> {
  const base = options.baseUrl || LOCAL_URL;
  const fullUrl = new URL(urlPath, base).toString();
  const res = await fetch(fullUrl, {
    method: options.method || 'GET',
    headers: options.headers || {},
  });
  const arrayBuffer = await res.arrayBuffer();
  return {
    status: res.status,
    headers: res.headers,
    body: Buffer.from(arrayBuffer),
  };
}

async function runAll() {
  console.log('================================================================');
  console.log('FUTUREVERSE × BATWAL’S VERSE AI × YAGYX — E2E ZIP DOWNLOAD SUITE');
  console.log(`Local Test Host: ${LOCAL_URL}`);
  console.log('Remote deployment checks are intentionally disabled in this local test suite.');
  console.log('================================================================\n');

  // Test 1: ZIP generation succeeds
  try {
    const output = execSync('python3 scripts/generate_final_release_zip.py', { encoding: 'utf8' });
    const zipPath = path.resolve(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.strictEqual(fs.existsSync(zipPath), true, 'FUTUREVERSE_FINAL_RELEASE.zip exists');
    const stat = fs.statSync(zipPath);
    assert.ok(stat.size > 10 * 1024 * 1024, `Size ${stat.size} exceeds 10MB`);

    // Ensure futureverse-source.zip alias copy exists
    fs.copyFileSync(zipPath, path.resolve(process.cwd(), 'protected_releases/futureverse-source.zip'));
    fs.copyFileSync(zipPath, path.resolve(process.cwd(), 'futureverse-source.zip'));

    results.push({
      id: 1,
      name: 'ZIP generation succeeds',
      verdict: 'PASS',
      evidence: `Archive generated successfully (${stat.size} bytes / ${(stat.size / (1024 * 1024)).toFixed(2)} MB); archive count and integrity verified by generator.`,
    });
  } catch (err: any) {
    results.push({
      id: 1,
      name: 'ZIP generation succeeds',
      verdict: 'FAIL',
      evidence: err.message,
    });
  }

  // Authenticate using an explicitly configured test/deployment secret. The server must
  // place the session in an HttpOnly cookie; the token must not be exposed in JSON.
  let ownerCookie = '';
  let authBlockedReason = '';
  try {
    const actor = process.env.TEST_OWNER_ACTOR || 'Dhaval Chandrashekhar Batwal';
    const secret = process.env.TEST_OWNER_SECRET || process.env.FUTUREVERSE_OWNER_KEY || '';
    if (!secret) throw new Error('Set TEST_OWNER_SECRET (or FUTUREVERSE_OWNER_KEY) to run authenticated E2E cases.');
    // Supply credentials in the login body; never print or persist the secret.
    const loginUrl = new URL('/api/export/owner-authenticate', LOCAL_URL).toString();
    const loginFetch = await fetch(loginUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ actor, passkey: secret }),
    });
    const parsed = await loginFetch.json() as { success?: boolean; sessionToken?: string; error?: string };
    assert.strictEqual(loginFetch.status, 200, parsed.error || `Owner login returned HTTP ${loginFetch.status}`);
    assert.strictEqual(parsed.success, true);
    assert.strictEqual(parsed.sessionToken, undefined, 'Session token must never be returned in JSON');
    const setCookie = loginFetch.headers.get('set-cookie') || '';
    const cookieMatch = setCookie.match(/(?:^|[,;]\s*)(fv_owner_token=[^; ,]+)/);
    assert.ok(cookieMatch, 'Expected HttpOnly fv_owner_token cookie');
    ownerCookie = cookieMatch![1];
    if (/\bhttponly\b/i.test(setCookie) !== true) throw new Error('Owner session cookie must be HttpOnly');
    results.push({ id: 10, name: 'Owner auth uses an HttpOnly cookie without JSON token', verdict: 'PASS', evidence: 'Owner login returned success, Set-Cookie contains fv_owner_token; JSON contained no session token.' });
  } catch (err: any) {
    authBlockedReason = err.message;
    results.push({ id: 10, name: 'Owner auth uses an HttpOnly cookie without JSON token', verdict: 'BLOCKED', evidence: authBlockedReason });
  }

  // Test 2: Download endpoint returns HTTP 200 when authorized and artifact exists
  if (!ownerCookie) {
    results.push({ id: 2, name: 'Authorized download returns HTTP 200', verdict: 'BLOCKED', evidence: authBlockedReason || 'No authenticated owner cookie.' });
  } else {
    try {
      const res = await httpRequest('/api/export/project', { headers: { Cookie: ownerCookie } });
      assert.strictEqual(res.status, 200, `Expected status 200, got ${res.status}`);
      assert.ok(res.body.length > 1000000, `Expected non-empty ZIP body, received ${res.body.length} bytes`);
      results.push({ id: 2, name: 'Authorized download returns HTTP 200', verdict: 'PASS', evidence: `HTTP 200 and ${res.body.length} ZIP bytes returned using the HttpOnly-session cookie.` });
    } catch (err: any) {
      results.push({ id: 2, name: 'Authorized download returns HTTP 200', verdict: 'FAIL', evidence: err.message });
    }
  }

  // Test 3: Response contains correct ZIP content-type and download filename
  if (!ownerCookie) {
    results.push({ id: 3, name: 'Download response has ZIP content type and safe filename', verdict: 'BLOCKED', evidence: authBlockedReason || 'No authenticated owner cookie.' });
  } else {
    try {
      const res = await httpRequest('/api/export/project?filename=futureverse-source.zip', { headers: { Cookie: ownerCookie } });
      const contentType = res.headers.get('content-type');
      const contentDisposition = res.headers.get('content-disposition');
      assert.strictEqual(res.status, 200);
      assert.strictEqual(contentType, 'application/zip', `Expected application/zip, got ${contentType}`);
      assert.ok(contentDisposition && contentDisposition.includes('attachment') && contentDisposition.includes('futureverse-source.zip'), `Content-Disposition header: "${contentDisposition}"`);
      results.push({ id: 3, name: 'Download response has ZIP content type and safe filename', verdict: 'PASS', evidence: `Content-Type: ${contentType}; Content-Disposition: ${contentDisposition}.` });
    } catch (err: any) {
      results.push({ id: 3, name: 'Download response has ZIP content type and safe filename', verdict: 'FAIL', evidence: err.message });
    }
  }

  // Test 4: Supplying the owner's public email in the query must not authorize a ZIP.
  try {
    const res = await httpRequest('/export/futureverse-source.zip?owner_email=aibabayaga0%40gmail.com');
    assert.strictEqual(res.status, 403, `Expected 403 for email query bypass, got ${res.status}`);
    assert.notStrictEqual(res.headers.get('content-type'), 'application/zip');
    results.push({ id: 4, name: 'Public owner email cannot bypass archive authentication', verdict: 'PASS', evidence: 'Owner-email query request returned HTTP 403 and no ZIP stream.' });
  } catch (err: any) {
    results.push({ id: 4, name: 'Public owner email cannot bypass archive authentication', verdict: 'FAIL', evidence: err.message });
  }

  // Test 5: The authorized archive passes integrity testing and can be extracted.
  if (!ownerCookie) {
    results.push({ id: 5, name: 'Authorized archive passes integrity and extraction', verdict: 'BLOCKED', evidence: authBlockedReason || 'No authenticated owner cookie.' });
  } else {
    try {
      const res = await httpRequest('/api/export/project', { headers: { Cookie: ownerCookie } });
      assert.strictEqual(res.status, 200);
      const testTempZip = path.resolve(process.cwd(), 'temp_test_download.zip');
      const testTempDir = path.resolve(process.cwd(), 'temp_test_extracted');
      fs.writeFileSync(testTempZip, res.body);
      if (fs.existsSync(testTempDir)) fs.rmSync(testTempDir, { recursive: true, force: true });
      fs.mkdirSync(testTempDir, { recursive: true });
      execSync(`unzip -t "${testTempZip}"`, { stdio: 'pipe' });
      execSync(`unzip -q "${testTempZip}" -d "${testTempDir}"`, { stdio: 'pipe' });
      const extractedFiles = fs.readdirSync(testTempDir);
      assert.ok(extractedFiles.includes('package.json'), 'package.json found in extracted archive');
      assert.ok(extractedFiles.includes('src'), 'src directory found in extracted archive');
      assert.ok(extractedFiles.includes('server.ts'), 'server.ts found in extracted archive');
      fs.rmSync(testTempZip, { force: true });
      fs.rmSync(testTempDir, { recursive: true, force: true });
      results.push({ id: 5, name: 'Authorized archive passes integrity and extraction', verdict: 'PASS', evidence: 'ZIP integrity passed; package.json, src/ and server.ts were present after extraction.' });
    } catch (err: any) {
      results.push({ id: 5, name: 'Authorized archive passes integrity and extraction', verdict: 'FAIL', evidence: err.message });
    }
  }

  // Test 6: Unauthorized users are denied access (HTTP 403)
  try {
    const unauthRes = await httpRequest('/api/export/project');
    assert.strictEqual(unauthRes.status, 403, `Expected 403, got ${unauthRes.status}`);
    const unauthBody = JSON.parse(unauthRes.body.toString('utf8'));
    assert.strictEqual(unauthBody.code, 'OWNER_AUTHORIZATION_REQUIRED');

    // Also test invalid token
    const badTokenRes = await httpRequest('/api/export/project', {
      headers: { Authorization: 'Bearer fv-owner-fake-token-attempt' },
    });
    assert.strictEqual(badTokenRes.status, 403, `Expected 403 for forged token, got ${badTokenRes.status}`);

    results.push({
      id: 6,
      name: 'Unauthorized users are denied access',
      verdict: 'PASS',
      evidence: `Unauthenticated and forged token requests both returned HTTP 403 Forbidden with OWNER_AUTHORIZATION_REQUIRED guard.`,
    });
  } catch (err: any) {
    results.push({
      id: 6,
      name: 'Unauthorized users are denied access',
      verdict: 'FAIL',
      evidence: err.message,
    });
  }

  // Test 7: Missing artifacts return a clear 404 when the requester is authenticated.
  if (!ownerCookie) {
    results.push({ id: 7, name: 'Missing artifacts return a clear 404', verdict: 'BLOCKED', evidence: authBlockedReason || 'No authenticated owner cookie.' });
  } else {
    try {
      const missingRes = await httpRequest('/api/export/archive/nonexistent-release-archive-999.zip', { headers: { Cookie: ownerCookie } });
      assert.strictEqual(missingRes.status, 404, `Expected 404, got ${missingRes.status}`);
      const jsonBody = JSON.parse(missingRes.body.toString('utf8'));
      assert.strictEqual(jsonBody.code, 'ARTIFACT_NOT_FOUND');
      results.push({ id: 7, name: 'Missing artifacts return a clear 404', verdict: 'PASS', evidence: 'Authenticated missing-artifact request returned HTTP 404 / ARTIFACT_NOT_FOUND.' });
    } catch (err: any) {
      results.push({ id: 7, name: 'Missing artifacts return a clear 404', verdict: 'FAIL', evidence: err.message });
    }
  }

  // Test 8: The public source ZIP contains no operational ledgers, authority records or registration emails.
  try {
    const zipPath = path.resolve(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    const listing = execSync(`unzip -Z1 "${zipPath}"`, { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
    const forbiddenEntries = [
      /(^|\/)\.env($|\.)/, /(^|\/)id_rsa($|\.)/, /\.pem$/i, /\.key$/i,
      /node_modules\//, /secrets\.json$/i, /^server\.js$/,
      /^data\/(ownership_authority|yagyx_payments_ledger|test_yagyx_payments_ledger|verse_agent_executions|deep_research_records|demand_signals|opportunities|growth_experiments)\.json$/,
      /^public\/futureverse-verified-release\.zip$/,
    ];
    const leaks = listing.filter((name) => name !== '.env.example' && forbiddenEntries.some((pattern) => pattern.test(name)));
    assert.deepStrictEqual(leaks, [], `Private or stale entries leaked into archive: ${leaks.join(', ')}`);
    assert.ok(listing.includes('.env.example'), 'Safe environment template should be retained');
    assert.ok(listing.includes('public/brand-kit/futureverse-brand-kit.zip'), 'Small public brand-kit asset should be retained');
    const campaign = JSON.parse(execSync(`unzip -p "${zipPath}" data/campaign_schedule.json`, { encoding: 'utf8' }));
    assert.deepStrictEqual(campaign.registrations, []);
    assert.deepStrictEqual(campaign.auditHistory, []);
    results.push({ id: 8, name: 'Release package excludes private runtime state', verdict: 'PASS', evidence: `Checked ${listing.length} archive paths; private runtime ledgers/authority/execution records absent and campaign registrations redacted.` });
  } catch (err: any) {
    results.push({ id: 8, name: 'Release package excludes private runtime state', verdict: 'FAIL', evidence: err.message });
  }

  // Test 9: Invalid session-looking query tokens cannot authorize protected ZIP routes.
  try {
    const endpoint = '/export/futureverse-source.zip?owner_token=fv-owner-fake-token';
    const res = await httpRequest(endpoint, { baseUrl: LOCAL_URL });
    assert.strictEqual(res.status, 403, `Expected HTTP 403, got ${res.status}`);
    assert.notStrictEqual(res.headers.get('content-type'), 'application/zip');
    results.push({ id: 9, name: 'Query-string session tokens cannot authorize ZIP downloads', verdict: 'PASS', evidence: 'Fake non-nonce owner token in the query string returned HTTP 403; no remote deployment was contacted.' });
  } catch (err: any) {
    results.push({ id: 9, name: 'Query-string session tokens cannot authorize ZIP downloads', verdict: 'FAIL', evidence: err.message });
  }

  // Print Summary Table
  console.log('\n--- VERIFICATION AUDIT EVIDENCE MATRIX ---');
  for (const r of results) {
    console.log(`[${r.verdict}] Test ${r.id}: ${r.name}`);
    console.log(`       Evidence: ${r.evidence}`);
  }

  const passedCount = results.filter((r) => r.verdict === 'PASS').length;
  const blockedCount = results.filter((r) => r.verdict === 'BLOCKED').length;
  const failedCount = results.filter((r) => r.verdict === 'FAIL').length;
  console.log(`\n================================================================`);
  console.log(`E2E ZIP SUITE RESULT: ${passedCount} PASS / ${blockedCount} BLOCKED / ${failedCount} FAIL out of ${results.length}`);
  console.log('================================================================');

  if (failedCount > 0 || blockedCount > 0) {
    process.exit(1);
  }
}

runAll().catch((err) => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
