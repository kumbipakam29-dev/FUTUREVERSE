import assert from 'node:assert/strict';
import fs from 'node:fs';

const service = fs.readFileSync(new URL('../src/server/aiProviderService.ts', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
assert.match(service, /testConfiguredLocalModel\(modelId: string\)/, 'bounded local inference smoke test exists');
assert.match(service, /verifiedModels\.some\(\(model\) => model\.id === modelId && model\.provider === 'ollama-local'\)/, 'local test enforces catalog allowlist');
assert.match(service, /FUTUREVERSE_LOCAL_TEST_OK/, 'test prompt is fixed server-side');
assert.match(service, /result\.providerUsed === 'ollama-local' && result\.text\.includes\(expectedMarker\)/, 'local model must return the expected marker to count as a pass');
assert.match(service, /const expectedMarker = 'FUTUREVERSE_LOCAL_TEST_OK'/, 'smoke test requires a known response marker');
assert.match(server, /app\.post\('\/api\/ai\/provider-test'/, 'inference test route exists');
assert.match(server, /Verified owner session required to run local AI inference tests/, 'route requires owner authorization');
assert.match(server, /checkRateLimit\(req, res, 3, 60_000\)/, 'route is rate limited');
assert.match(server, /Only allowlisted local catalog models can be tested/, 'route rejects non-local models');
assert.match(server, /private, no-store, no-cache, must-revalidate/, 'test response is not cacheable');
assert.match(service, /config\.abortSignal = controller\.signal/, 'Gemini generation receives the timeout abort signal');
assert.match(service, /finally\s*\{\s*clearTimeout\(timer\);\s*\}\s*\n\s*\n\s*const textOutput/, 'Gemini request timeout is cleared even when generation throws');
console.log('AI provider inference test static checks: PASS (12 assertions)');
