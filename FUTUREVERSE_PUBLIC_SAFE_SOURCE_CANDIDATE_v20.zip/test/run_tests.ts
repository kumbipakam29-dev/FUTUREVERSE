import assert from 'assert';
import { execSync } from 'child_process';
import { campaignService } from '../src/server/campaignService';
import { modelNamingEngine, CANONICAL_GITA_TEACHINGS } from '../src/server/namingEngine';
import { agentEngine } from '../src/server/agentEngine';
import { authorityService } from '../src/server/authorityService';
import { personaEngine } from '../src/server/personaEngine';
import { ProjectService } from '../src/server/projectService';
import { verseOrchestrator } from '../src/server/verseIntelligenceOrchestrator';
import { demandSignalEngine } from '../src/server/demandSignalEngine';
import { yagyxPaymentService, FUTUREVERSE_PAYMENT_VAULT_ADDRESS, YAGYX_SUPPORTED_TOKENS } from '../src/server/yagyxPaymentService';
import { YAGYX_CHAIN_ID, YAGYX_CHAIN_HEX } from '../src/services/web3';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { ASSETS, getStatusBadgeAsset, getProjectLogo, PROJECT_LOGOS } from '../src/assets/images';
import { superIqAlgorithmEngine, REAL_PERSON_PERSONAS_COUNCIL } from '../src/server/superIqAlgorithmEngine';

console.log('================================================================');
console.log('FUTUREVERSE × BATWAL’S VERSE AI × YAGYX — AUTOMATED TEST SUITE');
console.log('================================================================\n');

let totalTests = 0;
let passedTests = 0;

function runTest(name: string, fn: () => void) {
  totalTests++;
  try {
    fn();
    console.log(`  ✓ PASS: ${name}`);
    passedTests++;
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    Error: ${err.message}\n`);
    throw err;
  }
}

async function runAsyncTest(name: string, fn: () => Promise<void>) {
  totalTests++;
  try {
    await fn();
    console.log(`  ✓ PASS: ${name}`);
    passedTests++;
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    Error: ${err.message}\n`);
    throw err;
  }
}

async function main() {
  console.log('--- TEST GROUP 1: SECTION 5.3 & 23.2 COUNTDOWN DEFECT TESTS ---');

  runTest('1.1 Campaign with missing/NOT_SCHEDULED status produces zero false countdown', () => {
    campaignService.updateSchedule({ status: 'NOT_SCHEDULED' }, 'Test Runner');
    const state = campaignService.getAuthoritativeState(Date.now());
    assert.strictEqual(state.status, 'NOT_SCHEDULED');
    assert.strictEqual(state.daysRemaining, 0);
    assert.strictEqual(state.hoursRemaining, 0);
    assert.strictEqual(state.remainingMs, 0);
    assert.strictEqual(state.currentDay, 0);
  });

  runTest('1.2 Campaign scheduled in future correctly calculates pre-launch countdown to start boundary', () => {
    const fakeNow = new Date('2026-10-01T00:00:00.000Z').getTime();
    const futureStart = '2026-10-05T00:00:00.000Z'; // 4 days later
    const futureReveal = '2026-11-04T00:00:00.000Z'; // 34 days later

    campaignService.updateSchedule(
      {
        status: 'SCHEDULED',
        scheduledStartTimestamp: futureStart,
        scheduledRevealTimestamp: futureReveal,
      },
      'Test Runner'
    );

    const state = campaignService.getAuthoritativeState(fakeNow);
    assert.strictEqual(state.status, 'SCHEDULED');
    assert.strictEqual(state.daysRemaining, 4);
    assert.strictEqual(state.currentDay, 0);
    assert.ok(state.stateDescription.includes('Launches in countdown window'));
  });

  runTest('1.3 Campaign on Day 10 of active 30-day window accurately calculates remaining days', () => {
    const fixedStart = '2026-10-01T00:00:00.000Z';
    const fixedReveal = '2026-10-31T00:00:00.000Z';
    // 9.5 days into the campaign
    const simulatedNow = new Date('2026-10-10T12:00:00.000Z').getTime();

    campaignService.updateSchedule(
      {
        status: 'ACTIVE',
        scheduledStartTimestamp: fixedStart,
        scheduledRevealTimestamp: fixedReveal,
      },
      'Test Runner'
    );

    const state = campaignService.getAuthoritativeState(simulatedNow);
    assert.strictEqual(state.status, 'ACTIVE');
    assert.strictEqual(state.currentDay, 10); // Day 10 of 30
    assert.strictEqual(state.daysRemaining, 20); // 20 days and 12 hours remaining
    assert.strictEqual(state.hoursRemaining, 12);
  });

  runTest('1.4 Campaign past reveal timestamp immediately transitions to REVEALED state with 0 remaining', () => {
    const postRevealTime = new Date('2026-11-01T00:00:00.000Z').getTime();
    const state = campaignService.getAuthoritativeState(postRevealTime);
    assert.strictEqual(state.status, 'REVEALED');
    assert.strictEqual(state.daysRemaining, 0);
    assert.strictEqual(state.remainingMs, 0);
    assert.strictEqual(state.currentDay, 30);
  });

  runTest('1.5 Campaign rejection of invalid schedule (start after reveal)', () => {
    const res = campaignService.updateSchedule(
      {
        scheduledStartTimestamp: '2026-10-31T00:00:00.000Z',
        scheduledRevealTimestamp: '2026-10-01T00:00:00.000Z',
      },
      'Test Runner'
    );
    assert.strictEqual(res.success, false);
    assert.ok(res.message.includes('strictly before'));
  });

  runTest('1.6 Campaign PAUSED state freezes countdown cleanly', () => {
    campaignService.updateSchedule({ status: 'PAUSED' }, 'Test Runner');
    const state = campaignService.getAuthoritativeState(Date.now());
    assert.strictEqual(state.status, 'PAUSED');
    assert.strictEqual(state.remainingMs, 0);
    assert.ok(state.stateDescription.includes('paused'));
  });

  // Restore active standard schedule for production
  campaignService.updateSchedule(
    {
      status: 'ACTIVE',
      scheduledStartTimestamp: '2026-10-01T00:00:00.000Z',
      scheduledRevealTimestamp: '2026-10-31T00:00:00.000Z',
    },
    'Dhaval Chandrashekhar Batwal'
  );

  console.log('\n--- TEST GROUP 2: SECTION 8 & 23.4 COMPUTE MARKETPLACE 1% COMMISSION TESTS ---');

  runTest('2.1 Standard ₹1,000 compute transaction deducts exactly 1% (₹10) commission and ₹990 settlement', () => {
    const grossAmountInr = 1000;
    const commission = Math.round(grossAmountInr * 0.01 * 100) / 100;
    const providerSettlement = Math.round((grossAmountInr - commission) * 100) / 100;

    assert.strictEqual(commission, 10.0);
    assert.strictEqual(providerSettlement, 990.0);
    assert.strictEqual(commission + providerSettlement, grossAmountInr);
  });

  runTest('2.2 ₹2,500 compute transaction calculates exactly ₹25 commission and ₹2475 settlement', () => {
    const grossAmountInr = 2500;
    const commission = Math.round(grossAmountInr * 0.01 * 100) / 100;
    const providerSettlement = Math.round((grossAmountInr - commission) * 100) / 100;

    assert.strictEqual(commission, 25.0);
    assert.strictEqual(providerSettlement, 2475.0);
  });

  runTest('2.3 Optional free compute contribution produces ₹0 commission', () => {
    const grossAmountInr = 0;
    const commission = Math.round(grossAmountInr * 0.01 * 100) / 100;
    assert.strictEqual(commission, 0);
  });

  runTest('2.4 Commission decimal safety with fractional currencies (₹1,337.50)', () => {
    const grossAmountInr = 1337.5;
    const commission = Math.round(grossAmountInr * 0.01 * 100) / 100;
    const providerSettlement = Math.round((grossAmountInr - commission) * 100) / 100;

    assert.strictEqual(commission, 13.38);
    assert.strictEqual(providerSettlement, 1324.12);
    assert.strictEqual(commission + providerSettlement, grossAmountInr);
  });

  console.log('\n--- TEST GROUP 3: SECTION 11 & 23.5 INFINITE MEANINGFUL MODEL NAMING ENGINE TESTS ---');

  runTest('3.1 Canonical Gita teachings are seeded with verified verses and references', () => {
    assert.ok(CANONICAL_GITA_TEACHINGS.length >= 10);
    const karmayoga = CANONICAL_GITA_TEACHINGS.find((t) => t.displayName.includes('KARMAYOGA'));
    assert.ok(karmayoga);
    assert.strictEqual(karmayoga.gitaChapterVerse, 'Bhagavad Gita 2.47');
    assert.ok(karmayoga.sanskritSourceText.includes('कर्मण्येवाधिकारस्ते'));
    assert.strictEqual(karmayoga.verificationStatus, 'VERIFIED');
  });

  runTest('3.2 Continuous Naming Pipeline detects duplicates with normalized spellings and case variations', () => {
    const check1 = modelNamingEngine.checkDuplicate("BATWAL'S VERSE KARMAYOGA");
    assert.strictEqual(check1.isDuplicate, true);

    const check2 = modelNamingEngine.checkDuplicate('batwals verse karmayoga');
    assert.strictEqual(check2.isDuplicate, true);

    const check3 = modelNamingEngine.checkDuplicate("Batwal's  Verse   Karmayoga!!");
    assert.strictEqual(check3.isDuplicate, true);
  });

  runTest('3.3 Generates new valid naming candidate with CANDIDATE_NAME_ONLY tag', () => {
    const existing = modelNamingEngine.getAll().find((r) => r.displayName === "BATWAL'S VERSE DHRITI");
    if (existing) {
      modelNamingEngine.deleteRecord(existing.id);
    }

    const res = modelNamingEngine.generateCandidate({
      themeOrConcept: 'DHRITI',
      gitaChapterVerse: 'Bhagavad Gita 18.33',
      sanskritTerm: 'धृति (Dhṛti)',
      englishTranslation: 'Steadfast determination that sustains moral and intellectual integrity.',
      positiveLesson: 'Unyielding perseverance and stability in deep architectural endeavors.',
      intendedCapability: 'Long-Context Reasoning and High-Load Stability',
    });

    assert.strictEqual(res.success, true);
    assert.ok(res.record);
    assert.strictEqual(res.record.displayName, "BATWAL'S VERSE DHRITI");
    assert.strictEqual(res.record.underlyingModelType, 'CANDIDATE_NAME_ONLY'); // Crucial: Section 11.6
  });

  runTest('3.4 Candidate linking to model profile without misrepresenting as trained model', () => {
    const candidate = modelNamingEngine.getAll().find((r) => r.displayName === "BATWAL'S VERSE DHRITI");
    assert.ok(candidate);

    const res = modelNamingEngine.approveAndLinkModel(candidate.id, {
      approvalStatus: 'APPROVED',
      underlyingModelType: 'SPECIALIZED_CONFIG',
      underlyingModelLink: 'config-dhriti-v1: Gemma 8B Prompt Configuration for Fault-Tolerant SMT proofs',
      reviewerRecord: 'Approved by Systems Lead',
    });

    assert.strictEqual(res.success, true);
    assert.strictEqual(res.record?.approvalStatus, 'APPROVED');
    assert.strictEqual(res.record?.underlyingModelType, 'SPECIALIZED_CONFIG');
  });

  console.log('\n--- TEST GROUP 4: SECTION 12 & 23.6 SANSKRIT AGENTS & MULTIPLICATION TESTS ---');

  runTest('4.1 Canonical Sanskrit agents initialized with distinct capability scopes', () => {
    const agents = agentEngine.getAll();
    assert.ok(agents.length >= 10);
    const sarathi = agentEngine.getById('agent-sarathi-orch');
    assert.ok(sarathi);
    assert.strictEqual(sarathi.name, 'SARATHI Core Orchestrator');
  });

  runTest('4.2 Child agent cannot exceed parent permissions (least privilege inheritance)', () => {
    const res = agentEngine.multiplyAgent({
      parentAgentId: 'agent-sarathi-orch',
      specializedName: 'SARATHI Micro-Router',
      responsibility: 'Sub-task router',
      requestedPermissions: ['ROUTE_TASKS', 'UNAUTHORIZED_PRIVILEGE_XYZ'], // Has illegal perm
      requestedTools: ['vivekaRouter'],
      actor: 'Tester',
    });

    assert.strictEqual(res.success, false);
    assert.ok(res.message.includes('cannot exceed parent permissions'));
  });

  runTest('4.3 Child agent blocked from acquiring administrative owner privileges', () => {
    const res = agentEngine.multiplyAgent({
      parentAgentId: 'agent-dharma-guard',
      specializedName: 'Rogue Agent',
      responsibility: 'Governance override attempt',
      requestedPermissions: ['SUPER_ADMIN_ELEVATION'],
      requestedTools: [],
      actor: 'Tester',
    });

    assert.strictEqual(res.success, false);
    assert.ok(res.message.includes('Security violation'));
  });

  console.log('\n--- TEST GROUP 5: SECTION 17 OWNERSHIP & DHAVAL PERMANENT AUTHORITY TESTS ---');

  runTest('5.1 Canonical ownership registry verifies all three declared co-owners', () => {
    const reg = authorityService.getRegistry();
    assert.strictEqual(reg.owner, 'Dhaval Chandrashekhar Batwal');
    assert.strictEqual(reg.coOwner, 'Hemangini Chandrashwkhar Batwal');
    assert.strictEqual(reg.coOperationalOwner, 'Jayshriben Chandrashekhar Batwal');
  });

  runTest('5.2 Dhaval display designation change preserves immutable permissions and anti-lockout', () => {
    const res = authorityService.updateDesignation('Dhaval Chandrashekhar Batwal', 'Director');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.profile?.currentDesignation, 'Director');
    assert.strictEqual(res.profile?.protectedAuthority, true);
    assert.strictEqual(res.profile?.antiLockoutActive, true);
    assert.ok(res.profile?.effectivePermissions.includes('PERMANENT_SUPREME_AUTHORITY'));
  });

  runTest('5.3 Unauthorized actor cannot change Dhaval designation (Blocked with audit entry)', () => {
    const res = authorityService.updateDesignation('Attacker Anonymous', 'Owner');
    assert.strictEqual(res.success, false);
    assert.ok(res.message.includes('Security Violation'));

    const logs = authorityService.getAuditLogs();
    const latest = logs[0];
    assert.strictEqual(latest.outcome, 'BLOCKED');
    assert.strictEqual(latest.actor, 'Attacker Anonymous');
  });

  console.log('\n--- TEST GROUP 6: SECTION 7 & 23.3 YAGYX CHAIN INTEGRATION TESTS ---');

  runTest('6.1 YAGYX Chain ID conforms strictly to 13370 and hex 0x343a', () => {
    assert.strictEqual(YAGYX_CHAIN_ID, 13370);
    assert.strictEqual(YAGYX_CHAIN_HEX, '0x343a');
    assert.strictEqual(parseInt(YAGYX_CHAIN_HEX, 16), 13370);
  });

  console.log('\n--- TEST GROUP 7: SECTION 12 & 23.6 REAL AGENT EXECUTION & LOGGING TESTS ---');

  await runAsyncTest('7.1 Dispatches real task execution, verifies tool access and logs latency/tokens', async () => {
    const res = await agentEngine.executeTask(
      'agent-sarathi-orch',
      'Validate system architecture invariants and verify zero clock drift',
      'Test Suite Operator'
    );
    assert.strictEqual(res.success, true);
    assert.ok(res.execution);
    assert.strictEqual(res.execution.agentId, 'agent-sarathi-orch');
    assert.strictEqual(res.execution.state, 'COMPLETED');
    assert.ok(res.execution.latencyMs !== undefined && res.execution.latencyMs > 0);
    assert.ok(res.execution.resourceUsage.tokenCount > 0);
    assert.strictEqual(res.execution.resourceUsage.costInr, 0.05);
    assert.ok(res.execution.outputSummary?.includes('SARATHI Core Orchestrator'));
  });

  await runAsyncTest('7.2 Execution logs are durably saved and retrievable via getExecutionLogs', async () => {
    const logs = agentEngine.getExecutionLogs('agent-sarathi-orch');
    assert.ok(logs.length > 0);
    const latest = logs[0];
    assert.strictEqual(latest.agentId, 'agent-sarathi-orch');
    assert.strictEqual(latest.state, 'COMPLETED');
    assert.strictEqual(latest.authorizedActor, 'Test Suite Operator');
  });

  await runAsyncTest('7.3 Rejects execution on nonexistent agent ID with descriptive error', async () => {
    try {
      await agentEngine.executeTask('agent-nonexistent-999', 'Should fail immediately');
      assert.fail('Should have thrown an error for nonexistent agent');
    } catch (err: any) {
      assert.ok(err.message.includes('not found'));
    }
  });

  console.log('\n--- TEST GROUP 8: SECTION 2 AI PERSONA REGISTRY & INTEGRITY TESTS ---');

  runTest('8.1 Personas exist as separate behavioral concepts from agents with verified evaluations', () => {
    const personas = personaEngine.getAll();
    assert.ok(personas.length >= 6);
    const acharya = personaEngine.getById('persona-acharya-01');
    assert.ok(acharya);
    assert.strictEqual(acharya.name, 'ACHARYA');
    assert.strictEqual(acharya.interactionStyle, 'Socratic Mentor');
    assert.strictEqual(acharya.status, 'ACTIVE');
    assert.strictEqual(acharya.testPassed, true);
    assert.ok(acharya.systemInstructions.length > 20);
  });

  runTest('8.2 Persona stats accurately report registered count vs 1B target vision capacity', () => {
    // Clean up test persona if exists from previous run
    const existing = personaEngine.getAll().find((p) => p.name === 'VIGNESHWARA');
    if (existing) {
      personaEngine.deletePersona(existing.id);
    }

    const stats = personaEngine.getAuditedStats();
    assert.ok(stats.totalRegistered >= 14, `Expected at least 14 registered personas, got ${stats.totalRegistered}`);
    assert.strictEqual(stats.uniqueAndValid, stats.totalRegistered);
    assert.strictEqual(stats.active, stats.totalRegistered);
    assert.strictEqual(stats.disabled, 0);
    assert.strictEqual(stats.duplicates, 0);
    assert.ok(stats.targetCapacityDisplay.includes('1,000,000,000 Target Capacity'));
  });

  runTest('8.3 Creates new valid persona and searches with style filter', () => {
    const created = personaEngine.createPersona({
      name: 'VIGNESHWARA',
      tagline: 'Obstacle Remover & System Initializer',
      purpose: 'Verifies environment prerequisites before complex multi-step pipelines.',
      interactionStyle: 'Deterministic Systems Engineer',
      systemInstructions: 'Verify all hardware, environment variables, and cryptographic keys before allowing execution.',
      associatedBaseModel: 'Gemini 2.5 Flash',
      permissionScope: ['CHECK_PRECONDITIONS'],
      limitations: ['Cannot modify runtime state'],
    });

    assert.strictEqual(created.success, true);
    assert.ok(created.persona);

    const filtered = personaEngine.search('VIGNESHWARA', 'Deterministic Systems Engineer');
    assert.ok(filtered.length >= 1);
    assert.strictEqual(filtered[0].name, 'VIGNESHWARA');

    // Clean up created test persona to guarantee idempotency
    personaEngine.deletePersona(created.persona.id);
  });

  runTest('8.4 10,000 IQ real-person polymath personas configured with strict simulation transparency & cognitive depth', () => {
    const ramanujan = personaEngine.getById('persona-ramanujan-10k');
    assert.ok(ramanujan);
    assert.ok(ramanujan.name.startsWith('RAMANUJAN'));
    assert.ok(ramanujan.iqBenchmarkTarget && ramanujan.iqBenchmarkTarget >= 10000);
    assert.strictEqual(ramanujan.isHistoricalPolymathPersona, true);
    assert.strictEqual(ramanujan.realPersonInspiration, 'Srinivasa Ramanujan (1887–1920)');
    assert.ok(ramanujan.systemInstructions.includes('Srinivasa Ramanujan'));
    assert.ok(ramanujan.systemInstructions.includes('AI behavioral simulation honoring'));

    const daVinci = personaEngine.getById('persona-davinci-10k');
    assert.ok(daVinci);
    assert.strictEqual(daVinci.realPersonInspiration, 'Leonardo da Vinci (1452–1519)');
    assert.ok(daVinci.iqBenchmarkTarget && daVinci.iqBenchmarkTarget >= 10000);

    const aryabhata = personaEngine.getById('persona-aryabhata-10k');
    assert.ok(aryabhata);
    assert.strictEqual(aryabhata.realPersonInspiration, 'Aryabhata (476–550 CE)');

    const chanakya = personaEngine.getById('persona-chanakya-10k');
    assert.ok(chanakya);
    assert.strictEqual(chanakya.realPersonInspiration, 'Chanakya / Kautilya (c. 375–283 BCE)');

    const tesla = personaEngine.getById('persona-tesla-10k');
    assert.ok(tesla);
    assert.strictEqual(tesla.realPersonInspiration, 'Nikola Tesla (1856–1943)');
  });

  console.log('\n--- TEST GROUP 9: SECTION 8 PROJECT CREATION, FEEDBACK PERSISTENCE & VOTE INTEGRITY ---');

  const testProjectService = new ProjectService([]);

  let createdProjectId = '';
  runTest('9.1 Creates project with specification and interactive prototype', () => {
    const proj = testProjectService.create({
      title: 'Decentralized Compute Mesh Simulator',
      description: 'Simulates micro-compute tasks distributed across Android and laptop clusters with 1% commission.',
      category: 'Web3 & FinTech',
      type: 'Interactive Prototype',
      tags: ['compute', 'simulation', 'mesh'],
    });

    assert.ok(proj.id);
    assert.strictEqual(proj.title, 'Decentralized Compute Mesh Simulator');
    assert.strictEqual(proj.stars, 0);
    createdProjectId = proj.id;
  });

  let createdFeedbackId = '';
  runTest('9.2 Adds community feedback to project with durable storage', () => {
    const fb = testProjectService.addFeedback(createdProjectId, {
      author: 'Arjun Verma',
      content: 'Suggest adding latency distribution curve for mobile network nodes.',
      type: 'suggestion',
    });

    assert.ok(fb);
    assert.strictEqual(fb.author, 'Arjun Verma');
    assert.strictEqual(fb.upvotes, 0);
    createdFeedbackId = fb.id;

    const proj = testProjectService.getById(createdProjectId);
    assert.strictEqual(proj?.feedback.length, 1);
  });

  runTest('9.3 Duplicate vote prevention cleanly toggles upvotes without inflated counters', () => {
    // First vote by user-123
    const v1 = testProjectService.voteFeedback(createdProjectId, createdFeedbackId, 'user-123');
    assert.strictEqual(v1.success, true);
    assert.strictEqual(v1.feedback?.upvotes, 1);

    // Second vote by SAME user-123 toggles off
    const v2 = testProjectService.voteFeedback(createdProjectId, createdFeedbackId, 'user-123');
    assert.strictEqual(v2.success, true);
    assert.strictEqual(v2.feedback?.upvotes, 0);

    // Vote again by user-123 toggles on
    const v3 = testProjectService.voteFeedback(createdProjectId, createdFeedbackId, 'user-123');
    assert.strictEqual(v3.success, true);
    assert.strictEqual(v3.feedback?.upvotes, 1);

    // Vote by DIFFERENT user-456 increments to 2
    const v4 = testProjectService.voteFeedback(createdProjectId, createdFeedbackId, 'user-456');
    assert.strictEqual(v4.success, true);
    assert.strictEqual(v4.feedback?.upvotes, 2);
  });

  runTest('9.4 Deletes feedback cleanly from project', () => {
    const deleted = testProjectService.deleteFeedback(createdProjectId, createdFeedbackId);
    assert.strictEqual(deleted, true);

    const proj = testProjectService.getById(createdProjectId);
    assert.strictEqual(proj?.feedback.length, 0);
  });

  console.log('\n--- TEST GROUP 10: SECTION 7 & 9 MEMBERSHIP PRICING & ASSET SPECS ---');

  runTest('10.1 Membership pricing strictly adheres to ₹100/mo India and $1/mo Global', () => {
    const indiaPriceInr = 100;
    const globalPriceUsd = 1.0;
    assert.strictEqual(indiaPriceInr, 100);
    assert.strictEqual(globalPriceUsd, 1.0);
  });

  runTest('10.2 Asset reference and peg configurations adhere to declared economics', () => {
    const ygoRefPriceInr = 1.0; // ₹1 reference
    const yagyxRefPriceInr = 100.0; // ₹100 reference
    const yinrPegInr = 1.0; // ₹1 per YINR peg
    const yusdPegUsd = 1.0; // $1 per YUSD peg

    assert.strictEqual(ygoRefPriceInr, 1.0);
    assert.strictEqual(yagyxRefPriceInr, 100.0);
    assert.strictEqual(yinrPegInr, 1.0);
    assert.strictEqual(yusdPegUsd, 1.0);
  });

  console.log('\n--- TEST GROUP 11: SECTION 24 FINANCIAL EDGE CASES & PRECISION INVARIANTS ---');

  runTest('11.1 Zero amount compute job produces exactly ₹0 commission and ₹0 settlement', () => {
    const totalAmount = 0;
    const commission = Math.round(totalAmount * 0.01 * 100) / 100;
    const settlement = totalAmount - commission;
    assert.strictEqual(commission, 0);
    assert.strictEqual(settlement, 0);
  });

  runTest('11.2 Micro-transaction of 1 paisa (₹0.01) calculates zero commission with mathematical safety', () => {
    const totalAmount = 0.01;
    const commission = Math.round(totalAmount * 0.01 * 100) / 100;
    const settlement = Math.round((totalAmount - commission) * 100) / 100;
    assert.strictEqual(commission, 0);
    assert.strictEqual(settlement, 0.01);
  });

  runTest('11.3 High-value compute transaction (₹1,000,000) calculates exact ₹10,000 commission', () => {
    const totalAmount = 1000000;
    const commission = Math.round(totalAmount * 0.01);
    const settlement = totalAmount - commission;
    assert.strictEqual(commission, 10000);
    assert.strictEqual(settlement, 990000);
  });

  runTest('11.4 Integer minor unit invariant: paisa-based settlement reconciles exactly across randomized amounts', () => {
    const testVectors = [0, 0.01, 1, 99.99, 100, 1337.5, 2500, 9999.99, 50000, 10000000];
    for (const gross of testVectors) {
      const grossPaisa = Math.max(0, Math.round(gross * 100));
      const commissionPaisa = Math.round(grossPaisa * 0.01);
      const settlementPaisa = grossPaisa - commissionPaisa;
      assert.strictEqual(grossPaisa, commissionPaisa + settlementPaisa, `Invariant broken for gross amount ₹${gross}`);
      assert.strictEqual(grossPaisa >= 0, true);
      assert.strictEqual(commissionPaisa >= 0, true);
      assert.strictEqual(settlementPaisa >= 0, true);
    }
  });

  runTest('11.5 Negative or malformed input clamped to 0 without ledger corruption', () => {
    const negativeGross = -500;
    const grossPaisa = Math.max(0, Math.round(negativeGross * 100));
    const commissionPaisa = Math.round(grossPaisa * 0.01);
    const settlementPaisa = grossPaisa - commissionPaisa;
    assert.strictEqual(grossPaisa, 0);
    assert.strictEqual(commissionPaisa, 0);
    assert.strictEqual(settlementPaisa, 0);
  });

  runTest('11.6 Very high value transaction (₹10,000,000) integer minor units exact ₹100,000 commission', () => {
    const gross = 10000000;
    const grossPaisa = Math.round(gross * 100);
    const commissionPaisa = Math.round(grossPaisa * 0.01);
    const settlementPaisa = grossPaisa - commissionPaisa;
    assert.strictEqual(commissionPaisa, 10000000); // 10,000,000 paise = ₹100,000
    assert.strictEqual(settlementPaisa, 990000000); // 990,000,000 paise = ₹9,900,000
    assert.strictEqual(commissionPaisa / 100, 100000);
    assert.strictEqual(settlementPaisa / 100, 9900000);
  });

  console.log('\n--- TEST GROUP 12: MULTI-BRAIN ORCHESTRATION & 20 SPECIALIST ROLES ---');

  runTest('12.1 Exactly 20 specialist reasoning roles are defined with permitted tools and constraints', () => {
    const roles = verseOrchestrator.specialistRoles;
    assert.strictEqual(roles.length, 20);
    const chief = roles.find((r) => r.id === 'role-chief-orchestrator');
    const critic = roles.find((r) => r.id === 'role-adversarial-critic');
    const fin = roles.find((r) => r.id === 'role-financial-auditor');
    assert.ok(chief);
    assert.ok(critic);
    assert.ok(fin);
    assert.ok(critic.instructions.includes('red-teaming'));
  });

  runTest('12.2 Multi-Brain Selection utility formula correctly scores relevance and penalties', () => {
    const models = verseOrchestrator.modelRegistry;
    assert.ok(models.length >= 2);
    const utility = verseOrchestrator.calculateModelUtility(models[0], 'general', false);
    assert.ok(utility > 50 && utility <= 100);
  });

  await runAsyncTest('12.3 9-Stage Quality Review Gates execute with adversarial challenge and explicit limitations', async () => {
    const plan = await verseOrchestrator.orchestrateTask({
      taskQuery: 'Verify decentralized audit oracle invariant bounds',
    });
    assert.strictEqual(plan.reviewStages.length, 9);
    assert.ok(plan.selectedRoles.length >= 3);
    assert.ok(plan.adversarialChallenge.criticRole === 'Adversarial Critic');
    assert.ok(plan.finalOutput.explicitLimitations.length >= 1);
  });

  console.log('\n--- TEST GROUP 13: DEMAND-SIGNAL INTELLIGENCE & 6-FACTOR OPPORTUNITY SCORING ---');

  runTest('13.1 Opportunity scoring formula evaluates 0.25P + 0.20I + 0.15F + 0.15R + 0.15V + 0.10Q with mathematical precision', () => {
    const result = demandSignalEngine.calculateOpportunityScore({
      problemRelevance: 80,
      intent: 70,
      feedbackQuality: 60,
      repeatedEngagement: 50,
      demonstratedValue: 90,
      evidenceQuality: 100,
    });
    // Expected: 20 + 14 + 9 + 7.5 + 13.5 + 10 = 74
    assert.strictEqual(result.totalScore, 74);
    assert.ok(result.confidence > 80);
  });

  runTest('13.2 Product events are deduplicated within 3-second rapid window to prevent client inflation', () => {
    const r1 = demandSignalEngine.recordEvent({
      eventType: 'PROBLEM_SUBMITTED',
      subjectId: 'usr-audit-runner',
      projectId: 'proj-1',
      source: 'unit_test',
    });
    assert.strictEqual(r1.success, true);

    const r2 = demandSignalEngine.recordEvent({
      eventType: 'PROBLEM_SUBMITTED',
      subjectId: 'usr-audit-runner',
      projectId: 'proj-1',
      source: 'unit_test',
    });
    assert.strictEqual(r2.success, false);
    assert.ok(r2.message.includes('Deduplicated'));
  });

  runTest('13.3 Customer discovery opportunity records categorize evidence levels from Level 0 to Level 5', () => {
    const opps = demandSignalEngine.getOpportunities();
    assert.ok(opps.length >= 2);
    const opp1 = opps[0];
    assert.ok(['LEVEL_0_AI_HYPOTHESIS', 'LEVEL_1_INDIRECT_RESEARCH', 'LEVEL_2_DIRECT_USER_FEEDBACK', 'LEVEL_3_WORKING_PROTOTYPE_ATTEMPT', 'LEVEL_4_MEASURED_RETAINED_VALUE', 'LEVEL_5_VERIFIED_PURCHASE'].includes(opp1.evidenceLevel));
    assert.ok(opp1.recommendedAction.action.length > 0);
  });

  console.log('\n--- TEST GROUP 14: YAGYX-NATIVE ON-CHAIN PAYMENT VERIFICATION (Section 8 Directive) ---');

  runTest('14.1 Rejects unsupported token and fiat gateways (Stripe/Razorpay prohibited)', () => {
    const res = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'FIAT_GATEWAY' as any,
    });
    assert.strictEqual(res.success, false);
    assert.ok(res.error?.includes('Unsupported payment token'));
  });

  runTest('14.2 Calculates exact integer base units (18 decimals) without floating-point drift', () => {
    const ygoOrder = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.strictEqual(ygoOrder.success, true);
    assert.strictEqual(ygoOrder.order?.humanAmountRequired, 100);
    // 100 * 10^18
    assert.strictEqual(ygoOrder.order?.baseUnitsRequired, '100000000000000000000');
    assert.strictEqual(ygoOrder.order?.chainId, YAGYX_CHAIN_ID);
    assert.strictEqual(ygoOrder.order?.expectedRecipient, FUTUREVERSE_PAYMENT_VAULT_ADDRESS);
  });

  await runAsyncTest('14.3 Rejects verification when transaction was executed on wrong network (wrong chain ID)', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YAGYX',
    });
    assert.ok(orderRes.order);
    const orderId = orderRes.order.orderId;
    const testHash = `0xwrong_chain_tx_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderId, {
      simulatedReceipt: {
        status: 1,
        chainId: 1, // Mainnet Ethereum instead of 13370
        to: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: orderRes.order.baseUnitsRequired,
        blockNumber: 1337042,
        confirmations: 3,
      },
    });

    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('Wrong network'));
  });

  await runAsyncTest('14.4 Rejects underpayment and reverted transaction receipts', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const orderId = orderRes.order.orderId;
    const testHash = `0xunderpay_tx_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderId, testHash);

    // Test underpayment
    const verification = await yagyxPaymentService.verifyPayment(orderId, {
      simulatedReceipt: {
        status: 1,
        chainId: YAGYX_CHAIN_ID,
        to: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: '1000000000000000000', // Only 1 token instead of 100
        blockNumber: 1337043,
        confirmations: 3,
      },
    });
    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('Underpayment'));
  });

  await runAsyncTest('14.5 Rejects transaction to incorrect recipient address', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const orderId = orderRes.order.orderId;
    const testHash = `0xwrong_recipient_tx_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderId, {
      simulatedReceipt: {
        status: 1,
        chainId: YAGYX_CHAIN_ID,
        to: '0xattacker00000000000000000000000000000000', // Malicious address
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: orderRes.order.baseUnitsRequired,
        blockNumber: 1337044,
        confirmations: 3,
      },
    });
    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('Invalid recipient'));
  });

  await runAsyncTest('14.6 Authoritative on-chain payment verification activates 30-day membership entitlement atomically', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YAGYX',
    });
    assert.ok(orderRes.order);
    const orderId = orderRes.order.orderId;
    const testHash = `0xvalid_onchain_settle_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderId, {
      mockRpcVerification: true,
    });
    assert.strictEqual(verification.verified, true);
    assert.strictEqual(verification.membershipStatus, 'ACTIVE');
    assert.strictEqual(verification.order?.state, 'MEMBERSHIP_ACTIVE');
    assert.strictEqual(verification.order?.targetDurationDays, 30);
    assert.ok(verification.order?.entitlementExpiresAt);
  });

  await runAsyncTest('14.7 Blocks replay attacks: Rejects reuse of identical transaction hash for second membership order', async () => {
    const order1 = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    const order2 = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(order1.order && order2.order);

    const sharedHash = `0xreplay_exploit_hash_${Date.now()}`;
    // First order submits and verifies successfully
    yagyxPaymentService.submitTransactionHash(order1.order.orderId, sharedHash);
    const v1 = await yagyxPaymentService.verifyPayment(order1.order.orderId, { mockRpcVerification: true });
    assert.strictEqual(v1.verified, true);

    // Second order attempts to replay the same hash -> MUST BE REJECTED
    const submit2 = yagyxPaymentService.submitTransactionHash(order2.order.orderId, sharedHash);
    assert.strictEqual(submit2.success, false);
    assert.ok(submit2.error?.includes('Replay attacks are prohibited'));
  });

  console.log('\n--- TEST GROUP 15: ASSET PACK INTEGRATION, BADGE MAPPINGS & FALLBACK LOGOS ---');

  runTest('15.1 getStatusBadgeAsset accurately maps all canonical project lifecycle statuses', () => {
    const working = getStatusBadgeAsset('Working Application', 'Working Application');
    assert.strictEqual(working.src, '/badges/working-application.svg');
    assert.strictEqual(working.label, 'Working Application');

    const proto = getStatusBadgeAsset('Interactive Prototype', 'Interactive Prototype');
    assert.strictEqual(proto.src, '/badges/interactive-prototype.svg');
    assert.strictEqual(proto.label, 'Interactive Prototype');

    const sim = getStatusBadgeAsset('Simulation', 'Simulation');
    assert.strictEqual(sim.src, '/badges/simulation.svg');
    assert.strictEqual(sim.label, 'Simulation');

    const dev = getStatusBadgeAsset('In Development', 'In Development');
    assert.strictEqual(dev.src, '/badges/in-development.svg');
    assert.strictEqual(dev.label, 'In Development');

    const arch = getStatusBadgeAsset('Archived', 'Archived');
    assert.strictEqual(arch.src, '/badges/archived.svg');
    assert.strictEqual(arch.label, 'Archived');
  });

  runTest('15.2 getStatusBadgeAsset robustly defaults to In Development for draft/unknown inputs', () => {
    const draft = getStatusBadgeAsset('draft');
    assert.strictEqual(draft.src, '/badges/in-development.svg');

    const undef = getStatusBadgeAsset(undefined, undefined);
    assert.strictEqual(undef.src, '/badges/in-development.svg');

    const unknown = getStatusBadgeAsset('unknown_status_xyz');
    assert.strictEqual(unknown.src, '/badges/in-development.svg');
  });

  runTest('15.3 getProjectLogo maps project titles to corresponding project SVG assets', () => {
    const career = getProjectLogo('Career & Learning Path Navigator');
    assert.strictEqual(career, '/logos/projects/career-navigator.svg');

    const mesh = getProjectLogo('Decentralized Compute Mesh Simulator');
    assert.strictEqual(mesh, '/logos/projects/compute-mesh.svg');

    const oracle = getProjectLogo('Decentralized Audit Oracle');
    assert.strictEqual(oracle, '/logos/projects/audit-oracle.svg');

    const planner = getProjectLogo('Idea-to-Product Architecture Planner');
    assert.strictEqual(planner, '/logos/projects/product-planner.svg');

    const impact = getProjectLogo('Future-Planning & Impact Simulator');
    assert.strictEqual(impact, '/logos/projects/impact-simulator.svg');

    const engine = getProjectLogo('Community Problem-Solving Engine');
    assert.strictEqual(engine, '/logos/projects/community-engine.svg');
  });

  runTest('15.4 getProjectLogo strictly falls back to official FUTUREVERSE icon for custom or unknown titles', () => {
    const fallback = getProjectLogo('Unrecognized Custom Project 404');
    assert.strictEqual(fallback, ASSETS.futureverseIcon);
    assert.strictEqual(fallback, '/logos/futureverse-icon.svg');

    const fallbackEmpty = getProjectLogo('');
    assert.strictEqual(fallbackEmpty, ASSETS.futureverseIcon);

    const explicitCustom = getProjectLogo('Any Title', '/custom/verified/logo.svg');
    assert.strictEqual(explicitCustom, '/custom/verified/logo.svg');
  });

  runTest('15.5 All ecosystem vector logos physically exist on disk and contain valid SVG markup', () => {
    const logos = [
      ASSETS.futureverseLogo,
      ASSETS.futureverseIcon,
      ASSETS.batwalsVerseAiHub,
      ASSETS.yagyxLogo,
    ];

    for (const logoPath of logos) {
      const diskPath = path.join(process.cwd(), 'public', logoPath.replace(/^\//, ''));
      assert.ok(fs.existsSync(diskPath), `Missing logo asset on disk: ${diskPath}`);
      const content = fs.readFileSync(diskPath, 'utf8');
      assert.ok(content.includes('<svg') && content.includes('</svg>'), `Invalid SVG markup in: ${diskPath}`);
      assert.ok(content.length > 50, `Suspiciously empty SVG: ${diskPath}`);
    }
  });

  runTest('15.6 All status badges physically exist on disk and contain valid SVG markup', () => {
    const badges = Object.values(ASSETS.badges);
    for (const badgePath of badges) {
      const diskPath = path.join(process.cwd(), 'public', badgePath.replace(/^\//, ''));
      assert.ok(fs.existsSync(diskPath), `Missing badge asset on disk: ${diskPath}`);
      const content = fs.readFileSync(diskPath, 'utf8');
      assert.ok(content.includes('<svg') && content.includes('</svg>'), `Invalid SVG markup in: ${diskPath}`);
      assert.ok(content.length > 50, `Suspiciously empty SVG: ${diskPath}`);
    }
  });

  runTest('15.7 All declared project logos physically exist on disk and contain valid SVG markup', () => {
    for (const projectLogoPath of Object.values(PROJECT_LOGOS)) {
      const diskPath = path.join(process.cwd(), 'public', projectLogoPath.replace(/^\//, ''));
      assert.ok(fs.existsSync(diskPath), `Missing project logo asset on disk: ${diskPath}`);
      const content = fs.readFileSync(diskPath, 'utf8');
      assert.ok(content.includes('<svg') && content.includes('</svg>'), `Invalid SVG markup in: ${diskPath}`);
      assert.ok(content.length > 50, `Suspiciously empty SVG: ${diskPath}`);
    }
  });

  console.log('\n--- TEST GROUP 16: ILLUMINATI BRAND KIT & THEME PALETTE UTILITIES ---');

  runTest('16.1 Tailwind config and CSS variables globally define gold accent (#FFD700)', () => {
    const cssPath = path.join(process.cwd(), 'src', 'index.css');
    const themePath = path.join(process.cwd(), 'public', 'ui', 'futureverse-theme.css');
    const tailwindPath = path.join(process.cwd(), 'tailwind.config.ts');

    assert.ok(fs.existsSync(cssPath), 'src/index.css must exist');
    assert.ok(fs.existsSync(themePath), 'public/ui/futureverse-theme.css must exist');
    assert.ok(fs.existsSync(tailwindPath), 'tailwind.config.ts must exist');

    const cssContent = fs.readFileSync(cssPath, 'utf8');
    const themeContent = fs.readFileSync(themePath, 'utf8');
    const tailwindContent = fs.readFileSync(tailwindPath, 'utf8');

    assert.ok(cssContent.includes('#FFD700'), 'src/index.css must enforce #FFD700');
    assert.ok(themeContent.includes('#FFD700'), 'futureverse-theme.css must enforce #FFD700');
    assert.ok(tailwindContent.includes('#FFD700'), 'tailwind.config.ts must enforce #FFD700');
  });

  runTest('16.2 Utility classes exist for text-gold-accent, bg-gold-accent, border-gold-accent, and shadow-gold-accent', () => {
    const cssContent = fs.readFileSync(path.join(process.cwd(), 'src', 'index.css'), 'utf8');
    assert.ok(cssContent.includes('.text-gold-accent'), 'Missing .text-gold-accent utility class');
    assert.ok(cssContent.includes('.bg-gold-accent'), 'Missing .bg-gold-accent utility class');
    assert.ok(cssContent.includes('.border-gold-accent'), 'Missing .border-gold-accent utility class');
    assert.ok(cssContent.includes('.shadow-gold-accent'), 'Missing .shadow-gold-accent utility class');
    assert.ok(cssContent.includes('.glow-gold-accent'), 'Missing .glow-gold-accent utility class');
  });

  runTest('16.3 Specific neon glow gradients (bg-neon-cyber, bg-gold-sheen, bg-chrome-horizon) configured with brand kit hex stops', () => {
    const cssContent = fs.readFileSync(path.join(process.cwd(), 'src', 'index.css'), 'utf8');
    assert.ok(cssContent.includes('.bg-neon-cyber'), 'Missing .bg-neon-cyber utility');
    assert.ok(cssContent.includes('#00F0FF'), 'Missing Cyber Cyan #00F0FF');
    assert.ok(cssContent.includes('#6366F1'), 'Missing Cosmic Indigo #6366F1');
    assert.ok(cssContent.includes('#D946EF'), 'Missing Neon Magenta #D946EF');
    assert.ok(cssContent.includes('.bg-chrome-horizon'), 'Missing .bg-chrome-horizon utility');
  });

  runTest('16.4 All Illuminati Brand Kit SVG vector files and app icons exist and are valid', () => {
    const brandKitAssets = [
      'logos/futureverse-emblem.svg',
      'logos/futureverse-logo.svg',
      'logos/futureverse-wordmark-neon.svg',
      'logos/futureverse-wordmark-gold.svg',
      'logos/futureverse-wordmark-mono.svg',
      'logos/futureverse-icon.svg',
      'icons/app-icon-neon.svg',
      'icons/app-icon-gold.svg',
      'icons/app-icon-mono.svg',
      'animation/futureverse-loader.css',
      'brand-kit/README.md',
      'brand-kit/brand-guidelines.md',
    ];

    for (const relPath of brandKitAssets) {
      const diskPath = path.join(process.cwd(), 'public', relPath);
      assert.ok(fs.existsSync(diskPath), `Missing Illuminati Brand Kit asset: ${diskPath}`);
      const stats = fs.statSync(diskPath);
      assert.ok(stats.size > 20, `Asset is unexpectedly empty: ${diskPath}`);
    }
  });

  console.log('\n--- TEST GROUP 17: 1,000,000 IQ (1000k IQ) ALGORITHM & REAL WORLD PERSONAS ---');

  runTest('17.1 Real-world polymath council includes Turing, Shannon, Gauss, Noether, Ramanujan, Da Vinci, Einstein, Von Neumann', () => {
    const council = superIqAlgorithmEngine.getAllRealPersonPersonas();
    assert.ok(council.length >= 17, `Council should have at least 17 members, got ${council.length}`);
    const turing = council.find((p) => p.id === 'persona-turing-1000k');
    const shannon = council.find((p) => p.id === 'persona-shannon-1000k');
    const gauss = council.find((p) => p.id === 'persona-gauss-1000k');
    const noether = council.find((p) => p.id === 'persona-noether-1000k');
    assert.ok(turing, 'Missing Turing 1000k persona');
    assert.ok(shannon, 'Missing Shannon 1000k persona');
    assert.ok(gauss, 'Missing Gauss 1000k persona');
    assert.ok(noether, 'Missing Noether 1000k persona');
    assert.strictEqual(turing.iqBenchmark, 1000000);
    assert.strictEqual(shannon.iqBenchmark, 1000000);
  });

  await runAsyncTest('17.2 superIqAlgorithmEngine.execute1000kIqAlgorithm synthesizes 1,000,000 IQ benchmark with Turing decidability and Shannon entropy invariants', async () => {
    const result = await superIqAlgorithmEngine.execute1000kIqAlgorithm({
      prompt: 'Decentralized fault-tolerant consensus pipeline with cryptographic state verification',
    });
    assert.strictEqual(result.iqBenchmark, 1000000);
    assert.ok(result.algorithmTier === '1000000iq' || result.algorithmTier === '1000k');
    assert.ok(result.mathematicalInvariants.formalProofStatement.includes('Shannon entropy') || result.mathematicalInvariants.formalProofStatement.includes('invariant'));
    assert.ok(result.mathematicalInvariants.primaryEquation.includes('H(X)') || result.mathematicalInvariants.primaryEquation.includes('log'));
    assert.ok(result.polymathCouncilReview.length >= 4);
    assert.ok(result.transparencyNotice.includes('1,000,000 IQ') || result.transparencyNotice.includes('1000k IQ'));
  });

  await runAsyncTest('17.3 Targeted persona synthesis honors chosen real-world persona (Turing-1000k) with authentic historical sources and invariant principles', async () => {
    const result = await superIqAlgorithmEngine.execute100kIqAlgorithm({
      prompt: 'Automated state machine validation engine',
      personaId: 'persona-turing-1000k',
    });
    assert.strictEqual(result.iqBenchmark, 1000000);
    assert.strictEqual(result.primaryPersona?.historicalName, 'Alan Turing');
    assert.ok(result.primaryPersona?.historicalSources.some((s) => s.includes('Computable Numbers')));
    assert.ok(result.polymathCouncilReview[0].personaName.includes('TURING'));
  });

  runTest('17.4 PersonaEngine persists and filters 1,000,000 IQ (1000k) real-world personas with strict simulation transparency notice', () => {
    const all = personaEngine.getAll();
    const turingPersona = all.find((p) => p.id === 'persona-turing-1000k');
    assert.ok(turingPersona, 'PersonaEngine should include persona-turing-1000k');
    assert.strictEqual(turingPersona.iqBenchmarkTarget, 1000000);
    assert.ok(turingPersona.isHistoricalPolymathPersona, 'Must be marked as historical polymath persona');
    assert.ok(!turingPersona.isTrainedModel, 'Must not falsely claim to be a trained model');
    assert.ok(turingPersona.simulationTransparencyNotice?.includes('AI behavioral simulation honoring Alan Turing'));
  });

  console.log('\n--- TEST GROUP 18: PROJECT ZIP EXPORT & VERIFIED 403 REMEDIATION ---');

  runTest('18.1 Generated public-safe source release archive exists on disk and has a valid ZIP signature', () => {
    const zipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.ok(fs.existsSync(zipPath), `Generated source archive must exist at ${zipPath}; run the release generator first`);
    const stats = fs.statSync(zipPath);
    assert.ok(stats.size > 1024 * 1024, `Archive size must be > 1MB, got ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
    const fd = fs.openSync(zipPath, 'r');
    const header = Buffer.alloc(4);
    try {
      fs.readSync(fd, header, 0, 4, 0);
    } finally {
      fs.closeSync(fd);
    }
    assert.strictEqual(header[0], 0x50, 'ZIP byte 0 must be P');
    assert.strictEqual(header[1], 0x4b, 'ZIP byte 1 must be K');
    assert.strictEqual(header[2], 0x03, 'ZIP byte 2 must be 0x03');
    assert.strictEqual(header[3], 0x04, 'ZIP byte 3 must be 0x04');
  });

  runTest('18.2 Generated public-safe source archive exists in the expected local path', () => {
    const zipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.ok(fs.existsSync(zipPath), 'Generated source release must exist (run the release generator first)');
    assert.ok(fs.statSync(zipPath).size > 1 * 1024 * 1024, 'Generated source release must contain the application source');
    execSync(`unzip -t "${zipPath}"`, { stdio: 'pipe' });
  });

  runTest('18.3 Generated source ZIP SHA-256 matches the release manifest', () => {
    const zipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.ok(fs.existsSync(zipPath), 'Generated source release must exist');
    const hash = crypto.createHash('sha256').update(fs.readFileSync(zipPath)).digest('hex');
    const ledgerPath = path.join(process.cwd(), 'release_checksums.json');
    assert.ok(fs.existsSync(ledgerPath), 'Release manifest must exist after generation');
    const ledger = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
    const entry = ledger.release_archives?.['FUTUREVERSE_FINAL_RELEASE.zip'];
    assert.ok(entry, 'Manifest must include the generated source release');
    assert.strictEqual(hash, entry.sha256, 'SHA-256 must match the generated release manifest');
  });

  runTest('18.4 Release manifest file count and size match the generated source ZIP', () => {
    const zipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    const ledgerPath = path.join(process.cwd(), 'release_checksums.json');
    assert.ok(fs.existsSync(zipPath) && fs.existsSync(ledgerPath), 'Archive and manifest must exist');
    const ledger = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
    const entry = ledger.release_archives?.['FUTUREVERSE_FINAL_RELEASE.zip'];
    assert.ok(entry, 'Manifest must include the generated source release');
    assert.strictEqual(entry.size, fs.statSync(zipPath).size, 'Manifest archive size should match the file');
    const count = execSync(`unzip -Z1 "${zipPath}"`, { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean).length;
    assert.strictEqual(entry.fileCount, count, 'Manifest file count should match archive entries');
  });

  console.log('\n--- TEST GROUP 19: CREATIVE STUDIO HUB & ASSET LIBRARY ---');

  runTest('19.1 Creative Studio Hub component and scope documentation exist on disk', () => {
    const hubComponentPath = path.join(process.cwd(), 'src', 'components', 'CreativeStudioHub.tsx');
    const scopeDocPath = path.join(process.cwd(), 'CREATIVE_STUDIOS_SCOPE.md');
    assert.ok(fs.existsSync(hubComponentPath), 'CreativeStudioHub.tsx must exist');
    assert.ok(fs.existsSync(scopeDocPath), 'CREATIVE_STUDIOS_SCOPE.md must exist');
    const compContent = fs.readFileSync(hubComponentPath, 'utf8');
    assert.ok(compContent.includes('CreativeStudioHub'), 'Component must export CreativeStudioHub');
  });

  runTest('19.2 Creative Studio specifications define 14 specialized creative workspaces and Asset Library', () => {
    const hubComponentPath = path.join(process.cwd(), 'src', 'components', 'CreativeStudioHub.tsx');
    const compContent = fs.readFileSync(hubComponentPath, 'utf8');
    const expectedStudios = [
      'Music Studio', 'Image Studio', 'Video Studio', 'Voice Studio',
      'Animation Studio', '3D Studio', 'Game Studio', 'App Studio',
      'Website Studio', 'Story Studio', 'Podcast Studio', 'POD Design Studio'
    ];
    for (const name of expectedStudios) {
      assert.ok(compContent.includes(name), `Creative Studio Hub must configure ${name}`);
    }
    assert.ok(compContent.includes('print-on-demand'), 'Must include print-on-demand');
    assert.ok(compContent.includes('CreativeAsset'), 'Must define CreativeAsset for Asset Library');
  });

  runTest('19.3 Visual scene photo assets and Creative Studios assets exist on disk', () => {
    const requiredImages = [
      'hero_creation_canvas_1791613081866.jpg',
      'avatar_founder_elena_1791613095368.jpg',
      'interactive_simulation_hub_1791613110482.jpg',
      'community_evolution_board_1791613125845.jpg',
    ];
    for (const img of requiredImages) {
      assert.ok(fs.existsSync(path.join(process.cwd(), 'src', 'assets', 'images', img)), `src image must exist: ${img}`);
      assert.ok(fs.existsSync(path.join(process.cwd(), 'public', 'assets', 'images', img)), `public image must exist: ${img}`);
    }
  });

  console.log('\n--- TEST GROUP 20: STRICT OWNER-ONLY ZIP DOWNLOAD SECURITY & AUDIT ---');

  runTest('20.1 Audit static directories: public/ and dist/ contain ZERO unprotected project release ZIPs', () => {
    const scanDirs = [path.join(process.cwd(), 'public'), path.join(process.cwd(), 'dist')];
    for (const dir of scanDirs) {
      if (!fs.existsSync(dir)) continue;
      const scan = (current: string) => {
        const entries = fs.readdirSync(current, { withFileTypes: true });
        for (const entry of entries) {
          const fullPath = path.join(current, entry.name);
          if (entry.isDirectory()) {
            scan(fullPath);
          } else if (entry.name.toLowerCase().endsWith('.zip')) {
            // Only non-project assets (such as the 22KB SVG brand kit) are permitted in public
            const stats = fs.statSync(fullPath);
            assert.ok(
              stats.size < 500 * 1024,
              `Static directory ${dir} must NOT contain project release ZIPs. Found: ${fullPath} (${stats.size} bytes)`
            );
          }
        }
      };
      scan(dir);
    }
  });

  runTest('20.2 Canonical owner identity validation strictly recognizes owners and rejects non-owners', () => {
    // Valid canonical owners
    assert.strictEqual(authorityService.isCanonicalOwner('Dhaval Chandrashekhar Batwal'), true);
    assert.strictEqual(authorityService.isCanonicalOwner('usr-dhaval-canonical-001'), true);
    assert.strictEqual(authorityService.isCanonicalOwner('Hemangini Chandrashwkhar Batwal'), true);
    assert.strictEqual(authorityService.isCanonicalOwner('Jayshriben Chandrashekhar Batwal'), true);
    // Owner email identity recognition
    assert.strictEqual(authorityService.isCanonicalOwner('aibabayaga0@gmail.com'), true);
    assert.strictEqual(authorityService.isCanonicalOwner('aibabayaga0'), true);

    // Unauthorized entities must be strictly rejected
    assert.strictEqual(authorityService.isCanonicalOwner(''), false);
    assert.strictEqual(authorityService.isCanonicalOwner('guest'), false);
    assert.strictEqual(authorityService.isCanonicalOwner('attacker_admin'), false);
    assert.strictEqual(authorityService.isCanonicalOwner('Elena Rostova'), false);
    assert.strictEqual(authorityService.isCanonicalOwner(undefined as any), false);
  });

  runTest('20.3 Owner sign-in requires distinct configured owner secrets and rejects spoofed identities', () => {
    const names = ['FUTUREVERSE_OWNER_KEY', 'FUTUREVERSE_CO_OWNER_KEY', 'FUTUREVERSE_COOP_OWNER_KEY'] as const;
    const previous = Object.fromEntries(names.map((name) => [name, process.env[name]])) as Record<(typeof names)[number], string | undefined>;
    process.env.FUTUREVERSE_OWNER_KEY = 'test-only-dhaval-secret-0123456789-ABCDEF';
    process.env.FUTUREVERSE_CO_OWNER_KEY = 'test-only-hemangini-secret-0123456789-ABCDEF';
    process.env.FUTUREVERSE_COOP_OWNER_KEY = 'test-only-jayshriben-secret-0123456789-ABCDEF';
    try {
      const noSecret = authorityService.authenticateOwner('Dhaval Chandrashekhar Batwal');
      assert.strictEqual(noSecret.success, false, 'A canonical name alone cannot authenticate');

      const outsider = authorityService.authenticateOwner('unauthorized_user_99', 'test-only-dhaval-secret-0123456789-ABCDEF');
      assert.strictEqual(outsider.success, false, 'Unregistered identities must be rejected');

      const substringSpoof = authorityService.authenticateOwner('xDhaval Chandrashekhar Batwalx', 'test-only-dhaval-secret-0123456789-ABCDEF');
      assert.strictEqual(substringSpoof.success, false, 'Substring matches must never authenticate');

      const ownerAuth = authorityService.authenticateOwner('aibabayaga0@gmail.com', 'test-only-dhaval-secret-0123456789-ABCDEF');
      assert.strictEqual(ownerAuth.success, true, 'Canonical owner email must still work with owner secret');
      assert.strictEqual(ownerAuth.role, 'OWNER');
      assert.ok(ownerAuth.sessionToken && ownerAuth.sessionToken.startsWith('fv-owner-'));

      const wrongOwnerKey = authorityService.authenticateOwner('Hemangini Chandrashwkhar Batwal', 'test-only-dhaval-secret-0123456789-ABCDEF');
      assert.strictEqual(wrongOwnerKey.success, false, 'Dhaval key must not authenticate the co-owner');
      const coOwnerAuth = authorityService.authenticateOwner('Hemangini Chandrashwkhar Batwal', 'test-only-hemangini-secret-0123456789-ABCDEF');
      assert.strictEqual(coOwnerAuth.success, true, 'Co-owner must authenticate with their own credential');
      assert.strictEqual(coOwnerAuth.role, 'CO_OWNER');

      const wrongCoOperationalKey = authorityService.authenticateOwner('Jayshriben Chandrashekhar Batwal', 'test-only-hemangini-secret-0123456789-ABCDEF');
      assert.strictEqual(wrongCoOperationalKey.success, false, 'Co-owner key must not authenticate the operational co-owner');
      const coOperationalAuth = authorityService.authenticateOwner('Jayshriben Chandrashekhar Batwal', 'test-only-jayshriben-secret-0123456789-ABCDEF');
      assert.strictEqual(coOperationalAuth.success, true);
      assert.strictEqual(coOperationalAuth.role, 'CO_OPERATIONAL_OWNER');

      const sessionCheck = authorityService.verifyOwnerSession(ownerAuth.sessionToken);
      assert.strictEqual(sessionCheck.valid, true);
      assert.strictEqual(sessionCheck.role, 'OWNER');
      const badCheck = authorityService.verifyOwnerSession('fv-owner-tampered-fake-token-12345');
      assert.strictEqual(badCheck.valid, false);
    } finally {
      for (const name of names) {
        if (previous[name] === undefined) delete process.env[name];
        else process.env[name] = previous[name];
      }
    }
  });

  runTest('20.4 Single-use download nonces enforce strict consumption and replay prevention', () => {
    const previousSecret = process.env.FUTUREVERSE_OWNER_KEY;
    process.env.FUTUREVERSE_OWNER_KEY = 'test-only-dhaval-secret-0123456789-ABCDEF';
    try {
    const authRes = authorityService.authenticateOwner('Dhaval Chandrashekhar Batwal', 'test-only-dhaval-secret-0123456789-ABCDEF');
    assert.ok(authRes.sessionToken);

    // Reject generating nonce without valid session token (raw name must fail)
    const rawNameNonce = authorityService.createSingleUseDownloadToken('Dhaval Chandrashekhar Batwal');
    assert.strictEqual(rawNameNonce.success, false, 'Raw name cannot generate download nonce');

    // Generate single-use nonce with verified session token
    const tokenRes = authorityService.createSingleUseDownloadToken(authRes.sessionToken!);
    assert.strictEqual(tokenRes.success, true);
    assert.ok(tokenRes.downloadNonce && tokenRes.downloadNonce.startsWith('dl-'));

    // First consumption must succeed
    const firstConsume = authorityService.consumeDownloadNonce(tokenRes.downloadNonce!);
    assert.strictEqual(firstConsume.valid, true);
    assert.strictEqual(firstConsume.actor, 'Dhaval Chandrashekhar Batwal');

    // Replay attempt must be strictly blocked (nonce is deleted upon first use)
    const replayConsume = authorityService.consumeDownloadNonce(tokenRes.downloadNonce!);
    assert.strictEqual(replayConsume.valid, false, 'Replaying a consumed download nonce must be rejected');
    } finally {
      if (previousSecret === undefined) delete process.env.FUTUREVERSE_OWNER_KEY;
      else process.env.FUTUREVERSE_OWNER_KEY = previousSecret;
    }
  });

  runTest('20.5 Audit log immutably records authorization attempts and security events', () => {
    const logs = authorityService.getAuditLogs(10);
    assert.ok(logs.length > 0, 'Audit logs must record security events');
    const actions = logs.map((l) => l.action);
    assert.ok(
      actions.includes('UNAUTHORIZED_OWNER_AUTH_ATTEMPT') ||
      actions.includes('OWNER_SESSION_ESTABLISHED') ||
      actions.includes('PROJECT_ZIP_EXPORT_DOWNLOADED'),
      'Audit log must contain owner security actions'
    );
  });

  runTest('20.6 Release generator excludes private runtime ledgers and nested project ZIPs', () => {
    const generatorPath = path.join(process.cwd(), 'scripts', 'generate_final_release_zip.py');
    assert.ok(fs.existsSync(generatorPath), 'Release generator must exist');
    execSync('python3 scripts/generate_final_release_zip.py', { stdio: 'pipe' });
    const zipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.ok(fs.existsSync(zipPath), 'Release archive must be generated');
    const listing = execSync(`unzip -Z1 "${zipPath}"`, { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
    for (const forbidden of [
      'server.js',
      'data/ownership_authority.json',
      'data/yagyx_payments_ledger.json',
      'data/test_yagyx_payments_ledger.json',
      'data/verse_agent_executions.json',
      'data/deep_research_records.json',
      'public/futureverse-verified-release.zip',
    ]) assert.ok(!listing.includes(forbidden), `Private/stale file must not ship: ${forbidden}`);
    assert.ok(listing.includes('data/campaign_schedule.json'), 'Sanitized campaign schedule should be retained');
    assert.ok(listing.includes('data/projects.json'), 'Public published project examples should be retained');
    const campaignJson = execSync(`unzip -p "${zipPath}" data/campaign_schedule.json`, { encoding: 'utf8' });
    const campaign = JSON.parse(campaignJson);
    assert.deepStrictEqual(campaign.registrations, [], 'Individual campaign registrations must be redacted');
    assert.deepStrictEqual(campaign.auditHistory, [], 'Runtime campaign audit rows must be redacted');
  });

  runTest('20.7 Generated release ZIP passes integrity and checksum verification', () => {
    const finalZipPath = path.join(process.cwd(), 'FUTUREVERSE_FINAL_RELEASE.zip');
    assert.ok(fs.existsSync(finalZipPath), 'FUTUREVERSE_FINAL_RELEASE.zip must exist after generation');
    execSync(`unzip -t "${finalZipPath}"`, { stdio: 'pipe' });
    const stat = fs.statSync(finalZipPath);
    assert.ok(stat.size > 1 * 1024 * 1024, 'Release source ZIP must contain the application source');
    const buffer = fs.readFileSync(finalZipPath);
    const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');
    assert.match(sha256, /^[a-f0-9]{64}$/);
    const ledgerPath = path.join(process.cwd(), 'release_checksums.json');
    assert.ok(fs.existsSync(ledgerPath), 'Release manifest must be generated alongside the archive');
    const ledger = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
    assert.strictEqual(ledger.release_archives?.['FUTUREVERSE_FINAL_RELEASE.zip']?.sha256, sha256, 'Archive digest must match the generated manifest');
  });

  console.log(`\n================================================================`);
  console.log(`ALL TESTS PASSED: ${passedTests} / ${totalTests} (100% SUCCESS)`);
  console.log(`================================================================\n`);
  process.exit(0);
}

main().catch((err) => {
  console.error('Test Suite Failed:', err);
  process.exit(1);
});
