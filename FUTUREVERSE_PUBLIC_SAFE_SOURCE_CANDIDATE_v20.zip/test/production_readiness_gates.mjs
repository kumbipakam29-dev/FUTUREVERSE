import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const payments = fs.readFileSync(path.join(root, 'src/server/yagyxPaymentService.ts'), 'utf8');
const personas = fs.readFileSync(path.join(root, 'src/server/personaEngine.ts'), 'utf8');

function blockBetween(source, startNeedle, endNeedle) {
  const start = source.indexOf(startNeedle);
  const end = source.indexOf(endNeedle, start + startNeedle.length);
  assert.ok(start >= 0 && end > start, `Could not locate block ${startNeedle}`);
  return source.slice(start, end);
}

const checkout = blockBetween(server, "app.post('/api/membership/checkout'", "app.post('/api/membership/confirm'");
assert.match(checkout, /status\(503\)/);
assert.match(checkout, /PAYMENTS_NOT_PRODUCTION_READY/);
assert.match(checkout, /Do not transfer tokens/);
assert.doesNotMatch(checkout, /createCheckoutOrder/);

const confirm = blockBetween(server, "app.post('/api/membership/confirm'", '// COMPUTE MARKETPLACE');
assert.match(confirm, /status\(503\)/);
assert.match(confirm, /PAYMENT_VERIFICATION_NOT_PRODUCTION_READY/);
assert.match(confirm, /membershipStatus: 'INACTIVE'/);
assert.doesNotMatch(confirm, /verifyPayment\(/);

const vote = blockBetween(server, "app.post('/api/projects/:id/feedback/:feedbackId/vote'", "app.delete('/api/projects/:id/feedback/:feedbackId'");
assert.match(vote, /status\(401\)/);
assert.match(vote, /AUTHENTICATED_VOTER_REQUIRED/);
assert.doesNotMatch(vote, /voterId|voterAddress|voteFeedback\(/);

const createPersona = blockBetween(server, "app.post('/api/verse/personas'", "app.put('/api/verse/personas/:id'");
assert.match(createPersona, /verifyOwnerAuthorization/);
assert.match(createPersona, /auth\.role !== 'OWNER'/);
assert.match(payments, /Never copy production payment records/);
assert.match(payments, /if \(isTestLedger\) return \[\]/);
assert.match(payments, /crypto\.randomUUID\(\)/);
assert.match(personas, /status: 'TESTING'/);
assert.match(personas, /evalScore: 0/);
assert.match(personas, /testPassed: false/);

console.log('PRODUCTION_READINESS_GATES=PASS (14 assertions)');
console.log('Payment and voting paths fail closed until real verification/authentication exists.');
console.log('Persona registration requires owner auth; new personas are unverified by default.');
