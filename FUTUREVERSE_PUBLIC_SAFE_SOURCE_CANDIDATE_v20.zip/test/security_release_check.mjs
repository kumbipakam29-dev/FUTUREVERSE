import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const archivePath = path.join(root, 'FUTUREVERSE_FINAL_RELEASE.zip');
const manifestPath = path.join(root, 'release_checksums.json');
const server = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const packageMetadata = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
assert.equal(packageMetadata.scripts?.test, 'node scripts/run_tests_isolated.mjs', 'npm test must run in a disposable copy instead of mutating project data');
assert.ok(fs.existsSync(path.join(root, 'scripts/run_tests_isolated.mjs')), 'Isolated test runner script must be shipped');
const authority = fs.readFileSync(path.join(root, 'src/server/authorityService.ts'), 'utf8');
const envExample = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

function assertRouteGuard(routeMarker, expectedText, label) {
  const start = server.indexOf(routeMarker);
  assert.notEqual(start, -1, `${label}: route exists`);
  const block = server.slice(start, Math.min(server.length, start + 1100));
  assert.ok(block.includes(expectedText), `${label}: expected authorization guard is missing`);
}

// Authentication must be based on unique per-role secrets and constant-time secret comparison.
for (const envName of ['FUTUREVERSE_OWNER_KEY', 'FUTUREVERSE_CO_OWNER_KEY', 'FUTUREVERSE_COOP_OWNER_KEY']) {
  assert.ok(authority.includes(envName), `Authority service must support ${envName}`);
  assert.ok(envExample.includes(`${envName}="REPLACE_WITH_UNIQUE_RANDOM_`), `${envName} must be a placeholder, not a committed secret`);
}
assert.ok(authority.includes('crypto.timingSafeEqual'), 'Secret checks must use constant-time digest comparison');
assert.ok(authority.includes('configuredSecret.length < 32'), 'Owner secret must have a minimum length');
assert.ok(authority.includes('this.resolveCanonicalOwner(actorNameOrId)'), 'Authentication must resolve exact canonical identity');
assert.ok(!/FUTUREVERSE_OWNER_KEY\s*\|\|\s*['"][^'"]{1,}/.test(authority), 'Do not allow a fallback shared/default owner secret');

// Protected operations must check active sessions at the server boundary.
assertRouteGuard("app.post('/api/verse/naming/approve'", "auth.role !== 'OWNER'", 'Model approval');
assertRouteGuard("app.post('/api/verse/agents/:id/rollback'", "auth.role !== 'OWNER'", 'Agent rollback');
assertRouteGuard("app.get('/api/verse/agents/:id/executions'", 'Verified owner session required', 'Agent execution logs');
assertRouteGuard("app.put('/api/verse/personas/:id'", "auth.role !== 'OWNER'", 'Persona modification');
assertRouteGuard("app.delete('/api/verse/personas/:id'", "auth.role !== 'OWNER'", 'Persona deletion');
assertRouteGuard("app.post('/api/evolution/:id/status'", 'Verified owner session required', 'Evolution status');
assertRouteGuard("app.post('/api/tasks/:id/review'", 'Verified owner session required', 'Contributor reward review');
assertRouteGuard("app.post('/api/launch/admin/reveal'", "auth.role !== 'OWNER'", 'Campaign reveal');
assertRouteGuard("app.get('/api/admin/audit-logs'", 'Verified owner session required', 'Audit logs');
const ownerStatusStart = server.indexOf("app.get('/api/export/owner-status'");
const ownerAuthStart = server.indexOf("app.post('/api/export/owner-authenticate'", ownerStatusStart);
const ownerStatusBlock = server.slice(ownerStatusStart, ownerAuthStart);
assert.ok(ownerStatusBlock.includes('verifyOwnerAuthorization(req, { recordFailure: false })'), 'Anonymous export-status polling must not persist an audit event per page visit');
assertRouteGuard("app.get(['/api/backup/download'", 'Owner sign-in required', 'Operational backup download');
assertRouteGuard("app.get('/api/backup/info'", 'Owner sign-in required to view backup metadata', 'Backup metadata');

// Authentication must not be based on public identity data or arbitrary URL session tokens.
const authHelperStart = server.indexOf('const verifyOwnerAuthorization =');
const authHelperEnd = server.indexOf('// --- Owner Status & Authentication Endpoints ---', authHelperStart);
assert.ok(authHelperStart >= 0 && authHelperEnd > authHelperStart, 'Owner auth helper must exist');
const authHelper = server.slice(authHelperStart, authHelperEnd);
assert.ok(!authHelper.includes('req.query.owner_email'), 'Public owner email must not be accepted as an auth credential');
assert.ok(authHelper.includes('allowDownloadNonce') && authHelper.includes("req.method === 'GET' || req.method === 'HEAD'"), 'Download nonce must be explicitly scoped to read-only download flow');
assert.ok(authHelper.includes('authorityService.verifyOwnerSession(token)'), 'Session tokens must be checked against active server sessions');
assert.ok(!server.includes("'Access-Control-Allow-Origin', '*'"), 'Do not enable wildcard CORS for owner endpoints');

assert.ok(packageJson.scripts.start.includes('tsx server.ts'), 'Server start script must invoke the TypeScript server entry point');
assert.ok(packageJson.scripts.prestart.includes('scripts/generate_final_release_zip.py'), 'npm start must refresh the sanitized archive before serving owner export routes');
const isolatedRunner = fs.readFileSync(path.join(root, 'scripts/run_tests_isolated.mjs'), 'utf8');
assert.ok(isolatedRunner.includes("['python3', ['scripts/generate_final_release_zip.py']]"), 'Isolated regression suite should generate the source archive first in its disposable copy');
assert.ok(isolatedRunner.includes('campaign.registrations = []') && isolatedRunner.includes('campaign.auditHistory = []'), 'Disposable regression copy must redact campaign registration/audit records');
assert.ok(isolatedRunner.includes("['email', 'phone', 'address', 'walletAddress', 'wallet_address']"), 'Disposable regression copy must strip author contact fields');

// The server must fail closed rather than falling back to legacy archives that may contain private records.
const releaseHashGuardStart = server.indexOf('const isCurrentPublicReleaseArchive =');
const zipResolverStart = server.indexOf('const getProjectZipPath =');
const authHelperForResolver = server.indexOf('const verifyOwnerAuthorization =', zipResolverStart);
assert.ok(releaseHashGuardStart >= 0 && zipResolverStart > releaseHashGuardStart && authHelperForResolver > zipResolverStart, 'Verified archive resolver must exist');
const zipResolver = server.slice(releaseHashGuardStart, authHelperForResolver);
assert.ok(zipResolver.includes('release_checksums.json'), 'Archive resolver must validate the current release manifest');
assert.ok(zipResolver.includes('FUTUREVERSE_FINAL_RELEASE.zip'), 'Archive resolver must allow the current safe release');
assert.ok(!zipResolver.includes('FUTUREVERSE_PROJECT_RELEASE_v3.1.zip'), 'Archive resolver must not fall back to a legacy project ZIP');
assert.ok(!zipResolver.includes('.aistudio/artifacts'), 'Archive resolver must not fall back to stale build-artifact ZIPs');
const dynamicArchiveStart = server.indexOf("app.get('/api/export/archive/:filename'");
const dynamicArchiveBlock = server.slice(dynamicArchiveStart, server.indexOf("// Protected Base64 Reconstitution Endpoint", dynamicArchiveStart));
assert.ok(dynamicArchiveBlock.includes('allowedAliases') && dynamicArchiveBlock.includes('isCurrentPublicReleaseArchive(safePath)'), 'Dynamic archive endpoint must only serve allowlisted hash-verified release aliases');
const legacyGenerator = fs.readFileSync(path.join(root, 'scripts/generate_clean_project_zip.py'), 'utf8');
assert.ok(legacyGenerator.includes('generate_final_release_zip.py'), 'Legacy generation command must delegate to the safe generator');
assert.ok(!legacyGenerator.includes('os.walk('), 'Legacy generator must not recursively package the working tree');

// The generated distributable must be internally consistent and privacy-filtered.
assert.ok(fs.existsSync(archivePath), 'Run scripts/generate_final_release_zip.py before this check');
assert.ok(fs.existsSync(manifestPath), 'Generated release manifest must exist');
execFileSync('unzip', ['-t', archivePath], { stdio: 'pipe' });
const zipHash = crypto.createHash('sha256').update(fs.readFileSync(archivePath)).digest('hex');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const entry = manifest.release_archives?.['FUTUREVERSE_FINAL_RELEASE.zip'];
assert.ok(entry, 'Manifest must contain the generated source archive');
assert.equal(entry.sha256, zipHash, 'Generated source archive hash must match the manifest');
assert.equal(entry.size, fs.statSync(archivePath).size, 'Generated source archive size must match the manifest');

const entries = execFileSync('unzip', ['-Z1', archivePath], { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
const forbiddenEntries = [
  'server.js',
  'data/ownership_authority.json',
  'data/yagyx_payments_ledger.json',
  'data/test_yagyx_payments_ledger.json',
  'data/verse_agent_executions.json',
  'data/deep_research_records.json',
  'data/demand_signals.json',
  'data/opportunities.json',
  'data/growth_experiments.json',
  'public/futureverse-verified-release.zip',
  'dependency_inventory.json',
  'public/preview/audit_report.json',
  'test/generate_100_tests_audit.ts',
];
for (const forbidden of forbiddenEntries) assert.ok(!entries.includes(forbidden), `Private/stale archive entry found: ${forbidden}`);
assert.ok(entries.includes('.env.example'), 'Safe environment template should be shipped');
assert.ok(entries.includes('test/security_release_check.mjs'), 'Repeatable security static-check script should be shipped');
assert.ok(!entries.some((name) => name.startsWith('.env') && name !== '.env.example'), 'No real environment file may be shipped');
assert.ok(!entries.some((name) => name.toLowerCase().endsWith('.zip') && name !== 'public/brand-kit/futureverse-brand-kit.zip'), 'No project release ZIP may be nested inside the source ZIP');
assert.ok(!entries.includes('public/brand-kit/verification-report.md'), 'Unverified historical brand-kit report must be excluded');
const internalReportNames = [
  'SECURITY_HARDENING_REVIEW_REPORT.md', 'KNOWN_LIMITATIONS.md', 'known_limitations.md',
  'YAGYX_CHAIN_FORENSIC_REPORT.md', 'YAGYX_CHAIN_SECURITY_FINDINGS.md',
  'YAGYX_CHAIN_BACKUP_MANIFEST.json', 'YAGYX_CHAIN_FILE_INVENTORY.json',
  'route_inventory.json', 'security_findings.json', 'repository_inventory.json',
  'feature_traceability.json', 'implementation_status.json', 'feature_status_matrix.csv',
];
for (const name of internalReportNames) assert.ok(!entries.includes(name), `Internal/stale audit artifact must not ship: ${name}`);
assert.ok(!entries.includes('scripts/generate_v31_reports.py'), 'Historic v3.1 report generator must not ship in source release');
assert.ok(!entries.some((name) => name.startsWith('public/assets/aistudio/')), 'Internal AI Studio prompt exports must not ship in public assets');

// Regression guard: no individual registration records belong in either source fallback.
// Keep the check structural so it does not re-embed removed contact addresses in this test.
const serverCampaignSource = fs.readFileSync(path.join(root, 'server.ts'), 'utf8');
const campaignServiceSource = fs.readFileSync(path.join(root, 'src/server/campaignService.ts'), 'utf8');
for (const [label, source] of [['server.ts', serverCampaignSource], ['campaign service', campaignServiceSource]]) {
  const registrationSeed = source.match(/registrations:\s*\[([\s\S]*?)\]/)?.[1] || '';
  assert.ok(!/\bemail\s*:/.test(registrationSeed), `Individual email records must not be embedded in ${label} campaign defaults`);
  assert.ok(!/\bhandle\s*:/.test(registrationSeed), `Individual handle records must not be embedded in ${label} campaign defaults`);
  assert.ok(/registrations:\s*\[\]/.test(source), `${label} campaign registration seed must be empty`);
}
const tempBrandKitPath = path.join(root, '.brand-kit-security-check.zip');
try {
  fs.writeFileSync(tempBrandKitPath, execFileSync('unzip', ['-p', archivePath, 'public/brand-kit/futureverse-brand-kit.zip']));
  const nestedNames = execFileSync('unzip', ['-Z1', tempBrandKitPath], { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
  assert.ok(!nestedNames.some((name) => /(^|\/)verification-report\.md$/i.test(name)), 'Nested brand kit must not carry an unverified forensic pass claim');
} finally {
  fs.rmSync(tempBrandKitPath, { force: true });
}

const campaign = JSON.parse(execFileSync('unzip', ['-p', archivePath, 'data/campaign_schedule.json'], { encoding: 'utf8' }));
assert.deepEqual(campaign.registrations, [], 'Campaign registrant records must be redacted from a source distribution');
assert.deepEqual(campaign.auditHistory, [], 'Campaign audit history must be excluded from a source distribution');
const publishedProjects = JSON.parse(execFileSync('unzip', ['-p', archivePath, 'data/projects.json'], { encoding: 'utf8' }));
assert.ok(publishedProjects.every((p) => String(p.visibility || '').toLowerCase() === 'published'), 'Only published project seed examples may be shipped');

console.log('SECURITY_RELEASE_CHECK=PASS');
console.log(`Static route/credential assertions: PASS`);
console.log(`Archive privacy checks: PASS (${entries.length} entries)`);
console.log(`Manifest SHA-256: ${zipHash}`);
console.log('NOTE: This does not replace full build, typecheck, HTTP integration tests, dependency audit, or user-level authorization tests.');
