import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';

const sourceRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'futureverse-auth-smoke-'));
const originalCwd = process.cwd();
const envNames = ['FUTUREVERSE_OWNER_KEY', 'FUTUREVERSE_CO_OWNER_KEY', 'FUTUREVERSE_COOP_OWNER_KEY'];
const previousEnv = Object.fromEntries(envNames.map((key) => [key, process.env[key]]));
const secrets = {
  FUTUREVERSE_OWNER_KEY: 'test-only-dhaval-secret-0123456789-ABCDEF',
  FUTUREVERSE_CO_OWNER_KEY: 'test-only-hemangini-secret-0123456789-ABCDEF',
  FUTUREVERSE_COOP_OWNER_KEY: 'test-only-jayshriben-secret-0123456789-ABCDEF',
};

try {
  process.chdir(tempRoot);
  for (const [key, value] of Object.entries(secrets)) process.env[key] = value;
  // Node's built-in ESM loader does not execute TypeScript. Compile just this isolated
  // service with the project's TypeScript dependency so the smoke test is executable
  // with plain `node` after dependencies are installed. The source file is not modified.
  const authoritySource = fs.readFileSync(path.join(sourceRoot, 'src/server/authorityService.ts'), 'utf8');
  const compiled = ts.transpileModule(authoritySource, {
    fileName: 'authorityService.ts',
    reportDiagnostics: true,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, verbatimModuleSyntax: false },
  });
  const errors = (compiled.diagnostics || []).filter((diagnostic) => diagnostic.category === ts.DiagnosticCategory.Error);
  assert.equal(errors.length, 0, 'authority service should transpile before runtime checks');
  const compiledPath = path.join(tempRoot, 'authorityService.mjs');
  fs.writeFileSync(compiledPath, compiled.outputText, 'utf8');
  const { AuthorityService } = await import(pathToFileURL(compiledPath).href);
  const service = new AuthorityService();

  const noSecret = service.authenticateOwner('Dhaval Chandrashekhar Batwal');
  assert.equal(noSecret.success, false, 'name alone must not authenticate');
  assert.equal(service.authenticateOwner('xDhaval Chandrashekhar Batwalx', secrets.FUTUREVERSE_OWNER_KEY).success, false, 'substring spoof rejected');
  assert.equal(service.authenticateOwner('outside-user', secrets.FUTUREVERSE_OWNER_KEY).success, false, 'unknown identity rejected');

  const owner = service.authenticateOwner('aibabayaga0@gmail.com', secrets.FUTUREVERSE_OWNER_KEY);
  assert.equal(owner.success, true);
  assert.equal(owner.role, 'OWNER');
  assert.ok(owner.sessionToken);
  assert.equal(service.verifyOwnerSession(owner.sessionToken).valid, true);

  assert.equal(service.authenticateOwner('Hemangini Chandrashwkhar Batwal', secrets.FUTUREVERSE_OWNER_KEY).success, false, 'owner secret cannot authenticate co-owner');
  const coOwner = service.authenticateOwner('Hemangini Chandrashwkhar Batwal', secrets.FUTUREVERSE_CO_OWNER_KEY);
  assert.equal(coOwner.success, true, coOwner.error);
  assert.equal(coOwner.role, 'CO_OWNER');

  assert.equal(service.authenticateOwner('Jayshriben Chandrashekhar Batwal', secrets.FUTUREVERSE_CO_OWNER_KEY).success, false, 'co-owner secret cannot authenticate operational co-owner');
  const coOperational = service.authenticateOwner('Jayshriben Chandrashekhar Batwal', secrets.FUTUREVERSE_COOP_OWNER_KEY);
  assert.equal(coOperational.success, true);
  assert.equal(coOperational.role, 'CO_OPERATIONAL_OWNER');

  const rawNameNonce = service.createSingleUseDownloadToken('Dhaval Chandrashekhar Batwal');
  assert.equal(rawNameNonce.success, false, 'raw identity cannot issue download nonce');
  const tokenResult = service.createSingleUseDownloadToken(owner.sessionToken);
  assert.equal(tokenResult.success, true);
  assert.equal(service.peekDownloadNonce(tokenResult.downloadNonce).valid, true);
  assert.equal(service.consumeDownloadNonce(tokenResult.downloadNonce).valid, true);
  assert.equal(service.consumeDownloadNonce(tokenResult.downloadNonce).valid, false, 'nonce replay rejected');

  const oldCoOwnerKey = process.env.FUTUREVERSE_CO_OWNER_KEY;
  process.env.FUTUREVERSE_CO_OWNER_KEY = process.env.FUTUREVERSE_OWNER_KEY;
  const duplicateSecret = service.authenticateOwner('Dhaval Chandrashekhar Batwal', secrets.FUTUREVERSE_OWNER_KEY);
  assert.equal(duplicateSecret.success, false, 'duplicate configured owner secrets block sign-in');
  process.env.FUTUREVERSE_CO_OWNER_KEY = oldCoOwnerKey;

  process.env.FUTUREVERSE_OWNER_KEY = 'short-secret';
  assert.equal(service.authenticateOwner('Dhaval Chandrashekhar Batwal', 'short-secret').success, false, 'short secrets are rejected');

  console.log('AUTH_SMOKE_RESULT=PASS');
  console.log('Checks: name-only reject; substring spoof reject; unknown identity reject; separate owner credentials; role assignment; session verification; nonce issuance requires session; single-use nonce replay reject; duplicate secrets reject; short secrets reject.');
} finally {
  process.chdir(originalCwd);
  for (const key of envNames) {
    if (previousEnv[key] === undefined) delete process.env[key];
    else process.env[key] = previousEnv[key];
  }
  fs.rmSync(tempRoot, { recursive: true, force: true });
}
