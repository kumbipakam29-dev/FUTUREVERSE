import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
const route = (path) => {
  const start = source.indexOf(`app.post('${path}'`);
  assert.notEqual(start, -1, `Route exists: ${path}`);
  const next = source.indexOf("\n  app.", start + 8);
  return source.slice(start, next === -1 ? source.length : next);
};

const create = route('/api/compute/jobs');
assert.match(create, /checkRateLimit\(req, res, 10, 60_000\)/, 'job creation is rate limited');
assert.match(create, /grossAmountInr/, 'job creation continues to support amount input');
assert.match(create, /Number\.isFinite\(parsedGross\)/, 'non-finite amount values are rejected');
assert.match(create, /parsedGross < 0/, 'negative amounts are rejected');
assert.match(create, /1_000_000_000/, 'gross amount has a documented upper bound');

const claim = route('/api/compute/jobs/:id/claim');
assert.match(claim, /checkRateLimit\(req, res, 20, 60_000\)/, 'job claims are rate limited');
assert.match(claim, /Provider identity fields must be strings/, 'claim identity fields are bounded');

const settle = route('/api/compute/jobs/:id/submit-result');
assert.match(settle, /checkRateLimit\(req, res, 20, 60_000\)/, 'settlement requests are rate limited');
assert.match(settle, /job\.status !== 'ASSIGNED'/, 'only assigned jobs can be settled');
assert.match(settle, /JOB_NOT_ASSIGNED/, 'invalid state transition returns a stable code');
assert.match(settle, /resultPayload\.length > 10_000/, 'result payload size is bounded');
assert.match(settle, /settlementMode: 'SIMULATED'/, 'settlement response explicitly identifies demo-only mode');
assert.match(settle, /payoutExecuted: false/, 'settlement cannot claim that a payout was executed');

const register = route('/api/compute/providers/register');
assert.match(register, /checkRateLimit\(req, res, 5, 60_000\)/, 'provider registration is rate limited');
assert.match(register, /Provider fields must be strings/, 'provider fields are bounded');

console.log('COMPUTE_ROUTE_HARDENING_CHECK=PASS');
console.log('Checks: rate limits, bounded input fields, finite amount bounds, assignment-before-settlement, payload size, demo-only settlement disclosure');
