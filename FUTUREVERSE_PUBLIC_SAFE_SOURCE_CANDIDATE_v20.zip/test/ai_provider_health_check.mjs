import assert from 'node:assert/strict';
import fs from 'node:fs';

const service = fs.readFileSync(new URL('../src/server/aiProviderService.ts', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
assert.match(service, /checkLocalProviderHealth\(timeoutMs = 1800\)/, 'health probe method exists');
assert.match(service, /Math\.max\(250, Math\.min\(timeoutMs, 5000\)\)/, 'health timeout is bounded');
assert.match(service, /finally\s*\{\s*clearTimeout\(timer\);\s*\}/, 'health timeout is always cleared');
assert.match(service, /Local provider is unreachable/, 'probe errors are normalized');
assert.match(service, /installedMappedModelCount/, 'reports count of installed mapped models');
assert.match(server, /app\.get\('\/api\/ai\/provider-health'/, 'health endpoint exists');
assert.match(server, /Cache-Control', 'no-store'/, 'health endpoint disables caching');
assert.match(server, /Health check unavailable/, 'endpoint has safe error response');
assert.doesNotMatch(service.slice(service.indexOf('public async checkLocalProviderHealth'), service.indexOf('public getStatus')), /this\.localModelMap\[[^\]]+\].*res\.|apiKey|GEMINI_API_KEY/, 'health method does not expose credentials or raw map');
console.log('AI provider health static checks: PASS (9 assertions)');
