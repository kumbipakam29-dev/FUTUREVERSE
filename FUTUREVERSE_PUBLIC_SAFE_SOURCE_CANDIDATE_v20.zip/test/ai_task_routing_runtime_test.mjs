import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';

const sourceRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'futureverse-ai-router-'));
const previousEnv = {
  VERSE_LOCAL_OPENAI_BASE_URL: process.env.VERSE_LOCAL_OPENAI_BASE_URL,
  VERSE_LOCAL_MODEL_MAP: process.env.VERSE_LOCAL_MODEL_MAP,
  GEMINI_API_KEY: process.env.GEMINI_API_KEY,
};
const originalFetch = globalThis.fetch;

try {
  const stubDir = path.join(tempRoot, 'node_modules', '@google', 'genai');
  fs.mkdirSync(stubDir, { recursive: true });
  fs.writeFileSync(path.join(tempRoot, 'node_modules', '@google', 'genai', 'package.json'), JSON.stringify({ type: 'module', exports: './index.js' }));
  fs.writeFileSync(path.join(stubDir, 'index.js'), `export class GoogleGenAI { constructor() { this.models = { generateContent: async ({ config } = {}) => { globalThis.__geminiCalls = (globalThis.__geminiCalls || 0) + 1; globalThis.__geminiLastAbortSignal = config?.abortSignal || null; if (globalThis.__geminiWait) { return await new Promise((resolve, reject) => { if (!config?.abortSignal) { globalThis.__geminiMissingAbortSignal = true; return; } if (config.abortSignal.aborted) { globalThis.__geminiWasAborted = true; const err = new Error('aborted'); err.name = 'AbortError'; reject(err); return; } config.abortSignal.addEventListener('abort', () => { globalThis.__geminiWasAborted = true; const err = new Error('aborted'); err.name = 'AbortError'; reject(err); }, { once: true }); }); } return { text: 'REMOTE_OK' }; } }; } }`);

  const source = fs.readFileSync(path.join(sourceRoot, 'src/server/aiProviderService.ts'), 'utf8');
  const compiled = ts.transpileModule(source, {
    fileName: 'aiProviderService.ts',
    reportDiagnostics: true,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, verbatimModuleSyntax: false },
  });
  const compileErrors = (compiled.diagnostics || []).filter((item) => item.category === ts.DiagnosticCategory.Error);
  assert.equal(compileErrors.length, 0, 'AI service source should transpile without syntax diagnostics');

  const moduleDir = path.join(tempRoot, 'src', 'server');
  fs.mkdirSync(moduleDir, { recursive: true });
  let moduleCounter = 0;
  async function createService(modelMap) {
    process.env.VERSE_LOCAL_OPENAI_BASE_URL = 'http://127.0.0.1:11434/v1';
    process.env.VERSE_LOCAL_MODEL_MAP = JSON.stringify(modelMap);
    process.env.GEMINI_API_KEY = 'test-key-only';
    const compiledPath = path.join(moduleDir, `aiProviderService-${moduleCounter++}.mjs`);
    fs.writeFileSync(compiledPath, compiled.outputText, 'utf8');
    const mod = await import(pathToFileURL(compiledPath).href);
    return mod.aiProviderService;
  }

  globalThis.__geminiCalls = 0;
  const requests = [];
  globalThis.fetch = async (_url, init = {}) => {
    const body = JSON.parse(init.body || '{}');
    requests.push(body.model);
    if (body.model === 'deepseek:latest') return new Response(JSON.stringify({ error: 'simulated unavailable model' }), { status: 503 });
    if (body.model === 'qwen:8b') {
      const isSmokePrompt = (body.messages || []).some((m) => String(m.content || '').includes('FUTUREVERSE_LOCAL_TEST_OK'));
      const content = isSmokePrompt ? (globalThis.__smokeText ?? 'LOCAL_OK') : 'LOCAL_OK';
      return new Response(JSON.stringify({ choices: [{ message: { content } }], usage: { prompt_tokens: 2, completion_tokens: 3 } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response('{}', { status: 404 });
  };
  const routed = await createService({
    'model-deepseek-v4-1-flash-open': 'deepseek:latest',
    'model-qwen3-8-27b-open': 'qwen:8b',
  });
  const routeResult = await routed.generateText('Please analyze this design', { task: 'reasoning' });
  assert.equal(routeResult.providerUsed, 'ollama-local', 'router should reach a local model');
  assert.equal(routeResult.text, 'LOCAL_OK');
  assert.deepEqual(requests, ['deepseek:latest', 'qwen:8b'], 'router should try task candidates in order and continue after a failed model');
  assert.equal(globalThis.__geminiCalls, 0, 'successful local inference should not contact Gemini');

  const generationFetch = globalThis.fetch;
  globalThis.fetch = async (url, init = {}) => {
    if (String(url).endsWith('/models')) {
      return new Response(JSON.stringify({ data: [{ id: 'qwen:8b' }] }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return generationFetch(url, init);
  };
  const healthResult = await routed.checkLocalProviderHealth();
  assert.equal(healthResult.reachable, true, 'health probe should detect a reachable local runtime');
  assert.equal(healthResult.mappedModelCount, 2, 'health probe should count configured model mappings');
  assert.equal(healthResult.installedMappedModelCount, 1, 'health probe should count only mappings present in the runtime');
  assert.equal(JSON.stringify(healthResult).includes('qwen:8b'), false, 'health response must not expose raw runtime tags');
  globalThis.fetch = generationFetch;

  const wrongMarkerTest = await routed.testConfiguredLocalModel('model-qwen3-8-27b-open');
  assert.equal(wrongMarkerTest.ok, false, 'local model response without the expected marker must fail the smoke test');
  assert.match(wrongMarkerTest.reason, /did not return the required smoke-test marker/);
  globalThis.__smokeText = 'FUTUREVERSE_LOCAL_TEST_OK';
  const validMarkerTest = await routed.testConfiguredLocalModel('model-qwen3-8-27b-open');
  assert.equal(validMarkerTest.ok, true, 'local model that returns the required marker should pass');
  delete globalThis.__smokeText;

  globalThis.fetch = async () => new Response(JSON.stringify({ error: 'simulated offline runtime' }), { status: 503 });
  const privateFallback = await createService({ 'model-qwen3-8-27b-open': 'qwen:8b' });
  const fallbackResult = await privateFallback.generateText('Write code for a tiny app', { task: 'coding' });
  assert.equal(fallbackResult.providerUsed, 'verse-deterministic-engine', 'failed local inference should use deterministic fallback by default');
  assert.equal(fallbackResult.isFallback, true);
  assert.equal(globalThis.__geminiCalls, 0, 'default local failure must not leak the prompt to remote Gemini');

  const remoteOptIn = await createService({ 'model-qwen3-8-27b-open': 'qwen:8b' });
  const remoteResult = await remoteOptIn.generateText('Write code for a tiny app', { task: 'coding', allowRemoteFallback: true });
  assert.equal(remoteResult.providerUsed, 'google-gemini', 'explicit opt-in may allow remote fallback');
  assert.equal(remoteResult.text, 'REMOTE_OK');
  assert.equal(globalThis.__geminiCalls, 1);
  assert.ok(globalThis.__geminiLastAbortSignal instanceof AbortSignal, 'Gemini SDK receives the request abort signal');

  const timeoutService = await createService({});
  globalThis.__geminiWait = true;
  const timedOut = await timeoutService.generateText('timeout test', { timeoutMs: 500 });
  assert.equal(globalThis.__geminiWasAborted, true, 'Gemini timeout aborts the SDK request signal');
  assert.equal(timedOut.providerUsed, 'verse-deterministic-engine', 'timed-out remote generation returns a fallback');
  globalThis.__geminiWait = false;

  await assert.rejects(() => remoteOptIn.generateText('test', { model: 'arbitrary-unverified-model' }), /not in the verified model catalog/);
  await assert.rejects(() => remoteOptIn.generateText('test', { task: 'vision' }), /task is not supported/);
  console.log('AI task routing runtime tests: PASS (22 assertions)');
} finally {
  globalThis.fetch = originalFetch;
  delete globalThis.__geminiCalls;
  delete globalThis.__geminiLastAbortSignal;
  delete globalThis.__geminiWait;
  delete globalThis.__geminiWasAborted;
  delete globalThis.__geminiMissingAbortSignal;
  delete globalThis.__smokeText;
  for (const [key, value] of Object.entries(previousEnv)) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
  fs.rmSync(tempRoot, { recursive: true, force: true });
}
