# FUTUREVERSE v18 — Provider Verification and Timeout Hardening Review

## Release scope

v18 is an isolated patch candidate based on the verified v17 source ZIP. It does not modify the previous ZIPs and is not a production deployment.

### Fixes

1. **Gemini SDK timeout signal forwarding.** The generation path already created an `AbortController` and a timeout timer, but the controller's signal was not passed to `models.generateContent`. The request configuration now includes `abortSignal: controller.signal`. This lets the SDK client operation react to the timeout instead of leaving the controller disconnected.
2. **Local inference smoke-test validity.** A model is no longer marked as passed merely because it returns any non-empty text. The response must originate from `ollama-local` and contain the fixed `FUTUREVERSE_LOCAL_TEST_OK` marker. The raw completion is not returned from the smoke-test endpoint.
3. **Runtime health checks.** Runtime regression tests now simulate a local `/models` response and check that the health probe counts mapped vs installed models while withholding raw runtime model tags.
4. **Timeout regression test.** The mocked Gemini client records the provided abort signal and rejects when it is aborted. The test verifies that the generation path falls back after the timeout path is triggered.

## Verification performed

- `node test/ai_provider_health_check.mjs` — PASS (9 assertions).
- `node test/ai_provider_inference_test_check.mjs` — PASS (12 assertions).
- `node test/ai_task_routing_check.mjs` — PASS (17 assertions).
- `node test/ai_task_routing_runtime_test.mjs` — PASS (22 assertions, using mocked local/Gemini providers).
- `npm run security:check` — PASS. This regenerated the sanitized source archive, then passed release/manifest privacy checks, owner-authority smoke tests, compute route checks, public owner-name privacy scan (53 assets), all provider static checks, and mocked provider routing tests.
- `npm test` — partial; its isolated archive, security-release, owner-authority, and compute checks passed, but the full suite stopped when `tsx` was unavailable (`spawnSync tsx ENOENT`).
- `npm run build` — blocked (`vite: not found`).
- `npm run lint` — blocked because the `vite/client` type definitions are not installed.
- v17 archive SHA-256 matched its provided checksum and `unzip -t` passed before source extraction; the v17 checksum was rechecked after this patch.

## Important limitation

The timeout signal is client-side cancellation/abort behavior. The Google Gen AI SDK documentation notes that client cancellation does not cancel the request at the service, and applicable usage may still be charged. See the official [GenerateContentConfig documentation](https://googleapis.github.io/js-genai/release_docs/interfaces/types.GenerateContentConfig.html).

No real Ollama instance, Chinese model weights, Gemini API request, or browser session was available for live tests. The mocked tests establish application behavior around signals and return values, not that a deployed provider is reachable or that a model meets quality expectations. Full Vite build/typecheck and complete end-to-end tests are still unverified because this source environment does not contain the project's installed dependencies (including Vite and the Google Gen AI SDK).

## Privacy and release safety

- Model smoke test prompt is fixed server-side; raw inference text is not included in its route response.
- Provider health output contains catalog IDs and installed/configured booleans, not raw installed model tags or API credentials.
- Previous v17 and earlier ZIPs remain unchanged.
- No GitHub push or deployment was performed.
- Keep source archives private because internal authorization code and configuration are included.
