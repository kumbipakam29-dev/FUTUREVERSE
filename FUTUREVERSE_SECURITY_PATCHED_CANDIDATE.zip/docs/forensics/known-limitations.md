# FUTUREVERSE v3.1 KNOWN LIMITATIONS

1. **External Public RPC:** While local YAGYX Chain ID 13370 validation and receipt parsing are fully tested, external live public RPC broadcasting requires operator deployment of public nodes.
2. **Deep Mathematical Proof Localization:** Interface navigation and cards are translated in English, Hindi, and Gujarati. Specialized LaTeX equations and Sanskrit shlokas remain in canonical academic formats.
