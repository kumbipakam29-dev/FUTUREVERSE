# FUTUREVERSE ROLLBACK GUIDE

## Rollback Procedure
1. Revert to previous tagged release v2.3.0 or stable git checkpoint.
2. Restore data stores from `/data/backups/`.
3. Restart Node.js process:
```bash
npm run build
node server.ts --port 3000 --host 0.0.0.0
```
4. Verify health endpoint `/api/health`.
