import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Illuminati Brand Kit Color Palette
        gold: {
          accent: '#FFD700', // Primary Illuminati Gold Accent
          light: '#FFFBEB',
          sheen: '#FEF08A',
          amber: '#F59E0B',
          dark: '#B45309',
        },
        illuminati: {
          gold: '#FFD700',
          cyan: '#00F0FF',
          blue: '#38BDF8',
          indigo: '#6366F1',
          purple: '#A855F7',
          magenta: '#D946EF',
          obsidian: '#020617',
          sanctum: '#080D1A',
          space: '#030712',
        },
      },
      fontFamily: {
        brand: ['Orbitron', 'Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        sans: ['Plus Jakarta Sans', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      backgroundImage: {
        'neon-cyber': 'linear-gradient(135deg, #00F0FF 0%, #6366F1 50%, #D946EF 100%)',
        'gold-sheen': 'linear-gradient(135deg, #FFFBEB 0%, #FFD700 45%, #F59E0B 80%, #B45309 100%)',
        'chrome-horizon': 'linear-gradient(180deg, #FFFFFF 0%, #E0E7FF 35%, #93C5FD 48%, #1E1B4B 50%, #312E81 52%, #6366F1 75%, #A855F7 90%, #0F172A 100%)',
        'orbit-glow': 'radial-gradient(circle at center, rgba(0, 240, 255, 0.25) 0%, rgba(99, 102, 241, 0.2) 40%, rgba(217, 70, 239, 0.1) 65%, transparent 80%)',
      },
      boxShadow: {
        'gold-accent': '0 0 20px rgba(255, 215, 0, 0.45)',
        'gold-glow': '0 0 30px rgba(255, 215, 0, 0.6), inset 0 0 15px rgba(255, 255, 255, 0.3)',
        'neon-cyan': '0 0 20px rgba(0, 240, 255, 0.5), 0 0 35px rgba(0, 240, 255, 0.25)',
        'neon-purple': '0 0 20px rgba(168, 85, 247, 0.5), 0 0 35px rgba(168, 85, 247, 0.25)',
        'neon-dual': '0 0 25px rgba(0, 240, 255, 0.4), 0 0 40px rgba(217, 70, 239, 0.3)',
      },
      dropShadow: {
        'gold-accent': '0 0 10px rgba(255, 215, 0, 0.75)',
        'neon-cyan': '0 0 10px rgba(0, 240, 255, 0.8)',
        'neon-purple': '0 0 12px rgba(168, 85, 247, 0.8)',
      },
    },
  },
  plugins: [],
} satisfies Config;
