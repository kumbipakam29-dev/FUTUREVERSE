import fs from 'fs';
import path from 'path';
import assert from 'assert';
import { execSync } from 'child_process';

console.log('================================================================');
console.log('PHASE 10: AUTOMATED DATA INTEGRITY & DISPOSABLE RECOVERY TEST');
console.log('================================================================\n');

const SOURCE_DATA_DIR = path.resolve(process.cwd(), 'data');
const DISPOSABLE_SANDBOX = path.resolve('/tmp', 'disposable_data_recovery_sandbox_' + Date.now());

async function runRecoveryVerification() {
  console.log('1. Setting up isolated sandbox at:', DISPOSABLE_SANDBOX);
  fs.mkdirSync(DISPOSABLE_SANDBOX, { recursive: true });

  // Copy all files to disposable sandbox
  const files = fs.readdirSync(SOURCE_DATA_DIR).filter((f) => f.endsWith('.json'));
  for (const file of files) {
    const src = path.join(SOURCE_DATA_DIR, file);
    const dest = path.join(DISPOSABLE_SANDBOX, file);
    fs.copyFileSync(src, dest);
  }
  console.log(`  ✓ Copied ${files.length} data files to disposable sandbox`);

  // Verify all files in sandbox are identical
  for (const file of files) {
    const original = fs.readFileSync(path.join(SOURCE_DATA_DIR, file), 'utf8');
    const copied = fs.readFileSync(path.join(DISPOSABLE_SANDBOX, file), 'utf8');
    assert.strictEqual(original, copied, `Integrity mismatch on file: ${file}`);
  }
  console.log('  ✓ Pre-recovery integrity verified for all sandbox copies');

  // 2. Simulate partial corruption in disposable copy
  const targetFile = path.join(DISPOSABLE_SANDBOX, 'campaign_schedule.json');
  console.log('2. Simulating corrupted file payload in disposable copy:', targetFile);
  fs.writeFileSync(targetFile, '{"corrupted": true, broken JSON payload...!!@#');

  let parseFailed = false;
  try {
    JSON.parse(fs.readFileSync(targetFile, 'utf8'));
  } catch {
    parseFailed = true;
  }
  assert.strictEqual(parseFailed, true, 'Corrupted file must fail standard JSON.parse');
  console.log('  ✓ Corruption verified: JSON parser failed gracefully as expected');

  // 3. Execute recovery procedure using baseline backup
  console.log('3. Executing recovery from latest verified backup archive...');
  const backupArchive = path.resolve(process.cwd(), 'BACKUP_PHASE_1000K_IQ_20261017_062806.tar.gz');
  assert.ok(fs.existsSync(backupArchive), `Backup archive must exist at ${backupArchive}`);

  const restoreStaging = path.join('/tmp', 'restore_stage_' + Date.now());
  fs.mkdirSync(restoreStaging, { recursive: true });

  execSync(`tar -xzf "${backupArchive}" -C "${restoreStaging}" ./data/campaign_schedule.json`);

  const restoredFile = path.join(restoreStaging, 'data', 'campaign_schedule.json');
  assert.ok(fs.existsSync(restoredFile), 'Restored file must exist in restore staging');

  const restoredContent = fs.readFileSync(restoredFile, 'utf8');
  const restoredParsed = JSON.parse(restoredContent);
  assert.ok(restoredParsed.status !== undefined || restoredParsed.state !== undefined, 'Restored data must have valid schema');
  console.log('  ✓ Extracted and validated clean replacement from backup');

  // Replace corrupted file in sandbox with restored copy
  fs.copyFileSync(restoredFile, targetFile);
  const recheckParsed = JSON.parse(fs.readFileSync(targetFile, 'utf8'));
  assert.ok(recheckParsed, 'Restored sandbox file parses cleanly');
  console.log('  ✓ Restored sandbox file verified 100% healed');

  // 4. Clean up disposable sandbox
  fs.rmSync(DISPOSABLE_SANDBOX, { recursive: true, force: true });
  fs.rmSync(restoreStaging, { recursive: true, force: true });
  console.log('4. Disposable sandboxes safely cleaned up without touching primary data directory.');

  console.log('\n================================================================');
  console.log('PHASE 10 DATA RECOVERY TEST: PASSED (100% SUCCESS)');
  console.log('================================================================\n');
}

runRecoveryVerification().catch((err) => {
  console.error('Data recovery test failed:', err);
  process.exit(1);
});
