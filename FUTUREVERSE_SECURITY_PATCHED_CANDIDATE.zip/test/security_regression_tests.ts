import assert from 'assert';
import { yagyxPaymentService, YAGYX_CHAIN_ID, FUTUREVERSE_PAYMENT_VAULT_ADDRESS, EVM_TX_HASH_REGEX } from '../src/server/yagyxPaymentService';
import { validateSafeRpcUrl, isPrivateIp } from '../src/server/ssrfValidator';

console.log('================================================================');
console.log('YAGYX CHAIN — SECURITY REGRESSION & HARDENING TEST SUITE');
console.log('================================================================\n');

let totalTests = 0;
let passedTests = 0;

function runTest(name: string, fn: () => void | Promise<void>) {
  totalTests++;
  try {
    const res = fn();
    if (res instanceof Promise) {
      return res
        .then(() => {
          console.log(`  ✓ PASS: ${name}`);
          passedTests++;
        })
        .catch((err) => {
          console.error(`  ✗ FAIL: ${name}`);
          console.error(`    Error: ${err.message}\n`);
          throw err;
        });
    } else {
      console.log(`  ✓ PASS: ${name}`);
      passedTests++;
    }
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    Error: ${err.message}\n`);
    throw err;
  }
}

async function main() {
  console.log('--- TEST GROUP 1: SSRF PROTECTION & NETWORK SECURITY ---');

  await runTest('1.1 SSRF Validator strictly blocks AWS/GCP cloud metadata IP 169.254.169.254', async () => {
    const res = await validateSafeRpcUrl('http://169.254.169.254/latest/meta-data/');
    assert.strictEqual(res.safe, false);
    assert.ok(res.reason?.includes('SSRF Violation'));
  });

  await runTest('1.2 SSRF Validator blocks metadata.google.internal', async () => {
    const res = await validateSafeRpcUrl('http://metadata.google.internal/computeMetadata/v1/');
    assert.strictEqual(res.safe, false);
    assert.ok(res.reason?.includes('SSRF Violation'));
  });

  await runTest('1.3 SSRF Validator blocks private Class A IP (10.0.0.1)', async () => {
    const res = await validateSafeRpcUrl('http://10.0.0.1:8545');
    assert.strictEqual(res.safe, false);
    assert.ok(res.reason?.includes('SSRF Violation'));
  });

  await runTest('1.4 SSRF Validator blocks private Class C IP (192.168.1.1)', async () => {
    const res = await validateSafeRpcUrl('http://192.168.1.1:8545');
    assert.strictEqual(res.safe, false);
    assert.ok(res.reason?.includes('SSRF Violation'));
  });

  await runTest('1.5 SSRF Validator blocks non-HTTP/HTTPS schemes (ftp:, file:, gopher:)', async () => {
    const res1 = await validateSafeRpcUrl('file:///etc/passwd');
    assert.strictEqual(res1.safe, false);
    const res2 = await validateSafeRpcUrl('gopher://127.0.0.1:8545');
    assert.strictEqual(res2.safe, false);
  });

  await runTest('1.6 Private IP helper accurately identifies loopback and private ranges', () => {
    assert.strictEqual(isPrivateIp('127.0.0.1'), true);
    assert.strictEqual(isPrivateIp('10.254.0.1'), true);
    assert.strictEqual(isPrivateIp('172.16.0.5'), true);
    assert.strictEqual(isPrivateIp('192.168.0.100'), true);
    assert.strictEqual(isPrivateIp('169.254.169.254'), true);
    assert.strictEqual(isPrivateIp('8.8.8.8'), false);
    assert.strictEqual(isPrivateIp('1.1.1.1'), false);
  });

  console.log('\n--- TEST GROUP 2: EVM HASH & PRODUCTION BYPASS SECURITY ---');

  runTest('2.1 EVM 32-byte transaction hash regex strictly validates 64 hexadecimal characters', () => {
    assert.strictEqual(EVM_TX_HASH_REGEX.test('0x343a000000000000000000000000000000000000000000000000000000001337'), true);
    // Malformed: too short (only 10 chars)
    assert.strictEqual(EVM_TX_HASH_REGEX.test('0x1234567890'), false);
    // Malformed: missing 0x prefix
    assert.strictEqual(EVM_TX_HASH_REGEX.test('343a000000000000000000000000000000000000000000000000000000001337'), false);
    // Malformed: non-hex characters
    assert.strictEqual(EVM_TX_HASH_REGEX.test('0xZZZZ000000000000000000000000000000000000000000000000000000001337'), false);
  });

  await runTest('2.2 Production mode strictly rejects mockRpcVerification bypass', async () => {
    const origEnv = process.env.NODE_ENV;
    try {
      process.env.NODE_ENV = 'production';
      const orderRes = yagyxPaymentService.createCheckoutOrder({
        region: 'India',
        selectedAsset: 'YAGYX',
      });
      assert.ok(orderRes.order);
      const fakeValidHash = '0x1111222233334444555566667777888899990000aaaabbbbccccddddeeeeffff';
      yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, fakeValidHash);

      const verification = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, {
        mockRpcVerification: true,
      });

      assert.strictEqual(verification.verified, false);
      assert.strictEqual(verification.membershipStatus, undefined);
      assert.ok(verification.error?.includes('Simulation bypass rejected in production mode'));
    } finally {
      process.env.NODE_ENV = origEnv;
    }
  });

  console.log('\n--- TEST GROUP 3: ON-CHAIN VERIFICATION INVARIANTS ---');

  await runTest('3.1 Rejects receipt with non-matching Chain ID', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const testHash = `0xchain_mismatch_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, {
      simulatedReceipt: {
        status: 1,
        chainId: 1, // Mainnet Ethereum instead of YAGYX 13370
        to: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: orderRes.order.baseUnitsRequired,
        blockNumber: 500,
        confirmations: 5,
      },
    });

    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('Wrong network'));
  });

  await runTest('3.2 Rejects receipt with execution status 0 (reverted)', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const testHash = `0xreverted_tx_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, {
      simulatedReceipt: {
        status: 0, // Reverted
        chainId: YAGYX_CHAIN_ID,
        to: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: orderRes.order.baseUnitsRequired,
        blockNumber: 501,
        confirmations: 5,
      },
    });

    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('reverted'));
  });

  await runTest('3.3 Rejects receipt with underpayment (valueBaseUnits < required)', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const testHash = `0xunderpayment_tx_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, testHash);

    const verification = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, {
      simulatedReceipt: {
        status: 1,
        chainId: YAGYX_CHAIN_ID,
        to: FUTUREVERSE_PAYMENT_VAULT_ADDRESS,
        from: '0xuser123456789012345678901234567890123456',
        valueBaseUnits: '1', // 1 wei instead of required 100 * 10^18
        blockNumber: 502,
        confirmations: 5,
      },
    });

    assert.strictEqual(verification.verified, false);
    assert.ok(verification.error?.includes('Underpayment'));
  });

  await runTest('3.4 Idempotent activation: Re-verifying confirmed order returns active state safely', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YAGYX',
    });
    assert.ok(orderRes.order);
    const testHash = `0xidempotent_test_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, testHash);

    const v1 = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, { mockRpcVerification: true });
    assert.strictEqual(v1.verified, true);
    assert.strictEqual(v1.membershipStatus, 'ACTIVE');

    // Re-verify: must succeed idempotently without error
    const v2 = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, { mockRpcVerification: true });
    assert.strictEqual(v2.verified, true);
    assert.strictEqual(v2.membershipStatus, 'ACTIVE');
  });

  await runTest('3.5 Concurrent verification race: Mutex locks transaction during in-flight verification', async () => {
    const orderRes = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(orderRes.order);
    const testHash = `0xconcurrency_mutex_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(orderRes.order.orderId, testHash);

    // Simulate in-flight lock manually by inserting into inFlightVerifications
    (yagyxPaymentService as any).inFlightVerifications.add(testHash.toLowerCase());

    const raceAttempt = await yagyxPaymentService.verifyPayment(orderRes.order.orderId, { mockRpcVerification: true });
    assert.strictEqual(raceAttempt.verified, false);
    assert.ok(raceAttempt.error?.includes('Concurrent verification in progress'));

    // Release lock
    (yagyxPaymentService as any).inFlightVerifications.delete(testHash.toLowerCase());
  });

  await runTest('3.6 Replay attack prevention: Blocks second order from claiming already credited hash', async () => {
    const order1 = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(order1.order);
    const sharedHash = `0xshared_replay_hash_${Date.now()}`;
    yagyxPaymentService.submitTransactionHash(order1.order.orderId, sharedHash);
    const v1 = await yagyxPaymentService.verifyPayment(order1.order.orderId, { mockRpcVerification: true });
    assert.strictEqual(v1.verified, true);

    // Second order attempts to use identical hash
    const order2 = yagyxPaymentService.createCheckoutOrder({
      region: 'India',
      selectedAsset: 'YGO',
    });
    assert.ok(order2.order);
    const submit2 = yagyxPaymentService.submitTransactionHash(order2.order.orderId, sharedHash);
    assert.strictEqual(submit2.success, false);
    assert.ok(submit2.error?.includes('already been credited'));
  });

  console.log(`\n================================================================`);
  console.log(`ALL SECURITY REGRESSION TESTS PASSED: ${passedTests} / ${totalTests} (100% SUCCESS)`);
  console.log(`================================================================\n`);
}

main().catch((err) => {
  console.error('Security regression suite failed:', err);
  process.exit(1);
});
