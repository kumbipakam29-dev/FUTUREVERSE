import assert from 'assert';

console.log('================================================================');
console.log('CREATION ENGINE AUTO-SAVE REGRESSION TEST SUITE');
console.log('Testing 30-Second Cadence, LocalStorage Persistence & Recovery');
console.log('================================================================\n');

let totalTests = 0;
let passedTests = 0;

function runTest(name: string, fn: () => void | Promise<void>) {
  totalTests++;
  try {
    const res = fn();
    if (res instanceof Promise) {
      return res
        .then(() => {
          console.log(`  ✓ PASS: ${name}`);
          passedTests++;
        })
        .catch((err) => {
          console.error(`  ✗ FAIL: ${name}`);
          console.error(`    Error: ${err.message}\n`);
          throw err;
        });
    } else {
      console.log(`  ✓ PASS: ${name}`);
      passedTests++;
    }
  } catch (err: any) {
    console.error(`  ✗ FAIL: ${name}`);
    console.error(`    Error: ${err.message}\n`);
    throw err;
  }
}

// Mock localStorage for headless Node.js environment
class LocalStorageMock {
  private store: Record<string, string> = {};

  getItem(key: string): string | null {
    return this.store[key] ?? null;
  }

  setItem(key: string, value: string): void {
    this.store[key] = String(value);
  }

  removeItem(key: string): void {
    delete this.store[key];
  }

  clear(): void {
    this.store = {};
  }
}

async function main() {
  const mockStorage = new LocalStorageMock();
  const STORAGE_KEY = 'futureverse_creation_engine_autosave';

  console.log('--- TEST GROUP 1: LOCALSTORAGE SERIALIZATION & PAYLOAD STRUCTURE ---');

  runTest('1.1 Should correctly serialize and store draft payload with timestamp', () => {
    const draftPayload = {
      prompt: 'Build a decentralized prediction market oracle aggregator',
      targetAudience: 'Web3 Quants & DeFi Protocols',
      intendedOutcome: 'Automated settlement & liquidity incentives',
      widgetPreference: 'Dynamic Parameters & Sprint Matrix',
      step: 1,
      improvementFeedback: '',
      generatedProject: null,
    };

    const envelope = {
      data: draftPayload,
      timestamp: Date.now(),
      version: 1,
    };

    mockStorage.setItem(STORAGE_KEY, JSON.stringify(envelope));
    const retrievedRaw = mockStorage.getItem(STORAGE_KEY);
    assert.ok(retrievedRaw !== null, 'Retrieved raw payload should not be null');

    const parsed = JSON.parse(retrievedRaw);
    assert.strictEqual(parsed.data.prompt, draftPayload.prompt);
    assert.strictEqual(parsed.data.targetAudience, draftPayload.targetAudience);
    assert.strictEqual(parsed.version, 1);
    assert.ok(typeof parsed.timestamp === 'number');
  });

  runTest('1.2 Should handle step 3 generated project persistence without data loss', () => {
    const fullProjectPayload = {
      prompt: 'Decentralized multi-sig Treasury DAO',
      targetAudience: 'DAO Governors',
      intendedOutcome: 'Proposal execution matrix',
      widgetPreference: 'Execution Sandbox',
      step: 3,
      improvementFeedback: 'Add threshold verification step',
      generatedProject: {
        id: 'proj-12345',
        title: 'Multi-Sig DAO Treasury Suite',
        tagline: 'Autonomous consensus treasury management',
        description: 'Comprehensive multi-signature DAO governance engine.',
        category: 'AI Agents',
        type: 'Interactive Prototype',
        visibility: 'draft',
        version: '1.0.0',
        author: {
          id: 'usr-local',
          name: 'Current Builder',
          handle: 'builder',
          avatar: 'https://example.com/avatar.jpg',
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        stars: 0,
        tags: ['dao', 'web3', 'governance'],
      },
    };

    mockStorage.setItem(STORAGE_KEY, JSON.stringify({
      data: fullProjectPayload,
      timestamp: Date.now(),
      version: 1,
    }));

    const raw = mockStorage.getItem(STORAGE_KEY);
    const parsed = JSON.parse(raw!);
    assert.strictEqual(parsed.data.step, 3);
    assert.strictEqual(parsed.data.generatedProject.title, 'Multi-Sig DAO Treasury Suite');
    assert.strictEqual(parsed.data.improvementFeedback, 'Add threshold verification step');
  });

  console.log('\n--- TEST GROUP 2: 30-SECOND CADENCE & DIRTY-CHECKING LOGIC ---');

  runTest('2.1 Default interval is configured to 30,000 ms (30 seconds)', () => {
    const DEFAULT_INTERVAL_MS = 30000;
    assert.strictEqual(DEFAULT_INTERVAL_MS, 30 * 1000);
    const seconds = Math.round(DEFAULT_INTERVAL_MS / 1000);
    assert.strictEqual(seconds, 30);
  });

  runTest('2.2 Dirty check correctly detects changes and avoids redundant writes', () => {
    let lastSavedString = '';
    let writesCount = 0;

    const maybeSave = (data: any) => {
      const serialized = JSON.stringify(data);
      if (serialized === lastSavedString) {
        return false; // Skip redundant write
      }
      lastSavedString = serialized;
      writesCount++;
      return true;
    };

    const initial = { prompt: 'Idea A' };
    assert.strictEqual(maybeSave(initial), true, 'First save should write');
    assert.strictEqual(writesCount, 1);

    // Second tick without change should NOT write
    assert.strictEqual(maybeSave(initial), false, 'Identical data should not write');
    assert.strictEqual(writesCount, 1);

    // After user edits prompt, should write
    assert.strictEqual(maybeSave({ prompt: 'Idea A with new voice dictation' }), true);
    assert.strictEqual(writesCount, 2);
  });

  console.log('\n--- TEST GROUP 3: RESTORATION & RESILIENCE ---');

  runTest('3.1 Should gracefully handle malformed JSON in localStorage', () => {
    mockStorage.setItem(STORAGE_KEY, 'invalid-json{{{');
    
    let recoveredData = null;
    try {
      const raw = mockStorage.getItem(STORAGE_KEY);
      if (raw) {
        recoveredData = JSON.parse(raw);
      }
    } catch {
      recoveredData = null;
    }

    assert.strictEqual(recoveredData, null, 'Corrupted draft should safely fallback to null');
  });

  runTest('3.2 Clear draft should completely purge localStorage key', () => {
    mockStorage.setItem(STORAGE_KEY, JSON.stringify({ data: { prompt: 'Sample' }, timestamp: Date.now() }));
    assert.ok(mockStorage.getItem(STORAGE_KEY) !== null);

    mockStorage.removeItem(STORAGE_KEY);
    assert.strictEqual(mockStorage.getItem(STORAGE_KEY), null);
  });

  runTest('3.3 Valid-to-save predicate prevents empty/default states from clobbering', () => {
    const isValidToSave = (data: { prompt: string; step: number; generatedProject: any; improvementFeedback: string }) => {
      return Boolean(
        data.prompt.trim() ||
        data.step > 1 ||
        data.generatedProject ||
        data.improvementFeedback.trim()
      );
    };

    assert.strictEqual(isValidToSave({ prompt: '', step: 1, generatedProject: null, improvementFeedback: '' }), false);
    assert.strictEqual(isValidToSave({ prompt: 'My new project', step: 1, generatedProject: null, improvementFeedback: '' }), true);
    assert.strictEqual(isValidToSave({ prompt: '', step: 3, generatedProject: { id: 'p1' }, improvementFeedback: '' }), true);
  });

  console.log('\n================================================================');
  console.log(`AUTO-SAVE TEST SUITE RESULTS: ${passedTests}/${totalTests} Passed`);
  console.log('================================================================');
  assert.strictEqual(passedTests, totalTests, 'All auto-save tests must pass');
}

main().catch((err) => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
