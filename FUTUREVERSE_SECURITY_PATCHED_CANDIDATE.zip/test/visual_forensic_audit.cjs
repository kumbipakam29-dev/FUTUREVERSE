const { chromium } = require('/root/.bun/install/global/node_modules/playwright-core');
const fs = require('fs');
const path = require('path');

const SCREENSHOT_DIR = path.join(process.cwd(), 'public/preview/screenshots');
if (!fs.existsSync(SCREENSHOT_DIR)) {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
}

const VIEWPORTS = [
  { name: '320_mobile_compact', width: 320, height: 740 },
  { name: '360_android_standard', width: 360, height: 780 },
  { name: '390_iphone_modern', width: 390, height: 844 },
  { name: '430_mobile_large', width: 430, height: 932 },
  { name: '768_tablet_portrait', width: 768, height: 1024 },
  { name: '1024_laptop_compact', width: 1024, height: 768 },
  { name: '1280_laptop_standard', width: 1280, height: 800 },
  { name: '1440_desktop_hd', width: 1440, height: 900 },
];

const SCREENS = [
  { id: 'discovery', name: 'Landing Page & Discovery', tab: 'discovery' },
  { id: 'launch', name: '30-Day Campaign & Countdown', tab: 'launch' },
  { id: 'membership', name: 'Membership Governance & Tiers', tab: 'membership' },
  { id: 'creation', name: 'AI Creation Engine', tab: 'creation' },
  { id: 'explore', name: 'Explore & Project Cards', tab: 'explore' },
  { id: 'workspace', name: 'Builder Workspace', tab: 'workspace' },
  { id: 'verse', name: "BATWAL'S VERSE AI HUB", tab: 'verse' },
  { id: 'yagyx', name: 'YAGYX Network Hub', tab: 'yagyx' },
];

async function runAudit() {
  console.log('================================================================');
  console.log('FUTUREVERSE VISUAL FORENSIC AUDIT & RESPONSIVE MATRIX TESTING');
  console.log('================================================================\n');

  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu'],
  });

  const auditReport = {
    timestamp: new Date().toISOString(),
    viewportsTested: VIEWPORTS.map((v) => `${v.width}px (${v.name})`),
    screensAudited: [],
    defectsFound: [],
    screenshotsCaptured: [],
    consoleErrors: [],
    failedNetworkRequests: [],
  };

  const context = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    deviceScaleFactor: 1,
  });

  const page = await context.newPage();

  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      const text = msg.text();
      // Filter out harmless HMR or dev notices if any
      if (!text.includes('favicon.ico') && !text.includes('HMR')) {
        auditReport.consoleErrors.push(text);
      }
    }
  });

  page.on('requestfailed', (req) => {
    auditReport.failedNetworkRequests.push({
      url: req.url(),
      failure: req.failure() ? req.failure().errorText : 'Unknown',
    });
  });

  // Navigate to root
  console.log('Navigating to http://localhost:3000...');
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(1000);

  // 1. Audit Global Navbar
  console.log('\n--- 1. AUDITING GLOBAL NAVBAR ---');
  const navbarLogo = await page.$('header button img[alt="FUTUREVERSE"]');
  if (navbarLogo) {
    const box = await navbarLogo.boundingBox();
    const isVisible = await navbarLogo.isVisible();
    const naturalWidth = await navbarLogo.evaluate((el) => el.naturalWidth);
    const naturalHeight = await navbarLogo.evaluate((el) => el.naturalHeight);
    const currentSrc = await navbarLogo.evaluate((el) => el.currentSrc);

    console.log(`  ✓ Navbar Logo: visible=${isVisible}, box=${box ? `${box.width}x${box.height}` : 'null'}, natural=${naturalWidth}x${naturalHeight}, src=${currentSrc}`);
    auditReport.screensAudited.push({
      screen: 'Global Navbar',
      logo: 'futureverse-logo.svg',
      visible: isVisible && !!box && box.width > 0 && box.height > 0,
      renderedWidth: box ? box.width : 0,
      renderedHeight: box ? box.height : 0,
      src: currentSrc,
    });
  } else {
    auditReport.defectsFound.push('Navbar FUTUREVERSE logo element not found in DOM.');
  }

  // 2. Audit Each Screen at Standard Desktop
  for (const screen of SCREENS) {
    console.log(`\n--- AUDITING SCREEN: ${screen.name} (Tab: ${screen.tab}) ---`);

    // Switch tab using navbar button or custom dispatch
    await page.evaluate((tabId) => {
      // Find button in header or trigger react tab
      const buttons = Array.from(document.querySelectorAll('header button, header nav button'));
      const target = buttons.find((b) => b.textContent && b.textContent.toLowerCase().includes(tabId));
      if (target) {
        target.click();
      } else {
        // Fallback direct URL or click
        window.location.hash = tabId;
      }
    }, screen.tab);

    // If tab navigation via button click in DOM:
    // Try finding exact button text
    const clicked = await page.evaluate((tabId) => {
      const allButtons = Array.from(document.querySelectorAll('button'));
      const map = {
        discovery: 'Discovery',
        launch: '30-Day Launch',
        membership: 'Membership',
        creation: 'Creation Engine',
        explore: 'Explore',
        workspace: 'Workspace',
        verse: 'Verse AI',
        yagyx: 'YAGYX Chain',
      };
      const label = map[tabId];
      if (!label) return false;

      // Look in primary nav
      let b = allButtons.find((el) => el.textContent && el.textContent.includes(label));
      if (b) {
        b.click();
        return true;
      }
      return false;
    }, screen.tab);

    // If needed, check ecosystem dropdown for secondary tabs
    if (!clicked && (screen.tab === 'explore' || screen.tab === 'workspace' || screen.tab === 'membership')) {
      await page.evaluate((tabId) => {
        const ecosystemBtn = Array.from(document.querySelectorAll('button')).find((b) => b.textContent && b.textContent.includes('Ecosystem'));
        if (ecosystemBtn) ecosystemBtn.click();
      });
      await page.waitForTimeout(300);
      await page.evaluate((tabId) => {
        const allButtons = Array.from(document.querySelectorAll('button'));
        const map = {
          explore: 'Explore Directory',
          workspace: 'Builder Workspace',
          membership: 'Membership',
        };
        const label = map[tabId];
        const b = allButtons.find((el) => el.textContent && el.textContent.includes(label));
        if (b) b.click();
      }, screen.tab);
    }

    await page.waitForTimeout(800);

    // Capture screen screenshot
    const shotPath = path.join(SCREENSHOT_DIR, `screen_${screen.id}_desktop.png`);
    await page.screenshot({ path: shotPath, fullPage: false });
    auditReport.screenshotsCaptured.push(`screen_${screen.id}_desktop.png`);

    // Verify images on this screen
    const images = await page.evaluate(() => {
      const imgs = Array.from(document.querySelectorAll('main img'));
      return imgs.map((img) => ({
        src: img.src,
        alt: img.alt,
        visible: img.offsetWidth > 0 && img.offsetHeight > 0,
        renderedWidth: img.offsetWidth,
        renderedHeight: img.offsetHeight,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight,
        className: img.className,
      }));
    });

    console.log(`  Found ${images.length} rendered images in <main>:`);
    images.forEach((img) => {
      const isOk = img.visible && img.renderedWidth > 0 && img.renderedHeight > 0;
      console.log(`    ${isOk ? '✓' : '✗'} [${img.renderedWidth}x${img.renderedHeight}px] ${img.alt || 'no-alt'} -> ${img.src}`);
    });

    auditReport.screensAudited.push({
      screen: screen.name,
      tab: screen.tab,
      imageCount: images.length,
      images: images.slice(0, 8),
    });
  }

  // 3. Audit Project Cards & Status Badges on Explore Screen
  console.log('\n--- AUDITING PROJECT CARDS & STATUS BADGES ---');
  // Navigate to explore
  await page.evaluate(() => {
    const ecosystemBtn = Array.from(document.querySelectorAll('button')).find((b) => b.textContent && b.textContent.includes('Ecosystem'));
    if (ecosystemBtn) ecosystemBtn.click();
  });
  await page.waitForTimeout(300);
  await page.evaluate(() => {
    const b = Array.from(document.querySelectorAll('button')).find((el) => el.textContent && el.textContent.includes('Explore Directory'));
    if (b) b.click();
  });
  await page.waitForTimeout(800);

  const cardAudit = await page.evaluate(() => {
    const cards = Array.from(document.querySelectorAll('[data-testid="project-card"]'));
    return cards.map((card) => {
      const title = card.querySelector('h3')?.textContent || 'Untitled';
      const logo = card.querySelector('[data-testid="project-logo"]');
      const badge = card.querySelector('[data-testid="project-status-badge"]');
      return {
        title,
        logo: logo ? {
          src: logo.src,
          visible: logo.offsetWidth > 0 && logo.offsetHeight > 0,
          width: logo.offsetWidth,
          height: logo.offsetHeight,
          naturalWidth: logo.naturalWidth,
        } : null,
        badge: badge ? {
          src: badge.src,
          alt: badge.alt,
          statusLabel: badge.getAttribute('data-status'),
          visible: badge.offsetWidth > 0 && badge.offsetHeight > 0,
          width: badge.offsetWidth,
          height: badge.offsetHeight,
          naturalWidth: badge.naturalWidth,
        } : null,
      };
    });
  });

  console.log(`  Found ${cardAudit.length} project cards:`);
  cardAudit.forEach((c) => {
    console.log(`    Project: "${c.title}"`);
    if (c.logo) {
      console.log(`      Logo: visible=${c.logo.visible} (${c.logo.width}x${c.logo.height}px) -> ${c.logo.src}`);
    } else {
      console.log(`      Logo: MISSING ELEMENT`);
    }
    if (c.badge) {
      console.log(`      Badge: status="${c.badge.statusLabel}" visible=${c.badge.visible} (${c.badge.width}x${c.badge.height}px) -> ${c.badge.src}`);
    } else {
      console.log(`      Badge: MISSING ELEMENT`);
    }
  });

  // 4. Audit Project Detail Modal
  console.log('\n--- AUDITING PROJECT DETAIL MODAL ---');
  const launchButtons = await page.$$('[data-testid="project-card"] button');
  if (launchButtons.length > 0) {
    // Click Launch button on first card
    const firstLaunch = await page.$('[data-testid="project-card"] button:has-text("Launch")');
    if (firstLaunch) {
      await firstLaunch.click();
      await page.waitForTimeout(500);

      const modalInfo = await page.evaluate(() => {
        const modal = document.querySelector('.fixed.inset-0');
        if (!modal) return null;
        const title = modal.querySelector('h2')?.textContent;
        const imgs = Array.from(modal.querySelectorAll('img')).map((i) => ({
          src: i.src,
          alt: i.alt,
          width: i.offsetWidth,
          height: i.offsetHeight,
          visible: i.offsetWidth > 0 && i.offsetHeight > 0,
        }));
        return { title, imgs };
      });

      console.log('  Modal Audit Result:', JSON.stringify(modalInfo, null, 2));
      const modalShot = path.join(SCREENSHOT_DIR, 'screen_project_modal.png');
      await page.screenshot({ path: modalShot });
      auditReport.screenshotsCaptured.push('screen_project_modal.png');

      // Close modal
      const closeBtn = await page.$('button[aria-label="Close modal"]');
      if (closeBtn) await closeBtn.click();
      await page.waitForTimeout(300);
    }
  }

  // 5. Responsive Matrix Testing Across All 8 Viewports
  console.log('\n--- AUDITING RESPONSIVE MATRIX (8 VIEWPORTS) ---');
  for (const vp of VIEWPORTS) {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.waitForTimeout(400);

    // Navigate to Discovery for viewport test
    await page.evaluate(() => {
      const b = Array.from(document.querySelectorAll('button')).find((el) => el.textContent && el.textContent.includes('Discovery'));
      if (b) b.click();
    });
    await page.waitForTimeout(400);

    const vpMetrics = await page.evaluate((expectedWidth) => {
      const docWidth = document.documentElement.scrollWidth;
      const bodyWidth = document.body.scrollWidth;
      const hasHorizontalScroll = docWidth > expectedWidth + 1; // 1px threshold for subpixel

      // Check header navbar visibility
      const header = document.querySelector('header');
      const headerBox = header ? header.getBoundingClientRect() : null;

      // Check main logo
      const logo = document.querySelector('header button img[alt="FUTUREVERSE"]');
      const logoBox = logo ? logo.getBoundingClientRect() : null;

      return {
        viewportWidth: expectedWidth,
        docScrollWidth: docWidth,
        bodyScrollWidth: bodyWidth,
        hasHorizontalScroll,
        headerRendered: !!headerBox && headerBox.height > 0,
        logoRendered: !!logoBox && logoBox.width > 0 && logoBox.height > 0,
        logoWidth: logoBox ? logoBox.width : 0,
        logoHeight: logoBox ? logoBox.height : 0,
      };
    }, vp.width);

    const shotName = `responsive_${vp.width}px_${vp.name}.png`;
    const shotPath = path.join(SCREENSHOT_DIR, shotName);
    await page.screenshot({ path: shotPath, fullPage: false });
    auditReport.screenshotsCaptured.push(shotName);

    console.log(`  Viewport ${vp.width}px (${vp.name}):`);
    console.log(`    - ScrollWidth: ${vpMetrics.docScrollWidth}px | Horizontal Overflow: ${vpMetrics.hasHorizontalScroll ? 'DEFECT DETECTED' : 'CLEAN (No overflow)'}`);
    console.log(`    - Header: visible=${vpMetrics.headerRendered}`);
    console.log(`    - Logo: visible=${vpMetrics.logoRendered} (${Math.round(vpMetrics.logoWidth)}x${Math.round(vpMetrics.logoHeight)}px)`);

    if (vpMetrics.hasHorizontalScroll) {
      auditReport.defectsFound.push(`Horizontal overflow detected at ${vp.width}px: scrollWidth=${vpMetrics.docScrollWidth}px`);
    }
  }

  // 6. Test Image Fallback Mechanism
  console.log('\n--- AUDITING IMAGE FALLBACK MECHANISM ---');
  await page.evaluate(() => {
    const ecosystemBtn = Array.from(document.querySelectorAll('button')).find((b) => b.textContent && b.textContent.includes('Ecosystem'));
    if (ecosystemBtn) ecosystemBtn.click();
  });
  await page.waitForTimeout(300);
  await page.evaluate(() => {
    const b = Array.from(document.querySelectorAll('button')).find((el) => el.textContent && el.textContent.includes('Explore Directory'));
    if (b) b.click();
  });
  await page.waitForTimeout(800);

  const fallbackTestResult = await page.evaluate(async () => {
    const card = document.querySelector('[data-testid="project-card"]');
    if (!card) return { passed: false, reason: 'No card found' };

    const logo = card.querySelector('[data-testid="project-logo"]');
    if (!logo) return { passed: false, reason: 'No logo element found' };

    const originalSrc = logo.src;
    logo.dispatchEvent(new Event('error', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 200));

    const newSrc = logo.src;
    const fellBackToIcon = newSrc.includes('futureverse-icon.svg');

    return {
      passed: fellBackToIcon,
      originalSrc,
      newSrc,
      fellBackToIcon,
    };
  });

  console.log(`  Fallback verification: ${fallbackTestResult.passed ? 'PASSED' : 'FAILED'}`);
  console.log(`  Details: original=${fallbackTestResult.originalSrc} -> after error=${fallbackTestResult.newSrc}`);

  // Summary
  console.log('\n================================================================');
  console.log('AUDIT COMPLETE');
  console.log(`Screenshots Captured: ${auditReport.screenshotsCaptured.length}`);
  console.log(`Console Errors: ${auditReport.consoleErrors.length}`);
  console.log(`Failed Requests: ${auditReport.failedNetworkRequests.length}`);
  console.log(`Defects Found: ${auditReport.defectsFound.length}`);
  console.log('================================================================\n');

  fs.writeFileSync(
    path.join(process.cwd(), 'public/preview/audit_report.json'),
    JSON.stringify(auditReport, null, 2)
  );

  await browser.close();
}

runAudit().catch((err) => {
  console.error('Audit script failed:', err);
  process.exit(1);
});
