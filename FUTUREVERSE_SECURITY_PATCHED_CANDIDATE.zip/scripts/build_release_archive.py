import zipfile
import os

zip_dest = 'public/brand-kit/futureverse-release-v2.4.0.zip'
exclude_dirs = {
    'node_modules', '.git', 'dist', '.aistudio', '__pycache__', '.vite', 'coverage', '.cache'
}
exclude_files = {
    '.env', '.env.local', 'futureverse-release-v2.4.0.zip'
}

count = 0
total_bytes = 0

with zipfile.ZipFile(zip_dest, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        # Exclude directories in-place
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file in exclude_files or file.endswith('.pyc') or file.startswith('.env.'):
                continue
            filepath = os.path.join(root, file)
            # Skip huge files or private items
            if os.path.islink(filepath):
                continue
            arcname = os.path.relpath(filepath, '.')
            zipf.write(filepath, arcname)
            count += 1
            total_bytes += os.path.getsize(filepath)

print(f"Archive successfully generated: {zip_dest}")
print(f"Included {count} files, uncompressed size {total_bytes / 1024 / 1024:.2f} MB, zip size {os.path.getsize(zip_dest) / 1024:.2f} KB")

# Also copy to dist if dist exists
if os.path.exists('dist/brand-kit'):
    import shutil
    shutil.copyfile(zip_dest, 'dist/brand-kit/futureverse-release-v2.4.0.zip')
    print("Copied to dist/brand-kit/futureverse-release-v2.4.0.zip")
