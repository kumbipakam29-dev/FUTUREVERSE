import zipfile
import os
import hashlib
import shutil
import json

zip_filename = 'FUTUREVERSE_PROJECT_RELEASE_v3.1.zip'
exclude_dirs = {
    'node_modules', '.git', 'dist', '.aistudio', '__pycache__', '.vite', 'coverage', '.cache'
}
exclude_files = {
    '.env', '.env.local', zip_filename, 'FUTUREVERSE_PROJECT_ARCHIVE.zip'
}
exclude_exts = {
    '.pyc', '.tar.gz'
}

count = 0
total_uncompressed = 0

print(f"Building {zip_filename}...")

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            if f in exclude_files or any(f.endswith(ext) for ext in exclude_exts):
                continue
            # Also exclude old recursive zip files from inside the release archive
            if f.endswith('.zip'):
                continue
            filepath = os.path.join(root, f)
            if os.path.islink(filepath):
                continue
            arcname = os.path.relpath(filepath, '.')
            zf.write(filepath, arcname)
            count += 1
            total_uncompressed += os.path.getsize(filepath)

file_size = os.path.getsize(zip_filename)

# Compute SHA-256
h = hashlib.sha256()
with open(zip_filename, 'rb') as f:
    while chunk := f.read(65536):
        h.update(chunk)
sha256 = h.hexdigest()

print(f"SUCCESS: {zip_filename} created.")
print(f"Total Files: {count}")
print(f"Uncompressed: {total_uncompressed / 1024 / 1024:.2f} MB")
print(f"Archive Size: {file_size / 1024:.2f} KB ({file_size / 1024 / 1024:.2f} MB)")
print(f"SHA-256: {sha256}")

# Distribute copies STRICTLY to protected server paths (NEVER to public/ or dist/)
targets = [
    'protected_releases/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
    'FUTUREVERSE_PROJECT_ARCHIVE.zip',
    'FUTUREVERSE_PROJECT_v3.1.zip'
]

for t in targets:
    os.makedirs(os.path.dirname(t) if os.path.dirname(t) else '.', exist_ok=True)
    shutil.copyfile(zip_filename, t)
    print(f"Copied to protected location: {t}")

# Audit: ensure NO project release zip is in public/ or dist/
for pub_check in [
    'public/brand-kit/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
    'public/brand-kit/futureverse-project.zip',
    'public/brand-kit/futureverse-release-v2.4.0.zip',
    'public/futureverse-verified-release.zip',
    'dist/brand-kit/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
    'dist/brand-kit/futureverse-project.zip',
    'dist/futureverse-verified-release.zip'
]:
    if os.path.exists(pub_check):
        os.remove(pub_check)

# Also copy to AI Studio artifacts directory
artifact_dir = '.aistudio/artifacts/brain/3109c8ff-6cf9-4a16-8809-a710923040d4'
if os.path.exists(artifact_dir):
    shutil.copyfile(zip_filename, os.path.join(artifact_dir, zip_filename))
    print(f"Copied to artifact dir: {artifact_dir}/{zip_filename}")

# Update release_checksums.json
if os.path.exists('release_checksums.json'):
    with open('release_checksums.json', 'r') as rf:
        rc = json.load(rf)
    if 'release_archives' not in rc:
        rc['release_archives'] = {}
    rc['release_archives'][zip_filename] = {'sha256': sha256, 'size': file_size}
    if 'files' not in rc:
        rc['files'] = {}
    rc['files'][zip_filename] = {'sha256': sha256, 'size': file_size}
    with open('release_checksums.json', 'w') as wf:
        json.dump(rc, wf, indent=2)
    print("Updated release_checksums.json with canonical hash and size")

if os.path.exists('CURRENT_RELEASE_CHECKSUMS.json'):
    with open('CURRENT_RELEASE_CHECKSUMS.json', 'r') as rf:
        crc = json.load(rf)
    crc['archive_name'] = zip_filename
    crc['sha256'] = sha256
    crc['size_bytes'] = file_size
    with open('CURRENT_RELEASE_CHECKSUMS.json', 'w') as wf:
        json.dump(crc, wf, indent=2)
    print("Updated CURRENT_RELEASE_CHECKSUMS.json with canonical hash and size")

# Write metadata record to docs/releases/
metadata = {
    'archive': zip_filename,
    'sizeBytes': file_size,
    'sizeMB': round(file_size / 1024 / 1024, 2),
    'uncompressedMB': round(total_uncompressed / 1024 / 1024, 2),
    'fileCount': count,
    'sha256': sha256,
    'canonicalUrls': [
        f'/export/futureverse-project.zip',
        f'/FUTUREVERSE_PROJECT_RELEASE_v3.1.zip',
        f'/brand-kit/futureverse-project.zip',
        f'/api/export/project'
    ]
}

with open('docs/releases/project-archive-info.json', 'w') as f:
    json.dump(metadata, f, indent=2)

print("Export metadata saved to docs/releases/project-archive-info.json")
