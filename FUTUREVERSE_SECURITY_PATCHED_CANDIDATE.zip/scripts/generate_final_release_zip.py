import zipfile
import os
import hashlib
import shutil
import json

zip_filename = 'FUTUREVERSE_FINAL_RELEASE.zip'
exclude_dirs = {
    'node_modules', '.git', 'dist', '.aistudio', '__pycache__', '.vite', 'coverage', '.cache', 'protected_releases', 'temp_test_extracted'
}
exclude_files = {
    zip_filename, 'futureverse-source.zip', 'temp_test_download.zip'
}
exclude_exts = {
    '.pyc', '.tar.gz', '.log'
}

count = 0
total_uncompressed = 0
included_files = []

print(f"Building {zip_filename}...")

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in sorted(dirs) if d not in exclude_dirs]
        for f in sorted(files):
            # Exclude secrets: any .env* file EXCEPT .env.example
            if f.startswith('.env') and f != '.env.example':
                continue
            if f in exclude_files or any(f.endswith(ext) for ext in exclude_exts):
                continue
            # Exclude all existing zip archives to prevent recursive nested dumps
            if f.endswith('.zip'):
                continue
            filepath = os.path.join(root, f)
            if os.path.islink(filepath):
                continue
            arcname = os.path.relpath(filepath, '.')
            zf.write(filepath, arcname)
            count += 1
            total_uncompressed += os.path.getsize(filepath)
            included_files.append(arcname)

file_size = os.path.getsize(zip_filename)

# Compute SHA-256
h = hashlib.sha256()
with open(zip_filename, 'rb') as f:
    while chunk := f.read(65536):
        h.update(chunk)
sha256 = h.hexdigest()

print(f"SUCCESS: {zip_filename} created.")
print(f"Total Files Included: {count}")
print(f"Uncompressed: {total_uncompressed / 1024 / 1024:.2f} MB")
print(f"Archive Size: {file_size} bytes ({file_size / 1024 / 1024:.2f} MB)")
print(f"SHA-256: {sha256}")

# 1. Verify ZIP signature ("PK\x03\x04")
with open(zip_filename, 'rb') as f:
    magic = f.read(4)
    if magic != b'PK\x03\x04':
        raise RuntimeError(f"Invalid ZIP magic bytes: {magic}")
print("ZIP Signature Verified: PK\\x03\\x04 (0x50 0x4B 0x03 0x04)")

# 2. Verify integrity with ZipFile testzip
with zipfile.ZipFile(zip_filename, 'r') as zf:
    corrupt = zf.testzip()
    if corrupt is not None:
        raise RuntimeError(f"Corrupt file found in archive: {corrupt}")
    file_list = zf.namelist()
    print(f"ZIP Integrity Verified: 0 errors across {len(file_list)} files.")

# 3. Verify essential files exist in archive
essential_files = ['package.json', 'server.ts', 'src/App.tsx', 'src/main.tsx', 'index.html', 'vite.config.ts', 'tsconfig.json']
with zipfile.ZipFile(zip_filename, 'r') as zf:
    names = set(zf.namelist())
    for ef in essential_files:
        if ef not in names:
            raise RuntimeError(f"Essential file missing from archive: {ef}")
print("Essential Files Verified: package.json, server.ts, src/App.tsx, src/main.tsx, index.html, vite.config.ts, tsconfig.json all present.")

# 4. Copy to AI Studio artifacts directory so the platform exposes it as a downloadable artifact
artifact_dirs = [
    '/.aistudio/artifacts/brain/3109c8ff-6cf9-4a16-8809-a710923040d4',
    '.aistudio/artifacts/brain/3109c8ff-6cf9-4a16-8809-a710923040d4'
]
for adir in artifact_dirs:
    if os.path.exists(adir):
        shutil.copyfile(zip_filename, os.path.join(adir, zip_filename))
        shutil.copyfile(zip_filename, os.path.join(adir, 'futureverse-source.zip'))
        print(f"Copied to artifact dir: {adir}/{zip_filename}")

# Copy to protected_releases for server-side release storage
os.makedirs('protected_releases', exist_ok=True)
shutil.copyfile(zip_filename, os.path.join('protected_releases', zip_filename))
shutil.copyfile(zip_filename, os.path.join('protected_releases', 'futureverse-source.zip'))
shutil.copyfile(zip_filename, 'futureverse-source.zip')
print(f"Copied to protected_releases/{zip_filename} and mirrors.")

# Record in release_checksums.json
if os.path.exists('release_checksums.json'):
    with open('release_checksums.json', 'r') as rf:
        rc = json.load(rf)
    if 'release_archives' not in rc:
        rc['release_archives'] = {}
    rc['release_archives'][zip_filename] = {'sha256': sha256, 'size': file_size, 'fileCount': count}
    with open('release_checksums.json', 'w') as wf:
        json.dump(rc, wf, indent=2)
    print("Updated release_checksums.json")

