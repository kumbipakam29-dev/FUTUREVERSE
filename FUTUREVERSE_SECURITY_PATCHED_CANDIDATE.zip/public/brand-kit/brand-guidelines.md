# FUTUREVERSE BRAND GUIDELINES

## 1. Brand Philosophy: The All-Seeing Quantum Matrix
FUTUREVERSE is the supreme intersection of autonomous intelligence and value settlement. The triangle represents stability, hierarchy, and sacred geometry. The eye represents omniscient perception, clarity, and continuous evolution.

## 2. Emblem Geometry & Clearance
- Maintain clear space equal to 25% of the emblem's outer bounding box on all sides.
- Do not stretch, skew, or distort the sacred equilateral triangle aspect ratio.
- Orbit rings must remain centered on the central pupil singularity.

## 3. Dark & Light Theme Usage
- **Dark Theme (Default):** Use `futureverse-wordmark-neon.svg` or `futureverse-logo.svg` against `#020617` or `#0B0F19`.
- **Light Theme:** Use `futureverse-wordmark-mono.svg` or gold accents with enhanced high-contrast text rendering.
- **Mobile Devices (<640px):** Logo scales fluidly between 120px and 160px width without overlapping adjacent controls.
