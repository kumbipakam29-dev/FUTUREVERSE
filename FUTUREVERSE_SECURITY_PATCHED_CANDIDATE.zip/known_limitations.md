# FUTUREVERSE KNOWN LIMITATIONS

1. **Mainnet Public RPC:** The system is configured for YAGYX Chain ID 13370 (0x343a). When no external public RPC is online, the system runs in high-fidelity local diagnostic sandbox mode.
2. **Multilingual Dictionary:** Core navigation and high-traffic screens support English, Hindi, and Gujarati. Deep technical logs and mathematical proofs currently display in English with Sanskrit transliterations.
