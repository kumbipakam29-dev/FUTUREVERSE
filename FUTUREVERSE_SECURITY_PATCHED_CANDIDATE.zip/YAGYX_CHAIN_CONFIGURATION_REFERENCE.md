# YAGYX CHAIN (CHAIN ID 13370 / 0x343a)
## Comprehensive Technical Configuration Reference

**Document Version**: 1.0.0  
**Authority Reference**: FUTUREVERSE × BATWAL'S VERSE AI × YAGYX Ecosystem  
**Classification**: Engineering Reference Document  
**Status**: Verified from Repository Source Code & Runtime Configuration

---

### 1. Network Identity & Core Parameters

| Parameter | Configuration Value | Verification Status | Source Reference |
| :--- | :--- | :--- | :--- |
| **Network Name** | YAGYX Chain | Verified in codebase | `src/services/web3.ts:95` |
| **Decimal Chain ID** | `13370` | Verified in unit tests & test audit | `src/server/yagyxPaymentService.ts:29` |
| **Hexadecimal Chain ID** | `0x343a` | Verified in Web3 switcher | `src/services/web3.ts:2` |
| **Native Gas Currency** | YAGYX | Verified in Web3 switcher | `src/services/web3.ts:98` |
| **Currency Symbol** | `YAGYX` | Verified | `src/services/web3.ts:98` |
| **Native Decimals** | `18` | Verified in integer arithmetic | `src/server/yagyxPaymentService.ts:63` |
| **Base Gas Unit** | `wei` (10^-18 YAGYX) | Verified in transaction builder | `src/services/web3.ts:78` |
| **EVM Compatibility** | Standard EVM (Ethereum Virtual Machine) | Verified in EIP-1193 RPC specs | `src/services/web3.ts:82` |

---

### 2. Network Endpoint Specifications

| Endpoint Role | Configured Target URL | Protocol | Reachability Status | Notes |
| :--- | :--- | :--- | :--- | :--- |
| **Primary JSON-RPC** | `https://rpc.yagyx.network` | HTTPS / JSON-RPC 2.0 | **Unreachable (`ENOTFOUND`)** | DNS record not resolved in public DNS |
| **Environment Fallback** | `process.env.YAGYX_RPC_URL` | HTTPS / HTTP | `NOT_SET` | Overrides default when provided |
| **WebSocket RPC** | `wss://rpc.yagyx.network` | WSS / WebSocket | **Unverified (Pending DNS)** | Standard EVM event subscription endpoint |
| **Block Explorer** | `https://explorer.yagyx.network` | HTTPS | **Unverified (Pending DNS)** | Configured in `wallet_addEthereumChain` |
| **Local App Server** | `http://localhost:3000` | HTTP | **Active & Verified** | Express + Vite dev server |

---

### 3. Ecosystem Token & Contract Registry

*Note: All addresses below represent configured reference constants. Bytecode on-chain is unverified due to offline public RPC.*

#### A. Native Gas & Compute Asset: YAGYX
- **Symbol**: `YAGYX`
- **Asset Type**: Native EVM Protocol Coin (not a smart contract)
- **Decimals**: `18`
- **Starting Reference Benchmark**: ₹100 INR / $1.18 USD (Configured reference price, subject to market discovery)
- **Primary Role**: Transaction gas, compute job escrow settlement, node staking

#### B. Governance & Ecosystem Token: YGO
- **Symbol**: `YGO`
- **Asset Type**: ERC-20 Smart Contract Token
- **Configured Address**: `0x1000000000000000000000000000000000001337`
- **Decimals**: `18`
- **Starting Reference Benchmark**: ₹1 INR / $0.0118 USD
- **Primary Role**: Evolution proposal voting weight, contributor task bounties, community rewards
- **Payment Priority**: Priority 1 in payment hierarchy

#### C. Regional Rupee-Pegged Asset: YINR
- **Symbol**: `YINR`
- **Asset Type**: ERC-20 Fiat-Pegged Token
- **Configured Address**: `0x2000000000000000000000000000000000001337`
- **Decimals**: `18`
- **Target Value**: ₹1.00 INR
- **Reserve Audit Status**: Pending independent reserve audit attestation
- **Payment Priority**: Priority 3 in payment hierarchy

#### D. Global Dollar-Pegged Asset: YUSD
- **Symbol**: `YUSD`
- **Asset Type**: ERC-20 Fiat-Pegged Token
- **Configured Address**: `0x3000000000000000000000000000000000001337`
- **Decimals**: `18`
- **Target Value**: $1.00 USD
- **Reserve Audit Status**: Pending independent reserve audit attestation
- **Payment Priority**: Priority 4 in payment hierarchy

#### E. Protocol Recipient Vault
- **Configured Address**: `0x71C836376510343a000000000000000000013370`
- **Role**: Target recipient for all verified membership payments and compute commissions
- **Environment Override**: `process.env.YAGYX_VAULT_ADDRESS`
- **Verification Invariant**: The backend verification engine strictly rejects any payment receipt where `receipt.to.toLowerCase() !== vaultAddress.toLowerCase()`.

---

### 4. Genesis Block Specification (Target Blueprint)

Because the live chain is not reachable via `https://rpc.yagyx.network`, the target EVM genesis configuration required to instantiate the node is documented below:

```json
{
  "config": {
    "chainId": 13370,
    "homesteadBlock": 0,
    "eip150Block": 0,
    "eip155Block": 0,
    "eip158Block": 0,
    "byzantiumBlock": 0,
    "constantinopleBlock": 0,
    "petersburgBlock": 0,
    "istanbulBlock": 0,
    "berlinBlock": 0,
    "londonBlock": 0,
    "clique": {
      "period": 3,
      "epoch": 30000
    }
  },
  "difficulty": "1",
  "gasLimit": "30000000",
  "extradata": "0x000000000000000000000000000000000000000000000000000000000000000071C836376510343a0000000000000000000133700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
  "alloc": {
    "0x71C836376510343a000000000000000000013370": {
      "balance": "1000000000000000000000000000"
    }
  }
}
```

---

### 5. Build, Environment & Execution Configuration

- **Node.js Target**: Node.js 20+ (ESM module mode enabled in `package.json`).
- **TypeScript**: Strict type checking enabled (`tsconfig.json`).
- **Dependencies**:
  - `express`: REST API and middleware server
  - `cors`: Cross-origin request security
  - `lucide-react`: Modern SVG icons
  - `@google/genai`: Gemini 3.8 Flash SDK for BATWAL'S VERSE AI
  - `react`: React 19 SPA framework
  - `tailwindcss`: Utility CSS
  - `vite`: Production asset bundler
- **Build Commands**:
  - `npm run build`: Executes Vite production bundling (`dist/` directory)
  - `npm run lint`: Executes `tsc --noEmit`
  - `npm run dev`: Runs `tsx server.ts`
- **Test Commands**:
  - `npx tsx test/run_tests.ts`: 50-test automated invariant suite
  - `npx tsx test/generate_100_tests_audit.ts`: 100-test master forensic audit
