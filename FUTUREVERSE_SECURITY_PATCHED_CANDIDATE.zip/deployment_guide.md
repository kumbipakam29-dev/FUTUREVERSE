# FUTUREVERSE DEPLOYMENT GUIDE

## Prerequisites
- Node.js >= 20.x
- NPM >= 10.x

## Build Command
```bash
npm run build
```

## Start Server Command
```bash
node server.ts --port 3000 --host 0.0.0.0
```

## Health Verification
```bash
curl -I http://localhost:3000/api/health
```
