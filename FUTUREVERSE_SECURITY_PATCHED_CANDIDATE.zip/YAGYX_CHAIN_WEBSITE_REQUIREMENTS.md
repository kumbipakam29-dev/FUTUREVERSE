# YAGYX CHAIN OFFICIAL WEBSITE
## Technical Specification & Implementation Requirements

**Purpose**: Blueprint for developing the official stand-alone website and developer portal for YAGYX Chain without modifying or disrupting the core FUTUREVERSE platform.  
**Audience**: Frontend engineers, Web3 designers, and developer advocates.  
**Status**: Specification Phase (Ready for Implementation).

---

### 1. Website Overview & Brand Identity

- **Site Title**: YAGYX Chain — The Global Value Operating System
- **Core Value Proposition**: Sovereign, high-throughput, EVM-compatible settlement layer for decentralized compute, autonomous AI agents, and frictionless peer-to-peer micro-settlement.
- **Ecosystem Links**: Native settlement engine for **FUTUREVERSE** and **BATWAL'S VERSE AI**.
- **Founding Stewards**: Dhaval Chandrashekhar Batwal (Lead Steward), Hemangini Chandrashekhar Batwal, Jayshriben Chandrashekhar Batwal.

---

### 2. Core Functional Modules & Page Hierarchy

```
yagyx.network /
├── / (Home / Ecosystem Landing Page)
├── /network (Live Network Telemetry & Node Health)
├── /explorer (Block & Transaction Explorer)
├── /pay (YAGYX Pay Merchant & Web3 Checkout Demo)
├── /developers (RPC Endpoints, SDKs & Contract Guides)
├── /faucet (Testnet Gas Dispenser)
├── /assets (YAGYX, YGO, YINR, YUSD Token Specifications)
└── /governance (Evolution Proposals & Ownership Registry)
```

---

### 3. Detailed Component Specifications

#### A. Network Status Dashboard (`/network`)
- **Live Metrics**:
  - Current Block Height (queried via `eth_blockNumber`)
  - Average Block Time (seconds per block)
  - Network Gas Price (`eth_gasPrice` in Gwei)
  - Active Validator Count (or authority signers)
  - Current TPS (Transactions Per Second)
  - JSON-RPC Endpoint Health & Latency (ping response time in ms)
- **Network Requirement Flag**: *Requires a live running node at `https://rpc.yagyx.network`.* When node is offline, display: `"Network offline or awaiting public node peering"`.

#### B. Block Explorer (`/explorer`)
- **Key Views**:
  - Latest Blocks Table (Block #, Miner/Signer, Tx Count, Timestamp)
  - Recent Transactions Feed (Tx Hash, From, To, Value in YAGYX, Status)
  - Address Details Page (Native Balance, Token Balances, Transaction History)
  - Transaction Details Modal (Status, Block, Gas Used, Nonce, Input Data)
- **Integration Path**: Either deploy an open-source Blockscout instance or render a lightweight custom indexer using Node.js + SQLite/PostgreSQL caching blocks via RPC polling.

#### C. One-Click Wallet Integration (`"Add YAGYX to MetaMask"`)
- **EIP-1193 Script**:
  ```typescript
  async function addYagyxToWallet() {
    if (!window.ethereum) return alert('No Web3 wallet detected.');
    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [{
        chainId: '0x343a', // 13370 in hex
        chainName: 'YAGYX Chain',
        nativeCurrency: {
          name: 'YAGYX',
          symbol: 'YAGYX',
          decimals: 18,
        },
        rpcUrls: ['https://rpc.yagyx.network'],
        blockExplorerUrls: ['https://explorer.yagyx.network'],
      }],
    });
  }
  ```

#### D. YAGYX Pay (`/pay`)
- **Features**:
  - Embeddable Web3 checkout modal for merchants.
  - Multi-asset selection (YGO, YAGYX, YINR, YUSD).
  - Exact integer base-unit conversions (`toBaseUnits(amount, 18)`).
  - Transparent fee disclosure (zero hidden recurring subscriptions).
  - Real-time transaction receipt monitoring via `eth_getTransactionReceipt`.

#### E. Developer Documentation (`/developers`)
- **Network Parameters Reference**:
  - Chain ID: `13370`
  - Hex: `0x343a`
  - RPC Endpoint: `https://rpc.yagyx.network`
  - WebSocket Endpoint: `wss://rpc.yagyx.network`
  - Currency: `YAGYX` (18 decimals)
- **Integration Code Snippets**:
  - `viem` / `wagmi` Chain definition:
    ```typescript
    import { defineChain } from 'viem';

    export const yagyx = defineChain({
      id: 13370,
      name: 'YAGYX Chain',
      nativeCurrency: { name: 'YAGYX', symbol: 'YAGYX', decimals: 18 },
      rpcUrls: {
        default: { http: ['https://rpc.yagyx.network'] },
      },
      blockExplorers: {
        default: { name: 'YAGYX Explorer', url: 'https://explorer.yagyx.network' },
      },
    });
    ```
  - `ethers.js` Provider:
    ```typescript
    import { ethers } from 'ethers';
    const provider = new ethers.JsonRpcProvider('https://rpc.yagyx.network', 13370);
    ```

#### F. Ecosystem Assets Specification (`/assets`)
- Dedicated transparency pages for:
  - **YAGYX**: Native Gas & Compute settlement token.
  - **YGO**: Ecosystem governance & contributor rewards token.
  - **YINR**: Regional Rupee-pegged asset (with honest reserve disclosure).
  - **YUSD**: Global Dollar-pegged asset (with honest reserve disclosure).

---

### 4. Implementation Phasing Without Modifying Existing Chain

1. **Phase 1 (Static & Interactive Showcase)**: Build the website with full branding, interactive wallet connector (`wallet_addEthereumChain`), documentation, and simulated explorer cards.
2. **Phase 2 (RPC Integration)**: Once `rpc.yagyx.network` is routed to an operational node, connect the `/network` telemetry and `/explorer` views to read live blocks.
3. **Phase 3 (Contract Deployment & Faucet)**: Deploy official ERC-20 token contracts on Chain 13370 and connect the testnet faucet.
