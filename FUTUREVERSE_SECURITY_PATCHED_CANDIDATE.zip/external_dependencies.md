# FUTUREVERSE EXTERNAL DEPENDENCIES

| Dependency | Purpose | Status | Local Handling |
| :--- | :--- | :--- | :--- |
| Gemini API | AI Generation & 1000k IQ Synthesis | CONFIGURABLE | Safe deterministic fallback when key omitted or timeout occurs |
| YAGYX Chain RPC | Public RPC Broadcast | BLOCKED_EXTERNAL_DEPENDENCY | Diagnostic adapter & integer validation fully functional locally |
| Razorpay / Stripe | Legacy Fiat Payment | PROHIBITED / DISCOURAGED | YAGYX-native on-chain payment used by design |
