# FUTUREVERSE v3.1 STAGING DEPLOYMENT GUIDE

1. **Install Dependencies:**
   ```bash
   npm install
   ```
2. **Build Client Bundle:**
   ```bash
   npm run build
   ```
3. **Launch Server:**
   ```bash
   node server.ts --port 3000 --host 0.0.0.0
   ```
4. **Smoke Test:**
   ```bash
   curl -I http://localhost:3000/api/health
   ```
