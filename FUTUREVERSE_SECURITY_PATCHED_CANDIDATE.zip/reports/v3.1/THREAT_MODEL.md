# FUTUREVERSE v3.1 THREAT MODEL

## 1. Asset Classification
- **Critical Assets:** Canonical Ownership Registry, YAGYX Vault Destination Address (`0x71C836376510343a000000000000000000013370`), Payment Ledger, Compute Settlement Balances.
- **Sensitive Assets:** User creation drafts, private feedback, agent execution logs.
- **Public Assets:** Project catalog, Gita teachings, Brand kit vectors.

## 2. Threat Vectors & Defense in Depth
- **Attacker Privilege Escalation:** Prevented via zero client-side role reliance; all mutations verified server-side.
- **Financial Double-Spending / Replay:** Defeated by transactional hash idempotency and integer base unit math.
- **AI Agent Permission Bloat:** Child agent multiplication strictly inherits subset permissions; cannot escalate to owner.
- **Denial of Service / Unbounded Loops:** Hard execution limits on agent recursion (max 10 iterations, 30s timeout).
