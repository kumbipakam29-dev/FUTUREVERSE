# FUTUREVERSE v3.1 ROLLBACK GUIDE

1. In the event of a staging/production issue, revert code to tag `v2.4.0`:
   ```bash
   git checkout tags/v2.4.0
   ```
2. Restore persistent data files from `data/backups/`.
3. Rebuild and restart server:
   ```bash
   npm run build
   node server.ts --port 3000 --host 0.0.0.0
   ```
