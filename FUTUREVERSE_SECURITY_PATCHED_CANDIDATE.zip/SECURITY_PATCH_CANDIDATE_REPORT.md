# FUTUREVERSE Security Patch Candidate — 2026-10-27

This archive is a patched candidate, not a production-certified release.

## Changes made
- Replaced substring-based owner identity checks with exact matching in `src/server/authorityService.ts`.
- Protected `POST /api/launch/schedule` with the existing server-side owner-session guard.
- Protected `POST /api/launch/admin/reveal` with the owner-session guard and an exact Dhaval identity check.
- Protected `POST /api/admin/dhaval/update-designation` with the owner-session guard and an exact Dhaval identity check.
- Removed trust in caller-supplied `actor` / `authorizedActor` labels for these sensitive operations.

## Validation performed
- Original archive passed ZIP integrity test.
- Patched archive passed ZIP integrity test.
- Source-fragment assertions passed for all four intended edits.

## Not yet verified
- Full dependency install, TypeScript typecheck, automated test suite, and production build have not been run here.
- Live YAGYX RPC, on-chain payment verification, hosted deployment, and browser end-to-end behavior have not been tested.
- Add regression tests for unauthenticated requests, fake actor names, valid owner sessions, and session expiry before production deployment.

## Original archive SHA-256
`aeb69e8dd838cbed6bd3f23849eff5fa2c05fa31d9e20930816a8d1f19a2732d`
