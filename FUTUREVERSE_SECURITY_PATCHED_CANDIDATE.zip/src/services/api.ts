import {
  Project,
  EvolutionItem,
  ContributorTask,
  YagyxNetworkInfo,
  LaunchCampaign,
  AuthoritativeCampaignState,
  CampaignLifecycleStatus,
  ComputeJob,
  ComputeProvider,
  OfficialChannel,
  SocialPost,
  SocialAgent,
  VerseModel,
  VerseAgent,
  SarathiRoutingResult,
  OwnershipRegistry,
  PermanentAuthorityProfile,
  AuditLogEvent,
  MembershipOrder,
  ModelNamingRecord,
  AgentVersionRecord,
  YagyxLedgerRecord,
  YagyxRpcProbeResult,
  YagyxSecurityReport,
  AIProviderStatus,
  DeepResearchDossier,
  AppBuilderSession,
} from '../types';

export const api = {
  async getHealth() {
    const res = await fetch('/api/health');
    return res.json();
  },

  async getYagyxConfig(): Promise<YagyxNetworkInfo> {
    const res = await fetch('/api/yagyx/config');
    return res.json();
  },

  async getYagyxLedger(): Promise<{ totalOrders: number; confirmedOrders: number; orders: YagyxLedgerRecord[] }> {
    const res = await fetch('/api/yagyx/ledger');
    if (!res.ok) throw new Error('Failed to fetch YAGYX ledger');
    return res.json();
  },

  async probeYagyxRpc(rpcUrl?: string): Promise<YagyxRpcProbeResult> {
    const res = await fetch('/api/yagyx/rpc-probe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rpcUrl }),
    });
    if (!res.ok) throw new Error('RPC probe request failed');
    return res.json();
  },

  async getYagyxSecurityFindings(): Promise<YagyxSecurityReport> {
    const res = await fetch('/api/yagyx/security');
    if (!res.ok) throw new Error('Failed to fetch security report');
    return res.json();
  },

  // --- Common AI Provider Architecture (Phase 2) ---
  async getAiProviderStatus(): Promise<AIProviderStatus> {
    const res = await fetch('/api/ai/provider-status');
    if (!res.ok) throw new Error('Failed to fetch AI provider status');
    return res.json();
  },

  // --- Real Deep Research (Phase 3) ---
  async executeDeepResearch(query: string, scope: 'ALL' | 'WORKSPACE_FILES' | 'WEB_AND_EVM' = 'ALL'): Promise<DeepResearchDossier> {
    const res = await fetch('/api/research/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, scope }),
    });
    if (!res.ok) throw new Error('Deep research query failed');
    return res.json();
  },

  async getResearchHistory(): Promise<{ total: number; records: DeepResearchDossier[] }> {
    const res = await fetch('/api/research/history');
    if (!res.ok) throw new Error('Failed to fetch research history');
    return res.json();
  },

  async getResearchRecord(id: string): Promise<DeepResearchDossier> {
    const res = await fetch(`/api/research/${id}`);
    if (!res.ok) throw new Error('Failed to fetch research record');
    return res.json();
  },

  async deleteResearchRecord(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/research/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete research record');
    return res.json();
  },

  // --- Autonomous App Builder (Phase 4) ---
  async startAppBuild(prompt: string): Promise<AppBuilderSession> {
    const res = await fetch('/api/builder/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    if (!res.ok) throw new Error('Autonomous app build pipeline failed to start');
    return res.json();
  },

  async getAppBuildSession(sessionId: string): Promise<AppBuilderSession> {
    const res = await fetch(`/api/builder/session/${sessionId}`);
    if (!res.ok) throw new Error('Failed to fetch app build session');
    return res.json();
  },

  async commitAppRelease(sessionId: string): Promise<{ success: boolean; message: string; project: Project }> {
    const res = await fetch('/api/builder/commit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    });
    if (!res.ok) throw new Error('Failed to commit app release');
    return res.json();
  },

  // --- Authoritative 30-Day Mystery Launch (Section 5.3) ---
  async getLaunchCampaign(): Promise<AuthoritativeCampaignState> {
    const res = await fetch('/api/launch/campaign');
    return res.json();
  },

  async updateCampaignSchedule(params: {
    status?: CampaignLifecycleStatus;
    scheduledStartTimestamp?: string;
    scheduledRevealTimestamp?: string;
    authoritativeTimezone?: string;
    actor?: string;
  }): Promise<{ success: boolean; message: string }> {
    const res = await fetch('/api/launch/schedule', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update schedule');
    }
    return res.json();
  },

  async registerEarlyAccess(email: string, handle?: string) {
    const res = await fetch('/api/launch/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, handle }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to register');
    }
    return res.json();
  },

  async unlockDay30Reveal(authorizedActor: string) {
    const res = await fetch('/api/launch/admin/reveal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ authorizedActor }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to unlock core reveal');
    }
    return res.json();
  },

  // --- Section 11: Infinite Meaningful Model Naming Engine ---
  async getModelNamingRecords(): Promise<{ records: ModelNamingRecord[]; total: number }> {
    const res = await fetch('/api/verse/naming');
    return res.json();
  },

  async searchModelNamingRecords(params: { query?: string; verificationStatus?: string; approvalStatus?: string }): Promise<{ records: ModelNamingRecord[]; total: number }> {
    const searchParams = new URLSearchParams();
    if (params.query) searchParams.set('query', params.query);
    if (params.verificationStatus) searchParams.set('verificationStatus', params.verificationStatus);
    if (params.approvalStatus) searchParams.set('approvalStatus', params.approvalStatus);

    const res = await fetch(`/api/verse/naming/search?${searchParams.toString()}`);
    return res.json();
  },

  async generateModelNamingCandidate(params: {
    themeOrConcept?: string;
    gitaChapterVerse?: string;
    sanskritTerm?: string;
    englishTranslation?: string;
    positiveLesson?: string;
    intendedCapability?: string;
    actor?: string;
  }): Promise<{ success: boolean; message: string; record?: ModelNamingRecord }> {
    const res = await fetch('/api/verse/naming/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to generate naming candidate');
    }
    return res.json();
  },

  async approveAndLinkModel(params: {
    id: string;
    approvalStatus: 'APPROVED' | 'REJECTED';
    underlyingModelType: 'SPECIALIZED_CONFIG' | 'FINE_TUNED_MODEL' | 'BASE_MODEL';
    underlyingModelLink: string;
    reviewerRecord: string;
  }): Promise<{ success: boolean; message: string; record?: ModelNamingRecord }> {
    const res = await fetch('/api/verse/naming/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to approve candidate');
    }
    return res.json();
  },

  // --- Section 12: AI Agent Naming & Multiplication Engine ---
  async multiplyAgent(params: {
    parentAgentId: string;
    specializedName: string;
    responsibility: string;
    requestedPermissions: string[];
    requestedTools: string[];
    actor?: string;
  }): Promise<{ success: boolean; message: string; agent?: VerseAgent }> {
    const res = await fetch('/api/verse/agents/multiply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Agent multiplication failed');
    }
    return res.json();
  },

  async getAgentVersions(agentId: string): Promise<{ versions: AgentVersionRecord[] }> {
    const res = await fetch(`/api/verse/agents/${agentId}/versions`);
    return res.json();
  },

  async rollbackAgent(agentId: string, targetVersion: string): Promise<{ success: boolean; message: string; agent?: VerseAgent }> {
    const res = await fetch(`/api/verse/agents/${agentId}/rollback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetVersion }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Rollback failed');
    }
    return res.json();
  },

  // --- Membership Checkout & Payment ---
  async checkoutMembership(data: {
    userId?: string;
    tier: string;
    region: 'India' | 'Global';
    selectedAsset: 'YGO' | 'YAGYX' | 'YINR' | 'YUSD';
  }): Promise<{ order: MembershipOrder }> {
    const res = await fetch('/api/membership/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Checkout initialization failed');
    return res.json();
  },

  async confirmMembership(orderId: string, txHash?: string): Promise<{ order: MembershipOrder }> {
    const res = await fetch('/api/membership/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, txHash }),
    });
    if (!res.ok) throw new Error('Payment confirmation failed');
    return res.json();
  },

  // --- Compute Marketplace & 1% Commission ---
  async getComputeJobs(): Promise<{ jobs: ComputeJob[]; total: number }> {
    const res = await fetch('/api/compute/jobs');
    return res.json();
  },

  async createComputeJob(data: Partial<ComputeJob>): Promise<{ job: ComputeJob }> {
    const res = await fetch('/api/compute/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Job creation failed');
    return res.json();
  },

  async claimComputeJob(jobId: string, providerName?: string): Promise<{ job: ComputeJob }> {
    const res = await fetch(`/api/compute/jobs/${jobId}/claim`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ providerName }),
    });
    if (!res.ok) throw new Error('Claim failed');
    return res.json();
  },

  async submitComputeResult(jobId: string, resultPayload: string): Promise<{ job: ComputeJob }> {
    const res = await fetch(`/api/compute/jobs/${jobId}/submit-result`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resultPayload }),
    });
    if (!res.ok) throw new Error('Failed to submit result and settle');
    return res.json();
  },

  async getComputeProviders(): Promise<{ providers: ComputeProvider[]; total: number }> {
    const res = await fetch('/api/compute/providers');
    return res.json();
  },

  async registerComputeProvider(data: Partial<ComputeProvider>): Promise<{ provider: ComputeProvider }> {
    const res = await fetch('/api/compute/providers/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Provider registration failed');
    return res.json();
  },

  // --- FUTUREVERSE Social Hub ---
  async getOfficialChannel(userId: string): Promise<{ channel: OfficialChannel }> {
    const res = await fetch(`/api/social/channel/${userId}`);
    if (!res.ok) throw new Error('Channel not found');
    return res.json();
  },

  async createOrUpdateSocialChannel(data: Partial<OfficialChannel>): Promise<{ channel: OfficialChannel }> {
    const res = await fetch('/api/social/channel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to save channel');
    return res.json();
  },

  async getSocialPosts(): Promise<{ posts: SocialPost[]; total: number }> {
    const res = await fetch('/api/social/posts');
    return res.json();
  },

  async publishSocialPost(data: Partial<SocialPost>): Promise<{ post: SocialPost }> {
    const res = await fetch('/api/social/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to publish post');
    return res.json();
  },

  async getSocialAgents(): Promise<{ agents: SocialAgent[]; total: number }> {
    const res = await fetch('/api/social/agents');
    return res.json();
  },

  // --- BATWAL'S VERSE AI Ecosystem ---
  async getVerseModels(): Promise<{ models: VerseModel[]; total: number; targetVision: string }> {
    const res = await fetch('/api/verse/models');
    return res.json();
  },

  async getVerseAgents(): Promise<{ agents: VerseAgent[]; total: number; targetVision: string }> {
    const res = await fetch('/api/verse/agents');
    return res.json();
  },

  async orchestrateVerse(taskQuery: string): Promise<{
    routingResult: SarathiRoutingResult;
    orchestratedPlan?: any;
    specialistRoles?: any[];
    reviewStages?: any[];
    adversarialChallenge?: any;
    finalOutput?: any;
    metrics?: any;
    provenance?: any;
  }> {
    const res = await fetch('/api/verse/orchestrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ taskQuery }),
    });
    if (!res.ok) throw new Error('SARATHI orchestration failed');
    return res.json();
  },

  // --- Ownership & Permanent Authority for Dhaval Chandrashekhar Batwal ---
  async getAuthorityProfile(): Promise<{
    ownership: OwnershipRegistry;
    dhavalProfile: PermanentAuthorityProfile;
    auditLogsCount: number;
  }> {
    const res = await fetch('/api/admin/authority');
    return res.json();
  },

  async updateDhavalDesignation(newDesignation: string, actor?: string): Promise<{
    message: string;
    profile: PermanentAuthorityProfile;
  }> {
    const res = await fetch('/api/admin/dhaval/update-designation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newDesignation, actor }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update designation');
    }
    return res.json();
  },

  async getAuditLogs(): Promise<{ logs: AuditLogEvent[]; total: number }> {
    const res = await fetch('/api/admin/audit-logs');
    return res.json();
  },

  // --- STRICT OWNER-ONLY PROJECT RELEASE EXPORT APIs ---
  async getOwnerExportStatus(token?: string): Promise<{ isOwner: boolean; canDownload: boolean; ownerName?: string; designation?: string }> {
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch('/api/export/owner-status', { headers });
    return res.json();
  },

  async authenticateOwnerForExport(actor: string, passkey?: string): Promise<{
    success: boolean;
    sessionToken?: string;
    actor?: string;
    designation?: string;
    canDownload: boolean;
    error?: string;
  }> {
    const res = await fetch('/api/export/owner-authenticate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ actor, passkey }),
    });
    return res.json();
  },

  async authorizeProjectDownload(token?: string): Promise<{
    success: boolean;
    downloadNonce?: string;
    downloadUrl?: string;
    expiresInSeconds?: number;
    error?: string;
  }> {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch('/api/export/project/authorize', {
      method: 'POST',
      headers,
    });
    return res.json();
  },

  // --- Projects CRUD & Community APIs ---
  async getProjects(params?: { category?: string; type?: string; visibility?: string; search?: string }): Promise<{ projects: Project[]; total: number }> {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.type) searchParams.set('type', params.type);
    if (params?.visibility) searchParams.set('visibility', params.visibility);
    if (params?.search) searchParams.set('search', params.search);

    const res = await fetch(`/api/projects?${searchParams.toString()}`);
    return res.json();
  },

  async getProject(id: string): Promise<{ project: Project }> {
    const res = await fetch(`/api/projects/${id}`);
    if (!res.ok) throw new Error('Failed to fetch project');
    return res.json();
  },

  async createProject(data: Partial<Project>): Promise<{ project: Project }> {
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to create project');
    return res.json();
  },

  async updateProject(id: string, data: Partial<Project>): Promise<{ project: Project }> {
    const res = await fetch(`/api/projects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update project');
    return res.json();
  },

  async deleteProject(id: string): Promise<{ message: string; id: string }> {
    const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete project');
    return res.json();
  },

  async submitProjectFeedback(projectId: string, data: { author: string; content: string; type: string }) {
    const res = await fetch(`/api/projects/${projectId}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to submit feedback');
    return res.json();
  },

  async voteProjectFeedback(projectId: string, feedbackId: string, voterId?: string) {
    const res = await fetch(`/api/projects/${projectId}/feedback/${feedbackId}/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ voterId }),
    });
    if (!res.ok) throw new Error('Failed to vote on feedback');
    return res.json();
  },

  async deleteProjectFeedback(projectId: string, feedbackId: string) {
    const res = await fetch(`/api/projects/${projectId}/feedback/${feedbackId}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete feedback');
    return res.json();
  },

  async moderateProjectFeedback(projectId: string, feedbackId: string, status: 'APPROVED' | 'PENDING' | 'FLAGGED', moderator?: string) {
    const res = await fetch(`/api/projects/${projectId}/feedback/${feedbackId}/moderate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, moderator }),
    });
    if (!res.ok) throw new Error('Failed to moderate feedback');
    return res.json();
  },

  // --- AI Personas APIs (Audit Section 2) ---
  async getPersonas(params?: { query?: string; style?: string; status?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.query) searchParams.set('query', params.query);
    if (params?.style) searchParams.set('style', params.style);
    if (params?.status) searchParams.set('status', params.status);
    const res = await fetch(`/api/verse/personas?${searchParams.toString()}`);
    return res.json();
  },

  async getPersonaStats() {
    const res = await fetch('/api/verse/personas/stats');
    return res.json();
  },

  async createPersona(data: any) {
    const res = await fetch('/api/verse/personas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to create persona');
    }
    return res.json();
  },

  async updatePersona(id: string, data: any) {
    const res = await fetch(`/api/verse/personas/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update persona');
    }
    return res.json();
  },

  async deletePersona(id: string) {
    const res = await fetch(`/api/verse/personas/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete persona');
    return res.json();
  },

  async evalPersona(id: string, score: number) {
    const res = await fetch(`/api/verse/personas/${id}/eval`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ score }),
    });
    if (!res.ok) throw new Error('Failed to evaluate persona');
    return res.json();
  },

  // --- Agent Statistics & Real Execution Tracking (Audit Section 1 & 3) ---
  async getAgentStats() {
    const res = await fetch('/api/verse/agents/stats');
    return res.json();
  },

  async executeAgentTask(agentId: string, taskQuery: string, actor?: string) {
    const res = await fetch(`/api/verse/agents/${agentId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ taskQuery, actor }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Task execution failed');
    }
    return res.json();
  },

  async getAgentExecutions(agentId?: string) {
    const url = agentId ? `/api/verse/agents/${agentId}/executions` : '/api/verse/agents/executions';
    const res = await fetch(url);
    return res.json();
  },

  async aiCreateProject(
    prompt: string,
    answers?: Record<string, string>,
    options?: { algorithmTier?: string; personaId?: string }
  ) {
    const res = await fetch('/api/ai/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        answers,
        algorithmTier: options?.algorithmTier,
        personaId: options?.personaId,
      }),
    });
    if (!res.ok) throw new Error('Failed to generate project with AI');
    return res.json();
  },

  async getPolymathCouncil() {
    const res = await fetch('/api/verse/personas/council');
    if (!res.ok) throw new Error('Failed to fetch polymath council');
    return res.json();
  },

  async simulatePersona(personaId: string, prompt: string) {
    const res = await fetch(`/api/verse/personas/${personaId}/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to simulate persona response');
    }
    return res.json();
  },

  async aiImproveProject(project: Project, feedbackText: string, options?: { algorithmTier?: string; personaId?: string }) {
    const res = await fetch('/api/ai/improve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        project,
        feedbackText,
        algorithmTier: options?.algorithmTier,
        personaId: options?.personaId,
      }),
    });
    if (!res.ok) throw new Error('Failed to improve project with AI');
    return res.json();
  },

  async getEvolutionItems(): Promise<{ items: EvolutionItem[]; total: number }> {
    const res = await fetch('/api/evolution');
    return res.json();
  },

  async submitEvolutionItem(data: { title: string; category: string; description: string; proposer?: any }): Promise<{ item: EvolutionItem }> {
    const res = await fetch('/api/evolution', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to submit evolution item');
    return res.json();
  },

  async voteEvolutionItem(id: string): Promise<{ item: EvolutionItem }> {
    const res = await fetch(`/api/evolution/${id}/vote`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to vote');
    return res.json();
  },

  async updateEvolutionStatus(id: string, data: { status: string; reviewNotes?: string; reviewer?: string }): Promise<{ item: EvolutionItem }> {
    const res = await fetch(`/api/evolution/${id}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update status');
    return res.json();
  },

  async getContributorTasks(): Promise<{ tasks: ContributorTask[]; total: number }> {
    const res = await fetch('/api/tasks');
    return res.json();
  },

  async submitTaskWork(taskId: string, data: { contributorName: string; contributorAddress?: string; submissionUrl: string; notes: string }) {
    const res = await fetch(`/api/tasks/${taskId}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to submit task work');
    return res.json();
  },

  async reviewTaskSubmission(taskId: string, data: { submissionId: string; decision: 'ACCEPT' | 'REJECT'; reviewNote?: string }) {
    const res = await fetch(`/api/tasks/${taskId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to review submission');
    return res.json();
  },

  // --- Intelligence & Demand Signal Engine (Master Build Prompt) ---
  async getSpecialistRoles() {
    const res = await fetch('/api/verse/specialist-roles');
    return res.json();
  },

  async getSignalEvents(options?: { excludeTest?: boolean; limit?: number }) {
    const query = new URLSearchParams();
    if (options?.excludeTest) query.set('excludeTest', 'true');
    if (options?.limit) query.set('limit', String(options.limit));
    const res = await fetch(`/api/signals/events?${query.toString()}`);
    return res.json();
  },

  async recordSignalEvent(eventData: any) {
    const res = await fetch('/api/signals/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(eventData),
    });
    return res.json();
  },

  async getOpportunities() {
    const res = await fetch('/api/signals/opportunities');
    return res.json();
  },

  async addOpportunity(data: any) {
    const res = await fetch('/api/signals/opportunities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },

  async getGrowthExperiments() {
    const res = await fetch('/api/signals/experiments');
    return res.json();
  },
};
