export const YAGYX_CHAIN_ID = 13370;
export const YAGYX_CHAIN_HEX = '0x343a';

export interface WalletState {
  isInstalled: boolean;
  isConnected: boolean;
  address: string | null;
  chainId: number | null;
  isCorrectNetwork: boolean;
  balance: string | null;
  error: string | null;
}

export class Web3Service {
  private static getEthereum() {
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      return (window as any).ethereum;
    }
    return null;
  }

  static hasProvider(): boolean {
    return !!this.getEthereum();
  }

  static async getConnectedAccount(): Promise<string | null> {
    const ethereum = this.getEthereum();
    if (!ethereum) return null;
    try {
      const accounts = await ethereum.request({ method: 'eth_accounts' });
      return accounts && accounts.length > 0 ? accounts[0] : null;
    } catch {
      return null;
    }
  }

  static async getChainId(): Promise<number | null> {
    const ethereum = this.getEthereum();
    if (!ethereum) return null;
    try {
      const chainIdHex = await ethereum.request({ method: 'eth_chainId' });
      return parseInt(chainIdHex, 16);
    } catch {
      return null;
    }
  }

  static async connectWallet(): Promise<{ address: string; chainId: number }> {
    const ethereum = this.getEthereum();
    if (!ethereum) {
      throw new Error('No EIP-1193 Web3 wallet extension found. Please install MetaMask, Rabby, or a compatible Web3 browser wallet.');
    }

    try {
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      if (!accounts || accounts.length === 0) {
        throw new Error('No accounts selected by user.');
      }
      const chainIdHex = await ethereum.request({ method: 'eth_chainId' });
      const chainId = parseInt(chainIdHex, 16);

      return {
        address: accounts[0],
        chainId,
      };
    } catch (err: any) {
      if (err.code === 4001) {
        throw new Error('Connection request declined by user in wallet.');
      }
      throw new Error(err.message || 'Failed to connect wallet.');
    }
  }

  static async switchToYagyxChain(): Promise<boolean> {
    const ethereum = this.getEthereum();
    if (!ethereum) {
      throw new Error('No Web3 wallet extension found.');
    }

    try {
      await ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: YAGYX_CHAIN_HEX }],
      });
      return true;
    } catch (switchError: any) {
      // Error code 4902 indicates that the chain has not been added to MetaMask
      if (switchError.code === 4902) {
        try {
          await ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: YAGYX_CHAIN_HEX,
                chainName: 'YAGYX Chain',
                nativeCurrency: {
                  name: 'YAGYX',
                  symbol: 'YAGYX',
                  decimals: 18,
                },
                rpcUrls: ['https://rpc.yagyx.network'],
                blockExplorerUrls: ['https://explorer.yagyx.network'],
              },
            ],
          });
          return true;
        } catch (addError: any) {
          throw new Error(addError.message || 'Failed to register YAGYX Chain (13370) in wallet.');
        }
      }
      if (switchError.code === 4001) {
        throw new Error('Network switch cancelled by user.');
      }
      throw new Error(switchError.message || 'Failed to switch network to YAGYX Chain (13370).');
    }
  }

  static async getNativeBalance(address: string): Promise<string | null> {
    const ethereum = this.getEthereum();
    if (!ethereum || !address) return null;
    try {
      const balanceHex = await ethereum.request({
        method: 'eth_getBalance',
        params: [address, 'latest'],
      });
      const wei = BigInt(balanceHex);
      // Format to 4 decimals
      const etherVal = Number(wei) / 1e18;
      return etherVal.toFixed(4);
    } catch {
      return null;
    }
  }

  static async sendYagyxTransaction(params: {
    from: string;
    to: string;
    valueHex: string;
    dataHex?: string;
  }): Promise<string> {
    const ethereum = this.getEthereum();
    if (!ethereum) {
      throw new Error('No Web3 wallet extension found.');
    }

    try {
      const txHash = await ethereum.request({
        method: 'eth_sendTransaction',
        params: [
          {
            from: params.from,
            to: params.to,
            value: params.valueHex,
            data: params.dataHex || '0x',
          },
        ],
      });
      return txHash;
    } catch (err: any) {
      if (err.code === 4001) {
        throw new Error('Transaction authorization rejected by user in wallet.');
      }
      throw new Error(err.message || 'On-chain transaction execution failed.');
    }
  }

  static onAccountsChanged(callback: (accounts: string[]) => void): () => void {
    const ethereum = this.getEthereum();
    if (!ethereum || !ethereum.on) return () => {};
    ethereum.on('accountsChanged', callback);
    return () => {
      if (ethereum.removeListener) {
        ethereum.removeListener('accountsChanged', callback);
      }
    };
  }

  static onChainChanged(callback: (chainIdHex: string) => void): () => void {
    const ethereum = this.getEthereum();
    if (!ethereum || !ethereum.on) return () => {};
    ethereum.on('chainChanged', callback);
    return () => {
      if (ethereum.removeListener) {
        ethereum.removeListener('chainChanged', callback);
      }
    };
  }
}
