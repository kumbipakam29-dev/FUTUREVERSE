/**
 * FUTUREVERSE 30-Day Mystery Launch Campaign Manager
 * Canonical export alias for campaignService
 */
export { campaignService, campaignService as launchManager } from './campaignService.ts';
