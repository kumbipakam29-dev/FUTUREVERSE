import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import type { OwnershipRegistry, PermanentAuthorityProfile, AuditLogEvent } from '../types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const AUTHORITY_FILE = path.join(DATA_DIR, 'ownership_authority.json');

export const CANONICAL_OWNERSHIP_REGISTRY: OwnershipRegistry = {
  owner: 'Dhaval Chandrashekhar Batwal',
  coOwner: 'Hemangini Chandrashwkhar Batwal',
  coOperationalOwner: 'Jayshriben Chandrashekhar Batwal',
  ownerEmail: 'aibabayaga0@gmail.com',
};

const DEFAULT_PERMANENT_AUTHORITY: PermanentAuthorityProfile = {
  userId: 'usr-dhaval-canonical-001',
  canonicalName: 'Dhaval Chandrashekhar Batwal',
  email: 'aibabayaga0@gmail.com',
  currentDesignation: 'Owner',
  protectedAuthority: true,
  effectivePermissions: [
    'PERMANENT_SUPREME_AUTHORITY',
    'PLATFORM_GLOBAL_ADMINISTRATION',
    'COMMISSION_POLICY_OVERSIGHT',
    'SECURITY_CORE_OVERRIDE',
    'YAGYX_CHAIN_INTEGRATION_MANAGEMENT',
    'EMERGENCY_ANTI_LOCKOUT_RECOVERY',
    'DAY_30_CORE_REVEAL_GATEKEEPER',
    'MODEL_AND_AGENT_PRODUCTION_RELEASE_APPROVAL',
  ],
  antiLockoutActive: true,
  designationHistory: [
    {
      previousDesignation: 'Founder',
      newDesignation: 'Owner',
      changedAt: '2026-10-01T00:00:00Z',
      actor: 'Dhaval Chandrashekhar Batwal',
      antiLockoutPreserved: true,
    },
  ],
};

interface ActiveOwnerSession {
  token: string;
  actor: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
}

interface SingleUseDownloadNonce {
  nonce: string;
  actor: string;
  userId: string;
  expiresAt: number;
}

export class AuthorityService {
  private registry: OwnershipRegistry;
  private dhavalProfile: PermanentAuthorityProfile;
  private auditLogs: AuditLogEvent[] = [];
  private activeSessions: Map<string, ActiveOwnerSession> = new Map();
  private singleUseDownloadNonces: Map<string, SingleUseDownloadNonce> = new Map();

  constructor() {
    const loaded = this.loadState();
    this.registry = loaded.registry;
    this.dhavalProfile = loaded.dhavalProfile;
    this.auditLogs = loaded.auditLogs;
  }

  private loadState() {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      if (fs.existsSync(AUTHORITY_FILE)) {
        const raw = fs.readFileSync(AUTHORITY_FILE, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('Could not read authority file, using canonical defaults:', err);
    }
    const init = {
      registry: CANONICAL_OWNERSHIP_REGISTRY,
      dhavalProfile: DEFAULT_PERMANENT_AUTHORITY,
      auditLogs: [
        {
          id: `aud-auth-001`,
          timestamp: '2026-10-01T00:00:00Z',
          actor: 'Dhaval Chandrashekhar Batwal',
          action: 'PERMANENT_AUTHORITY_INITIALIZED',
          target: 'FUTUREVERSE Governance Registry',
          details: 'Supreme administrative permissions and anti-lockout protection locked to canonical identity.',
          outcome: 'SUCCESS' as const,
        },
      ],
    };
    this.saveDirect(init);
    return init;
  }

  private saveDirect(data: any): void {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(AUTHORITY_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to save authority state:', err);
    }
  }

  public save(): void {
    this.saveDirect({
      registry: this.registry,
      dhavalProfile: this.dhavalProfile,
      auditLogs: this.auditLogs,
    });
  }

  public getRegistry(): OwnershipRegistry {
    return this.registry;
  }

  public getOwnership(): OwnershipRegistry {
    return this.registry;
  }

  public getDhavalProfile(): PermanentAuthorityProfile {
    return this.dhavalProfile;
  }

  public getAuditLogs(limit?: number): AuditLogEvent[] {
    if (limit && limit > 0) return this.auditLogs.slice(0, limit);
    return this.auditLogs;
  }

  /**
   * Section 17.2: Dhaval's Designation & Protected Authority Separation
   * Allowed display designations: 'Owner', 'Super Admin', 'Director', 'Founder', 'Chairman', 'Chief Architect'
   * Changing displayed designation MUST NOT alter or revoke underlying protected effective permissions.
   */
  public updateDesignation(
    actorName: string,
    newDesignation: string
  ): { success: boolean; message: string; profile?: PermanentAuthorityProfile } {
    // 1. Strict verification: Only Dhaval's verified identity can change this designation
    const normalizedActor = actorName.trim().toLowerCase();
    const isDhaval =
      normalizedActor === 'dhaval chandrashekhar batwal' ||
      normalizedActor === 'aibabayaga0@gmail.com' ||
      normalizedActor === String(this.dhavalProfile.userId || '').trim().toLowerCase();

    if (!isDhaval) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorName,
        action: 'UNAUTHORIZED_DESIGNATION_CHANGE_ATTEMPT',
        target: 'Permanent Authority Profile',
        details: `Actor "${actorName}" attempted to modify Dhaval Chandrashekhar Batwal designation to "${newDesignation}". Access blocked.`,
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        message: 'Security Violation: Only Dhaval Chandrashekhar Batwal can update this designation.',
      };
    }

    const ALLOWED_LABELS = ['Owner', 'Super Admin', 'Director', 'Founder', 'Chairman', 'Chief Architect'];
    if (!ALLOWED_LABELS.includes(newDesignation)) {
      return {
        success: false,
        message: `Invalid designation label. Allowed: ${ALLOWED_LABELS.join(', ')}.`,
      };
    }

    const prev = this.dhavalProfile.currentDesignation;
    this.dhavalProfile.currentDesignation = newDesignation;

    // Enforce invariant: Effective permissions and anti-lockout CANNOT be diminished!
    this.dhavalProfile.protectedAuthority = true;
    this.dhavalProfile.antiLockoutActive = true;

    this.dhavalProfile.designationHistory.unshift({
      previousDesignation: prev,
      newDesignation,
      changedAt: new Date().toISOString(),
      actor: 'Dhaval Chandrashekhar Batwal',
      antiLockoutPreserved: true,
    });

    const successEvent: AuditLogEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: 'Dhaval Chandrashekhar Batwal',
      action: 'DESIGNATION_UPDATED',
      target: 'Dhaval Chandrashekhar Batwal Profile',
      details: `Display designation updated from "${prev}" to "${newDesignation}". Effective permissions and anti-lockout permanently preserved.`,
      outcome: 'SUCCESS',
    };
    this.auditLogs.unshift(successEvent);
    this.save();

    return {
      success: true,
      message: `Designation updated to "${newDesignation}". Protected authority and anti-lockout remain fully active.`,
      profile: this.dhavalProfile,
    };
  }

  /**
   * Checks whether the actor name or ID matches any canonical declared owner.
   * Includes explicit recognition of owner email id (aibabayaga0@gmail.com).
   */
  public isCanonicalOwner(actorNameOrId?: string): boolean {
    if (!actorNameOrId || typeof actorNameOrId !== 'string') return false;
    const clean = actorNameOrId.trim().toLowerCase();
    if (!clean) return false;

    // Exact owner email identity check only. Substrings are not identities.
    if (
      clean === 'aibabayaga0@gmail.com' ||
      clean === (this.dhavalProfile.email || '').trim().toLowerCase()
    ) {
      return true;
    }

    // Direct user ID check
    if (clean === this.dhavalProfile.userId.toLowerCase() || clean === 'usr-dhaval-canonical') {
      return true;
    }

    // Declared canonical owners check
    const ownerClean = (this.registry.owner || '').trim().toLowerCase();
    const coOwnerClean = (this.registry.coOwner || '').trim().toLowerCase();
    const coOpOwnerClean = (this.registry.coOperationalOwner || '').trim().toLowerCase();

    if (clean === ownerClean) return true;
    if (clean === coOwnerClean) return true;
    if (clean === coOpOwnerClean) return true;

    return false;
  }

  /**
   * Authenticates an owner with strict server-side configured secret passkey and issues an active session token.
   * Hardcoded fallback secrets are completely removed. Server-side FUTUREVERSE_OWNER_KEY is strictly required.
   */
  public authenticateOwner(
    actorNameOrId: string,
    providedKey?: string
  ): { success: boolean; sessionToken?: string; actor?: string; error?: string } {
    if (!this.isCanonicalOwner(actorNameOrId)) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorNameOrId || 'Anonymous / Guest',
        action: 'UNAUTHORIZED_OWNER_AUTH_ATTEMPT',
        target: 'Project ZIP Download Guard',
        details: `Access denied. Actor "${actorNameOrId}" is not a verified canonical project owner.`,
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        error: 'Unauthorized: Actor identity is not a registered canonical project owner.',
      };
    }

    // Strict Server-Side Configuration Requirement (Zero Hardcoded Secrets)
    const canonicalKey = process.env.FUTUREVERSE_OWNER_KEY;
    if (!canonicalKey || !canonicalKey.trim()) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorNameOrId,
        action: 'SERVER_SECURITY_CONFIG_MISSING',
        target: 'Project ZIP Download Guard',
        details: 'Server security configuration error: FUTUREVERSE_OWNER_KEY is not set in environment.',
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        error: 'Server security configuration error: FUTUREVERSE_OWNER_KEY is not configured on the server.',
      };
    }

    const cleanProvidedKey = (providedKey || '').trim();
    if (!cleanProvidedKey) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorNameOrId,
        action: 'OWNER_PASSKEY_REJECTED',
        target: 'Project ZIP Download Guard',
        details: 'Canonical owner identity provided without required secret passkey.',
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        error: 'Unauthorized: Valid canonical owner secret passkey is strictly required.',
      };
    }

    // Constant-time passkey verification to prevent timing side-channel attacks
    const providedBuf = Buffer.from(cleanProvidedKey, 'utf8');
    const canonicalBuf = Buffer.from(canonicalKey.trim(), 'utf8');
    const isMatch = providedBuf.length === canonicalBuf.length && crypto.timingSafeEqual(providedBuf, canonicalBuf);

    if (!isMatch) {
      const errEvent: AuditLogEvent = {
        id: `aud-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: actorNameOrId,
        action: 'OWNER_PASSKEY_REJECTED',
        target: 'Project ZIP Download Guard',
        details: 'Canonical owner identity provided but secret passkey failed verification.',
        outcome: 'BLOCKED',
      };
      this.auditLogs.unshift(errEvent);
      this.save();
      return {
        success: false,
        error: 'Unauthorized: Valid canonical owner secret passkey is strictly required.',
      };
    }

    const clean = (actorNameOrId || '').trim().toLowerCase();
    const isEmail = clean === 'aibabayaga0@gmail.com' || clean === (this.dhavalProfile.email || '').toLowerCase();
    const actorDisplay = isEmail
      ? `Dhaval Chandrashekhar Batwal (${actorNameOrId.trim()})`
      : actorNameOrId.trim();

    // Generate high-entropy 256-bit session token
    const token = `fv-owner-${crypto.randomBytes(32).toString('hex')}`;
    const session: ActiveOwnerSession = {
      token,
      actor: actorDisplay,
      userId: this.dhavalProfile.userId,
      createdAt: Date.now(),
      expiresAt: Date.now() + 2 * 60 * 60 * 1000, // 2-hour validity
    };
    this.activeSessions.set(token, session);

    const logEvent: AuditLogEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: actorNameOrId,
      action: 'OWNER_SESSION_ESTABLISHED',
      target: 'Project ZIP Download Guard',
      details: 'Owner session authenticated with verified secret passkey. Authorized for standalone archive download.',
      outcome: 'SUCCESS',
    };
    this.auditLogs.unshift(logEvent);
    this.save();

    return {
      success: true,
      sessionToken: token,
      actor: actorDisplay,
    };
  }

  /**
   * Validates an active owner session token.
   */
  public verifyOwnerSession(token?: string): { valid: boolean; actor?: string; userId?: string } {
    if (!token || !token.trim()) return { valid: false };
    const session = this.activeSessions.get(token.trim());
    if (!session) return { valid: false };
    if (Date.now() > session.expiresAt) {
      this.activeSessions.delete(token.trim());
      return { valid: false };
    }
    return { valid: true, actor: session.actor, userId: session.userId };
  }

  /**
   * Issues a short-lived (15-minute) single-use download nonce for direct browser file streaming.
   * STRICTLY requires a verified active owner session token. Client-supplied names or IDs are rejected.
   */
  public createSingleUseDownloadToken(sessionToken: string): { success: boolean; downloadNonce?: string; error?: string } {
    const sessionCheck = this.verifyOwnerSession(sessionToken);

    if (!sessionCheck.valid) {
      return { success: false, error: 'Unauthorized: Active authenticated owner session required.' };
    }

    const actor = sessionCheck.actor!;
    const nonce = `dl-${crypto.randomBytes(24).toString('hex')}`;
    this.singleUseDownloadNonces.set(nonce, {
      nonce,
      actor,
      userId: sessionCheck.userId || this.dhavalProfile.userId,
      expiresAt: Date.now() + 15 * 60 * 1000, // 15-minute window for download completion
    });

    return { success: true, downloadNonce: nonce };
  }

  /**
   * Validates download nonce without consuming (used for HEAD and OPTIONS pre-flight checks).
   */
  public peekDownloadNonce(nonce?: string): { valid: boolean; actor?: string } {
    if (!nonce || !nonce.trim()) return { valid: false };
    const clean = nonce.trim();
    const entry = this.singleUseDownloadNonces.get(clean);
    if (!entry) return { valid: false };
    if (Date.now() > entry.expiresAt) return { valid: false };
    return { valid: true, actor: entry.actor };
  }

  /**
   * Validates and immediately consumes a single-use download nonce.
   */
  public consumeDownloadNonce(nonce?: string): { valid: boolean; actor?: string } {
    if (!nonce || !nonce.trim()) return { valid: false };
    const clean = nonce.trim();
    const entry = this.singleUseDownloadNonces.get(clean);
    if (!entry) return { valid: false };
    this.singleUseDownloadNonces.delete(clean); // strictly single-use
    if (Date.now() > entry.expiresAt) return { valid: false };

    // Record audit event for successful download
    const event: AuditLogEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor: entry.actor,
      action: 'PROJECT_ZIP_EXPORT_DOWNLOADED',
      target: 'FUTUREVERSE_FINAL_RELEASE.zip',
      details: `Project release ZIP downloaded by verified owner (${entry.actor}) via single-use authorization nonce.`,
      outcome: 'SUCCESS',
    };
    this.auditLogs.unshift(event);
    this.save();

    return { valid: true, actor: entry.actor };
  }

  /**
   * Record security audit log directly.
   */
  public recordAuditLog(actor: string, action: string, target: string, details: string, outcome: 'SUCCESS' | 'BLOCKED' | 'FLAGGED'): void {
    const event: AuditLogEvent = {
      id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      target,
      details,
      outcome,
    };
    this.auditLogs.unshift(event);
    this.save();
  }
}

export const authorityService = new AuthorityService();
