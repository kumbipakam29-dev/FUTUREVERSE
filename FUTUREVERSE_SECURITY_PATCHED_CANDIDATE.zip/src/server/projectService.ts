import fs from 'fs';
import path from 'path';
import type { Project, ProjectFeedback } from '../types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const PROJECTS_FILE = path.join(DATA_DIR, 'projects.json');

export class ProjectService {
  private projects: Project[] = [];

  constructor(initialProjects: Project[]) {
    this.projects = this.loadProjects(initialProjects);
  }

  private loadProjects(defaults: Project[]): Project[] {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      if (fs.existsSync(PROJECTS_FILE)) {
        const raw = fs.readFileSync(PROJECTS_FILE, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('Could not read projects file, using defaults:', err);
    }
    this.saveDirect(defaults);
    return [...defaults];
  }

  private saveDirect(list: Project[]): void {
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(PROJECTS_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to save projects to file:', err);
    }
  }

  public save(): void {
    this.saveDirect(this.projects);
  }

  public getAll(params?: { category?: string; type?: string; visibility?: string; search?: string }): Project[] {
    let filtered = [...this.projects];
    if (params?.category && params.category !== 'All') {
      filtered = filtered.filter((p) => p.category === params.category);
    }
    if (params?.type && params.type !== 'All') {
      filtered = filtered.filter((p) => p.type === params.type);
    }
    if (params?.visibility) {
      filtered = filtered.filter((p) => p.visibility === params.visibility);
    }
    if (params?.search && params.search.trim()) {
      const q = params.search.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tagline.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return filtered;
  }

  public getById(id: string): Project | undefined {
    if (id === 'proj-career-planner' || id === 'proj-career-navigator') {
      const match = this.projects.find((p) => p.id === 'proj-career-planner' || p.id === 'proj-career-navigator');
      if (match) {
        return {
          ...match,
          title: 'AI-Assisted Career & Learning Path Navigator',
        };
      }
    }
    return this.projects.find((p) => p.id === id);
  }

  public create(data: Partial<Project>): Project {
    const newProj: Project = {
      id: `proj-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: data.title || 'Untitled Creation',
      tagline: data.tagline || data.title || '',
      description: data.description || '',
      category: data.category || 'AI Agents',
      type: data.type || 'Interactive Prototype',
      visibility: data.visibility || 'draft',
      version: data.version || '1.0.0',
      author: data.author || {
        id: 'usr-current',
        name: 'Community Builder',
        handle: 'builder_anon',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        verified: false,
        foundingMember: false,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      stars: 0,
      forks: 0,
      tags: data.tags || ['futureverse'],
      specification: data.specification || {
        targetAudience: 'General Community',
        problemStatement: data.description || '',
        keyFeatures: [],
        userFlow: [],
        architecture: {
          frontend: 'React 19',
          backend: 'Express.js',
          dataModel: 'Standard',
          securityNotes: 'Default security controls',
        },
      },
      prototype: data.prototype || {
        type: 'custom_widget',
        headline: data.title || 'Interactive Prototype',
        interactiveElements: [],
        outputSections: [],
      },
      feedback: [],
      aiGenerated: !!data.aiGenerated,
      modelUsed: data.modelUsed,
    };

    this.projects.unshift(newProj);
    this.save();
    return newProj;
  }

  public update(id: string, data: Partial<Project>): Project | null {
    const idx = this.projects.findIndex((p) => p.id === id);
    if (idx === -1) return null;

    this.projects[idx] = {
      ...this.projects[idx],
      ...data,
      id: this.projects[idx].id,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.projects[idx];
  }

  public delete(id: string): boolean {
    const idx = this.projects.findIndex((p) => p.id === id);
    if (idx === -1) return false;
    this.projects.splice(idx, 1);
    this.save();
    return true;
  }

  /**
   * Section 5 Audit Requirement: Full Feedback System with Durable Persistence
   */
  public addFeedback(
    projectId: string,
    data: {
      author?: string;
      authorName?: string;
      authorAddress?: string;
      isFoundingMember?: boolean;
      rating?: number;
      content: string;
      type?: 'feedback' | 'suggestion' | 'bug';
      category?: string;
    }
  ): ProjectFeedback | null {
    const proj = this.getById(projectId);
    if (!proj) return null;

    const newFeedback: ProjectFeedback = {
      id: `fb-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      author: data.authorName || data.author || 'Community Contributor',
      authorName: data.authorName || data.author,
      authorAddress: data.authorAddress,
      isFoundingMember: data.isFoundingMember,
      rating: data.rating,
      category: data.category || (data.type ? data.type.toUpperCase() : 'GENERAL'),
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      type: data.type || (data.category?.toLowerCase() as any) || 'feedback',
      content: data.content.trim(),
      createdAt: new Date().toISOString(),
      upvotes: 0,
      upvotedBy: [],
      status: 'APPROVED',
    };

    proj.feedback.unshift(newFeedback);
    this.save();
    return newFeedback;
  }

  public voteFeedback(
    projectId: string,
    feedbackId: string,
    voterId: string = 'voter-anon'
  ): { success: boolean; hasVoted?: boolean; upvotes?: number; feedback?: ProjectFeedback; message: string } {
    const proj = this.getById(projectId);
    if (!proj) return { success: false, message: 'Project not found' };

    const fb = proj.feedback.find((f) => f.id === feedbackId);
    if (!fb) return { success: false, message: 'Feedback not found' };

    if (!fb.upvotedBy) fb.upvotedBy = [];

    // Duplicate vote prevention check
    const existingIndex = fb.upvotedBy.indexOf(voterId);
    if (existingIndex >= 0) {
      // Toggle off / remove vote
      fb.upvotedBy.splice(existingIndex, 1);
      fb.upvotes = Math.max(0, fb.upvotes - 1);
      this.save();
      return { success: true, hasVoted: false, upvotes: fb.upvotes, feedback: fb, message: 'Vote removed successfully.' };
    } else {
      // Add vote
      fb.upvotedBy.push(voterId);
      fb.upvotes += 1;
      this.save();
      return { success: true, hasVoted: true, upvotes: fb.upvotes, feedback: fb, message: 'Vote recorded successfully.' };
    }
  }

  public deleteFeedback(projectId: string, feedbackId: string): boolean {
    const proj = this.getById(projectId);
    if (!proj) return false;

    const idx = proj.feedback.findIndex((f) => f.id === feedbackId);
    if (idx === -1) return false;

    proj.feedback.splice(idx, 1);
    this.save();
    return true;
  }

  public moderateFeedback(
    projectId: string,
    feedbackId: string,
    status: 'APPROVED' | 'PENDING' | 'FLAGGED',
    moderator: string = 'Admin'
  ): ProjectFeedback | null {
    const proj = this.getById(projectId);
    if (!proj) return null;

    const fb = proj.feedback.find((f) => f.id === feedbackId);
    if (!fb) return null;

    fb.status = status;
    fb.moderatedBy = moderator;
    this.save();
    return fb;
  }
}

export const projectService = new ProjectService([]);
