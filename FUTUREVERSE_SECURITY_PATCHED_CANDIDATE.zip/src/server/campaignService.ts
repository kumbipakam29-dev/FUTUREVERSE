import fs from 'fs';
import path from 'path';
import type { AuthoritativeCampaignState, CampaignLifecycleStatus, LaunchCampaignStage } from '../types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const CAMPAIGN_FILE = path.join(DATA_DIR, 'campaign_schedule.json');

export interface StoredCampaignConfig {
  status: CampaignLifecycleStatus;
  scheduledStartTimestamp: string | null;
  scheduledRevealTimestamp: string | null;
  authoritativeTimezone: string;
  campaignVersion: number;
  totalDays: number;
  isRevealed: boolean;
  revealedAt?: string | null;
  registeredCount: number;
  registrations: Array<{
    id: string;
    email: string;
    handle: string;
    registeredAt: string;
    verified: boolean;
  }>;
  stages: LaunchCampaignStage[];
  day30CoreReveal: {
    headline: string;
    visionDocument: string;
    ecosystemBlueprint: string;
    unlockedCapabilities: string[];
  };
  auditHistory: Array<{
    timestamp: string;
    actor: string;
    action: string;
    details: string;
  }>;
}

const DEFAULT_STAGES: LaunchCampaignStage[] = [
  {
    dayRange: 'Days 1–5',
    title: 'Brand Genesis & Community Philosophy',
    teaser: 'The genesis of FUTUREVERSE: Built with the community, not just for the community.',
    status: 'COMPLETED',
  },
  {
    dayRange: 'Days 6–12',
    title: 'Opportunity to Participate & Ecosystem Alignment',
    teaser: 'Genesis node registration, early builder bounties, and YAGYX Chain integration.',
    status: 'ACTIVE',
  },
  {
    dayRange: 'Days 13–21',
    title: 'Selected Capabilities & Architecture Preview',
    teaser: 'Previewing BATWAL’S VERSE AI, the 1% Compute Marketplace, and Social Hub Autopilot.',
    status: 'UPCOMING',
  },
  {
    dayRange: 'Days 22–29',
    title: 'Anticipation & Terms Finalization',
    teaser: 'Finalizing founding member terms, verifiable token models, and reward distribution.',
    status: 'UPCOMING',
  },
  {
    dayRange: 'Day 30',
    title: 'The Core Reveal',
    teaser: 'Protected access reveal: The full architectural realization of BATWAL’S VERSE AI & FUTUREVERSE.',
    status: 'UPCOMING',
  },
];

// Authoritative Default Schedule (Fixed 30-day window, durable across restarts)
// Fixed scheduled start: 2026-10-01T00:00:00.000Z
// Fixed scheduled reveal: 2026-10-31T00:00:00.000Z
const DEFAULT_CONFIG: StoredCampaignConfig = {
  status: 'ACTIVE',
  scheduledStartTimestamp: '2026-10-01T00:00:00.000Z',
  scheduledRevealTimestamp: '2026-10-31T00:00:00.000Z',
  authoritativeTimezone: 'Asia/Kolkata (IST) / UTC',
  campaignVersion: 1,
  totalDays: 30,
  isRevealed: false,
  revealedAt: null,
  registeredCount: 428,
  registrations: [
    {
      id: 'reg-1',
      email: 'builder.alex@futureverse.org',
      handle: 'alex_sol',
      registeredAt: '2026-10-02T12:00:00Z',
      verified: true,
    },
    {
      id: 'reg-2',
      email: 'sara.chen@openintelligence.io',
      handle: 'sarachen',
      registeredAt: '2026-10-04T15:30:00Z',
      verified: true,
    },
    {
      id: 'reg-3',
      email: 'rahul.deshmukh@yagyx.net',
      handle: 'rahul_d',
      registeredAt: '2026-10-08T09:15:00Z',
      verified: true,
    },
  ],
  stages: DEFAULT_STAGES,
  day30CoreReveal: {
    headline: 'BATWAL’S VERSE AI & THE GLOBAL REPUTATION MESH',
    visionDocument:
      'The complete unification of 15,000+ AI models, 1,000,000 agents orchestrated by SARATHI, paired with decentralized compute validation and verifiable YAGYX settlement.',
    ecosystemBlueprint:
      'Full open orchestration specification across VIVEKA, BUDDHI, DRISHTI, VAANI, JNANA, SMRITI, KARMA, DHARMA, and YOGA.',
    unlockedCapabilities: [
      'Global SARATHI Task Mesh Deployment',
      'Autonomous Distributed Compute Settlement at 1% Commission',
      'Multi-Platform Social Autopilot with Guardian AI',
      'Unrestricted Project Workspace & Genesis Token Staking',
    ],
  },
  auditHistory: [
    {
      timestamp: '2026-10-01T00:00:00.000Z',
      actor: 'Dhaval Chandrashekhar Batwal',
      action: 'CAMPAIGN_SCHEDULE_INITIALIZED',
      details: 'Established authoritative 30-day window: 2026-10-01 to 2026-10-31.',
    },
  ],
};

export class CampaignService {
  private config: StoredCampaignConfig;

  constructor() {
    this.config = this.loadConfig();
  }

  private loadConfig(): StoredCampaignConfig {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(CAMPAIGN_FILE)) {
        const data = fs.readFileSync(CAMPAIGN_FILE, 'utf8');
        return JSON.parse(data);
      }
    } catch (err) {
      console.warn('Could not read campaign file, using default config:', err);
    }
    // Write defaults
    this.saveConfigDirect(DEFAULT_CONFIG);
    return { ...DEFAULT_CONFIG };
  }

  private saveConfigDirect(cfg: StoredCampaignConfig): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(CAMPAIGN_FILE, JSON.stringify(cfg, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to persist campaign config:', err);
    }
  }

  public saveConfig(): void {
    this.saveConfigDirect(this.config);
  }

  /**
   * Derive the authoritative real-time status and accurate remaining countdown.
   * Prevents client clock manipulation and fixes the countdown defect.
   */
  public getAuthoritativeState(currentTimeMs: number = Date.now()): AuthoritativeCampaignState {
    const { status, scheduledStartTimestamp, scheduledRevealTimestamp, authoritativeTimezone, campaignVersion } =
      this.config;

    const serverNow = currentTimeMs;
    const serverCurrentTime = new Date(serverNow).toISOString();

    let remainingMs = 0;
    let stateDescription = '';
    let currentDay = 1;
    let effectiveStatus: CampaignLifecycleStatus = status;

    if (status === 'NOT_SCHEDULED' || !scheduledStartTimestamp || !scheduledRevealTimestamp) {
      effectiveStatus = 'NOT_SCHEDULED';
      stateDescription = 'Launch Campaign schedule not yet configured by governance.';
      return {
        status: 'NOT_SCHEDULED',
        scheduledStartTimestamp: null,
        scheduledRevealTimestamp: null,
        authoritativeTimezone,
        campaignVersion,
        serverCurrentTime,
        remainingMs: 0,
        daysRemaining: 0,
        hoursRemaining: 0,
        minutesRemaining: 0,
        secondsRemaining: 0,
        stateDescription,
        totalDays: 30,
        currentDay: 0,
        registeredCount: this.config.registeredCount,
        isRevealed: false,
        stages: this.config.stages,
      };
    }

    if (status === 'PAUSED') {
      stateDescription = 'Campaign countdown paused by administrative governance.';
      return {
        status: 'PAUSED',
        scheduledStartTimestamp,
        scheduledRevealTimestamp,
        authoritativeTimezone,
        campaignVersion,
        serverCurrentTime,
        remainingMs: 0,
        daysRemaining: 0,
        hoursRemaining: 0,
        minutesRemaining: 0,
        secondsRemaining: 0,
        stateDescription,
        totalDays: 30,
        currentDay: 0,
        registeredCount: this.config.registeredCount,
        isRevealed: this.config.isRevealed,
        stages: this.config.stages,
      };
    }

    const startMs = new Date(scheduledStartTimestamp).getTime();
    const revealMs = new Date(scheduledRevealTimestamp).getTime();

    if (serverNow < startMs) {
      // Scheduled in the future (countdown to start)
      effectiveStatus = 'SCHEDULED';
      remainingMs = Math.max(0, startMs - serverNow);
      stateDescription = `Campaign scheduled. Launches in countdown window.`;
      currentDay = 0;
    } else if (serverNow >= revealMs || this.config.isRevealed) {
      // Reached reveal boundary or manually revealed
      effectiveStatus = 'REVEALED';
      remainingMs = 0;
      currentDay = 30;
      stateDescription = '30-Day Campaign Concluded. Day 30 Core Reveal Unlocked.';
    } else {
      // Actively within the 30-day window (countdown to reveal)
      effectiveStatus = 'ACTIVE';
      remainingMs = Math.max(0, revealMs - serverNow);

      const elapsedMs = serverNow - startMs;
      const elapsedDays = Math.floor(elapsedMs / (1000 * 60 * 60 * 24));
      currentDay = Math.min(30, Math.max(1, elapsedDays + 1));
      stateDescription = `Campaign Active: Day ${currentDay} of 30. Remaining time to Day 30 Core Reveal.`;
    }

    const daysRemaining = Math.floor(remainingMs / (1000 * 60 * 60 * 24));
    const hoursRemaining = Math.floor((remainingMs / (1000 * 60 * 60)) % 24);
    const minutesRemaining = Math.floor((remainingMs / (1000 * 60)) % 60);
    const secondsRemaining = Math.floor((remainingMs / 1000) % 60);

    // Update stage statuses dynamically based on currentDay
    const updatedStages = this.config.stages.map((stage) => {
      if (effectiveStatus === 'REVEALED') {
        return { ...stage, status: 'COMPLETED' as const };
      }
      if (stage.dayRange === 'Days 1–5') {
        return { ...stage, status: currentDay > 5 ? ('COMPLETED' as const) : ('ACTIVE' as const) };
      }
      if (stage.dayRange === 'Days 6–12') {
        return {
          ...stage,
          status: currentDay > 12 ? ('COMPLETED' as const) : currentDay >= 6 ? ('ACTIVE' as const) : ('UPCOMING' as const),
        };
      }
      if (stage.dayRange === 'Days 13–21') {
        return {
          ...stage,
          status: currentDay > 21 ? ('COMPLETED' as const) : currentDay >= 13 ? ('ACTIVE' as const) : ('UPCOMING' as const),
        };
      }
      if (stage.dayRange === 'Days 22–29') {
        return {
          ...stage,
          status: currentDay > 29 ? ('COMPLETED' as const) : currentDay >= 22 ? ('ACTIVE' as const) : ('UPCOMING' as const),
        };
      }
      if (stage.dayRange === 'Day 30') {
        return { ...stage, status: currentDay >= 30 ? ('ACTIVE' as const) : ('UPCOMING' as const) };
      }
      return stage;
    });

    return {
      status: effectiveStatus,
      scheduledStartTimestamp,
      scheduledRevealTimestamp,
      authoritativeTimezone,
      campaignVersion,
      serverCurrentTime,
      remainingMs,
      daysRemaining,
      hoursRemaining,
      minutesRemaining,
      secondsRemaining,
      stateDescription,
      totalDays: 30,
      currentDay,
      registeredCount: this.config.registeredCount,
      isRevealed: this.config.isRevealed || effectiveStatus === 'REVEALED',
      stages: updatedStages,
      day30CoreReveal: this.config.isRevealed || effectiveStatus === 'REVEALED' ? this.config.day30CoreReveal : undefined,
    };
  }

  /**
   * Admin reschedule/pause/activate with validation (Section 5.3)
   */
  public updateSchedule(
    params: {
      status?: CampaignLifecycleStatus;
      scheduledStartTimestamp?: string;
      scheduledRevealTimestamp?: string;
      authoritativeTimezone?: string;
    },
    actor: string
  ): { success: boolean; message: string } {
    if (params.scheduledStartTimestamp && params.scheduledRevealTimestamp) {
      const s = new Date(params.scheduledStartTimestamp).getTime();
      const r = new Date(params.scheduledRevealTimestamp).getTime();
      if (isNaN(s) || isNaN(r)) {
        return { success: false, message: 'Invalid timestamp format. Expected ISO-8601 strings.' };
      }
      if (s >= r) {
        return { success: false, message: 'Scheduled start timestamp must be strictly before reveal timestamp.' };
      }
      this.config.scheduledStartTimestamp = params.scheduledStartTimestamp;
      this.config.scheduledRevealTimestamp = params.scheduledRevealTimestamp;
    }

    if (params.status) {
      this.config.status = params.status;
    }
    if (params.authoritativeTimezone) {
      this.config.authoritativeTimezone = params.authoritativeTimezone;
    }

    this.config.campaignVersion += 1;
    this.config.auditHistory.unshift({
      timestamp: new Date().toISOString(),
      actor,
      action: 'SCHEDULE_UPDATED',
      details: `Status: ${this.config.status}, Start: ${this.config.scheduledStartTimestamp}, Reveal: ${this.config.scheduledRevealTimestamp}`,
    });

    this.saveConfig();
    return { success: true, message: 'Authoritative campaign schedule updated successfully.' };
  }

  public registerUser(email: string, handle: string): { success: boolean; message: string; registration?: any; registeredCount?: number } {
    const cleanEmail = email.trim().toLowerCase();
    const existing = this.config.registrations.find((r) => r.email === cleanEmail);
    if (existing) {
      return { success: true, message: 'Already registered for 30-day early access!', registration: existing, registeredCount: this.config.registeredCount };
    }

    const reg = {
      id: `reg-${Date.now()}`,
      email: cleanEmail,
      handle: handle?.trim() || cleanEmail.split('@')[0],
      registeredAt: new Date().toISOString(),
      verified: true,
    };

    this.config.registrations.push(reg);
    this.config.registeredCount += 1;
    this.saveConfig();

    return { success: true, message: 'Successfully registered for early access!', registration: reg, registeredCount: this.config.registeredCount };
  }

  public unlockCoreReveal(actorName: string): { success: boolean; message: string } {
    this.config.isRevealed = true;
    this.config.revealedAt = new Date().toISOString();
    this.config.auditHistory.unshift({
      timestamp: new Date().toISOString(),
      actor: actorName,
      action: 'CORE_REVEAL_UNLOCKED',
      details: 'Day 30 core reveal unlocked by permanent authority holder.',
    });
    this.saveConfig();
    return { success: true, message: 'Core Reveal unlocked successfully!' };
  }

  public getRegistrations() {
    return this.config.registrations;
  }
}

export const campaignService = new CampaignService();
