import dns from 'node:dns/promises';
import net from 'node:net';

/**
 * SSRF Protection Validator for YAGYX Chain RPC & Network Probing
 *
 * Implements Phase 3, Item 6:
 * Blocks unauthorized private, loopback, link-local, and cloud metadata targets:
 * - IPv4: 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, 0.0.0.0/8
 * - IPv6: ::1, fc00::/7 (unique local), fe80::/10 (link-local), ::ffff:0:0/96
 * - Hostnames: localhost, *.internal, *.local, metadata.google.internal, instance-data
 * - Protocols: strictly http: and https: only
 */

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4 || parts.some((p) => isNaN(p) || p < 0 || p > 255)) {
      return true; // invalid IP treated as unsafe
    }
    // 0.0.0.0/8 (Current network)
    if (parts[0] === 0) return true;
    // 10.0.0.0/8 (Private)
    if (parts[0] === 10) return true;
    // 127.0.0.0/8 (Loopback)
    if (parts[0] === 127) return true;
    // 169.254.0.0/16 (Link-local / Cloud Metadata)
    if (parts[0] === 169 && parts[1] === 254) return true;
    // 172.16.0.0/12 (Private)
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
    // 192.168.0.0/16 (Private)
    if (parts[0] === 192 && parts[1] === 168) return true;
    // 224.0.0.0/4 (Multicast)
    if (parts[0] >= 224) return true;
    return false;
  }

  if (net.isIPv6(ip)) {
    const lower = ip.toLowerCase();
    // IPv6 loopback
    if (lower === '::1' || lower === '0:0:0:0:0:0:0:1') return true;
    // Unspecified
    if (lower === '::' || lower === '0:0:0:0:0:0:0:0') return true;
    // Unique local (fc00::/7, fd00::/8)
    if (lower.startsWith('fc') || lower.startsWith('fd')) return true;
    // Link-local (fe80::/10)
    if (lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) {
      return true;
    }
    // IPv4-mapped IPv6 (::ffff:127.0.0.1, etc.)
    if (lower.includes('::ffff:')) {
      const v4Part = lower.split('::ffff:')[1];
      if (v4Part && net.isIPv4(v4Part)) {
        return isPrivateIp(v4Part);
      }
      return true;
    }
    return false;
  }

  return true; // Unknown format treated as unsafe
}

export async function validateSafeRpcUrl(
  urlStr: string,
  options?: { allowLocalhostInDev?: boolean }
): Promise<{ safe: boolean; reason?: string; normalizedUrl?: string }> {
  if (!urlStr || typeof urlStr !== 'string') {
    return { safe: false, reason: 'URL string is required.' };
  }

  const trimmed = urlStr.trim();
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch (err: any) {
    return { safe: false, reason: `Malformed URL format: ${err.message}` };
  }

  // 1. Protocol restriction: only http: and https:
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return {
      safe: false,
      reason: `Prohibited protocol "${parsed.protocol}". Only HTTP and HTTPS are permitted for RPC gateways.`,
    };
  }

  const hostname = parsed.hostname.toLowerCase();
  const isProd = process.env.NODE_ENV === 'production';
  const allowLocal = Boolean(!isProd && options?.allowLocalhostInDev);

  // 2. Prohibit cloud metadata endpoints unconditionally across all environments
  const metadataHostnames = [
    '169.254.169.254',
    'metadata.google.internal',
    'metadata',
    'instance-data',
  ];
  if (
    metadataHostnames.includes(hostname) ||
    hostname.endsWith('.internal') ||
    hostname.endsWith('.local')
  ) {
    return {
      safe: false,
      reason: 'SSRF Violation: Target hostname is a forbidden cloud metadata or internal network service.',
    };
  }

  // 3. Check loopback / localhost
  if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') {
    if (allowLocal) {
      return { safe: true, normalizedUrl: parsed.href };
    }
    return {
      safe: false,
      reason: 'SSRF Violation: Loopback and localhost endpoints are restricted in production environments.',
    };
  }

  // 4. IP literal check
  if (net.isIP(hostname)) {
    if (isPrivateIp(hostname)) {
      if (allowLocal && (hostname === '127.0.0.1' || hostname === '::1')) {
        return { safe: true, normalizedUrl: parsed.href };
      }
      return {
        safe: false,
        reason: `SSRF Violation: Target IP "${hostname}" is within a restricted private or link-local address range.`,
      };
    }
    return { safe: true, normalizedUrl: parsed.href };
  }

  // 5. DNS Resolution check
  try {
    const resolved = await dns.lookup(hostname, { all: true });
    for (const record of resolved) {
      if (isPrivateIp(record.address)) {
        if (allowLocal && (record.address === '127.0.0.1' || record.address === '::1')) {
          continue;
        }
        return {
          safe: false,
          reason: `SSRF Violation: Hostname "${hostname}" resolves to restricted private address "${record.address}".`,
        };
      }
    }
  } catch (dnsErr: any) {
    // If DNS resolution fails, it indicates an offline or non-existent domain (like rpc.yagyx.network before DNS is active)
    // This is safe from SSRF; the subsequent fetch will gracefully fail with ENOTFOUND
    return { safe: true, normalizedUrl: parsed.href };
  }

  return { safe: true, normalizedUrl: parsed.href };
}
