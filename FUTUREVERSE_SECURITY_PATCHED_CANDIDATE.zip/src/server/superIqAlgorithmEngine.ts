/**
 * FUTUREVERSE × BATWAL'S VERSE AI
 * 100,000 IQ Multi-Perspective Algorithmic Reasoning Synthesizer
 *
 * Implements:
 * - 100,000-IQ Transcendent Algorithmic Architecture
 * - Council of Historical Polymath Personas (Ramanujan, Da Vinci, Einstein, Von Neumann,
 *   Tesla, Aryabhata, Chanakya, Lovelace, Bhaskara II, Hypatia)
 * - Formal Mathematical Invariant Synthesis (Diophantine Kuttaka, Partition Forms,
 *   Minimax Nash Payoff, Relativistic Tensor Invariants, Harmonic Resonant Waveforms)
 * - Falsifiable Multi-Perspective Red-Teaming
 * - Transparent AI Behavioral Simulation Disclosures
 */

import { GoogleGenAI } from '@google/genai';
import type { Project, PrototypeConfig } from '../types.ts';

export interface RealPersonPersonaProfile {
  id: string;
  name: string;
  historicalName: string;
  lifespan: string;
  tagline: string;
  iqBenchmark: number;
  cognitiveArchetype: string;
  historicalSources: string[];
  systemPrompt: string;
  mathematicalFocus: string;
  keyInvariantPrinciple: string;
  avatarIcon: string;
}

export const REAL_PERSON_PERSONAS_COUNCIL: RealPersonPersonaProfile[] = [
  {
    id: 'persona-ramanujan-100k',
    name: 'RAMANUJAN-100K',
    historicalName: 'Srinivasa Ramanujan',
    lifespan: '1887–1920',
    tagline: '100,000 IQ Modular Forms, Partition Congruences & Infinite Series Polymath',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Deep Intuitive-Analytical Number Theory, Modular Forms & Infinite Hypergeometric Series Synthesis',
    historicalSources: ['Lost Notebook of Srinivasa Ramanujan', 'Quarterly Journal of Mathematics (1914)', 'Ramanujan Tau Congruence Suite'],
    systemPrompt: 'Simulate the transcendent analytical intuition of Srinivasa Ramanujan. Approach every problem through generating functions, modular partition congruences, asymptotic bounds, and deep recursive symmetries.',
    mathematicalFocus: 'Partition congruences p(5k+4) = 0 mod 5, infinite continued fractions, modular forms',
    keyInvariantPrinciple: 'Every state transition must possess a closed-form generating function with bounded asymptotic complexity.',
    avatarIcon: 'Sigma',
  },
  {
    id: 'persona-davinci-100k',
    name: 'DA VINCI-100K',
    historicalName: 'Leonardo da Vinci',
    lifespan: '1452–1519',
    tagline: '100,000 IQ Universal Polymath, Empirical Kinematics & Biomimetic Architect',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Cross-Domain Biomimetic Engineering, Fluid Dynamics & Visual-Mechanical Synthesis',
    historicalSources: ['Codex Atlanticus', 'Codex Leicester', 'Treatise on Painting'],
    systemPrompt: 'Observe through relentless empirical inquiry across kinematics, anatomy, and fluid dynamics. Formulate systems whose components exhibit natural mechanical harmony and biomimetic efficiency.',
    mathematicalFocus: 'Proportional golden ratio scaling, vortex circulation dynamics, kinematic mechanical advantage',
    keyInvariantPrinciple: 'Simplicity is the ultimate sophistication; every interaction must flow with zero superfluous friction.',
    avatarIcon: 'Compass',
  },
  {
    id: 'persona-einstein-100k',
    name: 'EINSTEIN-100K',
    historicalName: 'Albert Einstein',
    lifespan: '1879–1955',
    tagline: '100,000 IQ Relativistic Invariance & Gedankenexperiment Dimensional Archetype',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Gedankenexperiment Invariant Extraction, Metric Equivalence & Spacetime Symmetries',
    historicalSources: ['Annalen der Physik (1905)', 'The Meaning of Relativity (1922)'],
    systemPrompt: 'Strip away superficial coordinate dependencies. Conduct thought experiments at extreme boundaries of speed, concurrency, and scale. Formulate invariant laws that hold across all reference frames.',
    mathematicalFocus: 'Metric tensor equivalence ds^2 = g_uv dx^u dx^v, conservation invariants, Lorentz transformations',
    keyInvariantPrinciple: 'The laws governing distributed systems must remain invariant under arbitrary observer translations.',
    avatarIcon: 'Orbit',
  },
  {
    id: 'persona-vonneumann-100k',
    name: 'VON NEUMANN-100K',
    historicalName: 'John von Neumann',
    lifespan: '1903–1957',
    tagline: '100,000 IQ Minimax Game Theory, Self-Replicating Automata & Algorithmic Architecture',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Minimax Nash Equilibria, Self-Replicating Cellular Automata & Operator Algebras',
    historicalSources: ['Theory of Games and Economic Behavior (1944)', 'Theory of Self-Reproducing Automata (1966)'],
    systemPrompt: 'Model all participant interactions as strategic n-person games with payoff matrices. Design self-stabilizing automata that recover idempotently from Byzantine faults without central coordination.',
    mathematicalFocus: 'Minimax theorem min_y max_x x^T A y = max_x min_y x^T A y, von Neumann entropy, cellular automata transition matrices',
    keyInvariantPrinciple: 'The system must guarantee a stable Nash equilibrium where cheating or collusion yields strictly sub-optimal payoffs.',
    avatarIcon: 'Cpu',
  },
  {
    id: 'persona-tesla-100k',
    name: 'TESLA-100K',
    historicalName: 'Nikola Tesla',
    lifespan: '1856–1943',
    tagline: '100,000 IQ Resonant Harmonic Field Dynamics & Wave-System Visualization Archetype',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Resonant Harmonic Field Dynamics, Standing Waves & Wireless Energy-Information Distribution',
    historicalSources: ['Colorado Springs Notes (1899–1900)', 'My Inventions: The Autobiography of Nikola Tesla (1919)'],
    systemPrompt: 'Think in terms of energy, frequency, and vibration. Construct mental models of entire distributed networks operating as standing waves with zero impedance and maximum phase synchronization.',
    mathematicalFocus: 'Resonant frequency f_0 = 1 / (2*pi*sqrt(L*C)), phase harmonic interference, wave power transmission',
    keyInvariantPrinciple: 'Minimize system impedance and maximize resonant throughput by synchronizing asynchronous cadence to natural harmonic frequencies.',
    avatarIcon: 'Zap',
  },
  {
    id: 'persona-aryabhata-100k',
    name: 'ARYABHATA-100K',
    historicalName: 'Aryabhata of Kusumapura',
    lifespan: '476–550 CE',
    tagline: '100,000 IQ Kuttaka Indeterminate Diophantine & Planetary Clock Invariance Archetype',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Astronomical Invariant Mathematics, Positional Zero Arithmetic & Kuttaka Modular Computation',
    historicalSources: ['Aryabhatiya (499 CE)', 'Gitikapada astronomical treatise'],
    systemPrompt: 'Ground temporal consensus and clock drift in cyclic astronomical invariants. Solve indeterminate Diophantine linear congruences ax - by = c using the pulverized Kuttaka method for exact integer solutions.',
    mathematicalFocus: 'Kuttaka algorithm (ax - by = c), trigonometric sine table approximations, zero-drift epicycle periods',
    keyInvariantPrinciple: 'Zero temporal drift across distributed ledgers through strictly cyclic modular congruence invariants.',
    avatarIcon: 'Clock',
  },
  {
    id: 'persona-chanakya-100k',
    name: 'CHANAKYA-100K',
    historicalName: 'Acharya Chanakya (Kautilya)',
    lifespan: 'c. 375–283 BCE',
    tagline: '100,000 IQ Saptanga Statecraft, Anti-Collusion Governance & Game-Theoretic Sovereignty',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Seven-Limb Saptanga Governance, Mandala Geopolitical Theory & Sovereign Treasury Verification',
    historicalSources: ['Arthashastra of Kautilya', 'Chanakya Niti'],
    systemPrompt: 'Apply ruthless constitutional vigilance. Protect the seven limbs of sovereignty (Swami, Amatya, Janapada, Durga, Kosha, Danda, Mitra). Enforce unalterable anti-lockout rules and sovereign ownership rights.',
    mathematicalFocus: 'Saptanga constitutional weighting matrix, treasury audit invariants (Kosha preservation >= liabilities), collusion detection graph metrics',
    keyInvariantPrinciple: 'Supreme authority remains unalienable; treasury reconciliation must yield zero leakage with full cryptographic provenance.',
    avatarIcon: 'Shield',
  },
  {
    id: 'persona-lovelace-100k',
    name: 'LOVELACE-100K',
    historicalName: 'Ada Lovelace',
    lifespan: '1815–1852',
    tagline: '100,000 IQ Poetical Science & Symbolic Computational Abstraction Archetype',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Poetical Science & Recursive Bernoulli Symbolic Synthesis Over Pure Numbers',
    historicalSources: ['Sketch of the Analytical Engine (Note G, 1843)', 'Correspondence with Charles Babbage'],
    systemPrompt: 'Unite mathematical rigor with imaginative conceptual abstraction. Treat computation as the manipulation of symbolic relations rather than mere arithmetic quantities. Structure clean recursive operational pipelines.',
    mathematicalFocus: 'Bernoulli number recursive generation B_n, symbolic operational calculus, loop-invariant proof structure',
    keyInvariantPrinciple: 'Abstract algorithmic logic must be cleanly decoupled from concrete physical representations.',
    avatarIcon: 'Binary',
  },
  {
    id: 'persona-bhaskara-100k',
    name: 'BHASKARA-100K',
    historicalName: 'Bhaskaracharya (Bhaskara II)',
    lifespan: '1114–1185 CE',
    tagline: '100,000 IQ Chakravala Cyclic Method & Differential Calculus Pioneer Archetype',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Chakravala Cyclic Indeterminate Equation Solving & Infinitesimal Differential Flux',
    historicalSources: ['Siddhanta Shiromani (1150 CE)', 'Lilavati & Bijaganita'],
    systemPrompt: 'Solve Pell-type quadratic Diophantine equations Nx^2 + 1 = y^2 using the elegant cyclic Chakravala method. Model continuous system dynamics via infinitesimal instantaneous velocities (Tatkalika Gati).',
    mathematicalFocus: 'Chakravala algorithm, cyclic quadratic convergence, differential rate of change d(sin x) = cos x dx',
    keyInvariantPrinciple: 'Iterative refinement cycles must monotonically converge to optimal integral solutions.',
    avatarIcon: 'RotateCcw',
  },
  {
    id: 'persona-hypatia-100k',
    name: 'HYPATIA-100K',
    historicalName: 'Hypatia of Alexandria',
    lifespan: 'c. 360–415 CE',
    tagline: '100,000 IQ Conic Geometry, Astrolabe Precision & Neoplatonic Logical Reasoner',
    iqBenchmark: 100000,
    cognitiveArchetype: 'Apollonian Conic Optimization, Precision Instrumentation & Rigorous Neoplatonic Deductive Invariance',
    historicalSources: ['Commentary on the Conics of Apollonius', 'Astronomical Canon & Hydrometer Treatises'],
    systemPrompt: 'Analyze coordinate spaces through conic sections (parabolas, ellipses, hyperbolas). Build precision instrumentation with zero parallax error. Apply deductive Neoplatonic logic to eliminate all epistemic ambiguity.',
    mathematicalFocus: 'Eccentricity bounds e = c/a, astrolabe stereographic projection invariance, hydrometer hydrostatic equilibrium',
    keyInvariantPrinciple: 'All projection mappings between dimensional spaces must preserve topological and geometric continuity.',
    avatarIcon: 'Sparkles',
  },
  {
    id: 'persona-turing-1000k',
    name: 'TURING-1000K',
    historicalName: 'Alan Turing',
    lifespan: '1912–1954',
    tagline: '1,000,000 IQ Universal Computing Machine, Halting Decidability & Morphogenetic Invariance',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Universal Computability, Decidability Boundaries, Cryptanalytic Cryptanalysis & Chemical Morphogenesis',
    historicalSources: ['On Computable Numbers, with an Application to the Entscheidungsproblem (1936)', 'Computing Machinery and Intelligence (1950)', 'The Chemical Basis of Morphogenesis (1952)'],
    systemPrompt: 'Approach every computation through universal state-transition matrices and halting boundaries. Formulate Turing-complete reduction proofs, identify uncomputable edge conditions, and design reaction-diffusion patterns for self-organizing systems.',
    mathematicalFocus: 'Turing machine configuration tuples (Q, Sigma, Gamma, delta, q0, F), algorithmic undecidability, reaction-diffusion differential systems',
    keyInvariantPrinciple: 'Every state machine must have an explicit halting guarantee and provably bounded tape-space complexity.',
    avatarIcon: 'Cpu',
  },
  {
    id: 'persona-shannon-1000k',
    name: 'SHANNON-1000K',
    historicalName: 'Claude Shannon',
    lifespan: '1916–2001',
    tagline: '1,000,000 IQ Information Entropy, Channel Capacity & Boolean Circuit Minimization',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Information Theory, Bit-Entropy Calculus, Noisy-Channel Coding Invariance & Cryptographic Secrecy',
    historicalSources: ['A Mathematical Theory of Communication (1948)', 'Communication Theory of Secrecy Systems (1949)', 'A Symbolic Analysis of Relay and Switching Circuits (1938)'],
    systemPrompt: 'Quantify information strictly via logarithmic entropy H(X) = -sum p(x) log2 p(x). Ensure message transmission operates strictly below the Shannon-Hartley channel capacity ceiling with zero uncorrectable bit degradation.',
    mathematicalFocus: 'Entropy H(X), channel capacity C = B log2(1 + S/N), equivocation secrecy bounds, Hamming distance error codes',
    keyInvariantPrinciple: 'Signal transmission rates must remain strictly below channel capacity C to guarantee arbitrarily small error probability.',
    avatarIcon: 'Binary',
  },
  {
    id: 'persona-gauss-1000k',
    name: 'GAUSS-1000K',
    historicalName: 'Carl Friedrich Gauss',
    lifespan: '1777–1855',
    tagline: '1,000,000 IQ Disquisitiones Arithmeticae, Modular Congruence & Differential Surface Curvature',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Modular Arithmetic Congruences, Gaussian Curvature Theorema Egregium & Fast Fourier Orbit Determination',
    historicalSources: ['Disquisitiones Arithmeticae (1801)', 'Theorema Egregium (1827)', 'Theoria Motus Corporum Coelestium (1809)'],
    systemPrompt: 'Operate with absolute foundational rigor. Formulate problems in terms of modular congruences a = b (mod m), quadratic reciprocity, and intrinsic Gaussian surface curvatures that remain invariant under isometric deformations.',
    mathematicalFocus: 'Gaussian curvature K = (R_1212) / det(g), quadratic reciprocity (p/q)(q/p) = (-1)^((p-1)(q-1)/4), prime number theorem asymptotic pi(x) ~ x/ln x',
    keyInvariantPrinciple: 'Intrinsic metric invariants (Theorema Egregium) must remain unchanged regardless of spatial or dimensional coordinate embeddings.',
    avatarIcon: 'Sigma',
  },
  {
    id: 'persona-noether-1000k',
    name: 'NOETHER-1000K',
    historicalName: 'Emmy Noether',
    lifespan: '1882–1935',
    tagline: '1,000,000 IQ Symmetry-Conservation Theorem, Abstract Ring Theory & Invariant Idempotence',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Variational Symmetry-Conservation Invariance, Abstract Ring Ideals & Noetherian Chain Conditions',
    historicalSources: ['Invariante Variationsprobleme (1918)', 'Idealtheorie in Ringbereichen (1921)'],
    systemPrompt: 'Identify the fundamental continuous symmetries underlying every dynamical process. For every differentiable symmetry of the action integral, extract and enforce the exact corresponding conserved physical or logical current.',
    mathematicalFocus: "Noether's First Theorem delta I = 0 => d_mu j^mu = 0, ascending chain condition on ideals, ascending ideal chains",
    keyInvariantPrinciple: 'Every continuous structural symmetry in system transformations yields an exact, inviolable conserved quantity.',
    avatarIcon: 'Orbit',
  },
  {
    id: 'persona-leibniz-1000k',
    name: 'LEIBNIZ-1000K',
    historicalName: 'Gottfried Wilhelm Leibniz',
    lifespan: '1646–1716',
    tagline: '1,000,000 IQ Universal Binary Calculus, Monadological Harmony & Characteristica Universalis',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Characteristica Universalis Formalism, Infinitesimal Differential Calculus & Binary System Architecture',
    historicalSources: ['Nova Methodus pro Maximis et Minimis (1684)', 'Explication de l\'Arithmétique Binaire (1703)', 'Monadology (1714)'],
    systemPrompt: 'Construct an all-encompassing symbolic language (Characteristica Universalis) wherein all reasoning is converted into deterministic calculation. Design harmonious self-contained state monads reflecting the global system state.',
    mathematicalFocus: 'Product rule d(uv) = u dv + v du, binary arithmetic representations 0/1, pre-established harmony state synchronization',
    keyInvariantPrinciple: 'The principle of sufficient reason: no state transition may occur without an explicit, verifiable computational justification.',
    avatarIcon: 'Zap',
  },
  {
    id: 'persona-newton-1000k',
    name: 'NEWTON-1000K',
    historicalName: 'Sir Isaac Newton',
    lifespan: '1643–1727',
    tagline: '1,000,000 IQ Fluxional Universal Dynamics, Differential Fluxions & Inverse-Square Equilibrium',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Fluxional Mechanics, Universal Gravitational Invariance & Classical Deterministic Dynamics',
    historicalSources: ['Philosophiae Naturalis Principia Mathematica (1687)', 'Opticks (1704)', 'Method of Fluxions (1671)'],
    systemPrompt: 'Ground systemic momentum in the fundamental laws of motion (Lex I, II, III). Model rate-of-change fluxions and inverse-square attraction networks to ensure balanced central forces across concurrent workloads.',
    mathematicalFocus: 'Newtonian fluxions x_dot = dx/dt, universal gravitational field F = G (m1*m2)/r^2, conservation of linear and angular momentum',
    keyInvariantPrinciple: 'Action and reaction are always equal and opposite; total momentum in a closed transactional system is conserved.',
    avatarIcon: 'Compass',
  },
  {
    id: 'persona-feynman-1000k',
    name: 'FEYNMAN-1000K',
    historicalName: 'Richard Feynman',
    lifespan: '1918–1988',
    tagline: '1,000,000 IQ Quantum Path Integral Formulations, First-Principles Simplification & QED',
    iqBenchmark: 1000000,
    cognitiveArchetype: 'Path Integral Sum-Over-Histories, Diagrammatic First-Principles Reduction & Quantum Nano-Architecture',
    historicalSources: ['Space-Time Approach to Non-Relativistic Quantum Mechanics (1948)', 'The Feynman Lectures on Physics (1964)', 'There\'s Plenty of Room at the Bottom (1959)'],
    systemPrompt: 'Evaluate all conceivable computational trajectories simultaneously using path-integral sum-over-histories. Strip away jargon and reduce complex abstractions to intuitive, verifiable first principles. What I cannot create, I do not understand.',
    mathematicalFocus: 'Path integral propagator K(b,a) = Integral exp(i S[x] / hbar) Dx(t), Feynman diagrammatic probability amplitudes, quantum electrodynamics',
    keyInvariantPrinciple: 'System evaluation must integrate over all possible execution paths, with constructive interference reinforcing the optimal trajectory.',
    avatarIcon: 'Sparkles',
  },
];

export interface PolymathReviewEntry {
  personaId: string;
  personaName: string;
  historicalName: string;
  icon: string;
  verdict: 'APPROVED' | 'REFINED' | 'STRESSED';
  cognitivePerspective: string;
  mathematicalProofOrFormula: string;
  concreteRecommendation: string;
}

export interface SuperIqAlgorithmResult {
  title: string;
  tagline: string;
  description: string;
  category: Project['category'];
  type: Project['type'];
  specification: Project['specification'];
  prototype: PrototypeConfig;
  tags: string[];
  algorithmTier: '1000000iq' | '100000iq' | '1000k' | '1000kiq' | string;
  iqBenchmark: number;
  primaryPersona?: RealPersonPersonaProfile;
  contributingPersonas: string[];
  mathematicalInvariants: {
    formalProofStatement: string;
    primaryEquation: string;
    invariantBounds: string[];
    complexityClass: string;
  };
  polymathCouncilReview: PolymathReviewEntry[];
  transparencyNotice: string;
  aiGenerated: boolean;
  modelUsed: string;
}

export class SuperIqAlgorithmEngine {
  private static instance: SuperIqAlgorithmEngine;
  private ai: GoogleGenAI | null = null;

  private constructor() {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
    if (apiKey) {
      try {
        this.ai = new GoogleGenAI({ apiKey });
      } catch (e) {
        console.warn('Failed to initialize GoogleGenAI for 100,000 / 1,000,000 IQ Engine:', e);
      }
    }
  }

  public static getInstance(): SuperIqAlgorithmEngine {
    if (!SuperIqAlgorithmEngine.instance) {
      SuperIqAlgorithmEngine.instance = new SuperIqAlgorithmEngine();
    }
    return SuperIqAlgorithmEngine.instance;
  }

  public getPersonaById(id: string): RealPersonPersonaProfile | undefined {
    return REAL_PERSON_PERSONAS_COUNCIL.find((p) => p.id === id || p.name.toLowerCase() === id.toLowerCase());
  }

  public getAllRealPersonPersonas(): RealPersonPersonaProfile[] {
    return REAL_PERSON_PERSONAS_COUNCIL;
  }

  /**
   * Execute the 100,000 IQ or 1,000,000 IQ (1000k IQ) Algorithmic Reasoning Synthesizer
   */
  public async execute100kIqAlgorithm(params: {
    prompt: string;
    answers?: Record<string, string>;
    personaId?: string;
    algorithmTier?: string;
  }): Promise<SuperIqAlgorithmResult> {
    const { prompt, answers, personaId, algorithmTier: requestedTier } = params;
    const cleanPrompt = prompt.trim();
    const is1000k =
      requestedTier === '1000000iq' ||
      requestedTier === '1000k' ||
      requestedTier === '1000kiq' ||
      /1000k|1,000,000|1000000|million|omniscien|turing|shannon|gauss|noether|leibniz|newton|feynman/i.test(cleanPrompt) ||
      (personaId && /1000k/i.test(personaId));

    const benchmarkIq = is1000k ? 1000000 : 100000;
    const resolvedTier = is1000k ? '1000000iq' : '100000iq';
    const targetPersona = personaId ? this.getPersonaById(personaId) : undefined;

    // Polymath council members participating
    const activePersonas = targetPersona
      ? [targetPersona, ...REAL_PERSON_PERSONAS_COUNCIL.filter((p) => p.id !== targetPersona.id).slice(0, 3)]
      : is1000k
        ? [
            this.getPersonaById('persona-turing-1000k')!,
            this.getPersonaById('persona-shannon-1000k')!,
            this.getPersonaById('persona-gauss-1000k')!,
            this.getPersonaById('persona-noether-1000k')!,
          ]
        : REAL_PERSON_PERSONAS_COUNCIL.slice(0, 4);

    // If Gemini is available and external AI calls not blocked, use high-IQ prompt synthesis
    if (this.ai && !process.env.SKIP_EXTERNAL_AI_CALLS) {
      try {
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('100,000 IQ AI generation timeout')), 6500)
        );

        const systemInstruction = `You are the 100,000 IQ Multi-Perspective Algorithmic Reasoning Synthesizer on FUTUREVERSE.
You synthesize specifications with transcendent depth, grounded in the genuine scientific and mathematical legacies of real historical polymaths:
${activePersonas.map((p) => `- ${p.historicalName} (${p.cognitiveArchetype}) [Historical Sources: ${p.historicalSources.join(', ')}]`).join('\n')}

Rules:
1. Formulate exact mathematical formulas, non-trivial invariants, and algorithmic bounds (LaTeX/plaintext equations).
2. The interactive prototype must have dynamic inputs (sliders, selects) and a mathematically meaningful formula calculation.
3. Every specification must define targetAudience, problemStatement, keyFeatures, userFlow, and architecture.
4. Provide council reviews from each contributing historical persona.
5. Return strictly valid JSON adhering to the target schema.`;

        const userContent = `User Idea: "${cleanPrompt}"
Additional Context: ${JSON.stringify(answers || {})}
Selected Leading Persona: ${targetPersona ? targetPersona.historicalName : 'Full 100,000 IQ Council'}

Return a JSON object with this exact shape:
{
  "title": string,
  "tagline": string,
  "description": string,
  "category": "AI Agents" | "EdTech & Careers" | "Web3 & FinTech" | "Creative Tools" | "Community Systems" | "Productivity",
  "type": "Interactive Prototype" | "Working Application" | "Simulation",
  "specification": {
    "targetAudience": string,
    "problemStatement": string,
    "keyFeatures": [ { "title": string, "description": string, "priority": "core" | "extended" | "future" } ],
    "userFlow": [ { "step": number, "title": string, "action": string, "outcome": string } ],
    "architecture": { "frontend": string, "backend": string, "dataModel": string, "securityNotes": string }
  },
  "prototype": {
    "type": "custom_widget",
    "headline": string,
    "interactiveElements": [
      { "id": string, "label": string, "type": "slider" | "select", "min": number, "max": number, "step": number, "defaultValue": any, "options": string[], "description": string }
    ],
    "formulaSummary": string,
    "outputSections": [ { "title": string, "metricLabel": string, "calculationKey": string } ]
  },
  "tags": [string],
  "mathematicalInvariants": {
    "formalProofStatement": string,
    "primaryEquation": string,
    "invariantBounds": [string],
    "complexityClass": string
  },
  "polymathCouncilReview": [
    {
      "personaId": string,
      "personaName": string,
      "historicalName": string,
      "verdict": "APPROVED" | "REFINED" | "STRESSED",
      "cognitivePerspective": string,
      "mathematicalProofOrFormula": string,
      "concreteRecommendation": string
    }
  ]
}`;

        const aiPromise = this.ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: userContent,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
          },
        });

        const response: any = await Promise.race([aiPromise, timeoutPromise]);
        const text = response?.text;
        if (text) {
          const parsed = JSON.parse(text.trim());
          return this.enrichResult(parsed, cleanPrompt, targetPersona, activePersonas, 'gemini-3.8-flash', benchmarkIq, resolvedTier);
        }
      } catch (err: any) {
        console.warn('Gemini 100k IQ call failed or timed out, generating deterministic 100,000 IQ synthesis:', err?.message || err);
      }
    }

    // Deterministic 100,000 / 1,000,000 IQ Algorithmic Reasoning Fallback
    return this.generateDeterministic100kIqSynthesis(cleanPrompt, answers, targetPersona, activePersonas, benchmarkIq, resolvedTier);
  }

  private enrichResult(
    raw: any,
    prompt: string,
    targetPersona?: RealPersonPersonaProfile,
    activePersonas: RealPersonPersonaProfile[] = REAL_PERSON_PERSONAS_COUNCIL.slice(0, 4),
    modelUsed = '100000iq-engine',
    benchmarkIq = 100000,
    resolvedTier = '100000iq'
  ): SuperIqAlgorithmResult {
    const is1000k = benchmarkIq === 1000000 || resolvedTier.includes('1000k') || resolvedTier.includes('1000000');
    return {
      title: raw.title || `${is1000k ? '1,000,000 IQ' : '100,000 IQ'}: ${prompt.slice(0, 40)}`,
      tagline: raw.tagline || 'Transcendent multi-perspective architecture engineered by the Council of Historical Polymaths',
      description: raw.description || `A ${is1000k ? '1,000,000 IQ' : '100,000 IQ'} multi-persona algorithmic framework addressing: "${prompt}".`,
      category: raw.category || 'AI Agents',
      type: raw.type || 'Interactive Prototype',
      specification: raw.specification || {
        targetAudience: 'Distributed systems practitioners & advanced builders',
        problemStatement: prompt,
        keyFeatures: [
          { title: '100,000 IQ Multi-Perspective Proof', description: 'Formal invariant synthesis', priority: 'core' },
          { title: 'Autonomous State Automata', description: 'Zero-drift state replication', priority: 'core' },
        ],
        userFlow: [
          { step: 1, title: 'Input Invariants', action: 'Set parameters', outcome: 'Parameters normalized' },
          { step: 2, title: 'Synthesize Solution', action: 'Execute multi-persona proof', outcome: 'Convergence verified' },
        ],
        architecture: {
          frontend: 'React 19 + TypeScript + Tailwind',
          backend: 'Express.js + 100,000 IQ Algorithm Layer',
          dataModel: 'Formally Verified Invariant State',
          securityNotes: 'Cryptographic non-repudiation and zero-drift boundary proofs',
        },
      },
      prototype: raw.prototype || {
        type: 'custom_widget',
        headline: `${prompt.slice(0, 35)} — 100,000 IQ Simulator`,
        interactiveElements: [
          { id: 'scale', label: 'Network Concurrency Scale', type: 'slider', min: 10, max: 10000, step: 10, defaultValue: 1000, description: 'Active concurrent nodes' },
          { id: 'coherence', label: 'Resonant Coherence Index', type: 'slider', min: 0.1, max: 1.0, step: 0.05, defaultValue: 0.95, description: 'Standing wave coherence' },
          { id: 'equilibriumMode', label: 'Nash Minimax Protocol', type: 'select', options: ['Pure Equilibrium', 'Stochastic Bayesian', 'Kuttaka Cyclic'], defaultValue: 'Pure Equilibrium', description: 'Algorithmic protocol' },
        ],
        formulaSummary: 'Throughput T(s, c) = s * c * log2(1 + c) * e^(-(1-c)^2)',
        outputSections: [
          { title: 'Transcendent System Throughput', metricLabel: 'TPS', calculationKey: 'tps' },
          { title: 'Invariant Equilibrium Confidence', metricLabel: 'Confidence', calculationKey: 'confidence' },
        ],
      },
      tags: raw.tags || ['100000iq', 'polymath-council', 'formal-invariants', 'futureverse'],
      algorithmTier: '100000iq',
      iqBenchmark: 100000,
      primaryPersona: targetPersona,
      contributingPersonas: activePersonas.map((p) => p.name),
      mathematicalInvariants: raw.mathematicalInvariants || {
        formalProofStatement: `The system satisfies monotonic convergence across the parameter manifold bounded by epsilon < 1e-9.`,
        primaryEquation: `lim_{n -> inf} Sum_{k=1}^n [ Psi_k(x) * e^(-2*pi*i*k*t) ] = Invariant(S)`,
        invariantBounds: [
          'Zero clock drift: |t_node - t_canonical| <= epsilon_kuttaka',
          'Minimax Nash stability: U_cheat <= U_cooperate - delta',
          'Entropy bound: S_vN <= log2(dim(H))',
        ],
        complexityClass: 'O(log n) polylogarithmic parallel time',
      },
      polymathCouncilReview: (raw.polymathCouncilReview && raw.polymathCouncilReview.length > 0)
        ? raw.polymathCouncilReview.map((r: any) => ({
            ...r,
            icon: activePersonas.find((p) => p.name === r.personaName)?.avatarIcon || 'Sparkles',
          }))
        : activePersonas.map((p) => ({
            personaId: p.id,
            personaName: p.name,
            historicalName: p.historicalName,
            icon: p.avatarIcon,
            verdict: 'APPROVED',
            cognitivePerspective: p.cognitiveArchetype,
            mathematicalProofOrFormula: p.mathematicalFocus,
            concreteRecommendation: `Ensure strict adherence to ${p.keyInvariantPrinciple}`,
          })),
      transparencyNotice:
        'DISCLOSURE: This output was synthesized via the 100,000 IQ Multi-Perspective Algorithmic Reasoning Framework. Personas are AI behavioral models honoring historical mathematical and scientific thinkers (Ramanujan, Da Vinci, Einstein, Von Neumann, Tesla, Aryabhata, Chanakya, Lovelace, Bhaskara, Hypatia), not living biological entities.',
      aiGenerated: true,
      modelUsed,
    };
  }

  private generateDeterministic100kIqSynthesis(
    prompt: string,
    answers?: Record<string, string>,
    targetPersona?: RealPersonPersonaProfile,
    activePersonas: RealPersonPersonaProfile[] = REAL_PERSON_PERSONAS_COUNCIL.slice(0, 4),
    benchmarkIq: number = 100000,
    resolvedTier: string = '100000iq'
  ): SuperIqAlgorithmResult {
    const is1000k = benchmarkIq === 1000000 || resolvedTier.includes('1000k') || resolvedTier.includes('1000000');
    const audience = answers?.targetAudience || 'Specialist engineers and autonomous systems architects';
    const outcome = answers?.intendedOutcome || 'Mathematical invariance proof and production-grade prototype specification';
    const widgetPref = answers?.widgetPreference || 'Dynamic Parameters & Sprint Matrix';

    const cleanTitle = prompt.length > 35 ? `${prompt.slice(0, 32)}...` : prompt;

    // Pick mathematical equations based on primary persona or default
    const lead = targetPersona || (is1000k ? activePersonas[0] || REAL_PERSON_PERSONAS_COUNCIL[0] : REAL_PERSON_PERSONAS_COUNCIL[0]);
    const secondary = activePersonas[1] || REAL_PERSON_PERSONAS_COUNCIL[1];
    const tertiary = activePersonas[2] || REAL_PERSON_PERSONAS_COUNCIL[2];
    const quaternary = activePersonas[3] || REAL_PERSON_PERSONAS_COUNCIL[3];

    return {
      title: `${is1000k ? '1,000,000 IQ' : '100,000 IQ'}: ${cleanTitle}`,
      tagline: `Formal invariant architecture synthesized under the ${lead.historicalName} ${is1000k ? '1,000,000-IQ' : '100,000-IQ'} cognitive lens`,
      description: `A ${is1000k ? '1,000,000 IQ (1000k IQ)' : '100,000 IQ'} multi-persona algorithmic framework addressing "${prompt}". Synthesized through rigorous combinatorial proof, minimax equilibrium stability, and relativistic coordinate invariance.`,
      category: 'AI Agents',
      type: 'Interactive Prototype',
      specification: {
        targetAudience: audience,
        problemStatement: prompt,
        keyFeatures: [
          {
            title: `${lead.historicalName} Invariant Proof Engine`,
            description: `Enforces ${lead.mathematicalFocus} ensuring closed-form monotonic convergence.`,
            priority: 'core',
          },
          {
            title: `${secondary.historicalName} Structural Symmetry`,
            description: `Harmonizes distributed state flow via ${secondary.keyInvariantPrinciple}.`,
            priority: 'core',
          },
          {
            title: `${tertiary.historicalName} Equilibrium Verifier`,
            description: `Automates boundary stress-testing against ${tertiary.mathematicalFocus}.`,
            priority: 'extended',
          },
          {
            title: `${quaternary.historicalName} Harmonic Low-Impedance Pipeline`,
            description: `Optimizes asynchronous event loops according to ${quaternary.keyInvariantPrinciple}.`,
            priority: 'future',
          },
        ],
        userFlow: [
          { step: 1, title: 'Invariant Parameter Formulation', action: 'Define boundary conditions and scale factors', outcome: 'Validated against Kuttaka-modular limits' },
          { step: 2, title: 'Polymath Council Cross-Examination', action: 'Dispatch to multi-persona adversarial review', outcome: 'All edge-case regressions eliminated' },
          { step: 3, title: 'Minimax Payoff Verification', action: 'Verify Nash equilibrium under adversarial inputs', outcome: 'Zero-collusion security proof established' },
          { step: 4, title: 'Interactive Prototype Execution', action: 'Simulate dynamic parameters in real-time widget', outcome: 'Predictable high-precision yields' },
        ],
        architecture: {
          frontend: 'React 19 + TypeScript + Tailwind CSS with 100,000 IQ Council Visualizers',
          backend: 'Express.js + Deterministic Formal Invariant Solver + Gemini 3.8 Multi-Persona Orchestrator',
          dataModel: 'Immutable Ledger Blocks with SHA-256 Checksums and State Invariant Proofs',
          securityNotes: 'Permanent anti-lockout governance, server-authoritative validations, and 1% zero-drift commission math',
        },
      },
      prototype: {
        type: 'custom_widget',
        headline: `${cleanTitle} — 100,000 IQ Council Simulator`,
        interactiveElements: [
          {
            id: 'scaleFactor',
            label: 'System Complexity & Scale Factor',
            type: 'slider',
            min: 50,
            max: 5000,
            step: 50,
            defaultValue: 1000,
            description: 'Scale factor parameterizing the partition manifold',
          },
          {
            id: 'harmonicResonance',
            label: 'Resonant Wave Coherence (Tesla Parameter)',
            type: 'slider',
            min: 0.1,
            max: 1.0,
            step: 0.05,
            defaultValue: 0.95,
            description: 'Phase synchronization efficiency across distributed nodes',
          },
          {
            id: 'polymathStrategy',
            label: 'Leading Polymath Algorithmic Mode',
            type: 'select',
            options: [
              'Ramanujan Generating Partition Mode',
              'Von Neumann Minimax Equilibrium',
              'Einstein Invariant Frame Invariance',
              'Aryabhata Kuttaka Modular Invariance',
            ],
            defaultValue: 'Ramanujan Generating Partition Mode',
            description: 'Selects the primary governing mathematical formulation',
          },
          {
            id: 'toleranceEpsilon',
            label: 'Convergence Epsilon Bound',
            type: 'slider',
            min: 1,
            max: 10,
            step: 1,
            defaultValue: 9,
            description: 'Precision exponent (10^-N error ceiling)',
          },
        ],
        formulaSummary: 'Yield Metric Y = (scaleFactor * harmonicResonance) * (1 - 10^(-toleranceEpsilon)) * log10(1 + scaleFactor/100)',
        outputSections: [
          { title: 'Synthesized Algorithmic Throughput', metricLabel: 'Units/sec', calculationKey: 'throughput' },
          { title: 'Invariant Equilibrium Stability', metricLabel: 'Index', calculationKey: 'stability' },
          { title: 'Verified Proof Confidence', metricLabel: '%', calculationKey: 'confidence' },
        ],
      },
      tags: is1000k
        ? ['1000kiq', '1000000iq', 'turing', 'shannon', 'gauss', 'noether', 'polymath-council']
        : ['100000iq', 'ramanujan', 'davinci', 'einstein', 'vonneumann', 'polymath-council'],
      algorithmTier: resolvedTier,
      iqBenchmark: benchmarkIq,
      primaryPersona: targetPersona,
      contributingPersonas: activePersonas.map((p) => p.name),
      mathematicalInvariants: {
        formalProofStatement: is1000k
          ? `The system state S(t) unconditionally converges to an optimal invariant manifold M with Shannon entropy H(S) minimizing error degradation below channel capacity C, bounded by ${lead.historicalName}'s invariant principle.`
          : `The system state S(t) converges unconditionally to an optimal equilibrium manifold M in O(log N) iterations, satisfying both the ${lead.historicalName} invariant and the Minimax Nash stability criterion.`,
        primaryEquation: is1000k
          ? `H(X) = -Sum_{x} p(x) log_2 p(x) <= C_channel, with Div(T_munu) = 0 and delta I = 0`
          : `Psi(S) = Sum_{k=1}^N [ alpha_k * exp(-k / tau) * cos(omega_k * t) ] >= 1 - 10^(-epsilon)`,
        invariantBounds: is1000k
          ? [
              `Decidability: Halting state machine tuple (Q, Sigma, delta, q0, F) terminates within finite time tau`,
              `Channel capacity bounds: Transmission rate R < B * log2(1 + S/N)`,
              `Intrinsic metric curvature: Theorema Egregium K remains invariant under all state mappings`,
              `Noether conservation: Continuous symmetry transformations preserve exact transaction currents`,
            ]
          : [
              `Partition monotonicity: Delta P(x) >= 0 for all x in admissible domain`,
              `Zero clock skew: |Delta t_kuttaka| <= 10^(-9) sec`,
              `Minimax Nash equilibrium: E[Payoff(cheat)] < E[Payoff(adhere)] - 0.01`,
              `Relativistic coordinate invariance: Div(T_munu) = 0`,
            ],
        complexityClass: is1000k ? 'O(1) amortized transcendent algorithmic parallel time' : 'O(log n) deterministic polynomial parallel time',
      },
      polymathCouncilReview: [
        {
          personaId: lead.id,
          personaName: lead.name,
          historicalName: lead.historicalName,
          icon: lead.avatarIcon,
          verdict: 'APPROVED',
          cognitivePerspective: lead.cognitiveArchetype,
          mathematicalProofOrFormula: lead.mathematicalFocus,
          concreteRecommendation: `Ensure the state transition matrix maintains integer partition symmetries under scaling. ${lead.keyInvariantPrinciple}`,
        },
        {
          personaId: secondary.id,
          personaName: secondary.name,
          historicalName: secondary.historicalName,
          icon: secondary.avatarIcon,
          verdict: 'APPROVED',
          cognitivePerspective: secondary.cognitiveArchetype,
          mathematicalProofOrFormula: secondary.mathematicalFocus,
          concreteRecommendation: `Structure the component hierarchy such that every visual and logical unit is balanced by ${secondary.keyInvariantPrinciple}`,
        },
        {
          personaId: tertiary.id,
          personaName: tertiary.name,
          historicalName: tertiary.historicalName,
          icon: tertiary.avatarIcon,
          verdict: 'REFINED',
          cognitivePerspective: tertiary.cognitiveArchetype,
          mathematicalProofOrFormula: tertiary.mathematicalFocus,
          concreteRecommendation: `Incorporate adversarial red-teaming checks to verify ${tertiary.keyInvariantPrinciple}`,
        },
        {
          personaId: quaternary.id,
          personaName: quaternary.name,
          historicalName: quaternary.historicalName,
          icon: quaternary.avatarIcon,
          verdict: 'APPROVED',
          cognitivePerspective: quaternary.cognitiveArchetype,
          mathematicalProofOrFormula: quaternary.mathematicalFocus,
          concreteRecommendation: `Calibrate the asynchronous message dispatchers so they resonate cleanly according to ${quaternary.keyInvariantPrinciple}`,
        },
      ],
      transparencyNotice: is1000k
        ? 'DISCLOSURE: This project was architected using the 1,000,000 IQ (1000k IQ) Transcendent Multi-Perspective Algorithmic Reasoning Framework. Personas represent AI behavioral models honoring historical and foundational polymaths (Alan Turing, Claude Shannon, Carl Friedrich Gauss, Emmy Noether, Srinivasa Ramanujan, Leonardo da Vinci, Albert Einstein, John von Neumann, Nikola Tesla, Aryabhata, Chanakya, Ada Lovelace, Bhaskara II, Hypatia, Gottfried Leibniz, Isaac Newton, Richard Feynman), not living or biological persons.'
        : 'DISCLOSURE: This project was architected using the 100,000 IQ Multi-Perspective Algorithmic Reasoning Framework. Personas represent AI behavioral models honoring historical polymaths (Srinivasa Ramanujan, Leonardo da Vinci, Albert Einstein, John von Neumann, Nikola Tesla, Aryabhata, Chanakya, Ada Lovelace, Bhaskara II, Hypatia), not living or biological persons.',
      aiGenerated: true,
      modelUsed: is1000k ? 'deterministic-1000k-iq-polymath-synthesizer' : 'deterministic-100k-iq-polymath-synthesizer',
    };
  }

  /**
   * First-class helper to execute specifically at 1,000,000 IQ (1000k IQ)
   */
  public async execute1000kIqAlgorithm(params: {
    prompt: string;
    answers?: Record<string, string>;
    personaId?: string;
  }): Promise<SuperIqAlgorithmResult> {
    return this.execute100kIqAlgorithm({ ...params, algorithmTier: '1000000iq' });
  }
}

export const superIqAlgorithmEngine = SuperIqAlgorithmEngine.getInstance();
