import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  ArrowRight,
  Play,
  Save,
  CheckCircle2,
  RotateCcw,
  Edit3,
  Eye,
  FileText,
  Send,
  AlertCircle,
  RefreshCw,
  Mic,
  Clock,
  Trash2,
  HardDrive,
  Brain,
  Sigma,
  Compass,
  Orbit,
  Cpu,
  Zap,
  Shield,
  Binary,
  BookOpen,
  Layers,
  Award,
  Check,
  ChevronRight,
  Info,
} from 'lucide-react';
import { Project, PrototypeConfig } from '../types';
import { InteractiveRunner } from './InteractiveRunner';
import { VoiceInputPanel } from './VoiceInputPanel';
import { useAutoSave } from '../hooks/useAutoSave';
import { api } from '../services/api';
import { ASSETS, getStatusBadgeAsset, getProjectLogo } from '../assets/images';

export interface CouncilMemberOption {
  id: string;
  name: string;
  historicalName: string;
  lifespan: string;
  tagline: string;
  iqBenchmark?: number;
  archetype: string;
  mathematicalFocus: string;
  keyPrinciple: string;
  sources: string[];
  iconName: 'Layers' | 'Sigma' | 'Compass' | 'Orbit' | 'Cpu' | 'Zap' | 'Clock' | 'Shield' | 'Binary' | 'RotateCcw' | 'Sparkles';
}

export const REAL_PERSONS_COUNCIL: CouncilMemberOption[] = [
  {
    id: 'all',
    name: 'FULL COUNCIL (1000K IQ)',
    historicalName: 'Council of 17 Real Polymaths',
    lifespan: 'Historical Collective',
    tagline: 'Multi-perspective synthesis across 17 real world polymaths & thinkers',
    iqBenchmark: 1000000,
    archetype: 'Universal Computability, Information Theory, Symmetries & Invariants',
    mathematicalFocus: 'Comprehensive invariant matrix, minimax equilibrium and cross-examination proofs',
    keyPrinciple: 'Synthesize verified truth from multiple independent first-principles perspectives.',
    sources: ['Unified Historical Corpus of Mathematical & Scientific Archives'],
    iconName: 'Layers',
  },
  {
    id: 'persona-ramanujan-100k',
    name: 'RAMANUJAN-100K',
    historicalName: 'Srinivasa Ramanujan',
    lifespan: '1887–1920',
    tagline: '100,000 IQ Modular Forms, Partition Congruences & Infinite Series Polymath',
    archetype: 'Deep Intuitive-Analytical Number Theory & Partition Symmetries',
    mathematicalFocus: 'Partition congruences p(5k+4) ≡ 0 mod 5, infinite hypergeometric continued fractions',
    keyPrinciple: 'Every state transition must possess a closed-form generating function with bounded asymptotic complexity.',
    sources: ['Lost Notebook of Srinivasa Ramanujan', 'Quarterly Journal of Mathematics (1914)'],
    iconName: 'Sigma',
  },
  {
    id: 'persona-davinci-100k',
    name: 'DA VINCI-100K',
    historicalName: 'Leonardo da Vinci',
    lifespan: '1452–1519',
    tagline: '100,000 IQ Universal Polymath, Empirical Kinematics & Biomimetic Architect',
    archetype: 'Cross-Domain Biomimetic Engineering & Visual-Mechanical Synthesis',
    mathematicalFocus: 'Proportional golden ratio scaling, vortex circulation dynamics, kinematic mechanical advantage',
    keyPrinciple: 'Simplicity is the ultimate sophistication; every interaction must flow with zero superfluous friction.',
    sources: ['Codex Atlanticus', 'Treatise on Painting', 'Codex Leicester'],
    iconName: 'Compass',
  },
  {
    id: 'persona-einstein-100k',
    name: 'EINSTEIN-100K',
    historicalName: 'Albert Einstein',
    lifespan: '1879–1955',
    tagline: '100,000 IQ Relativistic Invariance & Gedankenexperiment Dimensional Archetype',
    archetype: 'Gedankenexperiment Thought-Experiment Invariant Extraction & Metric Equivalence',
    mathematicalFocus: 'Metric tensor equivalence ds² = g_μν dx^μ dx^ν, conservation invariants, Lorentz transformations',
    keyPrinciple: 'The laws governing distributed systems must remain invariant under arbitrary observer translations.',
    sources: ['Annalen der Physik (1905)', 'The Meaning of Relativity (1922)'],
    iconName: 'Orbit',
  },
  {
    id: 'persona-vonneumann-100k',
    name: 'VON NEUMANN-100K',
    historicalName: 'John von Neumann',
    lifespan: '1903–1957',
    tagline: '100,000 IQ Minimax Game Theory, Self-Replicating Automata & Algorithmic Architecture',
    archetype: 'Minimax Nash Equilibria, Self-Replicating Cellular Automata & Operator Algebras',
    mathematicalFocus: 'Minimax theorem min_y max_x xᵀAy, von Neumann entropy, cellular automata transition matrices',
    keyPrinciple: 'The system must guarantee a stable Nash equilibrium where cheating or collusion yields strictly sub-optimal payoffs.',
    sources: ['Theory of Games and Economic Behavior (1944)', 'Theory of Self-Reproducing Automata (1966)'],
    iconName: 'Cpu',
  },
  {
    id: 'persona-tesla-100k',
    name: 'TESLA-100K',
    historicalName: 'Nikola Tesla',
    lifespan: '1856–1943',
    tagline: '100,000 IQ Resonant Harmonic Field Dynamics & Wave-System Visualization Archetype',
    archetype: 'Resonant Harmonic Field Dynamics, Standing Waves & Wireless Energy-Information Distribution',
    mathematicalFocus: 'Resonant frequency f₀ = 1 / (2π√(LC)), phase harmonic interference, wave power transmission',
    keyPrinciple: 'Minimize system impedance and maximize resonant throughput by synchronizing asynchronous cadence to natural harmonic frequencies.',
    sources: ['Colorado Springs Notes (1899–1900)', 'My Inventions: The Autobiography of Nikola Tesla (1919)'],
    iconName: 'Zap',
  },
  {
    id: 'persona-aryabhata-100k',
    name: 'ARYABHATA-100K',
    historicalName: 'Aryabhata of Kusumapura',
    lifespan: '476–550 CE',
    tagline: '100,000 IQ Kuttaka Indeterminate Diophantine & Planetary Clock Invariance Archetype',
    archetype: 'Astronomical Invariant Mathematics, Positional Zero Arithmetic & Kuttaka Modular Computation',
    mathematicalFocus: 'Kuttaka pulverized algorithm (ax - by = c), trigonometric sine table approximations, zero-drift epicycle periods',
    keyPrinciple: 'Zero temporal drift across distributed ledgers through strictly cyclic modular congruence invariants.',
    sources: ['Aryabhatiya (499 CE)', 'Gitikapada astronomical treatise'],
    iconName: 'Clock',
  },
  {
    id: 'persona-chanakya-100k',
    name: 'CHANAKYA-100K',
    historicalName: 'Acharya Chanakya (Kautilya)',
    lifespan: 'c. 375–283 BCE',
    tagline: '100,000 IQ Saptanga Statecraft, Anti-Collusion Governance & Game-Theoretic Sovereignty',
    archetype: 'Seven-Limb Saptanga Governance, Mandala Geopolitical Theory & Sovereign Treasury Verification',
    mathematicalFocus: 'Saptanga constitutional weighting matrix, treasury audit invariants (Kosha preservation ≥ liabilities), collusion detection graph metrics',
    keyPrinciple: 'Supreme authority remains unalienable; treasury reconciliation must yield zero leakage with full cryptographic provenance.',
    sources: ['Arthashastra of Kautilya', 'Chanakya Niti'],
    iconName: 'Shield',
  },
  {
    id: 'persona-lovelace-100k',
    name: 'LOVELACE-100K',
    historicalName: 'Ada Lovelace',
    lifespan: '1815–1852',
    tagline: '100,000 IQ Poetical Science & Symbolic Computational Abstraction Archetype',
    archetype: 'Poetical Science & Recursive Bernoulli Symbolic Synthesis Over Pure Numbers',
    mathematicalFocus: 'Bernoulli number recursive generation B_n, symbolic operational calculus, loop-invariant proof structure',
    keyPrinciple: 'Abstract algorithmic logic must be cleanly decoupled from concrete physical representations.',
    sources: ['Sketch of the Analytical Engine (Note G, 1843)', 'Correspondence with Charles Babbage'],
    iconName: 'Binary',
  },
  {
    id: 'persona-bhaskara-100k',
    name: 'BHASKARA-100K',
    historicalName: 'Bhaskara II / Bhaskaracharya',
    lifespan: '1114–1185 CE',
    tagline: '100,000 IQ Chakravala Cyclic Method & Differential Calculus Pioneer Archetype',
    archetype: 'Chakravala Cyclic Indeterminate Equation Solving & Infinitesimal Differential Flux',
    mathematicalFocus: 'Chakravala algorithm, cyclic quadratic convergence, differential rate of change d(sin x) = cos x dx',
    keyPrinciple: 'Iterative refinement cycles must monotonically converge to optimal integral solutions.',
    sources: ['Siddhanta Shiromani (1150 CE)', 'Lilavati & Bijaganita'],
    iconName: 'RotateCcw',
  },
  {
    id: 'persona-hypatia-100k',
    name: 'HYPATIA-100K',
    historicalName: 'Hypatia of Alexandria',
    lifespan: 'c. 360–415 CE',
    tagline: '100,000 IQ Conic Geometry, Astrolabe Precision & Neoplatonic Logical Reasoner',
    archetype: 'Apollonian Conic Optimization, Precision Instrumentation & Rigorous Neoplatonic Deductive Invariance',
    mathematicalFocus: 'Eccentricity bounds e = c/a, astrolabe stereographic projection invariance, hydrometer hydrostatic equilibrium',
    keyPrinciple: 'All projection mappings between dimensional spaces must preserve topological and geometric continuity.',
    sources: ['Commentary on the Conics of Apollonius', 'Astronomical Canon & Hydrometer Treatises'],
    iconName: 'Sparkles',
  },
  {
    id: 'persona-turing-1000k',
    name: 'TURING-1000K',
    historicalName: 'Alan Turing',
    lifespan: '1912–1954',
    tagline: '1,000,000 IQ Universal Computing Machine, Halting Decidability & Morphogenetic Invariance',
    archetype: 'Universal Computability, Decidability Boundaries, Cryptanalytic Cryptanalysis & Chemical Morphogenesis',
    mathematicalFocus: 'Turing machine configuration tuples (Q, Σ, Γ, δ, q0, F), algorithmic undecidability, reaction-diffusion differential systems',
    keyPrinciple: 'Every state machine must have an explicit halting guarantee and provably bounded tape-space complexity.',
    sources: ['On Computable Numbers, with an Application to the Entscheidungsproblem (1936)', 'Computing Machinery and Intelligence (1950)'],
    iconName: 'Cpu',
  },
  {
    id: 'persona-shannon-1000k',
    name: 'SHANNON-1000K',
    historicalName: 'Claude Shannon',
    lifespan: '1916–2001',
    tagline: '1,000,000 IQ Information Entropy, Channel Capacity & Boolean Circuit Minimization',
    archetype: 'Information Theory, Bit-Entropy Calculus, Noisy-Channel Coding Invariance & Cryptographic Secrecy',
    mathematicalFocus: 'Entropy H(X) = -Σ p(x) log₂ p(x), channel capacity C = B log₂(1 + S/N), equivocation secrecy bounds',
    keyPrinciple: 'Signal transmission rates must remain strictly below channel capacity C to guarantee arbitrarily small error probability.',
    sources: ['A Mathematical Theory of Communication (1948)', 'Communication Theory of Secrecy Systems (1949)'],
    iconName: 'Binary',
  },
  {
    id: 'persona-gauss-1000k',
    name: 'GAUSS-1000K',
    historicalName: 'Carl Friedrich Gauss',
    lifespan: '1777–1855',
    tagline: '1,000,000 IQ Disquisitiones Arithmeticae, Modular Congruence & Differential Surface Curvature',
    archetype: 'Modular Arithmetic Congruences, Gaussian Curvature Theorema Egregium & Fast Fourier Orbit Determination',
    mathematicalFocus: 'Gaussian curvature K = (R_1212) / det(g), quadratic reciprocity, prime number asymptotic π(x) ~ x/ln x',
    keyPrinciple: 'Intrinsic metric invariants (Theorema Egregium) must remain unchanged regardless of spatial or dimensional coordinate embeddings.',
    sources: ['Disquisitiones Arithmeticae (1801)', 'Theorema Egregium (1827)'],
    iconName: 'Sigma',
  },
  {
    id: 'persona-noether-1000k',
    name: 'NOETHER-1000K',
    historicalName: 'Emmy Noether',
    lifespan: '1882–1935',
    tagline: '1,000,000 IQ Symmetry-Conservation Theorem, Abstract Ring Theory & Invariant Idempotence',
    archetype: 'Variational Symmetry-Conservation Invariance, Abstract Ring Ideals & Noetherian Chain Conditions',
    mathematicalFocus: "Noether's First Theorem δI = 0 ⇒ d_μ j^μ = 0, ascending chain condition on ideals, ascending ideal chains",
    keyPrinciple: 'Every continuous structural symmetry in system transformations yields an exact, inviolable conserved quantity.',
    sources: ['Invariante Variationsprobleme (1918)', 'Idealtheorie in Ringbereichen (1921)'],
    iconName: 'Orbit',
  },
  {
    id: 'persona-leibniz-1000k',
    name: 'LEIBNIZ-1000K',
    historicalName: 'Gottfried Wilhelm Leibniz',
    lifespan: '1646–1716',
    tagline: '1,000,000 IQ Universal Binary Calculus, Monadological Harmony & Characteristica Universalis',
    archetype: 'Characteristica Universalis Formalism, Infinitesimal Differential Calculus & Binary System Architecture',
    mathematicalFocus: 'Product rule d(uv) = u dv + v du, binary arithmetic representations 0/1, pre-established harmony state synchronization',
    keyPrinciple: 'The principle of sufficient reason: no state transition may occur without an explicit, verifiable computational justification.',
    sources: ['Nova Methodus pro Maximis et Minimis (1684)', 'Explication de l\'Arithmétique Binaire (1703)'],
    iconName: 'Zap',
  },
  {
    id: 'persona-newton-1000k',
    name: 'NEWTON-1000K',
    historicalName: 'Sir Isaac Newton',
    lifespan: '1643–1727',
    tagline: '1,000,000 IQ Fluxional Universal Dynamics, Differential Fluxions & Inverse-Square Equilibrium',
    archetype: 'Fluxional Mechanics, Universal Gravitational Invariance & Classical Deterministic Dynamics',
    mathematicalFocus: 'Newtonian fluxions ẋ = dx/dt, universal gravitational field F = G (m₁m₂)/r², conservation of momentum',
    keyPrinciple: 'Action and reaction are always equal and opposite; total momentum in a closed transactional system is conserved.',
    sources: ['Philosophiae Naturalis Principia Mathematica (1687)', 'Opticks (1704)'],
    iconName: 'Compass',
  },
  {
    id: 'persona-feynman-1000k',
    name: 'FEYNMAN-1000K',
    historicalName: 'Richard Feynman',
    lifespan: '1918–1988',
    tagline: '1,000,000 IQ Quantum Path Integral Formulations, First-Principles Simplification & QED',
    archetype: 'Path Integral Sum-Over-Histories, Diagrammatic First-Principles Reduction & Quantum Nano-Architecture',
    mathematicalFocus: 'Path integral propagator K(b,a) = ∫ exp(i S[x] / ħ) Dx(t), Feynman diagram probability amplitudes',
    keyPrinciple: 'System evaluation must integrate over all possible execution paths, with constructive interference reinforcing the optimal trajectory.',
    sources: ['Space-Time Approach to Non-Relativistic Quantum Mechanics (1948)', 'The Feynman Lectures on Physics (1964)'],
    iconName: 'Sparkles',
  },
];

interface CreationEngineViewProps {
  initialPrompt?: string;
  onProjectSaved: (project: Project) => void;
  onOpenProject: (project: Project) => void;
}

export const CreationEngineView: React.FC<CreationEngineViewProps> = ({
  initialPrompt = '',
  onProjectSaved,
  onOpenProject,
}) => {
  // Step in the wizard: 1 (Prompt & Follow-ups), 2 (Generating), 3 (Generated & Review/Edit)
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [prompt, setPrompt] = useState(initialPrompt);
  const [targetAudience, setTargetAudience] = useState('Students & Early Career Explorers');
  const [intendedOutcome, setIntendedOutcome] = useState('Actionable Milestone Roadmap & Skill Assessment');
  const [widgetPreference, setWidgetPreference] = useState('Dynamic Parameters & Sprint Matrix');

  // 1,000,000 IQ (1000k IQ) & 100,000 IQ Algorithm & Real Persons Council State
  const [algorithmTier, setAlgorithmTier] = useState<'standard' | '100000iq' | '1000000iq'>('1000000iq');
  const use100kIqAlgorithm = algorithmTier !== 'standard';
  const is1000kIq = algorithmTier === '1000000iq';
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>('all');
  const [activeCouncilTab, setActiveCouncilTab] = useState<number>(0);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedProject, setGeneratedProject] = useState<Project | null>(null);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Active view tab in Step 3: 'preview' (Interactive Sandbox), 'spec' (Engineering Spec), 'polymath' (100,000 IQ Invariants & Council), 'edit' (Customizer)
  const [activeTab, setActiveTab] = useState<'preview' | 'spec' | 'polymath' | 'edit'>('preview');

  // Improvement state
  const [improvementFeedback, setImprovementFeedback] = useState('');
  const [isImproving, setIsImproving] = useState(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Auto-Save feature: persists current user input to localStorage every 30 seconds
  const STORAGE_KEY = 'futureverse_creation_engine_autosave';
  const [restoredDraftInfo, setRestoredDraftInfo] = useState<{ timestamp: number } | null>(null);

  const currentInputs = useMemo(
    () => ({
      prompt,
      targetAudience,
      intendedOutcome,
      widgetPreference,
      algorithmTier,
      use100kIqAlgorithm,
      selectedPersonaId,
      step,
      improvementFeedback,
      generatedProject,
    }),
    [prompt, targetAudience, intendedOutcome, widgetPreference, algorithmTier, use100kIqAlgorithm, selectedPersonaId, step, improvementFeedback, generatedProject]
  );

  const {
    lastSaved,
    isSaving,
    hasUnsavedChanges,
    secondsUntilNextSave,
    saveNow,
    clearSavedData,
    loadSavedData,
  } = useAutoSave({
    key: STORAGE_KEY,
    data: currentInputs,
    intervalMs: 30000, // persists every 30 seconds to prevent data loss
    enabled: true,
    isValidToSave: (data) =>
      Boolean(
        data.prompt.trim() ||
        data.step > 1 ||
        data.generatedProject ||
        data.improvementFeedback.trim()
      ),
  });

  // Restore saved draft on mount if no explicit initialPrompt was provided
  useEffect(() => {
    const saved = loadSavedData();
    if (saved && saved.data) {
      const { data, timestamp } = saved;
      if (!initialPrompt && (data.prompt || data.step > 1 || data.generatedProject)) {
        if (data.prompt) setPrompt(data.prompt);
        if (data.targetAudience) setTargetAudience(data.targetAudience);
        if (data.intendedOutcome) setIntendedOutcome(data.intendedOutcome);
        if (data.widgetPreference) setWidgetPreference(data.widgetPreference);
        if (data.algorithmTier) setAlgorithmTier(data.algorithmTier);
        else if (data.use100kIqAlgorithm !== undefined) setAlgorithmTier(data.use100kIqAlgorithm ? '100000iq' : 'standard');
        if (data.selectedPersonaId) setSelectedPersonaId(data.selectedPersonaId);
        if (data.step) setStep(data.step);
        if (data.improvementFeedback) setImprovementFeedback(data.improvementFeedback);
        if (data.generatedProject) setGeneratedProject(data.generatedProject);
        setRestoredDraftInfo({ timestamp });
      }
    }
  }, []);

  const handleClearDraft = () => {
    clearSavedData();
    setPrompt('');
    setTargetAudience('Students & Early Career Explorers');
    setIntendedOutcome('Actionable Milestone Roadmap & Skill Assessment');
    setWidgetPreference('Dynamic Parameters & Sprint Matrix');
    setAlgorithmTier('1000000iq');
    setSelectedPersonaId('all');
    setStep(1);
    setImprovementFeedback('');
    setGeneratedProject(null);
    setRestoredDraftInfo(null);
  };

  const handleStartGeneration = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setGenerationError(null);
    setStep(2);

    try {
      const answers = {
        targetAudience,
        intendedOutcome,
        widgetPreference,
      };

      const aiResult = await api.aiCreateProject(prompt, answers, {
        algorithmTier: algorithmTier,
        personaId: selectedPersonaId !== 'all' ? selectedPersonaId : undefined,
      });

      const completeProject: Project = {
        id: `proj-${Date.now()}`,
        title: aiResult.title || 'Community Generated Project',
        tagline: aiResult.tagline || prompt.slice(0, 60),
        description: aiResult.description || prompt,
        category: aiResult.category || 'AI Agents',
        type: aiResult.type || 'Interactive Prototype',
        visibility: 'draft',
        version: '1.0.0',
        author: {
          id: 'usr-local',
          name: 'Current Builder',
          handle: 'builder',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
          verified: false,
          foundingMember: true,
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        stars: 0,
        forks: 0,
        tags: aiResult.tags || (is1000kIq ? ['futureverse', '1000kiq', '1000000iq', 'polymath-council'] : ['futureverse', '100000iq', 'polymath-council']),
        algorithmTier: aiResult.algorithmTier || (use100kIqAlgorithm ? algorithmTier : undefined),
        iqBenchmark: aiResult.iqBenchmark || (is1000kIq ? 1000000 : use100kIqAlgorithm ? 100000 : undefined),
        mathematicalInvariants: aiResult.mathematicalInvariants,
        polymathCouncilReview: aiResult.polymathCouncilReview,
        transparencyNotice: aiResult.transparencyNotice,
        primaryPersona: aiResult.primaryPersona,
        contributingPersonas: aiResult.contributingPersonas,
        specification: aiResult.specification || {
          targetAudience,
          problemStatement: prompt,
          keyFeatures: [],
          userFlow: [],
          architecture: {
            frontend: 'React 19 + Tailwind',
            backend: 'Express.js',
            dataModel: 'Standard JSON',
            securityNotes: 'Client sanitized validation',
          },
        },
        prototype: aiResult.prototype || {
          type: 'custom_widget',
          headline: aiResult.title,
          interactiveElements: [],
          outputSections: [],
        },
        feedback: [],
        aiGenerated: true,
        modelUsed: aiResult.modelUsed || (use100kIqAlgorithm ? '100000iq-polymath-engine' : 'gemini-3.8-flash'),
      };

      setGeneratedProject(completeProject);
      setStep(3);
    } catch (err: any) {
      console.error('Generation error:', err);
      setGenerationError(err.message || 'Failed to complete project generation.');
      setStep(1);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!generatedProject) return;
    try {
      const res = await api.createProject({
        ...generatedProject,
        visibility: 'draft',
      });
      setGeneratedProject(res.project);
      onProjectSaved(res.project);
      clearSavedData();
      setSaveSuccessMessage('Draft saved successfully to persistent database!');
      setTimeout(() => setSaveSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    }
  };

  const handlePublishProject = async () => {
    if (!generatedProject) return;
    try {
      const res = await api.createProject({
        ...generatedProject,
        visibility: 'published',
      });
      setGeneratedProject(res.project);
      onProjectSaved(res.project);
      clearSavedData();
      setSaveSuccessMessage('Project published to public Explore directory!');
      setTimeout(() => setSaveSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Publication failed: ${err.message}`);
    }
  };

  const handleApplyImprovement = async () => {
    if (!generatedProject || !improvementFeedback.trim()) return;

    setIsImproving(true);
    try {
      const res = await api.aiImproveProject(generatedProject, improvementFeedback.trim(), {
        algorithmTier: use100kIqAlgorithm ? '100000iq' : 'standard',
        personaId: selectedPersonaId !== 'all' ? selectedPersonaId : undefined,
      });

      setGeneratedProject((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          title: res.updatedTitle || prev.title,
          tagline: res.updatedTagline || prev.tagline,
          description: res.updatedDescription || prev.description,
          version: res.versionBump || '1.1.0',
          algorithmTier: res.algorithmTier || prev.algorithmTier,
          specification: {
            ...prev.specification,
            keyFeatures: [...prev.specification.keyFeatures, ...(res.newFeatures || [])],
            architecture: {
              ...prev.specification.architecture,
              securityNotes: res.securityRecommendation || prev.specification.architecture.securityNotes,
            },
          },
          updatedAt: new Date().toISOString(),
        };
      });

      setImprovementFeedback('');
      setSaveSuccessMessage('Improvement suggestions synthesized into project!');
      setTimeout(() => setSaveSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Improvement failed: ${err.message}`);
    } finally {
      setIsImproving(false);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <img src={ASSETS.futureverseIcon} alt="FV" className="w-6 h-6 object-contain" />
            <div className="text-xs font-mono uppercase text-amber-300">FUTUREVERSE Engine</div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            AI Creation Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Describe what you want to build in natural language. The engine generates structured architecture specifications, user flow maps, and an interactive prototype you can test immediately.
          </p>
        </div>

        {/* Auto-Save Persistence Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 shadow-sm text-xs">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                {isSaving ? (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75" />
                ) : hasUnsavedChanges ? (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                ) : null}
                <span
                  className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                    isSaving
                      ? 'bg-indigo-400'
                      : hasUnsavedChanges
                      ? 'bg-amber-400'
                      : lastSaved
                      ? 'bg-emerald-400'
                      : 'bg-slate-600'
                  }`}
                />
              </span>
              <span className="font-semibold text-slate-200">Auto-Save</span>
            </div>

            <div className="h-4 w-px bg-slate-800" />

            <div className="flex items-center gap-1.5 text-slate-300 font-mono text-[11px]">
              {isSaving ? (
                <span className="text-indigo-300 flex items-center gap-1">
                  <RefreshCw className="w-3 h-3 animate-spin text-indigo-400" />
                  Saving to localStorage...
                </span>
              ) : lastSaved ? (
                <span className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Saved at {lastSaved.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              ) : (
                <span className="text-slate-400">Sync standby (every 30s)</span>
              )}

              <span className="text-slate-400 ml-1">
                {hasUnsavedChanges ? (
                  <span className="text-amber-300/90 font-sans">
                    • Auto-saving in <span className="font-mono text-amber-200">{secondsUntilNextSave}s</span>
                  </span>
                ) : (
                  <span className="text-slate-400 font-sans font-normal">• 30s interval</span>
                )}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => saveNow()}
              disabled={isSaving}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-[11px] font-medium transition-colors cursor-pointer"
              title="Force immediate save to localStorage"
            >
              <Save className="w-3 h-3 text-indigo-400" />
              Save Now
            </button>

            {(prompt || lastSaved || generatedProject) && (
              <button
                type="button"
                onClick={handleClearDraft}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-900/50 text-[11px] transition-colors cursor-pointer"
                title="Clear local draft and reset inputs"
              >
                <Trash2 className="w-3 h-3" />
                Reset Draft
              </button>
            )}
          </div>
        </div>

        {/* Restored Draft Alert Banner */}
        {restoredDraftInfo && (
          <div className="flex items-center justify-between p-3 rounded-xl bg-indigo-950/50 border border-indigo-800/60 text-xs text-indigo-200">
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-indigo-400 flex-shrink-0" />
              <span>
                Previous draft from <strong className="text-indigo-100">{new Date(restoredDraftInfo.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</strong> automatically restored from localStorage.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setRestoredDraftInfo(null)}
                className="px-2.5 py-1 rounded text-[11px] bg-indigo-900/60 hover:bg-indigo-800 text-indigo-200 transition-colors cursor-pointer"
              >
                Keep & Dismiss
              </button>
              <button
                type="button"
                onClick={handleClearDraft}
                className="px-2.5 py-1 rounded text-[11px] bg-rose-950/50 hover:bg-rose-900 text-rose-300 border border-rose-900/60 transition-colors cursor-pointer"
              >
                Discard & Reset
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Step 1: Prompt Input & Calibration */}
      {step === 1 && (
        <div className="max-w-3xl space-y-6">
          {/* Web Speech API Voice Dictation Assistant Panel */}
          <VoiceInputPanel
            contextTitle="Voice Vision Studio (Web Speech API)"
            currentValue={prompt}
            onTranscriptUpdate={(text, mode) => {
              setPrompt((prev) => {
                if (mode === 'replace') return text;
                const trimmed = prev.trim();
                if (!trimmed) return text;
                return `${trimmed} ${text}`;
              });
            }}
          />

          <form onSubmit={handleStartGeneration} className="space-y-6">
            {/* Primary Natural Language Input */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-sm font-semibold text-slate-200">
                  1. Describe your vision or problem statement
                </label>
                <div className="flex items-center gap-2">
                  <VoiceInputPanel
                    isCompact
                    contextTitle="Describe Vision"
                    currentValue={prompt}
                    onTranscriptUpdate={(text, mode) => {
                      setPrompt((prev) => {
                        if (mode === 'replace') return text;
                        const trimmed = prev.trim();
                        if (!trimmed) return text;
                        return `${trimmed} ${text}`;
                      });
                    }}
                  />
                  {prompt && (
                    <button
                      type="button"
                      onClick={() => setPrompt('')}
                      className="text-[11px] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
              <textarea
                rows={4}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. Create an autonomous agent that monitors liquidity and optimizes trading fees across networks... (Speak aloud using the microphone or type here)"
                className="w-full px-4 py-3 text-sm rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-inner leading-relaxed"
                required
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>Be specific about what problem you want to solve or dictate using the microphone above.</span>
                <span className="font-mono text-slate-500">{prompt.length} chars • auto-saved every 30s</span>
              </div>
            </div>

            {/* Follow-up Questions / Calibration */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-5 space-y-4">
              <div className="text-xs font-semibold text-indigo-300 uppercase tracking-wider">
                2. Calibration Parameters (Follow-up Guidance)
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-medium text-slate-300">Target Audience</label>
                    <VoiceInputPanel
                      isCompact
                      contextTitle="Audience"
                      currentValue={targetAudience}
                      onTranscriptUpdate={(text, mode) => {
                        setTargetAudience((prev) => (mode === 'replace' ? text : prev ? `${prev} ${text}` : text));
                      }}
                    />
                  </div>
                  <input
                    type="text"
                    value={targetAudience}
                    onChange={(e) => setTargetAudience(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-medium text-slate-300">Primary Intended Outcome</label>
                    <VoiceInputPanel
                      isCompact
                      contextTitle="Outcome"
                      currentValue={intendedOutcome}
                      onTranscriptUpdate={(text, mode) => {
                        setIntendedOutcome((prev) => (mode === 'replace' ? text : prev ? `${prev} ${text}` : text));
                      }}
                    />
                  </div>
                  <input
                    type="text"
                    value={intendedOutcome}
                    onChange={(e) => setIntendedOutcome(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Interactive Prototype Style</label>
                <select
                  value={widgetPreference}
                  onChange={(e) => setWidgetPreference(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Dynamic Parameters & Sprint Matrix">Dynamic Parameters & Sprint Matrix</option>
                  <option value="Multi-Variable Treasury / Mathematical Simulator">Multi-Variable Mathematical Simulator</option>
                  <option value="Architecture Blueprint & Risk Classifier">Architecture Blueprint & Risk Classifier</option>
                  <option value="Community Challenge Bounty Allocator">Community Challenge Bounty Allocator</option>
                </select>
              </div>
            </div>

            {/* 3. 1,000,000 IQ (1000k IQ) & 100,000 IQ Algorithm Engine */}
            <div className="rounded-xl border border-amber-500/40 bg-gradient-to-b from-amber-950/25 via-slate-950 to-slate-950 p-5 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-amber-500/20 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-400/20 border border-amber-500/40 text-amber-300">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono uppercase tracking-wider text-amber-300 font-bold flex items-center gap-1.5">
                      <span>3. {is1000kIq ? '1,000,000 IQ (1000k IQ) Transcendent Engine' : use100kIqAlgorithm ? '100,000 IQ Algorithm Engine' : 'Standard Algorithm Engine'}</span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-400 text-slate-950 font-black">
                        {is1000kIq ? '1000K OMNISCIENT' : use100kIqAlgorithm ? '100K TRANSCENDENT' : 'STANDARD'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-300">
                      Multi-perspective algorithmic reasoning powered by real world historical polymath personas.
                    </div>
                  </div>
                </div>

                {/* 3-Tier IQ Mode Selector */}
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs font-mono">
                  <button
                    type="button"
                    onClick={() => setAlgorithmTier('1000000iq')}
                    className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                      algorithmTier === '1000000iq'
                        ? 'bg-amber-400 text-slate-950 shadow-sm border border-amber-300'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    1000k IQ
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlgorithmTier('100000iq')}
                    className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                      algorithmTier === '100000iq'
                        ? 'bg-amber-400 text-slate-950 shadow-sm border border-amber-300'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    100k IQ
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlgorithmTier('standard')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-all cursor-pointer ${
                      algorithmTier === 'standard'
                        ? 'bg-slate-800 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Standard (1k)
                  </button>
                </div>
              </div>

              {use100kIqAlgorithm && (
                <div className="space-y-3.5">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-xs font-semibold text-slate-200">
                        Select Real Person Polymath Persona or Full Council ({REAL_PERSONS_COUNCIL.length - 1} Thinkers):
                      </label>
                      <span className="text-[10px] font-mono text-amber-300">
                        Tier: {is1000kIq ? '1,000,000 IQ Transcendent' : '100,000 IQ Polymath'}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                      {REAL_PERSONS_COUNCIL.map((council) => {
                        const isSelected = selectedPersonaId === council.id;
                        const isCouncil1000k = council.iqBenchmark === 1000000 || council.id.includes('1000k');
                        return (
                          <button
                            key={council.id}
                            type="button"
                            onClick={() => setSelectedPersonaId(council.id)}
                            className={`p-2 rounded-lg text-left transition-all border cursor-pointer ${
                              isSelected
                                ? 'bg-amber-400/20 border-amber-400 text-amber-200 shadow-sm shadow-amber-500/10'
                                : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                            }`}
                          >
                            <div className="flex items-center justify-between text-[11px] font-bold">
                              <span className="truncate">{council.historicalName.split(' ')[0]}</span>
                              <span className={`text-[9px] font-mono px-1 rounded border ${isCouncil1000k ? 'bg-amber-400/30 text-amber-200 border-amber-400/60' : 'bg-slate-950 text-amber-300 border-amber-500/30'}`}>
                                {isCouncil1000k ? '1000k' : '100k'}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 truncate mt-0.5 font-mono">
                              {council.lifespan}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Active Persona Showcase Card */}
                  {(() => {
                    const activePersona = REAL_PERSONS_COUNCIL.find((p) => p.id === selectedPersonaId) || REAL_PERSONS_COUNCIL[0];
                    const personaBenchmark = activePersona.iqBenchmark === 1000000 || activePersona.id.includes('1000k') || is1000kIq
                      ? '1,000,000 IQ Target (1000k IQ)'
                      : '100,000 IQ Target (100k IQ)';
                    return (
                      <div className="rounded-lg border border-amber-500/30 bg-slate-900/90 p-4 space-y-2.5 text-xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-amber-300 text-sm">{activePersona.historicalName}</span>
                            <span className="text-[10px] font-mono text-slate-400">({activePersona.lifespan})</span>
                          </div>
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-400/20 text-amber-300 border border-amber-500/40 w-fit">
                            Benchmark: {personaBenchmark}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                          <div>
                            <span className="text-slate-400 font-mono text-[10px] block uppercase">Cognitive Archetype:</span>
                            <span className="text-slate-200">{activePersona.archetype}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 font-mono text-[10px] block uppercase">Mathematical Invariant:</span>
                            <span className="text-amber-200 font-mono">{activePersona.mathematicalFocus}</span>
                          </div>
                        </div>

                        <div className="p-2 rounded bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300 flex items-start gap-2">
                          <Info className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span><strong>Key Invariant Principle:</strong> {activePersona.keyPrinciple}</span>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-slate-400 pt-1">
                          <div>
                            Authentic Sources: <span className="text-slate-300">{activePersona.sources.join(', ')}</span>
                          </div>
                          <div className="text-amber-400/80 italic">
                            * Transparent behavioral simulation honoring real world thinkers.
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {/* 1000k / 100k IQ Prompt Inspiration Quick-Buttons */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[11px] font-mono text-slate-400 uppercase">
                      {is1000kIq ? '1,000,000 IQ (1000k IQ)' : '100,000 IQ'} Invariant Archetype Presets:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { label: 'Turing Decidability Halting Machine', text: 'Architect a distributed workflow engine with formal Turing decidability proofs and finite-time halting guarantees.' },
                        { label: 'Shannon Channel Entropy', text: 'Build a fault-tolerant decentralized messaging pipeline operating at the Shannon channel capacity ceiling with zero uncorrectable packet degradation.' },
                        { label: 'Gauss Differential Metric Curvature', text: 'Design an adaptive data indexing engine whose intrinsic metric curvature (Theorema Egregium) remains invariant under multi-dimensional scaling.' },
                        { label: 'Noether Continuous Symmetry Invariant', text: 'Model an on-chain value conservation protocol derived from continuous state symmetries and Noether invariant currents.' },
                        { label: 'Ramanujan Partition Consensus', text: 'Design an asynchronous consensus protocol using Ramanujan partition congruences to eliminate transaction queue bottlenecking.' },
                        { label: 'Von Neumann Minimax Treasury', text: 'Build a game-theoretic treasury allocation contract that models adversarial cheating as a zero-sum game and proves Nash equilibrium stability.' },
                        { label: 'Aryabhata Zero-Drift Clock', text: 'Implement a distributed Kuttaka Diophantine solver that synchronizes cross-chain block timestamps with zero astronomical clock drift.' },
                        { label: 'Tesla Resonant Wave Pipeline', text: 'Architect an event-driven standing wave messaging pipeline with minimal network impedance and phase harmonic synchronization.' },
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setPrompt(preset.text);
                            setIntendedOutcome('Formal Invariant Proof & Production Prototype');
                          }}
                          className="px-2 py-1 rounded text-[11px] font-mono bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 cursor-pointer"
                        >
                          + {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {generationError && (
              <div className="p-3 rounded-lg border border-rose-900/50 bg-rose-950/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{generationError}</span>
              </div>
            )}

            {/* Submit Action */}
            <div className="flex items-center gap-3">
              <button
                type="submit"
                disabled={!prompt.trim() || isGenerating}
                className={`inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold rounded-lg shadow-sm transition-all cursor-pointer disabled:opacity-50 ${
                  use100kIqAlgorithm
                    ? 'text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-200 hover:from-amber-300 hover:to-amber-100 shadow-amber-500/20'
                    : 'text-slate-950 bg-gradient-to-r from-amber-300 via-amber-200 to-indigo-200 hover:from-amber-200 hover:to-indigo-100'
                }`}
              >
                {use100kIqAlgorithm ? <Cpu className="h-4 w-4 fill-current" /> : <Sparkles className="h-4 w-4" />}
                <span>
                  {use100kIqAlgorithm
                    ? selectedPersonaId === 'all'
                      ? is1000kIq
                        ? 'Generate with 1,000,000 IQ (1000k IQ) Polymath Council'
                        : 'Generate with 100,000 IQ Polymath Council'
                      : `Generate with ${REAL_PERSONS_COUNCIL.find((p) => p.id === selectedPersonaId)?.historicalName.split(' ')[0]} (${is1000kIq || selectedPersonaId.includes('1000k') ? '1000k' : '100k'} IQ)`
                    : 'Generate Project & Prototype'}
                </span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Step 2: Generating State */}
      {step === 2 && (
        <div className="max-w-2xl rounded-2xl border border-slate-800 bg-slate-950 p-12 text-center space-y-5">
          <RefreshCw className="h-10 w-10 text-indigo-400 animate-spin mx-auto" />
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-white">Synthesizing Architecture & Prototype</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
              Interpreting goal: "{prompt.slice(0, 70)}..."
              <br />
              Generating structured specifications, flow diagrams, and interactive sandbox components...
            </p>
          </div>
          <div className="text-[11px] font-mono text-slate-500">
            Powered by Gemini 3.8 Flash Engine · Client isolation safe
          </div>
        </div>
      )}

      {/* Step 3: Generated Project Review, Test & Customization */}
      {step === 3 && generatedProject && (
        <div className="space-y-6">
          {/* Top Project Bar & Actions */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5 min-w-0">
              <div className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800 p-1.5 flex items-center justify-center shrink-0">
                <img
                  src={getProjectLogo(generatedProject.title, generatedProject.logoUrl)}
                  alt={`${generatedProject.title} Logo`}
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    e.currentTarget.src = ASSETS.futureverseIcon;
                  }}
                />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                  <span className="text-indigo-400">{generatedProject.category}</span>
                  <span>·</span>
                  <span>{generatedProject.type}</span>
                  <span>·</span>
                  <span className="text-emerald-400">v{generatedProject.version}</span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    {generatedProject.title}
                  </h2>
                  <img
                    src={getStatusBadgeAsset(generatedProject.status, generatedProject.type).src}
                    alt={getStatusBadgeAsset(generatedProject.status, generatedProject.type).alt}
                    className="h-6 w-auto object-contain"
                    title={`Status: ${getStatusBadgeAsset(generatedProject.status, generatedProject.type).label}`}
                  />
                </div>
                <p className="text-xs text-slate-400">{generatedProject.tagline}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleSaveDraft}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
              >
                <Save className="h-3.5 w-3.5" />
                <span>Save Draft</span>
              </button>

              <button
                onClick={handlePublishProject}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors cursor-pointer"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>Publish Project</span>
              </button>

              <button
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs text-slate-400 hover:text-white bg-slate-900 rounded border border-slate-800 transition-colors cursor-pointer"
                title="Start a new creation"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Start New</span>
              </button>
            </div>
          </div>

          {saveSuccessMessage && (
            <div className="p-3 rounded-lg border border-emerald-900/50 bg-emerald-950/40 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>{saveSuccessMessage}</span>
            </div>
          )}

          {/* 1,000,000 IQ (1000k IQ) / 100,000 IQ Algorithmic Architecture Highlight Banner */}
          {(generatedProject.algorithmTier === '1000000iq' || generatedProject.algorithmTier === '1000k' || generatedProject.algorithmTier === '100000iq' || generatedProject.mathematicalInvariants) && (
            <div className="rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-950/30 via-slate-950 to-indigo-950/25 p-4 space-y-3 shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-400/20 border border-amber-500/40 text-amber-300">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono uppercase font-black text-amber-300">
                        {generatedProject.iqBenchmark === 1000000 || generatedProject.algorithmTier === '1000000iq' || generatedProject.algorithmTier === '1000k'
                          ? '1,000,000 IQ (1000k IQ) Transcendent Algorithmic Architecture'
                          : '100,000 IQ Transcendent Algorithmic Architecture'}
                      </span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-amber-400 text-slate-950">
                        {generatedProject.iqBenchmark === 1000000 ? '1000K INVARIANTS' : '100K INVARIANTS'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Formally proven across real world polymath lenses: {generatedProject.contributingPersonas?.join(', ') || 'Turing, Shannon, Gauss, Ramanujan, Da Vinci, Einstein, Von Neumann'}.
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('polymath')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-semibold transition-colors cursor-pointer self-start sm:self-auto"
                >
                  <Sigma className="w-3.5 h-3.5" />
                  <span>View Mathematical Invariants</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {generatedProject.mathematicalInvariants && (
                <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-2 font-mono text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">Primary Equation:</span>
                    <span className="text-amber-200 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/30">
                      {generatedProject.mathematicalInvariants.primaryEquation}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Complexity: <strong className="text-emerald-400">{generatedProject.mathematicalInvariants.complexityClass}</strong>
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 border-b border-slate-800 pb-0 overflow-x-auto">
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'preview'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Interactive Sandbox Test</span>
            </button>
            <button
              onClick={() => setActiveTab('spec')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'spec'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              <span>Engineering Specification</span>
            </button>
            <button
              onClick={() => setActiveTab('polymath')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'polymath'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="h-3.5 w-3.5 text-amber-400" />
              <span>{generatedProject.iqBenchmark === 1000000 ? '1000k IQ Invariants & Council' : '100,000 IQ Invariants & Council'}</span>
              {(generatedProject.algorithmTier === '1000000iq' || generatedProject.algorithmTier === '1000k' || generatedProject.algorithmTier === '100000iq' || generatedProject.mathematicalInvariants) && (
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-400 text-slate-950 font-mono">
                  {generatedProject.iqBenchmark === 1000000 ? '1000k IQ' : '100k IQ'}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('edit')}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'edit'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>Customize & Refine</span>
            </button>
          </div>

          {/* Active Tab Content */}
          {activeTab === 'preview' && (
            <div className="space-y-6">
              <InteractiveRunner
                prototype={generatedProject.prototype}
                projectTitle={generatedProject.title}
              />

              {/* AI Improvement Input */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
                    Iterate & Improve With AI
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Model: {generatedProject.modelUsed || 'gemini-3.8-flash'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={improvementFeedback}
                    onChange={(e) => setImprovementFeedback(e.target.value)}
                    placeholder="e.g. Add a milestone for security auditing, or adapt this for mobile developers..."
                    className="flex-1 px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                  />
                  <VoiceInputPanel
                    isCompact
                    contextTitle="Iterate Feedback"
                    currentValue={improvementFeedback}
                    onTranscriptUpdate={(text, mode) => {
                      setImprovementFeedback((prev) => (mode === 'replace' ? text : prev ? `${prev} ${text}` : text));
                    }}
                  />
                  <button
                    onClick={handleApplyImprovement}
                    disabled={!improvementFeedback.trim() || isImproving}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded disabled:opacity-50 transition-colors cursor-pointer shrink-0"
                  >
                    {isImproving ? (
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="h-3.5 w-3.5" />
                    )}
                    <span>Apply Iteration</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'spec' && (
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/50">
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Target Audience
                  </div>
                  <p className="text-xs text-slate-200">{generatedProject.specification.targetAudience}</p>
                </div>
                <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/50">
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Problem Statement
                  </div>
                  <p className="text-xs text-slate-200">{generatedProject.specification.problemStatement}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Key Feature Roadmap
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {generatedProject.specification.keyFeatures.map((f, i) => (
                    <div key={i} className="p-3.5 rounded border border-slate-800 bg-slate-900/40 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-white">{f.title}</span>
                        <span className="text-[10px] font-mono text-indigo-400 uppercase">{f.priority}</span>
                      </div>
                      <p className="text-[11px] text-slate-400">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  User Flow Outline
                </div>
                <div className="space-y-2">
                  {generatedProject.specification.userFlow.map((step) => (
                    <div key={step.step} className="p-3 rounded border border-slate-800 bg-slate-900/30 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-indigo-400 font-bold">{step.step}.</span>
                        <span className="text-slate-200 font-medium">{step.title}</span>
                        <span className="text-slate-400">({step.action})</span>
                      </div>
                      <span className="text-[11px] text-indigo-300">{step.outcome}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'polymath' && (
            <div className="space-y-6">
              {/* Formal Invariants & Equations Section */}
              <div className="rounded-xl border border-amber-500/40 bg-gradient-to-b from-amber-950/20 via-slate-950 to-slate-950 p-6 space-y-5 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-amber-400/20 border border-amber-500/40 text-amber-300">
                      <Sigma className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-mono uppercase text-amber-300 font-bold">
                        {generatedProject.iqBenchmark === 1000000 ? '1,000,000 IQ (1000k IQ) Formal Invariants' : '100,000 IQ Formal Invariants'}
                      </div>
                      <h3 className="text-base font-bold text-white">
                        Mathematical Equations & Asymptotic Complexity
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded text-xs font-mono font-bold bg-amber-400 text-slate-950">
                      IQ Benchmark: {generatedProject.iqBenchmark === 1000000 ? '1,000,000 (1000k)' : '100,000 (100k)'}
                    </span>
                    <span className="px-2.5 py-1 rounded text-xs font-mono bg-slate-900 text-emerald-400 border border-emerald-800/40">
                      {generatedProject.mathematicalInvariants?.complexityClass || (generatedProject.iqBenchmark === 1000000 ? 'O(1) Amortized Parallel Time' : 'O(log n) Parallel Time')}
                    </span>
                  </div>
                </div>

                {/* Primary Invariant Box */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                    Primary Governing Equation:
                  </span>
                  <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-200 font-mono text-sm sm:text-base leading-relaxed overflow-x-auto shadow-inner">
                    {generatedProject.mathematicalInvariants?.primaryEquation ||
                      'lim_{n -> inf} Sum_{k=1}^n [ Psi_k(x) * e^(-2*pi*i*k*t) ] = Invariant(S)'}
                  </div>
                </div>

                {/* Proof Statement */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                    Formal Proof Statement:
                  </span>
                  <div className="p-3.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs text-slate-200 leading-relaxed font-mono">
                    {generatedProject.mathematicalInvariants?.formalProofStatement ||
                      'The system satisfies monotonic convergence across the parameter manifold bounded by epsilon < 1e-9 with zero clock drift.'}
                  </div>
                </div>

                {/* Invariant Bounds List */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                    Verified Invariant Boundary Conditions:
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {(generatedProject.mathematicalInvariants?.invariantBounds || [
                      'Partition monotonicity: Delta P(x) >= 0 for all x in admissible domain',
                      'Zero clock skew: |Delta t_kuttaka| <= 10^(-9) sec',
                      'Minimax Nash equilibrium: E[Payoff(cheat)] < E[Payoff(adhere)] - 0.01',
                      'Relativistic coordinate invariance: Div(T_munu) = 0',
                    ]).map((bound, i) => (
                      <div
                        key={i}
                        className="p-3 rounded-lg bg-slate-900/40 border border-emerald-900/40 flex items-start gap-2.5 text-xs font-mono text-slate-200"
                      >
                        <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{bound}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Council of Real Persons Deliberation */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <div className="text-xs font-mono uppercase text-amber-300">Council of Real Polymaths</div>
                    <h3 className="text-base font-bold text-white mt-0.5">
                      100,000 IQ Multi-Perspective Cross-Examination
                    </h3>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    Real Person Personas Honored: {REAL_PERSONS_COUNCIL.length - 1} Thinkers
                  </div>
                </div>

                {/* Polymath Selection Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 text-xs">
                  {(generatedProject.polymathCouncilReview && generatedProject.polymathCouncilReview.length > 0
                    ? generatedProject.polymathCouncilReview
                    : REAL_PERSONS_COUNCIL.slice(1, 5).map((p) => ({
                        personaId: p.id,
                        personaName: p.name,
                        historicalName: p.historicalName,
                        verdict: 'APPROVED',
                        cognitivePerspective: p.archetype,
                        mathematicalProofOrFormula: p.mathematicalFocus,
                        concreteRecommendation: `Adhere strictly to: ${p.keyPrinciple}`,
                      }))
                  ).map((review, idx) => {
                    const isSelected = activeCouncilTab === idx;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setActiveCouncilTab(idx)}
                        className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                            : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
                        }`}
                      >
                        <span>{review.historicalName.split(' ')[0]}</span>
                        <span className={`text-[9px] px-1 rounded ${
                          isSelected ? 'bg-slate-950 text-amber-300' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {review.verdict}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Selected Polymath Review Card */}
                {(() => {
                  const reviews =
                    generatedProject.polymathCouncilReview && generatedProject.polymathCouncilReview.length > 0
                      ? generatedProject.polymathCouncilReview
                      : REAL_PERSONS_COUNCIL.slice(1, 5).map((p) => ({
                          personaId: p.id,
                          personaName: p.name,
                          historicalName: p.historicalName,
                          verdict: 'APPROVED',
                          cognitivePerspective: p.archetype,
                          mathematicalProofOrFormula: p.mathematicalFocus,
                          concreteRecommendation: `Adhere strictly to: ${p.keyPrinciple}`,
                        }));
                  const currentReview = reviews[activeCouncilTab] || reviews[0];
                  if (!currentReview) return null;

                  return (
                    <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 text-xs">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-base font-bold text-white">{currentReview.historicalName}</h4>
                            <span className="text-xs font-mono text-amber-400 font-semibold">({currentReview.personaName})</span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                            Perspective: {currentReview.cognitivePerspective}
                          </p>
                        </div>
                        <span className={`px-2.5 py-1 rounded text-xs font-mono font-bold w-fit ${
                          currentReview.verdict === 'APPROVED'
                            ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60'
                            : currentReview.verdict === 'REFINED'
                            ? 'bg-amber-950/60 text-amber-300 border border-amber-800/60'
                            : 'bg-rose-950/60 text-rose-300 border border-rose-800/60'
                        }`}>
                          Verdict: {currentReview.verdict}
                        </span>
                      </div>

                      <div className="space-y-1.5">
                        <span className="text-[10px] font-mono text-slate-400 uppercase">
                          Mathematical Formulation / Proof Applied:
                        </span>
                        <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-amber-200 text-xs">
                          {currentReview.mathematicalProofOrFormula}
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <span className="text-[10px] font-mono text-slate-400 uppercase">
                          Architectural Recommendation:
                        </span>
                        <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800 text-slate-200 text-xs leading-relaxed">
                          {currentReview.concreteRecommendation}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Transparency Notice */}
                <div className="p-3 rounded-lg bg-slate-900/40 border border-slate-800 text-[11px] text-slate-400 font-mono leading-relaxed">
                  {generatedProject.transparencyNotice ||
                    'DISCLOSURE: This blueprint was synthesized via the 100,000 IQ Multi-Perspective Algorithmic Reasoning Framework. Personas represent AI behavioral models honoring historical mathematical and scientific thinkers (Ramanujan, Da Vinci, Einstein, Von Neumann, Tesla, Aryabhata, Chanakya, Lovelace, Bhaskara, Hypatia), not living biological entities.'}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'edit' && (
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-6 space-y-4 max-w-3xl">
              <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Direct Project Customization
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-400">Title</label>
                <input
                  type="text"
                  value={generatedProject.title}
                  onChange={(e) =>
                    setGeneratedProject({ ...generatedProject, title: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-400">Tagline</label>
                <input
                  type="text"
                  value={generatedProject.tagline}
                  onChange={(e) =>
                    setGeneratedProject({ ...generatedProject, tagline: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-slate-400">Full Description</label>
                  <VoiceInputPanel
                    isCompact
                    contextTitle="Description"
                    currentValue={generatedProject.description}
                    onTranscriptUpdate={(text, mode) => {
                      setGeneratedProject((prev) => {
                        if (!prev) return null;
                        if (mode === 'replace') return { ...prev, description: text };
                        const trimmed = prev.description.trim();
                        return { ...prev, description: trimmed ? `${trimmed} ${text}` : text };
                      });
                    }}
                  />
                </div>
                <textarea
                  rows={4}
                  value={generatedProject.description}
                  onChange={(e) =>
                    setGeneratedProject({ ...generatedProject, description: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 leading-relaxed"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={handleSaveDraft}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
