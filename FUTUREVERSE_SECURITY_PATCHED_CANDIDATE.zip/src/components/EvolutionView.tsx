import React, { useState } from 'react';
import { ThumbsUp, Plus, ShieldCheck, CheckCircle2, Clock, Filter, AlertCircle, MessageSquare } from 'lucide-react';
import { EvolutionItem, EvolutionCategory, EvolutionStatus } from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';

interface EvolutionViewProps {
  items: EvolutionItem[];
  onRefresh: () => void;
}

export const EvolutionView: React.FC<EvolutionViewProps> = ({ items, onRefresh }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isReviewerMode, setIsReviewerMode] = useState(false);

  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<EvolutionCategory>('Engineering');
  const [newDescription, setNewDescription] = useState('');
  const [proposerName, setProposerName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Review state
  const [selectedItemForReview, setSelectedItemForReview] = useState<EvolutionItem | null>(null);
  const [reviewStatus, setReviewStatus] = useState<EvolutionStatus>('UNDER REVIEW');
  const [reviewNotes, setReviewNotes] = useState('');
  const [isSavingReview, setIsSavingReview] = useState(false);

  const categories = [
    'All',
    'Engineering',
    'UI/UX',
    'Testing',
    'Documentation',
    'Accessibility',
    'Security',
  ];

  const statuses = [
    'All',
    'SUBMITTED',
    'UNDER REVIEW',
    'SELECTED',
    'BUILDING',
    'TESTING',
    'RELEASED',
  ];

  const filteredItems = items.filter((item) => {
    if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
    if (selectedStatus !== 'All' && item.status !== selectedStatus) return false;
    return true;
  });

  const handleVote = async (id: string) => {
    try {
      await api.voteEvolutionItem(id);
      onRefresh();
    } catch (err: any) {
      alert(`Vote failed: ${err.message}`);
    }
  };

  const handleSubmitProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    setIsSubmitting(true);
    try {
      await api.submitEvolutionItem({
        title: newTitle.trim(),
        category: newCategory,
        description: newDescription.trim(),
        proposer: {
          name: proposerName.trim() || 'Community Builder',
        },
      });
      setIsSubmitModalOpen(false);
      setNewTitle('');
      setNewDescription('');
      onRefresh();
    } catch (err: any) {
      alert(`Proposal submission failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveReview = async () => {
    if (!selectedItemForReview) return;
    setIsSavingReview(true);
    try {
      await api.updateEvolutionStatus(selectedItemForReview.id, {
        status: reviewStatus,
        reviewNotes: reviewNotes.trim(),
        reviewer: 'Core Governance Reviewer',
      });
      setSelectedItemForReview(null);
      setReviewNotes('');
      onRefresh();
    } catch (err: any) {
      alert(`Status update failed: ${err.message}`);
    } finally {
      setIsSavingReview(false);
    }
  };

  const getStatusColor = (status: EvolutionStatus) => {
    switch (status) {
      case 'RELEASED':
        return 'text-emerald-400 border-emerald-800/80 bg-emerald-950/40';
      case 'TESTING':
        return 'text-cyan-400 border-cyan-800/80 bg-cyan-950/40';
      case 'BUILDING':
        return 'text-amber-400 border-amber-800/80 bg-amber-950/40';
      case 'SELECTED':
        return 'text-indigo-400 border-indigo-800/80 bg-indigo-950/40';
      case 'UNDER REVIEW':
        return 'text-purple-400 border-purple-800/80 bg-purple-950/40';
      default:
        return 'text-slate-400 border-slate-800 bg-slate-900/50';
    }
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-8">
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src={ASSETS.communityEvolutionBoard}
            alt="Evolution Studio"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/40" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="text-xs font-mono uppercase text-indigo-400">Platform Governance</div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Evolution Board
            </h1>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Help shape the FUTUREVERSE platform itself. Submit feature requests, report bugs, propose architectural improvements, and vote on prioritized initiatives.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Reviewer / Admin mode toggle */}
            <button
              onClick={() => setIsReviewerMode(!isReviewerMode)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded border transition-colors cursor-pointer ${
                isReviewerMode
                  ? 'border-indigo-600 bg-indigo-950 text-indigo-200'
                  : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>{isReviewerMode ? 'Reviewer Mode Active' : 'Switch to Reviewer'}</span>
            </button>

            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded-md transition-all cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Propose Improvement</span>
            </button>
          </div>
        </div>
      </div>

      {/* Lifecycle Status Bar Explanation */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
        <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-2">
          Evolution Lifecycle Pipeline
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-center text-xs font-mono">
          {['SUBMITTED', 'UNDER REVIEW', 'SELECTED', 'BUILDING', 'TESTING', 'RELEASED'].map((st, i) => (
            <div key={st} className="p-2 rounded bg-slate-950/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-500 block">Stage 0{i + 1}</span>
              <span className="text-slate-200 font-semibold">{st}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Category & Status Filter Tabs */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800 max-w-fit">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                selectedCategory === cat ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-mono text-[11px] uppercase">Status Filter:</span>
          <div className="flex flex-wrap gap-1">
            {statuses.map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                  selectedStatus === st
                    ? 'bg-indigo-950/70 border border-indigo-700/60 text-indigo-200'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Evolution Items List */}
      <div className="space-y-3">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 hover:border-slate-700 transition-all shadow-sm space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-indigo-400">{item.category}</span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400">By {item.proposer.name}</span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-500">{new Date(item.createdAt).toLocaleDateString()}</span>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <span
                  className={`text-[11px] font-mono font-semibold px-2.5 py-0.5 rounded border ${getStatusColor(
                    item.status
                  )}`}
                >
                  {item.status}
                </span>

                {isReviewerMode && (
                  <button
                    onClick={() => {
                      setSelectedItemForReview(item);
                      setReviewStatus(item.status);
                      setReviewNotes(item.reviewNotes || '');
                    }}
                    className="px-2 py-0.5 text-[11px] font-mono bg-indigo-900/50 hover:bg-indigo-800/60 text-indigo-200 rounded border border-indigo-700 cursor-pointer"
                  >
                    Review / Transition
                  </button>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-base font-bold text-white">{item.title}</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{item.description}</p>
            </div>

            {/* Official Review Notes */}
            {item.reviewNotes && (
              <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-950/70 text-xs">
                <div className="text-[11px] font-semibold text-slate-400 font-mono flex items-center justify-between">
                  <span>Official Review Note ({item.reviewedBy || 'Review Committee'})</span>
                  {item.reviewedAt && (
                    <span className="text-slate-500">{new Date(item.reviewedAt).toLocaleDateString()}</span>
                  )}
                </div>
                <p className="text-slate-300 text-xs mt-1 leading-relaxed">{item.reviewNotes}</p>
              </div>
            )}

            {/* Footer with Voting */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleVote(item.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
                >
                  <ThumbsUp className="h-3 w-3" />
                  <span className="tabular-nums font-bold">{item.votes}</span>
                  <span className="text-slate-400 text-[11px]">Votes</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Propose Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Propose Platform Evolution</h3>
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitProposal} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-300">Title</label>
                <input
                  type="text"
                  placeholder="e.g. Automated EIP-1193 RPC Fallback Handler"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-300">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Engineering">Engineering</option>
                    <option value="UI/UX">UI/UX</option>
                    <option value="Testing">Testing</option>
                    <option value="Documentation">Documentation</option>
                    <option value="Accessibility">Accessibility</option>
                    <option value="Security">Security</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300">Your Name / Handle</label>
                  <input
                    type="text"
                    placeholder="e.g. Alex (Builder)"
                    value={proposerName}
                    onChange={(e) => setProposerName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300">Detailed Description & Motivation</label>
                <textarea
                  rows={4}
                  placeholder="Explain why this proposal is valuable to the FUTUREVERSE community..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 leading-relaxed"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Proposal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reviewer Status Update Modal */}
      {selectedItemForReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Review Proposal Status</h3>
              <button
                onClick={() => setSelectedItemForReview(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="text-xs text-slate-300 font-semibold">{selectedItemForReview.title}</div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Target Status</label>
                <select
                  value={reviewStatus}
                  onChange={(e) => setReviewStatus(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="SUBMITTED">SUBMITTED</option>
                  <option value="UNDER REVIEW">UNDER REVIEW</option>
                  <option value="SELECTED">SELECTED</option>
                  <option value="BUILDING">BUILDING</option>
                  <option value="TESTING">TESTING</option>
                  <option value="RELEASED">RELEASED</option>
                  <option value="DECLINED">DECLINED</option>
                  <option value="DUPLICATE">DUPLICATE</option>
                  <option value="ON HOLD">ON HOLD</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Review Notes / Decision Rationale</label>
                <textarea
                  rows={3}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Provide context on this decision..."
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setSelectedItemForReview(null)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveReview}
                  disabled={isSavingReview}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer"
                >
                  {isSavingReview ? 'Saving...' : 'Apply Status Update'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
