import React, { useState } from 'react';
import { Play, GitFork, Star, Lock, Globe } from 'lucide-react';
import { Project } from '../types';
import { ASSETS, getStatusBadgeAsset, getProjectLogo } from '../assets/images';

interface ProjectCardProps {
  project: Project;
  onOpenProject: (project: Project) => void;
  onForkProject?: (project: Project) => void;
  onToggleVisibility?: (project: Project) => void;
  showVisibilityToggle?: boolean;
  className?: string;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onOpenProject,
  onForkProject,
  onToggleVisibility,
  showVisibilityToggle = false,
  className = '',
}) => {
  const [logoSrc, setLogoSrc] = useState<string>(getProjectLogo(project.title, project.logoUrl));
  const [logoFailed, setLogoFailed] = useState(false);
  const badge = getStatusBadgeAsset(project.status, project.type);

  const handleLogoError = () => {
    if (!logoFailed && logoSrc !== ASSETS.futureverseIcon) {
      setLogoFailed(true);
      setLogoSrc(ASSETS.futureverseIcon);
    }
  };

  return (
    <div
      className={`fv-glass-card flex flex-col justify-between p-5 sm:p-6 transition-all duration-200 group ${className}`}
      data-testid="project-card"
      data-project-id={project.id}
    >
      <div className="space-y-4">
        {/* Card Header: Project Logo + Status Badge */}
        <div className="flex items-start justify-between gap-2.5 sm:gap-3 min-w-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-slate-900 border border-slate-800 p-1.5 flex items-center justify-center shrink-0 shadow-inner group-hover:border-indigo-500/40 transition-colors">
              <img
                src={logoSrc}
                alt={`${project.title} Logo`}
                onError={(e) => {
                  e.currentTarget.src = ASSETS.futureverseIcon;
                  handleLogoError();
                }}
                className="w-full h-full object-contain"
                data-testid="project-logo"
              />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-[11px] font-mono text-indigo-400 font-medium">
                <span className="truncate">{project.category}</span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400 shrink-0">v{project.version}</span>
              </div>
              <h3 className="text-sm sm:text-base lg:text-lg font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                {project.title}
              </h3>
            </div>
          </div>

          {/* Official Status Badge SVG */}
          <div className="shrink-0 max-w-[45%] flex justify-end" title={`Status: ${badge.label}`}>
            <img
              src={badge.src}
              alt={badge.alt}
              className="h-6 sm:h-7 w-auto max-w-full object-contain transition-transform group-hover:scale-102"
              data-testid="project-status-badge"
              data-status={badge.label}
            />
          </div>
        </div>

        {/* Tagline / Description */}
        <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
          {project.tagline || project.description}
        </p>

        {/* Feature Preview or Tags */}
        {project.specification?.keyFeatures && project.specification.keyFeatures.length > 0 ? (
          <div className="space-y-1 pt-1">
            <div className="text-[10px] font-mono uppercase text-slate-400 font-semibold tracking-wider">
              Core Architecture
            </div>
            <div className="text-xs text-slate-300 flex items-start gap-1.5 line-clamp-1">
              <span className="text-amber-400">→</span>
              <span className="truncate">
                <strong className="text-slate-200">{project.specification.keyFeatures[0].title}:</strong>{' '}
                {project.specification.keyFeatures[0].description}
              </span>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {(project.tags || []).slice(0, 3).map((tag) => (
              <span key={tag} className="text-[10px] text-slate-400 font-mono bg-slate-900/60 px-2 py-0.5 rounded border border-slate-800">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Card Footer */}
      <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          {project.author?.avatar ? (
            <img
              src={project.author.avatar}
              alt={project.author.name}
              referrerPolicy="no-referrer"
              className="w-5 h-5 sm:w-6 sm:h-6 rounded-full border border-slate-700 object-cover shrink-0"
            />
          ) : (
            <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] text-slate-300 font-bold">
              {project.author?.name?.charAt(0) || 'U'}
            </div>
          )}
          <span className="text-[11px] text-slate-400 truncate">@{project.author?.handle || 'builder'}</span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {showVisibilityToggle && onToggleVisibility && (
            <button
              onClick={() => onToggleVisibility(project)}
              className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded cursor-pointer ${
                project.visibility === 'published'
                  ? 'bg-emerald-950/60 border border-emerald-800/60 text-emerald-300'
                  : 'bg-slate-800 border border-slate-700 text-slate-300'
              }`}
              title="Toggle visibility"
            >
              {project.visibility === 'published' ? <Globe className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
              <span className="hidden sm:inline">{project.visibility === 'published' ? 'Public' : 'Draft'}</span>
            </button>
          )}

          {onForkProject && (
            <button
              onClick={() => onForkProject(project)}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
              title="Fork project"
            >
              <GitFork className="h-3.5 w-3.5" />
            </button>
          )}

          <button
            onClick={() => onOpenProject(project)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer shadow-sm active:scale-98"
          >
            <Play className="h-3 w-3 fill-current" />
            <span>Launch</span>
          </button>
        </div>
      </div>
    </div>
  );
};
