import React, { useState } from 'react';
import { Plus, Play, Trash2, Edit, Globe, Lock, Download, Layers, CheckCircle2 } from 'lucide-react';
import { Project } from '../types';
import { api } from '../services/api';
import { ASSETS, getStatusBadgeAsset, getProjectLogo } from '../assets/images';

interface WorkspaceViewProps {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onCreateNew: () => void;
  onRefreshProjects: () => void;
}

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  projects,
  onOpenProject,
  onCreateNew,
  onRefreshProjects,
}) => {
  const [filterVisibility, setFilterVisibility] = useState<'all' | 'draft' | 'published'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const displayedProjects = projects.filter((p) => {
    if (filterVisibility === 'all') return true;
    return p.visibility === filterVisibility;
  });

  const handleToggleVisibility = async (project: Project) => {
    const newVisibility = project.visibility === 'published' ? 'draft' : 'published';
    try {
      await api.updateProject(project.id, { visibility: newVisibility });
      onRefreshProjects();
    } catch (err: any) {
      alert(`Failed to update visibility: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      return;
    }
    setDeletingId(id);
    try {
      await api.deleteProject(id);
      onRefreshProjects();
    } catch (err: any) {
      alert(`Failed to delete project: ${err.message}`);
    } finally {
      setDeletingId(null);
    }
  };

  const handleExportJson = (project: Project) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${project.title.toLowerCase().replace(/\s+/g, '-')}-spec.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="text-xs font-mono uppercase text-indigo-400">Builder Workspace</div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            My Projects & Drafts
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage your persistent creations, edit specifications, and publish to the FUTUREVERSE directory.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded-md transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>New Creation</span>
        </button>
      </div>

      {/* Visibility Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 max-w-fit">
        <button
          onClick={() => setFilterVisibility('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
            filterVisibility === 'all'
              ? 'bg-slate-800 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Items ({projects.length})
        </button>
        <button
          onClick={() => setFilterVisibility('published')}
          className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
            filterVisibility === 'published'
              ? 'bg-slate-800 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Published ({projects.filter((p) => p.visibility === 'published').length})
        </button>
        <button
          onClick={() => setFilterVisibility('draft')}
          className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
            filterVisibility === 'draft'
              ? 'bg-slate-800 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Drafts ({projects.filter((p) => p.visibility === 'draft').length})
        </button>
      </div>

      {/* Projects List */}
      {displayedProjects.length === 0 ? (
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-12 text-center space-y-4">
          <Layers className="h-8 w-8 text-slate-500 mx-auto" />
          <div className="text-base font-semibold text-white">No projects found in this view</div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            You can generate a new project instantly using the Creation Engine.
          </p>
          <button
            onClick={onCreateNew}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Start Building</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedProjects.map((project) => {
            const badge = getStatusBadgeAsset(project.status, project.type);
            const logo = getProjectLogo(project.title, project.logoUrl);
            return (
              <div
                key={project.id}
                className="fv-glass-card flex flex-col justify-between p-5 space-y-4 hover:border-slate-700 transition-all shadow-md group"
              >
                <div className="space-y-3">
                  {/* Top Bar: Project Logo + Category & Status Badge */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                        <img
                          src={logo}
                          alt={project.title}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            e.currentTarget.src = ASSETS.futureverseIcon;
                          }}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 text-[11px] font-mono text-indigo-400">
                          <span>{project.category}</span>
                          <span>·</span>
                          <span className="text-slate-400">v{project.version}</span>
                        </div>
                        <h3 className="text-base font-bold text-white hover:text-indigo-300 transition-colors line-clamp-1">
                          {project.title}
                        </h3>
                      </div>
                    </div>

                    <img
                      src={badge.src}
                      alt={badge.alt}
                      className="h-6 w-auto object-contain shrink-0"
                      title={badge.label}
                    />
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {project.tagline || project.description}
                  </p>

                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-1">
                    <span>Updated: {new Date(project.updatedAt).toLocaleDateString()}</span>
                    <button
                      onClick={() => handleToggleVisibility(project)}
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded cursor-pointer ${
                        project.visibility === 'published'
                          ? 'bg-emerald-950/60 border border-emerald-800/60 text-emerald-300'
                          : 'bg-slate-800 border border-slate-700 text-slate-400'
                      }`}
                    >
                      {project.visibility === 'published' ? <Globe className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
                      <span>{project.visibility === 'published' ? 'Public' : 'Draft'}</span>
                    </button>
                  </div>
                </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => onOpenProject(project)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer"
                >
                  <Play className="h-3 w-3 fill-current" />
                  <span>Launch Sandbox</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleExportJson(project)}
                    title="Export specification JSON"
                    className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                  </button>

                  <button
                    onClick={() => handleDelete(project.id)}
                    disabled={deletingId === project.id}
                    title="Delete project"
                    className="p-1.5 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
        </div>
      )}
    </div>
  );
};
