import React, { useState } from 'react';
import { X, Star, GitFork, Share2, MessageSquare, Check, Sparkles, Shield, Layers, ArrowRight } from 'lucide-react';
import { Project, ProjectFeedback } from '../types';
import { InteractiveRunner } from './InteractiveRunner';
import { api } from '../services/api';
import { ASSETS, getStatusBadgeAsset, getProjectLogo } from '../assets/images';

interface ProjectDetailModalProps {
  project: Project;
  onClose: () => void;
  onForkProject: (project: Project) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onForkProject,
}) => {
  const [activeTab, setActiveTab] = useState<'runner' | 'spec' | 'feedback'>('runner');
  const [feedbackAuthor, setFeedbackAuthor] = useState('');
  const [feedbackContent, setFeedbackContent] = useState('');
  const [feedbackType, setFeedbackType] = useState<'feedback' | 'suggestion' | 'bug'>('suggestion');
  const [feedbackList, setFeedbackList] = useState<ProjectFeedback[]>(project.feedback || []);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleShare = () => {
    const url = `${window.location.origin}?project=${project.id}`;
    navigator.clipboard?.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackContent.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await api.submitProjectFeedback(project.id, {
        author: feedbackAuthor.trim() || 'Community Contributor',
        content: feedbackContent.trim(),
        type: feedbackType,
      });
      setFeedbackList((prev) => [res.feedback, ...prev]);
      setFeedbackContent('');
    } catch (err) {
      console.error('Failed to submit feedback:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-5xl max-h-[92vh] flex flex-col rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl overflow-hidden my-auto">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800/80 px-6 py-4 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono uppercase tracking-wider text-indigo-400">
              {project.category}
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-400">
              {project.type}
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-500">v{project.version}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
            >
              {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5" />}
              <span>{copiedLink ? 'Link Copied' : 'Share'}</span>
            </button>

            <button
              onClick={() => onForkProject(project)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
            >
              <GitFork className="h-3.5 w-3.5" />
              <span>Fork ({project.forks})</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
              aria-label="Close modal"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Project Title & Author Banner */}
        <div className="px-6 py-5 border-b border-slate-800 bg-slate-950">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-4 min-w-0">
              <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 p-2 flex items-center justify-center shrink-0">
                <img
                  src={getProjectLogo(project.title, project.logoUrl)}
                  alt={`${project.title} Logo`}
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    e.currentTarget.src = ASSETS.futureverseIcon;
                  }}
                />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                    {project.title}
                  </h2>
                  <img
                    src={getStatusBadgeAsset(project.status, project.type).src}
                    alt={getStatusBadgeAsset(project.status, project.type).alt}
                    className="h-6 w-auto object-contain"
                    title={`Status: ${getStatusBadgeAsset(project.status, project.type).label}`}
                  />
                </div>
                <p className="text-sm text-slate-400 mt-1 max-w-3xl leading-relaxed">
                  {project.tagline || project.description}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <img
                src={project.author.avatar}
                alt={project.author.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full border border-slate-700 object-cover"
              />
              <div className="text-xs">
                <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <span>{project.author.name}</span>
                  {project.author.foundingMember && (
                    <span className="text-[10px] text-amber-300 font-mono">Founding Member</span>
                  )}
                </div>
                <div className="text-slate-400 font-mono">@{project.author.handle}</div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 mt-5 border-b border-slate-800/80 -mb-5 pb-0">
            <button
              onClick={() => setActiveTab('runner')}
              className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'runner'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Interactive Sandbox
            </button>
            <button
              onClick={() => setActiveTab('spec')}
              className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'spec'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Product Specification & Flow
            </button>
            <button
              onClick={() => setActiveTab('feedback')}
              className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'feedback'
                  ? 'border-indigo-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Community Feedback ({feedbackList.length})
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Tab 1: Interactive Runner */}
          {activeTab === 'runner' && (
            <InteractiveRunner prototype={project.prototype} projectTitle={project.title} />
          )}

          {/* Tab 2: Specification & User Flow */}
          {activeTab === 'spec' && (
            <div className="space-y-6">
              {/* Problem & Audience */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
                  <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Target Audience
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {project.specification.targetAudience}
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60">
                  <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Problem Statement
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {project.specification.problemStatement}
                  </p>
                </div>
              </div>

              {/* Key Features */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Key Feature Modules
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {project.specification.keyFeatures.map((feat, idx) => (
                    <div key={idx} className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/50 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-white">{feat.title}</span>
                        <span className="text-[10px] font-mono uppercase text-indigo-400">{feat.priority}</span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">{feat.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* User Flow */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Structured User Journey Outline
                </div>
                <div className="space-y-2">
                  {project.specification.userFlow.map((step) => (
                    <div key={step.step} className="p-3 rounded-lg border border-slate-800 bg-slate-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-indigo-950 border border-indigo-700/60 font-mono text-indigo-300 text-center flex items-center justify-center font-bold shrink-0">
                          {step.step}
                        </span>
                        <div>
                          <div className="font-semibold text-slate-200">{step.title}</div>
                          <div className="text-slate-400 mt-0.5">{step.action}</div>
                        </div>
                      </div>
                      <div className="text-indigo-300 font-medium sm:text-right text-[11px] bg-slate-950 px-2.5 py-1 rounded border border-slate-800/80 shrink-0">
                        Outcome: {step.outcome}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Architecture & Security */}
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <Shield className="h-4 w-4 text-emerald-400" />
                  <span>Architecture & Security Boundaries</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400">Frontend:</span>
                    <p className="text-slate-200 font-mono text-[11px] mt-0.5">{project.specification.architecture.frontend}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Backend:</span>
                    <p className="text-slate-200 font-mono text-[11px] mt-0.5">{project.specification.architecture.backend}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Data Model:</span>
                    <p className="text-slate-200 font-mono text-[11px] mt-0.5">{project.specification.architecture.dataModel}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Security Notes:</span>
                    <p className="text-slate-200 text-[11px] mt-0.5">{project.specification.architecture.securityNotes}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Community Feedback */}
          {activeTab === 'feedback' && (
            <div className="space-y-6">
              {/* Submission Form */}
              <form onSubmit={handleSubmitFeedback} className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 space-y-3">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Propose an Improvement or Report Feedback
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Your Name or Handle"
                    value={feedbackAuthor}
                    onChange={(e) => setFeedbackAuthor(e.target.value)}
                    className="px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-700 text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                  <select
                    value={feedbackType}
                    onChange={(e) => setFeedbackType(e.target.value as any)}
                    className="px-3 py-1.5 text-xs rounded bg-slate-950 border border-slate-700 text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="suggestion">Feature Suggestion</option>
                    <option value="feedback">General Feedback</option>
                    <option value="bug">Bug Report</option>
                  </select>
                </div>
                <textarea
                  rows={3}
                  placeholder="Share constructive feedback or propose a technical enhancement..."
                  value={feedbackContent}
                  onChange={(e) => setFeedbackContent(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-950 border border-slate-700 text-slate-200 focus:outline-none focus:border-indigo-500"
                  required
                />
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded disabled:opacity-50 transition-colors"
                  >
                    {isSubmitting ? 'Posting...' : 'Submit Feedback'}
                  </button>
                </div>
              </form>

              {/* Feedback List */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-400">
                  {feedbackList.length === 0 ? 'No feedback recorded yet. Be the first to share thoughts!' : 'Community Observations'}
                </div>

                {feedbackList.map((fb) => (
                  <div key={fb.id} className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/40 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-200">{fb.author}</span>
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                          {fb.type}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500">
                        {new Date(fb.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{fb.content}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
