import React, { useState } from 'react';
import { Search, Filter, Play, Star, GitFork, Plus, Layers } from 'lucide-react';
import { Project, ProjectCategory, ProjectType } from '../types';
import { ProjectCard } from './ProjectCard';

interface ExploreViewProps {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onForkProject: (project: Project) => void;
  onCreateNew: () => void;
}

export const ExploreView: React.FC<ExploreViewProps> = ({
  projects,
  onOpenProject,
  onForkProject,
  onCreateNew,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All');

  const categories = [
    'All',
    'AI Agents',
    'EdTech & Careers',
    'Web3 & FinTech',
    'Creative Tools',
    'Community Systems',
    'Productivity',
  ];

  const types = [
    'All',
    'Working Application',
    'Interactive Prototype',
    'Simulation',
    'Concept',
  ];

  const filteredProjects = projects.filter((project) => {
    // Only published projects in public explore
    if (project.visibility !== 'published') return false;

    if (selectedCategory !== 'All' && project.category !== selectedCategory) {
      return false;
    }
    if (selectedType !== 'All' && project.type !== selectedType) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = project.title.toLowerCase().includes(q);
      const matchDesc = project.description.toLowerCase().includes(q);
      const matchTag = project.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchDesc && !matchTag) return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-20">
      {/* Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="text-xs font-mono uppercase text-indigo-400">Community Repository</div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            Explore Creations
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Discover community-built interactive applications, simulations, and engineering blueprints.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded-md transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Create New Project</span>
        </button>
      </div>

      {/* Search & Filter Controls */}
      <div className="space-y-4">
        {/* Search input */}
        <div className="relative max-w-xl">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, description, or keyword..."
            className="w-full pl-10 pr-4 py-2.5 text-xs rounded-lg bg-slate-900 border border-slate-800 text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Categories (Interactive segmented button tabs) */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950/80 rounded-lg border border-slate-800/80 max-w-fit">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Project Type Filter Tabs */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-mono text-[11px] uppercase">Maturity:</span>
          <div className="flex flex-wrap gap-1">
            {types.map((t) => (
              <button
                key={t}
                onClick={() => setSelectedType(t)}
                className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                  selectedType === t
                    ? 'bg-indigo-950/70 border border-indigo-700/60 text-indigo-200'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-12 text-center space-y-4">
          <Layers className="h-8 w-8 text-slate-500 mx-auto" />
          <div className="text-base font-semibold text-white">No matching creations found</div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Try adjusting your search query or category filters, or be the first to build a project for this niche!
          </p>
          <button
            onClick={onCreateNew}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Launch Creation Engine</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onOpenProject={onOpenProject}
              onForkProject={onForkProject}
            />
          ))}
        </div>
      )}
    </div>
  );
};
