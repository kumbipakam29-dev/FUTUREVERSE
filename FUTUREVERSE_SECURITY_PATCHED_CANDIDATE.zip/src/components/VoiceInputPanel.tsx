import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Radio,
  Volume2,
  VolumeX,
  Languages,
  RotateCcw,
  Sparkles,
  AlertCircle,
  HelpCircle,
  Check,
  ChevronDown
} from 'lucide-react';
import { useSpeechRecognition, SUPPORTED_LANGUAGES } from '../hooks/useSpeechRecognition';

interface VoiceInputPanelProps {
  onTranscriptUpdate: (text: string, mode: 'append' | 'replace') => void;
  currentValue: string;
  placeholder?: string;
  contextTitle?: string;
  isCompact?: boolean;
}

const VOICE_IDEA_PROMPTS = [
  'Build an autonomous DeFi agent that monitors slippage and rebalances liquidity pools in real time.',
  'Create a decentralized AI compute marketplace where idle GPU nodes earn verified tokens.',
  'Design an interactive learning roadmap generator with weekly milestone assessments for developers.',
  'Develop an on-chain dispute resolution arbitration court with randomized juror staking.',
];

export const VoiceInputPanel: React.FC<VoiceInputPanelProps> = ({
  onTranscriptUpdate,
  currentValue,
  contextTitle = 'Project Idea Voice Input',
  isCompact = false,
}) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [insertMode, setInsertMode] = useState<'append' | 'replace'>('append');
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [showIdeaDrawer, setShowIdeaDrawer] = useState(false);

  const {
    isSupported,
    isListening,
    transcript,
    interimTranscript,
    error,
    toggleListening,
    stopListening,
    resetTranscript,
    setLanguage,
    currentLanguage,
  } = useSpeechRecognition({
    soundCue: soundEnabled,
    continuous: true,
    interimResults: true,
  });

  // Keep track of the last transcript delivered to avoid duplication
  const [lastDeliveredLength, setLastDeliveredLength] = useState(0);

  // Sync real-time transcription to parent
  useEffect(() => {
    if (!transcript) {
      setLastDeliveredLength(0);
      return;
    }

    if (transcript.length > lastDeliveredLength) {
      const newChunk = transcript.slice(lastDeliveredLength);
      setLastDeliveredLength(transcript.length);

      if (insertMode === 'replace' && lastDeliveredLength === 0) {
        onTranscriptUpdate(transcript, 'replace');
      } else {
        onTranscriptUpdate(newChunk, 'append');
      }
    }
  }, [transcript, lastDeliveredLength, insertMode, onTranscriptUpdate]);

  const handleClear = () => {
    resetTranscript();
    setLastDeliveredLength(0);
  };

  const handleSelectLanguage = (langCode: string) => {
    setLanguage(langCode);
    setShowLanguageDropdown(false);
  };

  const activeLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage) ||
    SUPPORTED_LANGUAGES[0];

  if (isCompact) {
    return (
      <div className="relative inline-flex items-center gap-1.5">
        <button
          type="button"
          onClick={toggleListening}
          disabled={!isSupported}
          title={
            !isSupported
              ? 'Web Speech API not supported in this browser'
              : isListening
              ? 'Click to stop listening'
              : 'Click to speak your input'
          }
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded transition-all cursor-pointer ${
            isListening
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse font-medium'
              : isSupported
              ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
              : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
          }`}
        >
          {isListening ? (
            <>
              <Radio className="h-3 w-3 text-rose-400 animate-spin" />
              <span>Listening...</span>
            </>
          ) : (
            <>
              <Mic className="h-3 w-3 text-indigo-400" />
              <span>Voice</span>
            </>
          )}
        </button>

        {isListening && (
          <button
            type="button"
            onClick={stopListening}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-[10px]"
            title="Stop recording"
          >
            <MicOff className="h-3 w-3" />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-800/90 bg-gradient-to-b from-slate-900/90 to-slate-950/90 p-4 space-y-3.5 shadow-lg backdrop-blur-sm">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/70 pb-3">
        <div className="flex items-center gap-2">
          <div
            className={`w-2.5 h-2.5 rounded-full ${
              isListening
                ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e] animate-ping'
                : isSupported
                ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]'
                : 'bg-amber-400'
            }`}
          />
          <span className="text-xs font-semibold text-slate-200 tracking-wide flex items-center gap-1.5">
            <Mic className="h-3.5 w-3.5 text-indigo-400" />
            {contextTitle}
          </span>
          {isListening && (
            <span className="px-2 py-0.5 text-[10px] font-mono uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-full font-bold animate-pulse">
              LIVE SPEECH
            </span>
          )}
        </div>

        {/* Toolbar Controls */}
        <div className="flex items-center gap-2">
          {/* Audio Chime Mute Toggle */}
          <button
            type="button"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-1.5 rounded transition-colors text-xs cursor-pointer ${
              soundEnabled
                ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                : 'text-slate-600 hover:text-slate-400'
            }`}
            title={soundEnabled ? 'Chime sound enabled' : 'Chime sound muted'}
          >
            {soundEnabled ? (
              <Volume2 className="h-3.5 w-3.5" />
            ) : (
              <VolumeX className="h-3.5 w-3.5" />
            )}
          </button>

          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
              className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-[11px] text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Select speech language"
            >
              <Languages className="h-3 w-3 text-indigo-400" />
              <span>{activeLangObj.label}</span>
              <ChevronDown className="h-3 w-3 text-slate-400" />
            </button>

            {showLanguageDropdown && (
              <div className="absolute right-0 mt-1 w-44 rounded-lg bg-slate-900 border border-slate-700 shadow-xl z-30 py-1 max-h-56 overflow-y-auto">
                <div className="px-3 py-1 text-[10px] uppercase font-mono text-slate-400 border-b border-slate-800">
                  Select Language
                </div>
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => handleSelectLanguage(lang.code)}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-indigo-600/30 hover:text-white flex items-center justify-between cursor-pointer"
                  >
                    <span>{lang.label}</span>
                    {lang.code === currentLanguage && (
                      <Check className="h-3 w-3 text-indigo-400" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Insert Mode Toggle */}
          <div className="inline-flex items-center rounded-lg bg-slate-900 p-0.5 border border-slate-800 text-[10px]">
            <button
              type="button"
              onClick={() => setInsertMode('append')}
              className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                insertMode === 'append'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Append speech to existing prompt"
            >
              Append
            </button>
            <button
              type="button"
              onClick={() => setInsertMode('replace')}
              className={`px-2 py-0.5 rounded transition-colors cursor-pointer ${
                insertMode === 'replace'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Replace prompt with newly spoken speech"
            >
              Replace
            </button>
          </div>
        </div>
      </div>

      {/* Main Interaction Area */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 rounded-lg bg-slate-950/60 border border-slate-800/80">
        <div className="flex items-center gap-3">
          {/* Big Mic Button with visual ring */}
          <div className="relative shrink-0">
            {isListening && (
              <span className="absolute -inset-1 rounded-full bg-rose-500/30 animate-ping" />
            )}
            <button
              type="button"
              onClick={toggleListening}
              disabled={!isSupported}
              className={`relative h-12 w-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                !isSupported
                  ? 'bg-slate-800 text-slate-600 border border-slate-700 cursor-not-allowed'
                  : isListening
                  ? 'bg-gradient-to-br from-rose-500 to-amber-500 text-white shadow-[0_0_15px_rgba(244,63,94,0.5)] scale-105'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md hover:scale-105'
              }`}
            >
              {isListening ? (
                <MicOff className="h-5 w-5 animate-pulse" />
              ) : (
                <Mic className="h-5 w-5" />
              )}
            </button>
          </div>

          <div className="space-y-0.5">
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-2">
              <span>{isListening ? 'Listening to your voice...' : 'Speak your project concept'}</span>
              {isListening && (
                <span className="inline-flex items-center gap-0.5">
                  <span className="w-1 h-3 bg-rose-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1 h-4 bg-amber-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1 h-2 bg-indigo-400 rounded-full animate-bounce" />
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400">
              {isListening
                ? 'Speak clearly into your microphone. Words are transcribed directly into your vision statement.'
                : isSupported
                ? 'Press the microphone button or say what kind of Web3 application, agent, or game you envision.'
                : 'Web Speech API is not supported in this browser. Please use Google Chrome, Edge, or Safari.'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          {isListening ? (
            <button
              type="button"
              onClick={stopListening}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <MicOff className="h-3.5 w-3.5" />
              <span>Done Speaking</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setShowIdeaDrawer(!showIdeaDrawer)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              <span>Voice Prompts</span>
            </button>
          )}

          {transcript && (
            <button
              type="button"
              onClick={handleClear}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Clear voice transcript buffer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Live Interim Transcript Bubble while listening */}
      {(isListening || interimTranscript) && (
        <div className="p-3 rounded-lg border border-indigo-500/30 bg-indigo-950/20 text-xs text-indigo-200 flex items-start gap-2.5 animate-fadeIn">
          <Radio className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5 animate-pulse" />
          <div className="space-y-1 flex-1">
            <div className="text-[10px] font-mono uppercase text-indigo-400 font-bold">
              Real-time Voice Stream
            </div>
            <div className="text-slate-100 font-normal leading-relaxed italic">
              {transcript ? (
                <span>"{transcript}" </span>
              ) : null}
              {interimTranscript && (
                <span className="text-amber-300 underline decoration-amber-400/50">
                  {interimTranscript}...
                </span>
              )}
              {!transcript && !interimTranscript && (
                <span className="text-slate-500 not-italic">
                  Awaiting speech input... Say something like "Create an AI trading bot..."
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {error && (
        <div className="p-3 rounded-lg border border-rose-900/60 bg-rose-950/40 text-rose-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => toggleListening()}
            className="text-[11px] underline hover:text-white font-medium cursor-pointer"
          >
            Retry
          </button>
        </div>
      )}

      {/* Voice Prompts Suggestions Drawer */}
      {showIdeaDrawer && (
        <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60 space-y-2">
          <div className="text-[11px] font-mono uppercase text-amber-300 flex items-center gap-1">
            <HelpCircle className="h-3.5 w-3.5" />
            <span>Inspiration Ideas (Say aloud or click to populate):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {VOICE_IDEA_PROMPTS.map((promptText, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  onTranscriptUpdate(promptText, 'replace');
                  setShowIdeaDrawer(false);
                }}
                className="text-left p-2.5 rounded border border-slate-800/80 bg-slate-950/70 hover:border-indigo-500/50 hover:bg-slate-900 text-slate-300 hover:text-white text-xs transition-colors cursor-pointer group"
              >
                <span className="text-indigo-400 group-hover:text-indigo-300 font-mono text-[10px] mr-1.5">
                  #{idx + 1}
                </span>
                "{promptText}"
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
