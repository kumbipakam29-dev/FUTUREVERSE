import React, { useState } from 'react';
import { Check, Shield, Sparkles, Award, ArrowRight, Lock, CheckCircle2, RefreshCw, CreditCard } from 'lucide-react';
import { MembershipOrder } from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';

import { WalletState, Web3Service, YAGYX_CHAIN_ID, YAGYX_CHAIN_HEX } from '../services/web3';

interface MembershipViewProps {
  onStartCreation: () => void;
  walletState?: WalletState;
  onConnectWallet?: () => void;
}

export const MembershipView: React.FC<MembershipViewProps> = ({
  onStartCreation,
  walletState,
  onConnectWallet,
}) => {
  const [selectedRegion, setSelectedRegion] = useState<'India' | 'Global'>('India');
  const [selectedAsset, setSelectedAsset] = useState<'YGO' | 'YAGYX' | 'YINR' | 'YUSD'>('YGO');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<any | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [confirmedSuccess, setConfirmedSuccess] = useState<string | null>(null);
  const [txHashInput, setTxHashInput] = useState('');

  // Initial membership pricing rule:
  // India: ₹100 for initial 1 month
  // Global: $1 for initial 1 month
  const currentPriceDisplay = selectedRegion === 'India' ? '₹100 / month' : '$1 / month';

  // Planned future subscription tiers (Disabled per Section 6)
  const plannedFutureTiers = [
    { period: '3 Months', status: 'Pending Authorized Configuration' },
    { period: '6 Months', status: 'Pending Authorized Configuration' },
    { period: '1 Year', status: 'Pending Authorized Configuration' },
    { period: '2 Years', status: 'Pending Authorized Configuration' },
    { period: '5 Years', status: 'Pending Authorized Configuration' },
    { period: 'Unlimited / Lifetime', status: 'Pending Authorized Configuration' },
  ];

  const handleStartCheckout = async () => {
    setIsProcessing(true);
    setConfirmedSuccess(null);
    setTxHashInput('');
    try {
      const res = await api.checkoutMembership({
        tier: 'Founding Member',
        region: selectedRegion,
        selectedAsset,
      });
      setActiveOrder(res.order || res);
      setIsCheckoutOpen(true);
    } catch (err: any) {
      alert(`Checkout error: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmPayment = async () => {
    if (!activeOrder) return;
    setIsProcessing(true);

    try {
      let finalTxHash = txHashInput.trim();

      // If user has connected wallet on YAGYX Chain and no hash entered, trigger on-chain transaction
      if (!finalTxHash && walletState?.isConnected && walletState.address) {
        if (!walletState.isCorrectNetwork) {
          await Web3Service.switchToYagyxChain();
        }

        const vault = activeOrder.vaultAddress || '0x71C836376510343a000000000000000000013370';
        // If native YAGYX, calculate wei value in hex
        let valHex = '0x0';
        if (activeOrder.selectedAsset === 'YAGYX') {
          const wei = BigInt(Math.round(activeOrder.assetAmountRequired * 1e6)) * BigInt(1e12);
          valHex = '0x' + wei.toString(16);
        }

        finalTxHash = await Web3Service.sendYagyxTransaction({
          from: walletState.address,
          to: vault,
          valueHex: valHex,
        });
        setTxHashInput(finalTxHash);
      }

      if (!finalTxHash) {
        alert(
          'No on-chain transaction hash found. Please connect your Web3 wallet on YAGYX Chain (13370) to authorize the transaction, or paste a verified transaction hash.'
        );
        setIsProcessing(false);
        return;
      }

      const res = await api.confirmMembership(activeOrder.id || activeOrder.checkoutId, finalTxHash);
      setActiveOrder(res.order);
      setConfirmedSuccess(
        `On-chain payment verified on YAGYX Chain (13370)! Tx Hash: ${finalTxHash.slice(0, 14)}... Membership entitlement active.`
      );
    } catch (err: any) {
      alert(`Verification error: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-12 pb-20 max-w-5xl mx-auto">
      {/* Title & Region Toggle */}
      <div className="text-center space-y-4">
        <div className="flex justify-center pb-1">
          <img
            src={ASSETS.futureverseLogo}
            alt="FUTUREVERSE Logo"
            className="h-10 sm:h-12 w-auto object-contain drop-shadow-[0_0_15px_rgba(99,102,241,0.35)]"
          />
        </div>

        <div className="inline-flex items-center gap-2 text-xs font-mono uppercase text-amber-300">
          <span>MEMBERSHIP GOVERNANCE & SUBSCRIPTION SYSTEM</span>
          <span>·</span>
          <span>SECTION 6 SPECIFICATION</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-wider font-brand fv-chrome-title">
          Transparent Membership & Contributor Tiers
        </h1>

        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Configured pricing policy: India at ₹100 for the initial one-month membership; Global at $1 for initial one-month membership. Exclusively settled with native YAGYX Chain assets (YGO, YAGYX, YINR, YUSD) on Chain ID 13370 (0x343a).
        </p>

        {/* Region Switcher */}
        <div className="inline-flex p-1 bg-slate-900 rounded-lg border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setSelectedRegion('India')}
            className={`px-4 py-1.5 rounded transition-colors cursor-pointer ${
              selectedRegion === 'India'
                ? 'bg-amber-300 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            India Tier (₹100)
          </button>
          <button
            onClick={() => setSelectedRegion('Global')}
            className={`px-4 py-1.5 rounded transition-colors cursor-pointer ${
              selectedRegion === 'Global'
                ? 'bg-amber-300 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Global Tier ($1)
          </button>
        </div>
      </div>

      {/* Active Tiers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tier 1: Free Explorer */}
        <div className="rounded-2xl p-6 sm:p-7 flex flex-col justify-between space-y-6 border border-slate-800 bg-slate-950/80">
          <div className="space-y-4">
            <div>
              <div className="text-xs font-mono text-indigo-400 uppercase">Open Access</div>
              <h3 className="text-xl font-bold text-white mt-1">Free Explorer</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Full access to explore public creations, run interactive sandbox widgets, and submit community proposals.
              </p>
            </div>

            <div className="text-xl font-extrabold font-mono text-white pt-2 border-t border-slate-800/80">
              Free Forever
            </div>

            <ul className="space-y-2.5 text-xs text-slate-300 pt-2">
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Explore all published interactive projects</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Save up to 5 project drafts</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Standard Gemini 3.8 Flash prototype builder</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Non-custodial YAGYX wallet connection</span>
              </li>
            </ul>
          </div>

          <button
            onClick={onStartCreation}
            className="w-full py-2.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            Explore Public Features
          </button>
        </div>

        {/* Tier 2: Founding Member (Initial 1-Month Configured) */}
        <div className="rounded-2xl p-6 sm:p-7 flex flex-col justify-between space-y-6 border-2 border-amber-400 bg-slate-900/90 shadow-2xl relative">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 text-[10px] font-mono font-bold uppercase bg-amber-400 text-slate-950 rounded-full shadow">
            Active 1-Month Program
          </div>

          <div className="space-y-4">
            <div>
              <div className="text-xs font-mono text-amber-300 uppercase">Genesis Builder Tier</div>
              <h3 className="text-xl font-bold text-white mt-1">Founding Member</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Initial one-month membership for builders shaping the platform architecture on YAGYX Chain.
              </p>
            </div>

            <div className="text-2xl font-extrabold font-mono text-amber-300 pt-2 border-t border-slate-800/80">
              {currentPriceDisplay}
            </div>

            <div className="space-y-2 pt-2">
              <label className="text-[11px] text-slate-400 font-mono block">Preferred Settlement Asset:</label>
              <div className="grid grid-cols-4 gap-1 text-[11px] font-mono">
                {(['YGO', 'YAGYX', 'YINR', 'YUSD'] as const).map((ast) => (
                  <button
                    key={ast}
                    onClick={() => setSelectedAsset(ast)}
                    className={`py-1 rounded border cursor-pointer ${
                      selectedAsset === ast
                        ? 'border-amber-400 bg-amber-950/80 text-amber-300 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    {ast}
                  </button>
                ))}
              </div>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-200 pt-1">
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Verified Founding Member profile badge</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Unlimited persistent project drafts</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Priority queue for Gemini 3.8 Flash generation</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Direct submission & voting weight on Evolution Board</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Eligible for verified YAGYX task bounties</span>
              </li>
            </ul>
          </div>

          <button
            onClick={handleStartCheckout}
            disabled={isProcessing}
            className="w-full py-2.5 text-xs font-semibold rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 transition-colors cursor-pointer"
          >
            {isProcessing ? 'Preparing Order...' : `Proceed to Checkout (${currentPriceDisplay})`}
          </button>
        </div>

        {/* Tier 3: Ecosystem Organization */}
        <div className="rounded-2xl p-6 sm:p-7 flex flex-col justify-between space-y-6 border border-slate-800 bg-slate-950/80">
          <div className="space-y-4">
            <div>
              <div className="text-xs font-mono text-indigo-400 uppercase">DAOs & Enterprises</div>
              <h3 className="text-xl font-bold text-white mt-1">Ecosystem Organization</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                For organizations running custom compute clusters, multi-reviewer bounties, and collective challenges.
              </p>
            </div>

            <div className="text-xl font-extrabold font-mono text-white pt-2 border-t border-slate-800/80">
              Custom Collaborative Escrow
            </div>

            <ul className="space-y-2.5 text-xs text-slate-300 pt-2">
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Dedicated ecosystem bounty escrow pools</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Multi-reviewer task sign-off workflows</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>1% Compute marketplace prioritization</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Dedicated SARATHI AI routing cluster</span>
              </li>
            </ul>
          </div>

          <button
            onClick={() => alert('Please contact Dhaval Chandrashekhar Batwal or core stewards for organizational enrollment.')}
            className="w-full py-2.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
          >
            Contact Stewards
          </button>
        </div>
      </div>

      {/* Planned Future Subscription Options (Disabled per Section 6 Rule) */}
      <div className="space-y-4 border-t border-slate-800 pt-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-lg font-bold text-white">Planned Future Subscription Options</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              These future plans are not finalized. They remain disabled until an authorized administrator configures their terms and availability.
            </p>
          </div>

          <span className="text-[11px] font-mono text-slate-500 bg-slate-900 px-3 py-1 rounded border border-slate-800 self-start sm:self-auto">
            Status: Disabled (Zero Fabricated Pricing)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {plannedFutureTiers.map((p) => (
            <div
              key={p.period}
              className="p-4 rounded-xl border border-slate-800/60 bg-slate-950/40 opacity-60 space-y-2 text-center"
            >
              <Lock className="h-4 w-4 text-slate-500 mx-auto" />
              <div className="text-xs font-bold text-slate-300">{p.period}</div>
              <div className="text-[10px] text-slate-500 font-mono leading-tight">{p.status}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Honest Disclaimer */}
      <div className="rounded-xl border border-slate-800/80 bg-slate-950/60 p-5 text-xs text-slate-400 space-y-2 leading-relaxed">
        <div className="font-semibold text-slate-300 flex items-center gap-2">
          <Shield className="h-4 w-4 text-indigo-400" />
          <span>Section 6 Terms & Transparency Guarantee</span>
        </div>
        <p>
          Membership grants verified platform access and community participation. It does not grant equity, guaranteed token returns, or financial income. All payment transactions display currency, applicable fees, and asset conversion breakdown before authorization.
        </p>
      </div>

      {/* Checkout Modal */}
      {isCheckoutOpen && activeOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Membership Order Checkout</h3>
              <button onClick={() => setIsCheckoutOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/60 space-y-2">
                <div className="flex justify-between text-slate-400">
                  <span>Selected Tier:</span>
                  <span className="text-white font-bold">{activeOrder.tier}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Billing Period:</span>
                  <span className="text-white">Initial 1 Month</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Configured Base:</span>
                  <span className="text-amber-300 font-bold">{activeOrder.priceDisplay}</span>
                </div>
                <div className="flex justify-between text-slate-400 border-t border-slate-800 pt-2">
                  <span>Payment Asset:</span>
                  <span className="text-indigo-400 font-bold">{activeOrder.selectedAsset}</span>
                </div>
                <div className="flex justify-between text-emerald-400 text-sm font-bold">
                  <span>Total Due:</span>
                  <span>
                    {activeOrder.assetAmountRequired} {activeOrder.selectedAsset}
                  </span>
                </div>
              </div>

              {confirmedSuccess ? (
                <div className="p-3 rounded-lg border border-emerald-900/60 bg-emerald-950/50 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>{confirmedSuccess}</span>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300 font-sans space-y-1.5">
                    <div className="font-semibold text-amber-300">YAGYX Native On-Chain Settlement (Chain ID: 13370):</div>
                    <p className="text-slate-400">
                      • Protocol Recipient Vault: <span className="font-mono text-emerald-400 text-[9px] break-all">{activeOrder.vaultAddress || '0x71C836376510343a000000000000000000013370'}</span>
                    </p>
                    <p className="text-slate-400">
                      • Strict on-chain verification: Transaction receipt execution status, recipient address, and token balance are verified on the backend before entitlement activation.
                    </p>
                    <p className="text-slate-400">
                      • Terms: Initial 1-month term without auto-recurring lock-in. Zero hidden recurring fees.
                    </p>
                  </div>

                  <div className="space-y-1 pt-1">
                    <label className="text-[10px] text-slate-400 block font-mono">
                      Transaction Hash (optional if signing with connected wallet):
                    </label>
                    <input
                      type="text"
                      placeholder="0x... (paste on-chain transaction hash)"
                      value={txHashInput}
                      onChange={(e) => setTxHashInput(e.target.value)}
                      className="w-full px-3 py-1.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-200"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsCheckoutOpen(false)}
                      className="px-4 py-2 text-slate-400 hover:text-white font-sans"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmPayment}
                      disabled={isProcessing}
                      className="px-5 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer font-sans"
                    >
                      {isProcessing ? 'Verifying on-chain...' : 'Authorize & Activate Membership'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
