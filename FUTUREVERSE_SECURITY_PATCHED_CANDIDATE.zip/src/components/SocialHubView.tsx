import React, { useState, useEffect } from 'react';
import { Share2, Users, Sparkles, Send, ShieldCheck, CheckCircle2, MessageCircle, Heart, Radio, Settings } from 'lucide-react';
import { OfficialChannel, SocialPost, SocialAgent, PublishingMode } from '../types';
import { api } from '../services/api';

export const SocialHubView: React.FC = () => {
  const [channel, setChannel] = useState<OfficialChannel | null>(null);
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [agents, setAgents] = useState<SocialAgent[]>([]);
  const [loading, setLoading] = useState(true);

  // New post state
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedSyndications, setSelectedSyndications] = useState<string[]>(['TELEGRAM', 'X']);
  const [isPosting, setIsPosting] = useState(false);

  // Channel settings modal
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [channelName, setChannelName] = useState('');
  const [channelBio, setChannelBio] = useState('');
  const [publishingMode, setPublishingMode] = useState<PublishingMode>('AI_ASSISTED');

  const loadSocialData = async () => {
    try {
      const [chanRes, postsRes, agentsRes] = await Promise.all([
        api.getOfficialChannel('usr-dhaval-canonical').catch(() => null),
        api.getSocialPosts(),
        api.getSocialAgents(),
      ]);

      if (chanRes && chanRes.channel) {
        setChannel(chanRes.channel);
        setChannelName(chanRes.channel.channelName);
        setChannelBio(chanRes.channel.bio);
        setPublishingMode(chanRes.channel.publishingMode);
      }
      setPosts(postsRes.posts);
      setAgents(agentsRes.agents);
    } catch (err) {
      console.error('Failed to load social hub data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSocialData();
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    setIsPosting(true);
    try {
      await api.publishSocialPost({
        channelId: channel?.id || 'chan-dhaval',
        author: channel?.channelName || 'Official Channel',
        content: newPostContent.trim(),
        syndicatedPlatforms: selectedSyndications as any,
        agentAttribution:
          publishingMode === 'AUTOPILOT'
            ? 'Autopilot (Safety Guardian Approved)'
            : 'Creator Agent (Supervised)',
      });
      setNewPostContent('');
      loadSocialData();
    } catch (err: any) {
      alert(`Posting error: ${err.message}`);
    } finally {
      setIsPosting(false);
    }
  };

  const handleUpdateChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createOrUpdateSocialChannel({
        userId: 'usr-dhaval-canonical',
        channelName,
        bio: channelBio,
        publishingMode,
      });
      setChannel(res.channel);
      setIsSettingsOpen(false);
      alert('Official channel updated successfully!');
    } catch (err: any) {
      alert(`Update failed: ${err.message}`);
    }
  };

  const toggleSyndication = (platform: string) => {
    setSelectedSyndications((prev) =>
      prev.includes(platform) ? prev.filter((p) => p !== platform) : [...prev, platform]
    );
  };

  if (!channel) {
    return (
      <div className="py-24 text-center text-xs font-mono text-slate-400">
        Connecting to Official FUTUREVERSE Social Channel...
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-20 max-w-5xl mx-auto">
      {/* Official Channel Identity Banner (Exactly 1 Official Channel Rule) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={channel.avatar}
              alt={channel.channelName}
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full border-2 border-indigo-500/60 object-cover shadow-lg"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {channel.channelName}
                </h1>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Official Channel
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                @{channel.handle} · {channel.subscribersCount.toLocaleString()} Subscribers
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 rounded border border-slate-800 transition-colors cursor-pointer"
            >
              <Settings className="h-3.5 w-3.5" />
              <span>Channel Settings</span>
            </button>
          </div>
        </div>

        <p className="text-xs text-slate-300 max-w-3xl leading-relaxed border-t border-slate-800/80 pt-4">
          {channel.bio}
        </p>

        {/* 3 Publishing Modes Indicator */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Publishing Mode:</span>
            <span className="text-amber-300 font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
              {channel.publishingMode}
            </span>
          </div>

          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <span>Constraint: Strictly 1 Official Channel Per Account</span>
          </div>
        </div>

        {/* External Social Platform Connectors */}
        <div className="space-y-2 border-t border-slate-800/80 pt-4">
          <div className="text-xs font-semibold text-slate-400">Connected External Adapters:</div>
          <div className="flex flex-wrap gap-2 text-xs font-mono">
            {channel.connectedPlatforms.map((cp) => (
              <div
                key={cp.platform}
                className={`px-3 py-1.5 rounded border flex items-center gap-2 ${
                  cp.connected
                    ? 'border-indigo-800/80 bg-indigo-950/40 text-indigo-300'
                    : 'border-slate-800 bg-slate-950 text-slate-500'
                }`}
              >
                <span>{cp.platform}</span>
                <span className="text-[10px] text-slate-400">
                  {cp.connected ? `(${cp.accountHandle})` : 'Disconnected'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Post Composer */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 shadow-sm">
        <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
          <span>Broadcast Channel Update</span>
          <span className="text-slate-500 font-mono text-[11px]">Syndication Pipeline</span>
        </div>

        <form onSubmit={handleCreatePost} className="space-y-3">
          <textarea
            rows={3}
            placeholder="Write an announcement or engineering breakthrough to broadcast across the FUTUREVERSE network..."
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)}
            className="w-full px-3.5 py-2.5 text-xs rounded-lg bg-slate-950 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 leading-relaxed"
            required
          />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="text-slate-400">Syndicate to:</span>
              {['TELEGRAM', 'X', 'WHATSAPP'].map((plat) => (
                <button
                  key={plat}
                  type="button"
                  onClick={() => toggleSyndication(plat)}
                  className={`px-2 py-0.5 rounded text-[11px] cursor-pointer ${
                    selectedSyndications.includes(plat)
                      ? 'bg-indigo-900 text-indigo-200 border border-indigo-700'
                      : 'bg-slate-950 text-slate-500 border border-slate-800'
                  }`}
                >
                  {plat}
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={isPosting || !newPostContent.trim()}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{isPosting ? 'Broadcasting...' : 'Publish Post'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Social Posts Stream */}
      <div className="space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-lg font-bold text-white">Channel Broadcast Stream</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Public feed of official channel announcements and community updates.
          </p>
        </div>

        <div className="space-y-3">
          {posts.map((post) => (
            <div
              key={post.id}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-3 shadow-sm hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{post.author}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-500">{new Date(post.publishedAt).toLocaleDateString()}</span>
                </div>

                {post.agentAttribution && (
                  <span className="text-[11px] text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/60">
                    {post.agentAttribution}
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-200 leading-relaxed">{post.content}</p>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1">
                    <Heart className="h-3.5 w-3.5 text-rose-400" />
                    <span>{post.likes}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="h-3.5 w-3.5 text-indigo-400" />
                    <span>{post.commentsCount}</span>
                  </span>
                </div>

                <div className="flex items-center gap-1 text-[11px]">
                  <span>Syndicated:</span>
                  {post.syndicatedPlatforms?.map((p) => (
                    <span key={p} className="text-slate-300">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 8 Specialized Agents Governance Board */}
      <div className="space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-lg font-bold text-white">The 8 Specialized Social Agents</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Explicitly bounded agent roles governed by user permissions and Safety Guardian AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {agents.map((ag) => (
            <div
              key={ag.id}
              className="p-4 rounded-xl border border-slate-800 bg-slate-950/60 space-y-2 text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">{ag.role}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    ag.status === 'ACTIVE'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  {ag.status}
                </span>
              </div>
              <p className="text-slate-400 text-[11px] leading-snug">{ag.scope}</p>
              <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
                Last: {ag.lastAction}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Channel Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Channel Governance Settings</h3>
              <button onClick={() => setIsSettingsOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdateChannel} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Channel Display Name</label>
                <input
                  type="text"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Publishing Mode</label>
                <select
                  value={publishingMode}
                  onChange={(e) => setPublishingMode(e.target.value as any)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                >
                  <option value="MANUAL">Manual Publishing</option>
                  <option value="AI_ASSISTED">AI-Assisted with User Approval</option>
                  <option value="AUTOPILOT">Autopilot (Safety Guardian Supervised)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Channel Bio</label>
                <textarea
                  rows={3}
                  value={channelBio}
                  onChange={(e) => setChannelBio(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  Save Channel Settings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
