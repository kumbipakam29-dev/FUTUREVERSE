import React, { useState, useEffect } from 'react';
import { Clock, Shield, Sparkles, CheckCircle2, Lock, Unlock, Users, ArrowRight, AlertCircle, Key, Calendar, Pause, Play, RefreshCw, Settings } from 'lucide-react';
import { AuthoritativeCampaignState, CampaignLifecycleStatus } from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';
import { FutureverseLoader } from './FutureverseLoader';

interface LaunchCampaignViewProps {
  onExploreCreations: () => void;
  onOpenMembership: () => void;
}

export const LaunchCampaignView: React.FC<LaunchCampaignViewProps> = ({
  onExploreCreations,
  onOpenMembership,
}) => {
  const [campaign, setCampaign] = useState<AuthoritativeCampaignState | null>(null);
  const [email, setEmail] = useState('');
  const [handle, setHandle] = useState('');
  const [registerSuccess, setRegisterSuccess] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);

  // Synchronized countdown state derived from server authoritative time
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Admin reveal modal
  const [isAdminRevealOpen, setIsAdminRevealOpen] = useState(false);
  const [actorName, setActorName] = useState('Dhaval Chandrashekhar Batwal');
  const [isRevealing, setIsRevealing] = useState(false);

  // Admin schedule management modal (Section 5.3)
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [scheduleStatus, setScheduleStatus] = useState<CampaignLifecycleStatus>('ACTIVE');
  const [schedStart, setSchedStart] = useState('2026-10-01T00:00:00.000Z');
  const [schedReveal, setSchedReveal] = useState('2026-10-31T00:00:00.000Z');
  const [isSavingSchedule, setIsSavingSchedule] = useState(false);

  const fetchCampaign = async () => {
    try {
      const data = await api.getLaunchCampaign();
      setCampaign(data);
      setTimeLeft({
        days: data.daysRemaining,
        hours: data.hoursRemaining,
        minutes: data.minutesRemaining,
        seconds: data.secondsRemaining,
      });
      setScheduleStatus(data.status);
      if (data.scheduledStartTimestamp) setSchedStart(data.scheduledStartTimestamp);
      if (data.scheduledRevealTimestamp) setSchedReveal(data.scheduledRevealTimestamp);
    } catch (err) {
      console.error('Failed to load campaign:', err);
    }
  };

  useEffect(() => {
    fetchCampaign();
  }, []);

  // Timezone-safe local tick synchronized with server authoritative schedule
  useEffect(() => {
    if (!campaign || campaign.status === 'NOT_SCHEDULED' || campaign.status === 'PAUSED' || campaign.status === 'REVEALED') {
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        let totalSec = prev.days * 86400 + prev.hours * 3600 + prev.minutes * 60 + prev.seconds - 1;
        if (totalSec <= 0) {
          fetchCampaign();
          return { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
        const days = Math.floor(totalSec / 86400);
        const hours = Math.floor((totalSec % 86400) / 3600);
        const minutes = Math.floor((totalSec % 3600) / 60);
        const seconds = totalSec % 60;
        return { days, hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [campaign?.status]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsRegistering(true);
    try {
      const res = await api.registerEarlyAccess(email.trim(), handle.trim());
      setRegisterSuccess(res.message);
      fetchCampaign();
      setEmail('');
      setHandle('');
    } catch (err: any) {
      alert(`Registration error: ${err.message}`);
    } finally {
      setIsRegistering(false);
    }
  };

  const handleAdminReveal = async () => {
    setIsRevealing(true);
    try {
      await api.unlockDay30Reveal(actorName);
      setIsAdminRevealOpen(false);
      fetchCampaign();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsRevealing(false);
    }
  };

  const handleSaveSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSchedule(true);
    try {
      const res = await api.updateCampaignSchedule({
        status: scheduleStatus,
        scheduledStartTimestamp: schedStart,
        scheduledRevealTimestamp: schedReveal,
        actor: actorName,
      });
      alert(res.message);
      setIsScheduleModalOpen(false);
      fetchCampaign();
    } catch (err: any) {
      alert(`Error updating schedule: ${err.message}`);
    } finally {
      setIsSavingSchedule(false);
    }
  };

  if (!campaign) {
    return (
      <div className="py-24 flex items-center justify-center">
        <FutureverseLoader message="Syncing 30-Day Campaign Timeline with Authoritative Server State..." />
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-20 max-w-5xl mx-auto">
      {/* Campaign Banner Header */}
      <div className="text-center space-y-4">
        <div className="flex justify-center pb-1">
          <img
            src={ASSETS.futureverseLogo}
            alt="FUTUREVERSE Logo"
            className="h-10 sm:h-12 w-auto object-contain drop-shadow-[0_0_15px_rgba(99,102,241,0.35)]"
          />
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-mono font-semibold text-amber-300 bg-amber-950/50 border border-amber-800/60 rounded-full">
          {campaign.status === 'NOT_SCHEDULED' ? (
            <span>SCHEDULE PENDING</span>
          ) : campaign.status === 'PAUSED' ? (
            <span>COUNTDOWN PAUSED</span>
          ) : campaign.status === 'SCHEDULED' ? (
            <span>PRE-LAUNCH COUNTDOWN ACTIVE</span>
          ) : campaign.status === 'REVEALED' ? (
            <span>CAMPAIGN CONCLUDED · DAY 30 REVEALED</span>
          ) : (
            <>
              <span>STAGE {campaign.currentDay <= 5 ? '01' : campaign.currentDay <= 12 ? '02' : campaign.currentDay <= 21 ? '03' : campaign.currentDay <= 29 ? '04' : '05'} ACTIVE</span>
              <span>·</span>
              <span>DAY {String(campaign.currentDay).padStart(2, '0')} OF 30</span>
            </>
          )}
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-wider text-balance font-brand fv-chrome-title">
          THE 30-DAY MYSTERY LAUNCH
        </h1>

        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
          FUTUREVERSE — "ASK ANYTHING. BUILD ANYTHING."
          <br />
          Built with the community, not just for the community. The core architectural revelation of BATWAL’S VERSE AI and the YAGYX ecosystem unlocks on Day 30.
        </p>

        {/* Administration Schedule Controls */}
        <div className="flex items-center justify-center gap-3 pt-1">
          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] font-mono text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded border border-slate-800 transition-colors cursor-pointer"
          >
            <Settings className="h-3 w-3 text-amber-400" />
            <span>Campaign Governance Schedule</span>
          </button>
        </div>
      </div>

      {/* Real Timezone-Safe Authoritative Countdown Block */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-900/80 via-slate-950 to-slate-950 p-6 sm:p-8 text-center space-y-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div className="text-xs font-mono text-amber-300 uppercase tracking-widest text-left">
            {campaign.stateDescription}
          </div>
          <div className="text-[11px] font-mono text-slate-500">
            Timezone: {campaign.authoritativeTimezone} · Version {campaign.campaignVersion}
          </div>
        </div>

        {campaign.status === 'NOT_SCHEDULED' ? (
          <div className="py-8 text-slate-400 text-sm font-mono border border-dashed border-slate-800 rounded-xl">
            Campaign timeline has not been activated yet. Authoritative schedule will be published by platform governance.
          </div>
        ) : campaign.status === 'PAUSED' ? (
          <div className="py-8 text-amber-400 text-sm font-mono border border-amber-900/40 bg-amber-950/20 rounded-xl">
            Campaign countdown is temporarily paused for ecosystem maintenance. Existing days and allocations remain preserved.
          </div>
        ) : (
          <div className="grid grid-cols-4 gap-3 sm:gap-6 max-w-xl mx-auto font-mono">
            <div className="p-3 sm:p-5 rounded-xl border border-slate-800 bg-slate-950/90 shadow-inner">
              <div className="text-2xl sm:text-5xl font-extrabold text-white tabular-nums">
                {String(timeLeft.days).padStart(2, '0')}
              </div>
              <div className="text-[10px] sm:text-xs text-slate-500 uppercase mt-1">Days</div>
            </div>
            <div className="p-3 sm:p-5 rounded-xl border border-slate-800 bg-slate-950/90 shadow-inner">
              <div className="text-2xl sm:text-5xl font-extrabold text-white tabular-nums">
                {String(timeLeft.hours).padStart(2, '0')}
              </div>
              <div className="text-[10px] sm:text-xs text-slate-500 uppercase mt-1">Hours</div>
            </div>
            <div className="p-3 sm:p-5 rounded-xl border border-slate-800 bg-slate-950/90 shadow-inner">
              <div className="text-2xl sm:text-5xl font-extrabold text-white tabular-nums">
                {String(timeLeft.minutes).padStart(2, '0')}
              </div>
              <div className="text-[10px] sm:text-xs text-slate-500 uppercase mt-1">Minutes</div>
            </div>
            <div className="p-3 sm:p-5 rounded-xl border border-slate-800 bg-slate-950/90 shadow-inner">
              <div className="text-2xl sm:text-5xl font-extrabold text-amber-400 tabular-nums">
                {String(timeLeft.seconds).padStart(2, '0')}
              </div>
              <div className="text-[10px] sm:text-xs text-amber-500 uppercase mt-1">Seconds</div>
            </div>
          </div>
        )}

        <div className="text-xs text-slate-400 flex flex-wrap items-center justify-center gap-3 pt-2">
          <span>Authoritative Backend Timestamp</span>
          <span>·</span>
          <span>Zero Fabricated Scarcity Counters</span>
          <span>·</span>
          <span>No Client Clock Skew</span>
        </div>
      </div>

      {/* Early Access Registration (Open to all builders, no fake caps) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-8 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Early Access Registration (Open to All Eligible Builders)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Join during the 30-day window to secure genesis status and test prototype creation tools first.
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs text-slate-300 bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
            <Users className="h-4 w-4 text-indigo-400" />
            <span className="tabular-nums font-bold text-white">{campaign.registeredCount}</span>
            <span className="text-slate-400">Builders Enrolled</span>
          </div>
        </div>

        <form onSubmit={handleRegister} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="px-3.5 py-2.5 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 sm:col-span-1"
            required
          />
          <input
            type="text"
            placeholder="Preferred builder handle (optional)"
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            className="px-3.5 py-2.5 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 sm:col-span-1"
          />
          <button
            type="submit"
            disabled={isRegistering}
            className="px-5 py-2.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded-lg transition-all cursor-pointer whitespace-nowrap disabled:opacity-50"
          >
            {isRegistering ? 'Registering...' : 'Secure Early Access'}
          </button>
        </form>

        {registerSuccess && (
          <div className="p-3 rounded-lg border border-emerald-900/50 bg-emerald-950/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{registerSuccess}</span>
          </div>
        )}
      </div>

      {/* 5-Stage Configurable Campaign Sequence */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white">30-Day Campaign Progression Matrix</h2>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {campaign.stages.map((stage, i) => (
            <div
              key={i}
              className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                stage.status === 'COMPLETED'
                  ? 'border-emerald-900/60 bg-emerald-950/20 text-slate-300'
                  : stage.status === 'ACTIVE'
                    ? 'border-amber-500/80 bg-amber-950/30 text-white shadow-lg ring-1 ring-amber-500/40'
                    : 'border-slate-800 bg-slate-950/50 text-slate-400'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-semibold text-slate-400">{stage.dayRange}</span>
                  {stage.status === 'COMPLETED' ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" /> Done
                    </span>
                  ) : stage.status === 'ACTIVE' ? (
                    <span className="text-amber-300 flex items-center gap-1 font-bold animate-pulse">
                      ● Active
                    </span>
                  ) : (
                    <span className="text-slate-400">Upcoming</span>
                  )}
                </div>

                <div className="text-xs font-bold leading-snug">{stage.title}</div>
                <p className="text-[11px] leading-relaxed text-slate-400">{stage.teaser}</p>
              </div>

              {stage.status === 'ACTIVE' && (
                <div className="mt-3 pt-2 border-t border-amber-900/40 flex items-center gap-1 text-[11px] font-mono text-amber-300">
                  <Clock className="h-3 w-3" /> Active Now
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Day 30 Core Announcement Container with Access Control */}
      <div className="rounded-2xl border border-indigo-900/80 bg-gradient-to-b from-indigo-950/30 via-slate-950 to-slate-950 p-6 sm:p-8 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2">
            {campaign.isRevealed ? (
              <Unlock className="h-5 w-5 text-emerald-400" />
            ) : (
              <Lock className="h-5 w-5 text-amber-400" />
            )}
            <div>
              <div className="text-xs font-mono uppercase text-amber-300">Section 5 Protected Disclosure</div>
              <h2 className="text-lg font-bold text-white">Day 30 Scheduled Reveal</h2>
            </div>
          </div>

          {!campaign.isRevealed && (
            <button
              onClick={() => setIsAdminRevealOpen(true)}
              className="text-xs font-mono text-indigo-400 hover:text-indigo-300 underline cursor-pointer self-start sm:self-auto"
            >
              Permanent Authority Unlock Key
            </button>
          )}
        </div>

        <div className="space-y-3">
          <h3 className="text-base font-bold text-slate-100">
            {campaign.day30CoreReveal ? campaign.day30CoreReveal.headline : 'Classified Core Reveal — Day 30'}
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            {campaign.day30CoreReveal ? campaign.day30CoreReveal.visionDocument : 'Access restricted until Day 30 or authorized administrative unlock.'}
          </p>

          {campaign.isRevealed && campaign.day30CoreReveal ? (
            <div className="space-y-4 pt-3">
              <div className="p-4 rounded-xl border border-amber-900/40 bg-amber-950/20 text-xs space-y-2">
                <div className="font-bold text-amber-300">Ecosystem Blueprint:</div>
                <p className="text-slate-200 leading-relaxed">{campaign.day30CoreReveal.ecosystemBlueprint}</p>
              </div>

              <div className="space-y-1.5">
                <div className="text-xs font-semibold text-slate-300">Unlocked Capabilities:</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {campaign.day30CoreReveal.unlockedCapabilities.map((cap, i) => (
                    <div key={i} className="p-2.5 rounded border border-slate-800 bg-slate-900/60 flex items-center gap-2 text-slate-200">
                      <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                      <span>{cap}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40 text-xs text-slate-400 flex items-center gap-2">
              <Shield className="h-4 w-4 text-indigo-400 shrink-0" />
              <span>
                Protected under Section 5 access controls. Unlocks automatically when countdown reaches zero, or by authorized administrative trigger.
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Admin Unlock Modal */}
      {isAdminRevealOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Unlock Day 30 Core Announcement</h3>
              <button onClick={() => setIsAdminRevealOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300">
                This administrative action verifies permanent authority holder identity and unlocks the core disclosure for the platform.
              </p>
              <div className="space-y-1">
                <label className="text-slate-400">Authorized Operator Name</label>
                <input
                  type="text"
                  value={actorName}
                  onChange={(e) => setActorName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-medium"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdminRevealOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleAdminReveal}
                  disabled={isRevealing}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  {isRevealing ? 'Verifying Authority...' : 'Confirm & Unlock Reveal'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Campaign Schedule Governance Modal (Section 5.3) */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-950 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Authoritative Campaign Schedule</h3>
              </div>
              <button onClick={() => setIsScheduleModalOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSchedule} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-semibold">Lifecycle Status</label>
                <select
                  value={scheduleStatus}
                  onChange={(e) => setScheduleStatus(e.target.value as CampaignLifecycleStatus)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                >
                  <option value="ACTIVE">ACTIVE (Running 30-Day Window)</option>
                  <option value="SCHEDULED">SCHEDULED (Upcoming Pre-Launch Countdown)</option>
                  <option value="PAUSED">PAUSED (Hold Timeline Temporarily)</option>
                  <option value="REVEALED">REVEALED (Unlock Day 30 Immediately)</option>
                  <option value="NOT_SCHEDULED">NOT_SCHEDULED (Reset Configuration)</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-slate-300 font-semibold">Scheduled Start (ISO-8601)</label>
                  <input
                    type="text"
                    value={schedStart}
                    onChange={(e) => setSchedStart(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono text-[11px]"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-slate-300 font-semibold">Scheduled Reveal (ISO-8601)</label>
                  <input
                    type="text"
                    value={schedReveal}
                    onChange={(e) => setSchedReveal(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono text-[11px]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-semibold">Authorized Governance Operator</label>
                <input
                  type="text"
                  value={actorName}
                  onChange={(e) => setActorName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-medium"
                />
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-800/80 pt-2">
                This updates the durable configuration file in backend storage (`campaign_schedule.json`). The countdown will immediately recalculate from this authoritative timeline without client-side clock drift.
              </p>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingSchedule}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isSavingSchedule ? 'Persisting...' : 'Save & Enforce Schedule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
