import React from 'react';

export interface FutureverseIlluminatiEmblemProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'hero' | number;
  animated?: boolean;
  className?: string;
  theme?: 'dark' | 'light' | 'auto';
  onClick?: () => void;
  title?: string;
}

const sizeMap = {
  xs: 24,
  sm: 32,
  md: 48,
  lg: 72,
  xl: 120,
  hero: 200,
};

export const FutureverseIlluminatiEmblem: React.FC<FutureverseIlluminatiEmblemProps> = ({
  size = 'md',
  animated = true,
  className = '',
  theme = 'auto',
  onClick,
  title = 'FUTUREVERSE All-Seeing Quantum Eye Emblem',
}) => {
  const pixelSize = typeof size === 'number' ? size : sizeMap[size] || 48;
  const uniqueId = React.useId().replace(/:/g, '');

  return (
    <div
      className={`inline-flex items-center justify-center shrink-0 select-none relative group ${className}`}
      style={{ width: pixelSize, height: pixelSize }}
      onClick={onClick}
      role={onClick ? 'button' : 'img'}
      aria-label={title}
      title={title}
    >
      <svg
        viewBox="0 0 256 256"
        width={pixelSize}
        height={pixelSize}
        className="w-full h-full overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id={`neonGrad-${uniqueId}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00F0FF" />
            <stop offset="45%" stopColor="#6366F1" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>

          <linearGradient id={`cyberCyan-${uniqueId}`} x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="100%" stopColor="#00F0FF" />
          </linearGradient>

          <linearGradient id={`goldGrad-${uniqueId}`} x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#B45309" />
            <stop offset="25%" stopColor="#F59E0B" />
            <stop offset="50%" stopColor="#FFD700" />
            <stop offset="75%" stopColor="#FEF08A" />
            <stop offset="100%" stopColor="#B45309" />
          </linearGradient>

          <linearGradient id={`chromeGrad-${uniqueId}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="20%" stopColor="#E2E8F0" />
            <stop offset="48%" stopColor="#94A3B8" />
            <stop offset="52%" stopColor="#1E293B" />
            <stop offset="75%" stopColor="#475569" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>

          <radialGradient id={`eyeAura-${uniqueId}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.95" />
            <stop offset="45%" stopColor="#6366F1" stopOpacity="0.7" />
            <stop offset="75%" stopColor="#A855F7" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>

          <radialGradient id={`backdropAura-${uniqueId}`} cx="50%" cy="55%" r="60%">
            <stop offset="0%" stopColor="#6366F1" stopOpacity="0.45" />
            <stop offset="45%" stopColor="#00F0FF" stopOpacity="0.2" />
            <stop offset="85%" stopColor="#A855F7" stopOpacity="0.05" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>

          <filter id={`bloom-${uniqueId}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="b1" />
            <feMerge>
              <feMergeNode in="b1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id={`goldBloom-${uniqueId}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="gb" />
            <feMerge>
              <feMergeNode in="gb" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <circle cx="128" cy="132" r="105" fill={`url(#backdropAura-${uniqueId})`} />

        <g className={animated ? 'fv-orbit-outer' : ''}>
          <ellipse
            cx="128"
            cy="132"
            rx="114"
            ry="48"
            transform="rotate(-28 128 132)"
            stroke={`url(#neonGrad-${uniqueId})`}
            strokeWidth="2"
            strokeDasharray="6 8 18 8"
            opacity="0.85"
            filter={`url(#bloom-${uniqueId})`}
          />
          <circle cx="28" cy="86" r="3.5" fill="#00F0FF" className={animated ? 'fv-particle-node' : ''} />
          <circle cx="228" cy="178" r="4" fill="#A855F7" className={animated ? 'fv-particle-node' : ''} />
        </g>

        <g className={animated ? 'fv-orbit-inner' : ''}>
          <ellipse
            cx="128"
            cy="132"
            rx="108"
            ry="42"
            transform="rotate(38 128 132)"
            stroke={`url(#goldGrad-${uniqueId})`}
            strokeWidth="1.6"
            strokeDasharray="4 6 12 6"
            opacity="0.75"
            filter={`url(#goldBloom-${uniqueId})`}
          />
          <circle cx="218" cy="74" r="3" fill="#FEF08A" />
          <circle cx="38" cy="190" r="3" fill="#F59E0B" />
        </g>

        <g opacity="0.3" stroke={`url(#neonGrad-${uniqueId})`} strokeWidth="1">
          <line x1="128" y1="130" x2="128" y2="16" />
          <line x1="128" y1="130" x2="68" y2="28" />
          <line x1="128" y1="130" x2="188" y2="28" />
          <line x1="128" y1="130" x2="22" y2="88" />
          <line x1="128" y1="130" x2="234" y2="88" />
        </g>

        <g className={animated ? 'fv-pyramid-body' : ''}>
          <polygon
            points="128,26 232,208 24,208"
            stroke={`url(#goldGrad-${uniqueId})`}
            strokeWidth="3.2"
            fill="none"
            opacity="0.95"
            filter={`url(#goldBloom-${uniqueId})`}
          />

          <polygon
            points="128,42 216,196 40,196"
            stroke={`url(#chromeGrad-${uniqueId})`}
            strokeWidth="3.5"
            fill="#030712"
            fillOpacity="0.88"
          />

          <polygon
            points="128,58 200,184 56,184"
            stroke={`url(#neonGrad-${uniqueId})`}
            strokeWidth="2.4"
            fill="#0B0F19"
            fillOpacity="0.96"
            filter={`url(#bloom-${uniqueId})`}
          />

          <line x1="128" y1="58" x2="128" y2="108" stroke={`url(#goldGrad-${uniqueId})`} strokeWidth="1.6" opacity="0.8" />
          <line x1="128" y1="156" x2="128" y2="184" stroke={`url(#cyberCyan-${uniqueId})`} strokeWidth="1.6" opacity="0.8" />
          <line x1="56" y1="184" x2="102" y2="146" stroke={`url(#goldGrad-${uniqueId})`} strokeWidth="1.4" opacity="0.75" />
          <line x1="200" y1="184" x2="154" y2="146" stroke={`url(#goldGrad-${uniqueId})`} strokeWidth="1.4" opacity="0.75" />
        </g>

        <g className={animated ? 'fv-eye-core' : ''} transform="translate(0, 4)">
          <ellipse cx="128" cy="128" rx="46" ry="24" fill={`url(#eyeAura-${uniqueId})`} />

          <path
            d="M 80,128 C 96,104 160,104 176,128 C 160,152 96,152 80,128 Z"
            fill="#030712"
            stroke={`url(#goldGrad-${uniqueId})`}
            strokeWidth="2.6"
            filter={`url(#goldBloom-${uniqueId})`}
          />

          <path
            d="M 86,128 C 100,109 156,109 170,128 C 156,147 100,147 86,128 Z"
            stroke={`url(#neonGrad-${uniqueId})`}
            strokeWidth="1.6"
            fill="none"
          />

          <circle cx="128" cy="128" r="16" fill={`url(#neonGrad-${uniqueId})`} />
          <circle cx="128" cy="128" r="13" fill="#0B0F19" stroke={`url(#cyberCyan-${uniqueId})`} strokeWidth="1.6" />

          <polygon
            points="128,121 134,124.5 134,131.5 128,135 122,131.5 122,124.5"
            fill="#00F0FF"
            filter={`url(#bloom-${uniqueId})`}
          />
          <circle cx="128" cy="128" r="4" fill="#FFFFFF" />

          <circle cx="124" cy="123" r="2.8" fill="#FFFFFF" opacity="0.95" />
          <circle cx="132" cy="132" r="1.4" fill="#FEF08A" opacity="0.85" />
        </g>

        <polygon
          points="128,14 130.5,23 139,26 130.5,29 128,38 125.5,29 117,26 125.5,23"
          fill={`url(#goldGrad-${uniqueId})`}
          filter={`url(#goldBloom-${uniqueId})`}
        />

        <circle cx="24" cy="208" r="4.5" fill={`url(#goldGrad-${uniqueId})`} filter={`url(#goldBloom-${uniqueId})`} />
        <circle cx="24" cy="208" r="2" fill="#FFFFFF" />
        <circle cx="232" cy="208" r="4.5" fill={`url(#goldGrad-${uniqueId})`} filter={`url(#goldBloom-${uniqueId})`} />
        <circle cx="232" cy="208" r="2" fill="#FFFFFF" />
      </svg>
    </div>
  );
};
