import React, { useState } from 'react';
import { Sparkles, ArrowRight, Play, Star, GitFork, Compass, Layers, Shield, Terminal, ArrowUpRight } from 'lucide-react';
import { Project } from '../types';
import { ASSETS } from '../assets/images';
import { ProjectCard } from './ProjectCard';
import { FutureverseIlluminatiEmblem } from './FutureverseIlluminatiEmblem';

interface DiscoveryViewProps {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onStartCreation: (initialPrompt?: string) => void;
  onExploreMore: () => void;
  onOpenYagyx: () => void;
  onOpenStudios?: () => void;
}

export const DiscoveryView: React.FC<DiscoveryViewProps> = ({
  projects,
  onOpenProject,
  onStartCreation,
  onExploreMore,
  onOpenYagyx,
  onOpenStudios,
}) => {
  const [quickPrompt, setQuickPrompt] = useState('');

  const featuredProjects = projects.slice(0, 4);

  const samplePrompts = [
    'Create a tool that helps students explore career options and build a learning roadmap',
    'Simulate community treasury burn, multi-variable runway, and growth scenarios',
    'Architect a high-throughput data pipeline blueprint with security threat model',
    'Coordinate a distributed community bounty solver for open source bug fixes',
  ];

  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickPrompt.trim()) return;
    onStartCreation(quickPrompt.trim());
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Editorial Hero Section */}
      <section className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-10 lg:p-14">
        {/* Measured Scrim & Ambient Canvas */}
        <div className="absolute inset-0 z-0">
          <img
            src={ASSETS.heroCreationCanvas}
            alt="FUTUREVERSE Studio Canvas"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/40" />
        </div>

        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center justify-between gap-8">
          <div className="max-w-3xl space-y-6">
            <div className="flex flex-wrap items-center gap-3 sm:gap-4">
              <img
                src={ASSETS.futureverseLogo}
                alt="FUTUREVERSE Logo"
                className="h-10 sm:h-12 w-auto object-contain drop-shadow-[0_0_20px_rgba(99,102,241,0.35)]"
              />
              <div className="inline-flex items-center gap-2 text-xs font-mono text-amber-300 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-800">
                <span>YAGYX ECOSYSTEM</span>
                <span className="text-slate-600">·</span>
                <span>COMMUNITY CREATION PLATFORM</span>
              </div>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-wider text-white text-balance leading-[1.1] font-brand">
              ASK ANYTHING.
              <br />
              <span className="fv-chrome-title">BUILD ANYTHING.</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Built with the community, not just for the community. Transform natural-language ideas into working prototypes, structured engineering specs, and verified community projects on YAGYX Chain.
            </p>

            {/* Natural Language Creation Prompt Input */}
            <form
              onSubmit={handlePromptSubmit}
              className="rounded-xl border border-indigo-900/50 bg-slate-900/90 p-2 sm:p-2.5 shadow-[0_0_30px_rgba(0,240,255,0.08)] backdrop-blur-md flex flex-col sm:flex-row items-stretch gap-2 max-w-3xl focus-within:border-cyan-500/60 transition-all"
            >
              <input
                type="text"
                value={quickPrompt}
                onChange={(e) => setQuickPrompt(e.target.value)}
                placeholder="Describe what you want to create (e.g., student career roadmap, treasury simulator...)"
                className="flex-1 bg-transparent px-3 py-2 text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 hover:from-amber-200 hover:to-yellow-100 rounded-lg shadow-[0_0_18px_rgba(245,158,11,0.35)] transition-all whitespace-nowrap cursor-pointer uppercase font-brand tracking-wider"
              >
                <Sparkles className="h-4 w-4" />
                <span>Start Creating</span>
              </button>
            </form>

            {/* Creative Studio Hub entry link */}
            {onOpenStudios && (
              <div className="pt-1 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onOpenStudios}
                  className="inline-flex items-center gap-2 rounded-lg border border-cyan-500/40 bg-cyan-950/40 px-3.5 py-1.5 text-xs font-bold text-cyan-200 hover:bg-cyan-900/50 hover:text-cyan-100 transition-colors cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                >
                  <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Open Creative Studio Hub</span>
                </button>
                <span className="text-[11px] font-mono text-slate-500">14 Studios (Music, Image, Video, Voice, 3D, POD & Asset Library)</span>
              </div>
            )}

            {/* Quick Idea Starters */}
            <div className="pt-2">
              <div className="text-xs text-slate-400 mb-2">Try an idea prompt:</div>
              <div className="flex flex-wrap gap-2">
                {samplePrompts.map((p, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => onStartCreation(p)}
                    className="text-xs text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded px-2.5 py-1 text-left transition-colors cursor-pointer"
                  >
                    "{p.slice(0, 42)}..."
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Dedicated Illuminati Sacred Geometry Emblem Box (Desktop) */}
          <div className="hidden xl:flex flex-col items-center justify-center p-6 rounded-2xl border border-indigo-950/60 bg-gradient-to-b from-slate-900/80 via-slate-950/90 to-slate-950 p-6 shadow-2xl backdrop-blur-md shrink-0 w-64 text-center group">
            <FutureverseIlluminatiEmblem size={132} animated={true} />
            <div className="mt-4 space-y-1">
              <span className="text-[11px] font-mono font-bold tracking-widest text-amber-300 block uppercase">
                QUANTUM ALL-SEEING EYE
              </span>
              <span className="text-[10px] font-mono text-slate-400 block">
                SACRED GEOMETRY ENGINE
              </span>
              <div className="pt-1.5 flex items-center justify-center gap-1.5 text-[9px] font-mono text-cyan-400/90">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span>ACTIVE DUAL ORBIT</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Journey Rhythm */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono uppercase text-indigo-400">Core Journey</div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1">
              How FUTUREVERSE Works
            </h2>
          </div>
          <p className="text-xs text-slate-400 max-w-md">
            From initial curiosity to verified community rewards and deployed experiences.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { step: '01', title: 'ASK', desc: 'Describe your vision in plain natural language' },
            { step: '02', title: 'EXPLORE', desc: 'Benchmark peer solutions and prototypes' },
            { step: '03', title: 'CREATE', desc: 'Generate specs, flows & interactive sandbox' },
            { step: '04', title: 'SHARE', desc: 'Publish to the collective directory' },
            { step: '05', title: 'IMPROVE', desc: 'Iterate via community feedback & AI' },
            { step: '06', title: 'BUILD TOGETHER', desc: 'Verify work & claim YAGYX rewards' },
          ].map((item) => (
            <div
              key={item.step}
              className="p-4 rounded-xl border border-slate-800/80 bg-slate-950/60 space-y-2 hover:border-slate-700 transition-colors"
            >
              <div className="text-xs font-mono font-bold text-amber-300">{item.step}</div>
              <div className="text-sm font-bold text-white">{item.title}</div>
              <p className="text-xs text-slate-400 leading-snug">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Interactive Experiences */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono uppercase text-indigo-400">Interactive Catalog</div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight mt-1">
              Featured Interactive Experiences
            </h2>
          </div>
          <button
            onClick={onExploreMore}
            className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
          >
            <span>Browse Full Directory</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {featuredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onOpenProject={onOpenProject}
            />
          ))}
        </div>
      </section>

      {/* Ecosystem Pillars Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-amber-500/60 bg-gradient-to-b from-amber-950/30 to-slate-950 p-5 space-y-3">
          <div className="text-[11px] font-mono text-amber-300 font-bold uppercase">Section 5 Launch</div>
          <h3 className="text-sm font-bold text-white">30-Day Mystery Campaign</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Timezone-safe countdown, Stage 02 active, early access builder enrollment, and Day 30 protected reveal.
          </p>
          <button
            onClick={onExploreMore}
            className="inline-flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-200 font-semibold pt-1 cursor-pointer"
          >
            <span>Enter Campaign</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="rounded-xl border border-indigo-500/60 bg-gradient-to-b from-indigo-950/30 to-slate-950 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-[11px] font-mono text-indigo-300 font-bold uppercase">Section 11 AI Matrix</div>
            <img src={ASSETS.futureverseIcon} alt="FV" className="h-4 w-4 opacity-70" />
          </div>
          <img
            src={ASSETS.batwalsVerseAiHub}
            alt="BATWAL'S VERSE AI HUB"
            className="h-8 w-auto object-contain my-1"
          />
          <p className="text-xs text-slate-300 leading-relaxed">
            SARATHI task orchestrator routing across 9 modules: VIVEKA, BUDDHI, DRISHTI, VAANI, JNANA, SMRITI, KARMA, DHARMA, YOGA.
          </p>
          <button
            onClick={onExploreMore}
            className="inline-flex items-center gap-1.5 text-xs text-indigo-300 hover:text-indigo-200 font-semibold pt-1 cursor-pointer"
          >
            <span>Orchestrate AI</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3">
          <div className="text-[11px] font-mono text-slate-400 font-bold uppercase">Section 9 Compute</div>
          <h3 className="text-sm font-bold text-white">Compute 1% Commission</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Decentralized workload execution with strict 1% fee. Android thermal throttles, PC, GPU, and server grid.
          </p>
          <button
            onClick={onExploreMore}
            className="inline-flex items-center gap-1.5 text-xs text-slate-300 hover:text-white font-semibold pt-1 cursor-pointer"
          >
            <span>Open Marketplace</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3">
          <div className="text-[11px] font-mono text-slate-400 font-bold uppercase">Section 10 Social</div>
          <h3 className="text-sm font-bold text-white">Official Social Channels</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Strictly 1 official channel per account. Multi-platform syndication with 8 specialized agents and Safety Guardian AI.
          </p>
          <button
            onClick={onExploreMore}
            className="inline-flex items-center gap-1.5 text-xs text-slate-300 hover:text-white font-semibold pt-1 cursor-pointer"
          >
            <span>Visit Social Hub</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </section>

      {/* YAGYX Chain & Community Evolution Showcase */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-amber-500/40 bg-gradient-to-b from-amber-950/20 via-slate-950 to-slate-950 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-amber-300 font-bold">Ecosystem Infrastructure</span>
            <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">Chain ID: 13370 / 0x343a</span>
          </div>

          <div className="py-1">
            <img
              src={ASSETS.yagyxLogo}
              alt="YAGYX Chain"
              className="h-10 sm:h-12 w-auto object-contain"
            />
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            FUTUREVERSE operates directly on the YAGYX Chain network (Chain ID: 13370). Connect your EIP-1193 browser wallet to verify ownership, review transparent reward distributions, and track ecosystem assets (YAGYX ₹100, YGO ₹1, YINR ₹1 target, YUSD $1 target).
          </p>

          <div className="pt-2">
            <button
              onClick={onOpenYagyx}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-amber-200 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-700/60 rounded transition-colors cursor-pointer"
            >
              <span>Inspect YAGYX Network State</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-indigo-400">Governance & Bounties</span>
            <span className="text-xs font-mono text-slate-400">Transparent Review</span>
          </div>

          <h3 className="text-lg font-bold text-white">Evolution Board & Verified Rewards</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Propose features, report bugs, and claim verified task bounties. We reward substantiated engineering, documentation, security audits, and UI contributions with transparent criteria.
          </p>

          <div className="pt-2">
            <button
              onClick={onExploreMore}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded transition-colors cursor-pointer"
            >
              <span>Explore Platform Evolution</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
