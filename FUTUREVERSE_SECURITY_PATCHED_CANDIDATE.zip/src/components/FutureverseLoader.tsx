import React from 'react';
import { FutureverseIlluminatiEmblem } from './FutureverseIlluminatiEmblem';

export interface FutureverseLoaderProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  className?: string;
  fullScreen?: boolean;
}

export const FutureverseLoader: React.FC<FutureverseLoaderProps> = ({
  message = 'INITIALIZING YOUR FUTURE...',
  size = 'lg',
  className = '',
  fullScreen = false,
}) => {
  const content = (
    <div className={`flex flex-col items-center justify-center gap-5 text-center select-none ${className}`}>
      {/* Sacred Geometry Triangle + Eye Emblem in Celestial Glowing Ring */}
      <div className="relative p-3 rounded-full bg-slate-950/60 border border-indigo-950/80 shadow-[0_0_50px_rgba(99,102,241,0.25)]">
        <FutureverseIlluminatiEmblem size={size} animated={true} />
      </div>

      <div className="space-y-3 max-w-sm">
        {/* Brand Title in Orbitron */}
        <h2
          className="text-xl sm:text-2xl font-black tracking-widest text-white fv-chrome-text uppercase m-0"
          style={{ fontFamily: "'Orbitron', sans-serif" }}
        >
          FUTUREVERSE
        </h2>

        {/* Status Message */}
        <p
          className="text-[11px] sm:text-xs font-semibold tracking-[0.25em] uppercase text-cyan-300/90 m-0 flex items-center justify-center gap-1.5"
          style={{ fontFamily: "'Orbitron', sans-serif" }}
        >
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#FFD700] animate-pulse" />
          <span>{message}</span>
        </p>

        {/* Sleek Glowing Neon Progress Bar (Brand Kit Specific Neon Glow Gradient) */}
        <div className="w-56 sm:w-64 h-1.5 bg-[#080D1A] rounded-full overflow-hidden p-0.5 border border-[#1E293B] mx-auto shadow-inner">
          <div className="h-full rounded-full bg-gradient-to-r from-[#00F0FF] via-[#6366F1] to-[#D946EF] animate-[pulse_2s_ease-in-out_infinite] w-full shadow-[0_0_14px_rgba(0,240,255,0.85)]" />
        </div>
      </div>
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-xl">
        {content}
      </div>
    );
  }

  return content;
};
