import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  AudioLines,
  Box,
  BookOpen,
  CheckCircle2,
  Clapperboard,
  Command,
  Download,
  ExternalLink,
  FileImage,
  FolderOpen,
  Gamepad2,
  Globe,
  Image as ImageIcon,
  Mic,
  Music,
  Palette,
  Podcast,
  Save,
  Sparkles,
  Smartphone,
  Trash2,
  Video,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { ASSETS } from '../assets/images';

type StudioId =
  | 'music' | 'image' | 'video' | 'voice' | 'animation' | '3d'
  | 'game' | 'app' | 'website' | 'story' | 'podcast' | 'pod' | 'command' | 'assets';
type HubMode = 'command' | 'studios' | 'assets';

interface StudioSpec {
  id: StudioId;
  name: string;
  description: string;
  outputs: string;
  icon: LucideIcon;
  group: 'Media' | 'Build' | 'Publish';
  providerNote: string;
  promptStarter: string;
  badge: string;
}

interface CreativeAsset {
  id: string;
  title: string;
  studioId: StudioId;
  studioName: string;
  prompt: string;
  createdAt: string;
  style: string;
  state: 'Prompt draft';
}

const STORAGE_KEY = 'futureverse.creative-assets.v1';

const STUDIOS: StudioSpec[] = [
  {
    id: 'music', name: 'Music Studio', description: 'Plan original songs, instrumentals, soundtracks and sonic identities.',
    outputs: 'Song brief · lyrics outline · arrangement · production prompt', icon: Music, group: 'Media',
    providerNote: 'Audio rendering provider is NOT_CONNECTED. This workspace prepares structured briefs and production prompts for the Creation Engine.',
    promptStarter: 'Create an original music concept with mood, genre, tempo range, instrumentation, song structure, lyrical theme, and a distinct sonic identity. Avoid copying any existing song or artist.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'image', name: 'Image Studio', description: 'Build image-generation briefs for illustrations, product visuals and concept art.',
    outputs: 'Visual brief · composition · palette · image prompt', icon: ImageIcon, group: 'Media',
    providerNote: 'Image rendering provider is NOT_CONNECTED. This workspace drafts detailed artistic briefs; no real image render is claimed.',
    promptStarter: 'Create a detailed visual brief describing subject, composition, framing, lighting, palette, textures, background, intended use, aspect ratio, and exclusions.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'video', name: 'Video Studio', description: 'Prepare video concepts, shot lists, scripts and production plans.',
    outputs: 'Script · storyboard · shot list · video prompt', icon: Video, group: 'Media',
    providerNote: 'External video rendering provider is NOT_CONNECTED. This workspace prepares production-ready instructions.',
    promptStarter: 'Plan a video with goal, audience, duration, aspect ratio, scene-by-scene storyboard, camera movement, voiceover, music direction, transitions, captions, and final call to action.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'voice', name: 'Voice Studio', description: 'Draft voiceovers, narration, dialogue and speech-performance directions.',
    outputs: 'Voice script · pronunciation notes · delivery direction', icon: Mic, group: 'Media',
    providerNote: 'External voice synthesis provider is NOT_CONNECTED. Browser voice input exists elsewhere in the project.',
    promptStarter: 'Write a voiceover with audience, language, tone, speaking pace, pronunciation guidance, pause markers, and a natural spoken style. Do not imitate a real person without authorization.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'animation', name: 'Animation Studio', description: 'Create character, motion, scene and timing specifications.',
    outputs: 'Animatic brief · frame plan · motion cues', icon: Clapperboard, group: 'Media',
    providerNote: 'Animation rendering engine is NOT_CONNECTED. This workspace prepares motion design plans.',
    promptStarter: 'Create an animation brief with character designs, setting, visual style, key poses, scene timing, transitions, camera, motion principles, and output frame rate.', badge: 'NOT_CONNECTED',
  },
  {
    id: '3d', name: '3D Studio', description: 'Specify 3D assets, environments, materials, lighting and scene requirements.',
    outputs: 'Model brief · scene layout · material list', icon: Box, group: 'Media',
    providerNote: 'External 3D mesh rendering integration is NOT_CONNECTED.',
    promptStarter: 'Specify a 3D asset or scene including scale, topology expectations, geometry, materials, UVs, lighting, camera, rigging or collision needs, file formats, and optimization constraints.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'game', name: 'Game Studio', description: 'Map game concepts into mechanics, levels, systems and implementation plans.',
    outputs: 'Game design document · mechanics · technical plan', icon: Gamepad2, group: 'Build',
    providerNote: 'Existing Creation Engine can receive this brief; executable game compilation is not performed by this hub.',
    promptStarter: 'Design a game with core loop, player goals, controls, mechanics, progression, levels, accessibility, art/audio direction, target platform, architecture, and a test plan.', badge: 'Brief + hand-off',
  },
  {
    id: 'app', name: 'App Studio', description: 'Turn an app idea into user journeys, screen plans, APIs and acceptance criteria.',
    outputs: 'Product spec · screen map · API plan · test checklist', icon: Smartphone, group: 'Build',
    providerNote: 'Existing Creation Engine can process the brief; production deployment still needs configuration and verification.',
    promptStarter: 'Create an application specification with user problems, personas, journeys, screens, data model, API contracts, authentication, privacy, accessibility, error states, and acceptance tests.', badge: 'Uses Creation Engine',
  },
  {
    id: 'website', name: 'Website Studio', description: 'Plan responsive websites, information architecture and accessible page flows.',
    outputs: 'Sitemap · page briefs · responsive and SEO plan', icon: Globe, group: 'Build',
    providerNote: 'Existing Creation Engine can process the brief; hosting and live integrations must be verified separately.',
    promptStarter: 'Plan a responsive website with objectives, visitors, sitemap, page-by-page content, brand direction, components, SEO metadata, performance, accessibility, analytics, and deployment requirements.', badge: 'Uses Creation Engine',
  },
  {
    id: 'story', name: 'Story Studio', description: 'Develop original narratives, characters, worlds and structured story arcs.',
    outputs: 'Story bible · outline · character arcs · scenes', icon: BookOpen, group: 'Publish',
    providerNote: 'Text drafting is supported through hand-off; no external publishing is performed here.',
    promptStarter: 'Develop an original story with premise, genre, audience, world rules, character motivations, conflict, act structure, pacing, emotional arc, and ending. Avoid copying protected characters or plots.', badge: 'Text workspace',
  },
  {
    id: 'podcast', name: 'Podcast Studio', description: 'Outline episodes, interviews, narration, sound cues and publishing metadata.',
    outputs: 'Episode outline · host script · show notes', icon: Podcast, group: 'Publish',
    providerNote: 'External podcast distribution and audio mastering are NOT_CONNECTED.',
    promptStarter: 'Create a podcast episode plan with show premise, audience, episode duration, segment timings, host script, interview questions, transitions, sound cues, fact-check list, show notes, and title options.', badge: 'NOT_CONNECTED',
  },
  {
    id: 'pod', name: 'POD Design Studio', description: 'Create print-on-demand design briefs with print-safe and listing details.',
    outputs: 'Design brief · print placement · listing copy', icon: Palette, group: 'Publish',
    providerNote: 'Artwork rendering and storefront publishing are NOT_CONNECTED in this workspace.',
    promptStarter: 'Create a print-on-demand design brief with product type, audience, original concept, front/back placement, print area, palette, transparent-background needs, minimum line thickness, production constraints, and listing copy.', badge: 'NOT_CONNECTED',
  },
];

function readSavedAssets(): CreativeAsset[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is CreativeAsset => Boolean(item && typeof item.id === 'string' && typeof item.title === 'string' && typeof item.prompt === 'string'));
  } catch {
    return [];
  }
}

function writeSavedAssets(items: CreativeAsset[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    return true;
  } catch {
    return false;
  }
}

interface CreativeStudioHubProps {
  onStartCreation: (initialPrompt?: string) => void;
}

export const CreativeStudioHub: React.FC<CreativeStudioHubProps> = ({ onStartCreation }) => {
  const [mode, setMode] = useState<HubMode>('command');
  const [activeStudioId, setActiveStudioId] = useState<StudioId>('image');
  const [assetTitle, setAssetTitle] = useState('Untitled creative brief');
  const [brief, setBrief] = useState(STUDIOS.find((studio) => studio.id === 'image')?.promptStarter ?? 'Describe your creative goal.');
  const [style, setStyle] = useState('Futuristic, polished, accessible');
  const [savedAssets, setSavedAssets] = useState<CreativeAsset[]>(() => readSavedAssets());
  const [notice, setNotice] = useState('');

  const activeStudio = useMemo(() => STUDIOS.find((studio) => studio.id === activeStudioId) ?? STUDIOS[1], [activeStudioId]);

  const selectStudio = (studio: StudioSpec) => {
    setActiveStudioId(studio.id);
    setBrief(studio.promptStarter);
    setAssetTitle(`${studio.name} brief`);
    setMode('command');
    setNotice('');
  };

  const buildHandoffPrompt = () => [
    `FUTUREVERSE ${activeStudio.name.toUpperCase()} — CREATIVE BRIEF`,
    `Working title: ${assetTitle.trim() || activeStudio.name + ' brief'}`,
    `Creative direction: ${style.trim() || 'Use the brief as the creative direction.'}`,
    `User brief: ${brief.trim()}`,
    `Expected deliverables: ${activeStudio.outputs}`,
    'Implementation guardrails: Preserve existing FUTUREVERSE and YAGYX functionality. State provider dependencies and unknowns explicitly. Do not claim an image/audio/video/model render, external connection, deployment, or publication unless it is actually performed and verified.',
  ].join('\n\n');

  const saveDraft = () => {
    if (!brief.trim()) {
      setNotice('Add a brief before saving.');
      return;
    }
    const newAsset: CreativeAsset = {
      id: typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `asset-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      title: assetTitle.trim() || `${activeStudio.name} brief`,
      studioId: activeStudio.id,
      studioName: activeStudio.name,
      prompt: buildHandoffPrompt(),
      createdAt: new Date().toISOString(),
      style: style.trim(),
      state: 'Prompt draft',
    };
    const next = [newAsset, ...savedAssets];
    setSavedAssets(next);
    const ok = writeSavedAssets(next);
    setNotice(ok ? 'Draft saved to this browser’s local Asset Library.' : 'Browser storage is unavailable; the draft is visible until this page reloads.');
  };

  const deleteAsset = (id: string) => {
    const next = savedAssets.filter((asset) => asset.id !== id);
    setSavedAssets(next);
    const ok = writeSavedAssets(next);
    setNotice(ok ? 'Saved draft removed.' : 'Could not update browser storage.');
  };

  const exportAssets = () => {
    const blob = new Blob([JSON.stringify({ schemaVersion: 1, exportedAt: new Date().toISOString(), assets: savedAssets }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'futureverse-creative-assets.json';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const renderStudioCard = (studio: StudioSpec) => {
    const Icon = studio.icon;
    return (
      <button
        type="button"
        key={studio.id}
        onClick={() => selectStudio(studio)}
        className={`group rounded-2xl border p-4 sm:p-5 text-left transition-all hover:-translate-y-0.5 ${activeStudioId === studio.id ? 'border-cyan-400/70 bg-cyan-950/25 shadow-[0_0_24px_rgba(0,240,255,0.1)]' : 'border-slate-800 bg-slate-950/65 hover:border-indigo-500/60'}`}
      >
        <div className="flex items-start justify-between gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-indigo-500/30 bg-indigo-950/50 text-cyan-200"><Icon className="h-5 w-5" /></span>
          <span className="rounded-full border border-slate-700 px-2 py-1 text-[9px] font-mono text-slate-400">{studio.group}</span>
        </div>
        <h3 className="mt-4 text-sm font-bold text-white group-hover:text-cyan-100">{studio.name}</h3>
        <p className="mt-2 min-h-10 text-xs leading-relaxed text-slate-400">{studio.description}</p>
        <div className="mt-4 flex items-center gap-1.5 text-[10px] font-mono text-cyan-300"><span>Open workspace</span><ArrowRight className="h-3 w-3" /></div>
      </button>
    );
  };

  return (
    <div className="space-y-7 pb-16">
      <section
        className="relative overflow-hidden rounded-3xl border border-indigo-500/30 bg-slate-950 p-6 sm:p-9 lg:p-12"
        style={{ backgroundImage: `linear-gradient(100deg, rgba(2,6,23,.97) 0%, rgba(2,6,23,.86) 55%, rgba(2,6,23,.55) 100%), url("${ASSETS.heroCreationCanvas}")`, backgroundPosition: 'center', backgroundSize: 'cover' }}
      >
        <div className="relative z-10 max-w-4xl">
          <div className="flex flex-wrap items-center gap-3">
            <img src={ASSETS.futureverseLogo} alt="FUTUREVERSE" className="h-9 sm:h-12 w-auto max-w-[220px] object-contain" />
            <span className="rounded-full border border-cyan-500/30 bg-cyan-950/50 px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-cyan-200">Creative Command Center</span>
          </div>
          <h1 className="mt-5 text-3xl font-black tracking-tight text-white sm:text-5xl">One command. Every creative workflow.</h1>
          <p className="mt-4 max-w-3xl text-sm leading-relaxed text-slate-300 sm:text-base">Plan, organize and hand off work across music, image, video, voice, animation, 3D, games, apps, websites, stories, podcasts and print-on-demand. Existing YAGYX Commerce remains a separate, preserved module.</p>
          <div className="mt-5 flex flex-wrap gap-2 text-[10px] font-mono">
            <span className="rounded-full border border-emerald-500/30 bg-emerald-950/40 px-3 py-1.5 text-emerald-200">Workspace available</span>
            <span className="rounded-full border border-amber-500/30 bg-amber-950/40 px-3 py-1.5 text-amber-200">External render providers: not verified</span>
            <span className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-1.5 text-slate-300">Local-first asset drafts</span>
          </div>
        </div>
      </section>

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Creative workspace sections">
        {([
          { id: 'command', label: 'Command Center', icon: Command },
          { id: 'studios', label: 'All Studios', icon: Sparkles },
          { id: 'assets', label: `Asset Library (${savedAssets.length})`, icon: FolderOpen },
        ] as const).map((tab) => {
          const Icon = tab.icon;
          return <button key={tab.id} type="button" role="tab" aria-selected={mode === tab.id} onClick={() => { setMode(tab.id); setNotice(''); }} className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-xs font-semibold transition-colors ${mode === tab.id ? 'border-cyan-400/70 bg-cyan-950/40 text-cyan-100' : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'}`}><Icon className="h-4 w-4" />{tab.label}</button>;
        })}
      </div>

      {notice && <div role="status" className="rounded-xl border border-cyan-500/20 bg-cyan-950/20 px-4 py-3 text-xs text-cyan-100">{notice}</div>}

      {mode === 'studios' && (
        <section className="space-y-6">
          {(['Media', 'Build', 'Publish'] as const).map((group) => (
            <div key={group} className="space-y-3">
              <div className="flex items-end justify-between border-b border-slate-800 pb-2"><h2 className="text-sm font-bold uppercase tracking-[0.16em] text-slate-200">{group} Studios</h2><span className="text-[10px] font-mono text-slate-500">{STUDIOS.filter((studio) => studio.group === group).length} workspaces</span></div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">{STUDIOS.filter((studio) => studio.group === group).map(renderStudioCard)}</div>
            </div>
          ))}
        </section>
      )}

      {mode === 'command' && (
        <section className="grid grid-cols-1 gap-6 xl:grid-cols-[0.82fr_1.18fr]">
          <div className="space-y-3">
            <div className="flex items-center justify-between"><h2 className="text-sm font-bold text-white">Choose a studio</h2><button type="button" onClick={() => setMode('studios')} className="text-xs text-cyan-300 hover:text-cyan-100">View all</button></div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-2">{STUDIOS.map((studio) => {
              const Icon = studio.icon;
              return <button key={studio.id} type="button" onClick={() => selectStudio(studio)} className={`flex items-center gap-2 rounded-xl border p-3 text-left text-xs transition-colors ${activeStudio.id === studio.id ? 'border-cyan-400/60 bg-cyan-950/30 text-cyan-100' : 'border-slate-800 bg-slate-950/70 text-slate-300 hover:border-slate-600'}`}><Icon className="h-4 w-4 shrink-0" /><span>{studio.name}</span></button>;
            })}</div>
            <div className="rounded-2xl border border-amber-500/20 bg-amber-950/15 p-4"><div className="flex items-center gap-2 text-xs font-semibold text-amber-200"><CheckCircle2 className="h-4 w-4" />Truth & provider status</div><p className="mt-2 text-xs leading-relaxed text-slate-300">{activeStudio.providerNote}</p><p className="mt-2 text-[10px] font-mono text-amber-200/80">Status: {activeStudio.badge}</p></div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-950/75 p-5 sm:p-6">
            <div className="flex items-start gap-3"><span className="rounded-xl border border-cyan-500/30 bg-cyan-950/40 p-3 text-cyan-200"><activeStudio.icon className="h-5 w-5" /></span><div><div className="text-[10px] font-mono uppercase tracking-widest text-cyan-300">Active workspace</div><h2 className="mt-1 text-xl font-bold text-white">{activeStudio.name}</h2><p className="mt-1 text-xs text-slate-400">Expected hand-off: {activeStudio.outputs}</p></div></div>
            <div className="mt-6 space-y-4">
              <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-300">Project / asset title</span><input value={assetTitle} onChange={(event) => setAssetTitle(event.target.value)} maxLength={120} className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400" placeholder="Give this draft a name" /></label>
              <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-300">Creative direction</span><input value={style} onChange={(event) => setStyle(event.target.value)} maxLength={300} className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-cyan-400" placeholder="Mood, visual language, audience, constraints" /></label>
              <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-300">Brief / command</span><textarea value={brief} onChange={(event) => setBrief(event.target.value)} rows={7} maxLength={12000} className="w-full resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-3 text-sm leading-relaxed text-white outline-none focus:border-cyan-400" placeholder="Describe what you want to create…" /></label>
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3"><div className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Command preview</div><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed text-slate-300">{brief.trim() ? brief.trim().slice(0, 600) + (brief.trim().length > 600 ? '…' : '') : 'Your brief preview will appear here.'}</p></div>
              <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
                <button type="button" onClick={saveDraft} className="inline-flex items-center justify-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-950/40 px-4 py-3 text-xs font-bold text-cyan-100 hover:bg-cyan-900/50"><Save className="h-4 w-4" />Save draft</button>
                <button type="button" onClick={() => { if (!brief.trim()) { setNotice('Add a brief before handing it off.'); return; } onStartCreation(buildHandoffPrompt()); }} className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-300 to-yellow-200 px-4 py-3 text-xs font-black text-slate-950 hover:from-amber-200 hover:to-yellow-100"><Sparkles className="h-4 w-4" />Continue in Creation Engine<ExternalLink className="h-3.5 w-3.5" /></button>
                <button type="button" onClick={() => { setBrief(activeStudio.promptStarter); setNotice('Starter brief restored.'); }} className="rounded-xl border border-slate-700 px-4 py-3 text-xs text-slate-300 hover:bg-slate-900">Reset brief</button>
              </div>
            </div>
          </div>
        </section>
      )}

      {mode === 'assets' && (
        <section className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"><div><h2 className="text-xl font-bold text-white">Creative Asset Library</h2><p className="mt-1 text-xs text-slate-400">Saved prompt drafts are stored locally in this browser. They are not cloud-synced.</p></div><button type="button" onClick={exportAssets} disabled={!savedAssets.length} className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-700 px-4 py-2.5 text-xs font-semibold text-slate-200 disabled:cursor-not-allowed disabled:opacity-40"><Download className="h-4 w-4" />Export JSON</button></div>
          {!savedAssets.length ? <div className="rounded-2xl border border-dashed border-slate-700 bg-slate-950/60 px-6 py-14 text-center"><FolderOpen className="mx-auto h-9 w-9 text-slate-500" /><h3 className="mt-3 text-sm font-semibold text-white">No saved drafts yet</h3><p className="mt-1 text-xs text-slate-400">Open Command Center, choose a studio and save your first creative brief.</p><button type="button" onClick={() => setMode('command')} className="mt-4 rounded-lg bg-cyan-950/60 px-4 py-2 text-xs font-semibold text-cyan-200">Create a draft</button></div> : <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">{savedAssets.map((asset) => <article key={asset.id} className="rounded-2xl border border-slate-800 bg-slate-950/75 p-4"><div className="flex items-start justify-between gap-3"><div><div className="text-[10px] font-mono uppercase text-cyan-300">{asset.studioName} · {asset.state}</div><h3 className="mt-1 text-sm font-bold text-white">{asset.title}</h3><p className="mt-1 text-[10px] text-slate-500">Saved {new Date(asset.createdAt).toLocaleString()}</p></div><button type="button" onClick={() => deleteAsset(asset.id)} aria-label={`Delete ${asset.title}`} className="rounded-lg p-2 text-slate-500 hover:bg-rose-950/30 hover:text-rose-300"><Trash2 className="h-4 w-4" /></button></div><p className="mt-3 line-clamp-4 whitespace-pre-wrap text-xs leading-relaxed text-slate-400">{asset.prompt}</p><div className="mt-4 flex flex-wrap gap-2"><button type="button" onClick={() => { const studio = STUDIOS.find((candidate) => candidate.id === asset.studioId); if (studio) setActiveStudioId(studio.id); setAssetTitle(asset.title); setBrief(asset.prompt); setStyle(asset.style); setMode('command'); }} className="rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-200">Open draft</button><button type="button" onClick={() => onStartCreation(asset.prompt)} className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-950 px-3 py-2 text-xs font-semibold text-indigo-200"><Sparkles className="h-3.5 w-3.5" />Continue in Creation Engine</button></div></article>)}</div>}
        </section>
      )}

      <section className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4"><div className="flex items-center gap-2 text-xs font-bold text-slate-200"><FileImage className="h-4 w-4 text-cyan-300" />Preserve originals</div><p className="mt-2 text-xs leading-relaxed text-slate-400">Studio briefs and saved prompts are additive. Existing creation, workspace, social, compute and YAGYX screens stay in place.</p></div>
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4"><div className="flex items-center gap-2 text-xs font-bold text-slate-200"><AudioLines className="h-4 w-4 text-indigo-300" />Be clear about connections</div><p className="mt-2 text-xs leading-relaxed text-slate-400">No media provider is declared live unless configuration and a real request are verified. The hub currently creates briefs and hands them to the existing Creation Engine.</p></div>
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4"><div className="flex items-center gap-2 text-xs font-bold text-slate-200"><Command className="h-4 w-4 text-amber-300" />A single creative front door</div><p className="mt-2 text-xs leading-relaxed text-slate-400">Use one place to start a brief, save it locally, export an asset index, or continue through the existing builder workflow.</p></div>
      </section>
    </div>
  );
};
