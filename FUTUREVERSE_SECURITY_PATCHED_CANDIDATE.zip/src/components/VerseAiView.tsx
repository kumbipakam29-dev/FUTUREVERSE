import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Terminal,
  Sparkles,
  Search,
  Layers,
  ShieldCheck,
  Zap,
  ArrowRight,
  CheckCircle2,
  RefreshCw,
  BookOpen,
  Plus,
  GitBranch,
  History,
  AlertTriangle,
  RotateCcw,
  Check,
  ExternalLink,
  Users,
  Play,
  Activity,
  Award,
  Sigma,
} from 'lucide-react';
import {
  VerseModel,
  VerseAgent,
  SarathiRoutingResult,
  ModelNamingRecord,
  AgentVersionRecord,
  VersePersona,
  AgentTaskExecution,
} from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';

export const VerseAiView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'models' | 'naming' | 'personas' | 'agents' | 'sarathi'>('models');
  const [models, setModels] = useState<VerseModel[]>([]);
  const [agents, setAgents] = useState<VerseAgent[]>([]);
  const [namingRecords, setNamingRecords] = useState<ModelNamingRecord[]>([]);
  const [personas, setPersonas] = useState<VersePersona[]>([]);
  const [agentStats, setAgentStats] = useState<any>(null);
  const [personaStats, setPersonaStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCapability, setSelectedCapability] = useState('All');
  const [namingSearch, setNamingSearch] = useState('');
  const [namingFilterStatus, setNamingFilterStatus] = useState('ALL');
  const [personaSearch, setPersonaSearch] = useState('');
  const [personaFilterStyle, setPersonaFilterStyle] = useState('ALL');

  // SARATHI Orchestration Console State (Section 13)
  const [taskQuery, setTaskQuery] = useState(
    'Prove mathematical invariant and formal boundary for the 1% platform commission ledger'
  );
  const [routingResult, setRoutingResult] = useState<SarathiRoutingResult | null>(null);
  const [fullOrchestration, setFullOrchestration] = useState<any | null>(null);
  const [specialistRolesList, setSpecialistRolesList] = useState<any[]>([]);
  const [isOrchestrating, setIsOrchestrating] = useState(false);

  // Model Naming Candidate Generator Modal (Section 11)
  const [isNamingModalOpen, setIsNamingModalOpen] = useState(false);
  const [conceptInput, setConceptInput] = useState('');
  const [gitaVerseInput, setGitaVerseInput] = useState('');
  const [sanskritInput, setSanskritInput] = useState('');
  const [translationInput, setTranslationInput] = useState('');
  const [lessonInput, setLessonInput] = useState('');
  const [capabilityInput, setCapabilityInput] = useState('Reasoning, Verification & Invariant Safety');
  const [isGeneratingName, setIsGeneratingName] = useState(false);

  // Candidate Approval Modal
  const [selectedCandidateToLink, setSelectedCandidateToLink] = useState<ModelNamingRecord | null>(null);
  const [modelTypeToLink, setModelTypeToLink] = useState<'SPECIALIZED_CONFIG' | 'FINE_TUNED_MODEL' | 'BASE_MODEL'>(
    'SPECIALIZED_CONFIG'
  );
  const [modelLinkDesc, setModelLinkDesc] = useState('');
  const [isApproving, setIsApproving] = useState(false);

  // Agent Multiplication Modal (Section 12)
  const [isMultiplyModalOpen, setIsMultiplyModalOpen] = useState(false);
  const [selectedParentAgent, setSelectedParentAgent] = useState<VerseAgent | null>(null);
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentResponsibility, setNewAgentResponsibility] = useState('');
  const [newAgentPermissions, setNewAgentPermissions] = useState<string[]>([]);
  const [isMultiplying, setIsMultiplying] = useState(false);

  // Agent Task Execution Modal (Section 3 Audit)
  const [isExecuteModalOpen, setIsExecuteModalOpen] = useState(false);
  const [selectedAgentToExecute, setSelectedAgentToExecute] = useState<VerseAgent | null>(null);
  const [executionTaskInput, setExecutionTaskInput] = useState('');
  const [isExecutingTask, setIsExecutingTask] = useState(false);
  const [executionResult, setExecutionResult] = useState<AgentTaskExecution | null>(null);

  // Agent Version History Modal
  const [selectedAgentHistory, setSelectedAgentHistory] = useState<VerseAgent | null>(null);
  const [agentVersions, setAgentVersions] = useState<AgentVersionRecord[]>([]);

  // Persona Creation Modal
  const [isCreatePersonaOpen, setIsCreatePersonaOpen] = useState(false);
  const [newPersonaName, setNewPersonaName] = useState('');
  const [newPersonaTagline, setNewPersonaTagline] = useState('');
  const [newPersonaPurpose, setNewPersonaPurpose] = useState('');
  const [newPersonaStyle, setNewPersonaStyle] = useState<any>('Socratic Mentor');
  const [newPersonaInstructions, setNewPersonaInstructions] = useState('');
  const [newPersonaModel, setNewPersonaModel] = useState('Gemini 2.5 Flash');
  const [isCreatingPersona, setIsCreatingPersona] = useState(false);

  // 100,000 IQ Real Person Simulation Modal State
  const [simulatingPersona, setSimulatingPersona] = useState<VersePersona | null>(null);
  const [simulationPrompt, setSimulationPrompt] = useState('');
  const [simulationResult, setSimulationResult] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationError, setSimulationError] = useState<string | null>(null);

  const loadAllVerseData = async () => {
    try {
      const [modRes, agRes, nameRes, personaRes, aStats, pStats] = await Promise.all([
        api.getVerseModels(),
        api.getVerseAgents(),
        api.getModelNamingRecords(),
        api.getPersonas(),
        api.getAgentStats(),
        api.getPersonaStats(),
      ]);
      setModels(modRes.models);
      setAgents(agRes.agents);
      setNamingRecords(nameRes.records);
      setPersonas(personaRes.personas);
      setAgentStats(aStats);
      setPersonaStats(pStats);
    } catch (err) {
      console.error('Failed to load Verse AI data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllVerseData();
  }, []);

  const handleRunSarathi = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!taskQuery.trim()) return;

    setIsOrchestrating(true);
    try {
      const res = await api.orchestrateVerse(taskQuery.trim());
      setRoutingResult(res.routingResult);
      setFullOrchestration(res);
    } catch (err: any) {
      alert(`Orchestration error: ${err.message}`);
    } finally {
      setIsOrchestrating(false);
    }
  };

  const handleGenerateNameCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!conceptInput.trim()) return;

    setIsGeneratingName(true);
    try {
      const res = await api.generateModelNamingCandidate({
        themeOrConcept: conceptInput.trim(),
        gitaChapterVerse: gitaVerseInput.trim() || undefined,
        sanskritTerm: sanskritInput.trim() || undefined,
        englishTranslation: translationInput.trim() || undefined,
        positiveLesson: lessonInput.trim() || undefined,
        intendedCapability: capabilityInput.trim() || undefined,
        actor: 'Lead AI Engineer',
      });
      alert(res.message);
      setIsNamingModalOpen(false);
      setConceptInput('');
      setGitaVerseInput('');
      setSanskritInput('');
      setTranslationInput('');
      setLessonInput('');
      loadAllVerseData();
    } catch (err: any) {
      alert(`Candidate generation error: ${err.message}`);
    } finally {
      setIsGeneratingName(false);
    }
  };

  const handleApproveAndLinkCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidateToLink) return;

    setIsApproving(true);
    try {
      const res = await api.approveAndLinkModel({
        id: selectedCandidateToLink.id,
        approvalStatus: 'APPROVED',
        underlyingModelType: modelTypeToLink,
        underlyingModelLink: modelLinkDesc.trim() || `Configured profile on Gemini/Gemma runtime`,
        reviewerRecord: 'Approved by Dhaval Chandrashekhar Batwal & Lead Architect',
      });
      alert(res.message);
      setSelectedCandidateToLink(null);
      setModelLinkDesc('');
      loadAllVerseData();
    } catch (err: any) {
      alert(`Error approving candidate: ${err.message}`);
    } finally {
      setIsApproving(false);
    }
  };

  const handleOpenMultiplyModal = (parent: VerseAgent) => {
    setSelectedParentAgent(parent);
    setNewAgentName(`${parent.name.split(' ')[0]} Specialist`);
    setNewAgentResponsibility(`Specialized sub-task execution derived from ${parent.capability}`);
    setNewAgentPermissions([parent.permissionScope[0]]);
    setIsMultiplyModalOpen(true);
  };

  const handleMultiplyAgentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedParentAgent) return;

    setIsMultiplying(true);
    try {
      const res = await api.multiplyAgent({
        parentAgentId: selectedParentAgent.id,
        specializedName: newAgentName.trim(),
        responsibility: newAgentResponsibility.trim(),
        requestedPermissions: newAgentPermissions,
        requestedTools: selectedParentAgent.toolAccess,
        actor: 'SARATHI Orchestrator',
      });
      alert(res.message);
      setIsMultiplyModalOpen(false);
      loadAllVerseData();
    } catch (err: any) {
      alert(`Agent multiplication error: ${err.message}`);
    } finally {
      setIsMultiplying(false);
    }
  };

  const handleOpenExecuteModal = (agent: VerseAgent) => {
    setSelectedAgentToExecute(agent);
    setExecutionTaskInput(`Execute formal verification check using ${agent.toolAccess[0] || 'active tools'}`);
    setExecutionResult(null);
    setIsExecuteModalOpen(true);
  };

  const handleExecuteAgentTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgentToExecute || !executionTaskInput.trim()) return;

    setIsExecutingTask(true);
    try {
      const res = await api.executeAgentTask(selectedAgentToExecute.id, executionTaskInput.trim());
      setExecutionResult(res.execution);
      loadAllVerseData();
    } catch (err: any) {
      alert(`Task execution failed: ${err.message}`);
    } finally {
      setIsExecutingTask(false);
    }
  };

  const handleCreatePersonaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersonaName.trim() || !newPersonaPurpose.trim()) return;

    setIsCreatingPersona(true);
    try {
      const res = await api.createPersona({
        name: newPersonaName.trim(),
        tagline: newPersonaTagline.trim() || `${newPersonaName} Persona`,
        purpose: newPersonaPurpose.trim(),
        interactionStyle: newPersonaStyle,
        systemInstructions: newPersonaInstructions.trim() || 'Provide high-integrity analysis.',
        associatedBaseModel: newPersonaModel,
      });
      alert(res.message);
      setIsCreatePersonaOpen(false);
      setNewPersonaName('');
      setNewPersonaTagline('');
      setNewPersonaPurpose('');
      setNewPersonaInstructions('');
      loadAllVerseData();
    } catch (err: any) {
      alert(`Error creating persona: ${err.message}`);
    } finally {
      setIsCreatingPersona(false);
    }
  };

  const handleSimulatePersonaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simulatingPersona || !simulationPrompt.trim()) return;

    setIsSimulating(true);
    setSimulationError(null);
    try {
      const res = await api.simulatePersona(simulatingPersona.id, simulationPrompt.trim());
      setSimulationResult(res);
    } catch (err: any) {
      setSimulationError(err.message || 'Simulation inquiry failed');
    } finally {
      setIsSimulating(false);
    }
  };

  const handleViewAgentHistory = async (agent: VerseAgent) => {
    setSelectedAgentHistory(agent);
    try {
      const res = await api.getAgentVersions(agent.id);
      setAgentVersions(res.versions);
    } catch (err) {
      console.error('Failed to load versions:', err);
    }
  };

  const handleRollbackAgent = async (targetVer: string) => {
    if (!selectedAgentHistory) return;
    try {
      const res = await api.rollbackAgent(selectedAgentHistory.id, targetVer);
      alert(res.message);
      handleViewAgentHistory(selectedAgentHistory);
      loadAllVerseData();
    } catch (err: any) {
      alert(`Rollback failed: ${err.message}`);
    }
  };

  const filteredModels = models.filter((m) => {
    if (selectedCapability !== 'All' && m.capability !== selectedCapability) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        m.name.toLowerCase().includes(q) ||
        m.family.toLowerCase().includes(q) ||
        m.orchestratorModule.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredNamingRecords = namingRecords.filter((r) => {
    if (namingFilterStatus !== 'ALL' && r.verificationStatus !== namingFilterStatus) return false;
    if (namingSearch.trim()) {
      const q = namingSearch.toLowerCase();
      return (
        r.displayName.toLowerCase().includes(q) ||
        r.sanskritTerm.toLowerCase().includes(q) ||
        r.gitaChapterVerse.toLowerCase().includes(q) ||
        r.englishTranslation.toLowerCase().includes(q) ||
        r.positiveLesson.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredPersonas = personas.filter((p) => {
    if (personaFilterStyle === '1,000,000 IQ (1000k)' || personaFilterStyle === '1000k') {
      if (p.iqBenchmarkTarget !== 1000000 && !p.id.includes('1000k') && !p.tagline?.includes('1,000,000')) return false;
    } else if (personaFilterStyle === '100,000 IQ Polymaths' || personaFilterStyle === '10,000 IQ Polymaths') {
      if (!p.isHistoricalPolymathPersona && (!p.iqBenchmarkTarget || p.iqBenchmarkTarget < 10000)) return false;
    } else if (personaFilterStyle !== 'ALL' && p.interactionStyle !== personaFilterStyle) {
      return false;
    }
    if (personaSearch.trim()) {
      const q = personaSearch.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.purpose.toLowerCase().includes(q) ||
        p.associatedBaseModel.toLowerCase().includes(q) ||
        (p.realPersonInspiration && p.realPersonInspiration.toLowerCase().includes(q)) ||
        (p.cognitiveArchetype && p.cognitiveArchetype.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src={ASSETS.batwalsVerseAiHub}
              alt="BATWAL'S VERSE AI HUB"
              className="h-10 sm:h-12 w-auto object-contain"
            />
          </div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase text-amber-300">
            <span>AI ECOSYSTEM ARCHITECTURE</span>
            <span>·</span>
            <span>BATWAL’S VERSE AI</span>
          </div>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wider font-brand fv-chrome-title">
          BATWAL’S VERSE AI & CONTINUOUS EVOLUTION HUB
        </h1>
        <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
          Integrated intelligence layer for FUTUREVERSE. Unifies verified Gita-inspired model identities, distinct AI
          personas, autonomous bounded Sanskrit agents, and free-first SARATHI task routing.
        </p>

        {/* Audited Registry Statistics Banners (Audit Section 1 & 7) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-2 text-xs font-mono">
          <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <span className="text-slate-400">Verified Agents:</span>
            <span className="text-emerald-400 font-bold">
              {agentStats ? `${agentStats.uniqueAndValid} Active` : '12'}
            </span>
          </div>
          <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <span className="text-slate-400">Target Agents:</span>
            <span className="text-amber-300 font-bold">1,000,000,000 Target</span>
          </div>
          <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <span className="text-slate-400">Registered Personas:</span>
            <span className="text-indigo-400 font-bold">
              {personaStats ? `${personaStats.uniqueAndValid} Active` : '6'}
            </span>
          </div>
          <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <span className="text-slate-400">Target Personas:</span>
            <span className="text-amber-300 font-bold">1,000,000,000 Target</span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('models')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            activeTab === 'models'
              ? 'bg-amber-400 text-slate-950 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          Model Registry ({models.length})
        </button>
        <button
          onClick={() => setActiveTab('naming')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'naming'
              ? 'bg-amber-400 text-slate-950 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <BookOpen className="h-3.5 w-3.5" />
          <span>Gita Model Naming Engine ({namingRecords.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('personas')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'personas'
              ? 'bg-amber-400 text-slate-950 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Users className="h-3.5 w-3.5" />
          <span>AI Personas Registry ({personas.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('agents')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'agents'
              ? 'bg-amber-400 text-slate-950 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <GitBranch className="h-3.5 w-3.5" />
          <span>Sanskrit AI Agents ({agents.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('sarathi')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'sarathi'
              ? 'bg-amber-400 text-slate-950 font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Terminal className="h-3.5 w-3.5" />
          <span>SARATHI Task Router</span>
        </button>
      </div>

      {/* TAB 1: MODEL REGISTRY */}
      {activeTab === 'models' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type="text"
                placeholder="Search registered models or orchestrator module..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto text-xs">
              <span className="text-slate-400 text-[11px]">Capability:</span>
              {['All', 'Reasoning', 'Vision', 'Language', 'Code', 'Multimodal'].map((cap) => (
                <button
                  key={cap}
                  onClick={() => setSelectedCapability(cap)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCapability === cap
                      ? 'bg-indigo-600 text-white font-medium'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {cap}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredModels.map((m) => (
              <div
                key={m.id}
                className="p-5 rounded-xl border border-slate-800 bg-slate-950 hover:border-indigo-500/50 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-amber-300 font-semibold">{m.orchestratorModule}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-slate-300 border border-slate-800">
                      {m.status}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug">{m.name}</h3>
                  <div className="text-[11px] text-slate-400 font-mono">{m.family}</div>

                  <div className="text-xs text-slate-300 pt-1 flex flex-wrap gap-2">
                    <span className="px-2 py-0.5 rounded bg-slate-900/80 text-[11px] text-indigo-300 border border-slate-800">
                      {m.capability}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-900/80 text-[11px] text-slate-300 border border-slate-800">
                      {m.parameters}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span>Score: {m.benchmarkScore}</span>
                  <span>{m.license}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: GITA MODEL NAMING ENGINE (Section 11) */}
      {activeTab === 'naming' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-amber-900/40 bg-gradient-to-b from-amber-950/20 via-slate-950 to-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-mono uppercase text-amber-300">Section 11 Core Requirement</div>
                <h2 className="text-lg font-bold text-white">Infinite Meaningful Model Naming Engine</h2>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed mt-1">
                  Continuous pipeline proposing authentic model identities inspired by Bhagavad Gita teachings. Names
                  represent positive lessons and must never misrepresent un-trained models as separate neural networks.
                </p>
              </div>

              <button
                onClick={() => setIsNamingModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
              >
                <Plus className="h-4 w-4" />
                <span>Discover Teaching Candidate</span>
              </button>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search Sanskrit teaching, chapter, or positive lesson..."
                  value={namingSearch}
                  onChange={(e) => setNamingSearch(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400 text-[11px]">Verification:</span>
                {['ALL', 'VERIFIED', 'PENDING_VERIFICATION'].map((status) => (
                  <button
                    key={status}
                    onClick={() => setNamingFilterStatus(status)}
                    className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                      namingFilterStatus === status
                        ? 'bg-amber-400 text-slate-950 font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    {status}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Teaching Records Cards */}
          <div className="space-y-4">
            {filteredNamingRecords.map((r) => (
              <div
                key={r.id}
                className="p-5 sm:p-6 rounded-xl border border-slate-800 bg-slate-950 hover:border-amber-500/40 transition-all space-y-4 shadow-lg"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white tracking-tight">{r.displayName}</h3>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-950/60 text-amber-300 border border-amber-900/60">
                        {r.gitaChapterVerse}
                      </span>
                      {r.verificationStatus === 'VERIFIED' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-900/60 flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3" /> VERIFIED
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-950/40 text-amber-400 border border-amber-800/40">
                          PENDING VERIFICATION
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono text-slate-400 mt-0.5">Sanskrit Term: {r.sanskritTerm}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2 py-1 rounded text-[10px] font-mono bg-slate-900 text-indigo-300 border border-slate-800">
                      {r.underlyingModelType}
                    </span>
                    {r.underlyingModelType === 'CANDIDATE_NAME_ONLY' && (
                      <button
                        onClick={() => {
                          setSelectedCandidateToLink(r);
                          setModelLinkDesc('');
                        }}
                        className="px-2.5 py-1 text-[11px] font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded cursor-pointer"
                      >
                        Link to Model Profile
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/50 space-y-1.5">
                    <div className="text-[10px] font-mono text-amber-300 uppercase">Original Shloka (Sanskrit & IAST)</div>
                    <div className="font-serif text-slate-100 text-sm">{r.sanskritSourceText}</div>
                    <div className="text-slate-400 font-mono text-[11px] italic">{r.transliteration}</div>
                  </div>

                  <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/50 space-y-1.5">
                    <div className="text-[10px] font-mono text-indigo-300 uppercase">English Translation & Plain Meaning</div>
                    <p className="text-slate-200 leading-relaxed font-sans">{r.englishTranslation}</p>
                    <p className="text-slate-400 text-[11px] leading-relaxed">{r.plainLanguageExplanation}</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs pt-2 border-t border-slate-800/60 font-mono">
                  <div className="text-slate-300">
                    <span className="text-amber-300">Positive Lesson:</span> {r.positiveLesson}
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    <span className="text-indigo-400">Intended Capability:</span> {r.intendedCapability}
                  </div>
                </div>

                {r.underlyingModelLink && (
                  <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800 text-[11px] font-mono text-emerald-400 flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 shrink-0" />
                    <span>Mapped Implementation: {r.underlyingModelLink}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AI PERSONAS REGISTRY (Audit Section 2) */}
      {activeTab === 'personas' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-indigo-900/40 bg-gradient-to-b from-indigo-950/20 via-slate-950 to-slate-950 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-mono uppercase text-amber-300">Section 2 Audit Requirement</div>
                <h2 className="text-lg font-bold text-white">AI Personas Registry & Interaction Styles</h2>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed mt-1">
                  Distinct behavioral specializations, pedagogical styles, and role configurations. Defined separately
                  from underlying models to never misrepresent an interaction style as an independent neural network.
                </p>
              </div>

              <button
                onClick={() => setIsCreatePersonaOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
              >
                <Plus className="h-4 w-4" />
                <span>Create New Persona</span>
              </button>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search personas by name, purpose, or model..."
                  value={personaSearch}
                  onChange={(e) => setPersonaSearch(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-2 overflow-x-auto text-xs py-1">
                <span className="text-slate-400 text-[11px] whitespace-nowrap">Filter:</span>
                {[
                  'ALL',
                  '1,000,000 IQ (1000k)',
                  '100,000 IQ Polymaths',
                  'Mathematical & First-Principles Sage',
                  'Universal Polymath Polyglot',
                  'Socratic Mentor',
                  'Deterministic Systems Engineer',
                  'Empathetic Educator',
                  'Executive Strategic Lead',
                  'Constitutional Security Sentinel',
                ].map((style) => {
                  const is1000k = style === '1,000,000 IQ (1000k)';
                  const is100k = style === '100,000 IQ Polymaths';
                  const isSuper = is1000k || is100k;
                  return (
                    <button
                      key={style}
                      onClick={() => setPersonaFilterStyle(style)}
                      className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer whitespace-nowrap ${
                        personaFilterStyle === style
                          ? isSuper
                            ? 'bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                            : 'bg-indigo-600 text-white font-medium'
                          : isSuper
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-700/60 hover:bg-amber-900/80'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {is1000k ? '⚡ 1,000,000 IQ (1000k)' : is100k ? '⚡ 100,000 IQ Polymaths' : style.split(' ')[0]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPersonas.map((p) => {
              const isPolymath = p.isHistoricalPolymathPersona || (p.iqBenchmarkTarget && p.iqBenchmarkTarget >= 10000);
              const iqBenchmark = p.iqBenchmarkTarget || 100000;
              return (
                <div
                  key={p.id}
                  className={`p-5 rounded-xl border transition-all flex flex-col justify-between space-y-4 shadow-lg ${
                    isPolymath
                      ? 'border-amber-500/40 bg-gradient-to-b from-amber-950/20 via-slate-950 to-slate-950 hover:border-amber-400/80 shadow-amber-500/5'
                      : 'border-slate-800 bg-slate-950 hover:border-indigo-500/50'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`font-bold ${isPolymath ? 'text-amber-400' : 'text-indigo-300'}`}>{p.name}</span>
                        {isPolymath && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-400/20 text-amber-300 border border-amber-500/40">
                            ⚡ {iqBenchmark.toLocaleString()} IQ
                          </span>
                        )}
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-900 text-slate-300 border border-slate-800">
                        v{p.version} · {p.status}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white leading-snug">{p.tagline}</h3>

                    {p.realPersonInspiration && (
                      <div className="text-[11px] font-mono text-cyan-300 bg-cyan-950/40 px-2 py-1 rounded border border-cyan-800/40">
                        🏛️ Historical Inspiration: <span className="font-semibold">{p.realPersonInspiration}</span>
                      </div>
                    )}

                    <p className="text-xs text-slate-300 leading-relaxed">{p.purpose}</p>

                    {p.cognitiveArchetype && (
                      <div className="text-[10px] font-mono text-amber-300/90 bg-slate-900/80 px-2 py-1 rounded border border-slate-800">
                        🧠 Cognitive Archetype: {p.cognitiveArchetype}
                      </div>
                    )}

                    {p.authenticHistoricalSources && p.authenticHistoricalSources.length > 0 && (
                      <div className="text-[10px] font-mono text-slate-400 bg-slate-900/40 px-2 py-1 rounded border border-slate-800 flex items-center gap-1 flex-wrap">
                        <span className="text-slate-500">📜 Sources:</span>
                        {p.authenticHistoricalSources.map((s, idx) => (
                          <span key={idx} className="text-slate-300 bg-slate-800/80 px-1 rounded">
                            {s}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="space-y-1 pt-1 text-xs font-mono">
                      <div className="text-[10px] text-indigo-400 uppercase">Style: {p.interactionStyle}</div>
                      <div className="text-[10px] text-slate-400">Runtime: {p.associatedBaseModel}</div>
                      {p.associatedAgentId && (
                        <div className="text-[10px] text-emerald-400">Linked Worker: {p.associatedAgentId}</div>
                      )}
                    </div>

                    <div className="p-2.5 rounded bg-slate-900/50 border border-slate-800/80 text-[11px] text-slate-300 italic">
                      "{p.systemInstructions}"
                    </div>

                    {isPolymath && (
                      <div className="text-[10px] text-amber-400/80 font-mono italic">
                        * Pedagogical behavioral simulation honoring historical intellectual legacy. Not a biological human.
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 pt-3 border-t border-slate-800/80">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-400 text-[11px]">Eval Score: {p.evalScore}%</span>
                      <span className="text-emerald-400 text-[11px]">{p.totalInteractions} interactions</span>
                    </div>

                    {isPolymath && (
                      <button
                        onClick={() => {
                          setSimulatingPersona(p);
                          setSimulationPrompt('');
                          setSimulationResult(null);
                          setSimulationError(null);
                        }}
                        className="w-full py-1.5 px-3 rounded text-xs font-mono font-semibold bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 border border-amber-500/40 hover:border-amber-400 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        <span>Simulate 100,000 IQ Inquiry</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: SANSKRIT AI AGENTS & REAL EXECUTION (Section 12 & 3) */}
      {activeTab === 'agents' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-indigo-900/40 bg-gradient-to-b from-indigo-950/20 via-slate-950 to-slate-950 p-6 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-mono uppercase text-amber-300">Section 12 & 3 Real Execution Verification</div>
                <h2 className="text-lg font-bold text-white">Sanskrit AI Agent Registry & Task Dispatcher</h2>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  Autonomous agents carrying distinct Sanskrit responsibilities. You can execute real tasks directly
                  against each agent to verify permissions, tool access, measured latency, and resource metrics.
                </p>
              </div>

              <div className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded self-start sm:self-auto">
                {agentStats ? `${agentStats.totalTasksLogged} Verified Tasks Logged` : '0 Tasks Logged'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((ag) => (
              <div
                key={ag.id}
                className="p-5 rounded-xl border border-slate-800 bg-slate-950 hover:border-indigo-500/50 transition-all flex flex-col justify-between space-y-4 shadow-lg"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-amber-300 font-bold">{ag.name.split(' ')[0]}</span>
                    <span className="text-slate-400">v{ag.version}</span>
                  </div>

                  <h3 className="text-sm font-bold text-white leading-snug">{ag.name}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{ag.capability}</p>

                  <div className="space-y-1 pt-1 text-xs">
                    <div className="text-[10px] font-mono text-slate-400 uppercase">Permission Scope:</div>
                    <div className="flex flex-wrap gap-1">
                      {ag.permissionScope.map((p, i) => (
                        <span key={i} className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-slate-300 border border-slate-800">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1 pt-1 text-xs">
                    <div className="text-[10px] font-mono text-slate-400 uppercase">Active Tool Access:</div>
                    <div className="flex flex-wrap gap-1">
                      {ag.toolAccess.map((t, i) => (
                        <span key={i} className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-indigo-950/40 text-indigo-300 border border-indigo-900/60">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <div className="font-mono text-slate-400 text-[11px]">Eval: {ag.evalScore}%</div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleViewAgentHistory(ag)}
                      className="px-2 py-1 rounded bg-slate-900 text-slate-300 hover:text-white border border-slate-800 text-[11px] font-mono cursor-pointer"
                    >
                      History
                    </button>
                    <button
                      onClick={() => handleOpenMultiplyModal(ag)}
                      className="px-2 py-1 rounded bg-slate-900 text-slate-300 hover:text-white border border-slate-800 text-[11px] font-mono cursor-pointer"
                    >
                      Multiply
                    </button>
                    <button
                      onClick={() => handleOpenExecuteModal(ag)}
                      className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-[11px] cursor-pointer flex items-center gap-1"
                    >
                      <Play className="h-3 w-3" />
                      <span>Execute</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SARATHI TASK ROUTER (Section 13) */}
      {activeTab === 'sarathi' && (
        <div className="rounded-2xl border border-indigo-900/60 bg-gradient-to-b from-indigo-950/20 via-slate-950 to-slate-950 p-6 sm:p-7 space-y-5 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div>
              <div className="text-xs font-mono text-amber-300 uppercase">Interactive Task Router</div>
              <h2 className="text-lg font-bold text-white mt-0.5">SARATHI Central AI Orchestrator</h2>
            </div>
            <div className="text-xs font-mono text-slate-400 bg-slate-900 px-3 py-1 rounded border border-slate-800">
              Engine: Gemini 3.8 Flash + Symbolic Sanskrit Router
            </div>
          </div>

          <form onSubmit={handleRunSarathi} className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">
                Submit Task to SARATHI for Multi-Model Routing:
              </label>
              <textarea
                rows={2}
                value={taskQuery}
                onChange={(e) => setTaskQuery(e.target.value)}
                placeholder="Describe any reasoning, multimodal, linguistic, or code task..."
                className="w-full px-3.5 py-2.5 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-mono"
                required
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-1.5 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() =>
                    setTaskQuery(
                      'Synthesize formal invariant proof showing the 1% platform commission calculation is decimal-safe'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-900 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                >
                  Prompt 1: 1% Ledger Proof
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setTaskQuery(
                      'Translate Bhagavad Gita 2.47 into clear modern Hindi and English with software engineering metaphors'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-900 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                >
                  Prompt 2: BG 2.47 Translation
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setTaskQuery(
                      'Audit security perimeter: ensure Dhaval Chandrashekhar Batwal designation change cannot alter permissions'
                    )
                  }
                  className="px-2.5 py-1 rounded bg-slate-900 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                >
                  Prompt 3: Authority Anti-Lockout
                </button>
              </div>

              <button
                type="submit"
                disabled={isOrchestrating}
                className="px-5 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-300 to-indigo-200 hover:from-amber-200 hover:to-indigo-100 rounded-lg transition-all cursor-pointer whitespace-nowrap disabled:opacity-50"
              >
                {isOrchestrating ? 'SARATHI Routing...' : 'Route with SARATHI'}
              </button>
            </div>
          </form>

          {routingResult && (
            <div className="rounded-xl border border-indigo-900/60 bg-slate-950 p-5 space-y-4 animate-in fade-in">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-bold text-white">SARATHI Routing Decision Generated</span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
                  <span>Latency: ~{routingResult.estimatedLatencyMs}ms</span>
                  <span>·</span>
                  <span>Est. Cost: ₹{routingResult.estimatedCostInr} INR (Free-Tier Eligible)</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Selected Model</div>
                  <div className="text-amber-300 font-bold mt-0.5">{routingResult.selectedModel.name}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">{routingResult.selectedModel.parameters}</div>
                </div>
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Subsystem Matrix</div>
                  <div className="text-indigo-300 font-bold mt-0.5">{routingResult.routingSubsystem}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">{routingResult.selectedModel.capability}</div>
                </div>
                <div className="p-3 rounded bg-slate-900/80 border border-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase">Designated Lead Agent</div>
                  <div className="text-emerald-300 font-bold mt-0.5">{routingResult.selectedAgent?.name || 'SARATHI'}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">Eval: 99.2%</div>
                </div>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/50 text-xs text-slate-200 leading-relaxed font-sans">
                <div className="font-mono text-[10px] text-indigo-400 uppercase mb-1">Architectural Reasoning:</div>
                {routingResult.reasoningSummary}
              </div>

              {/* Master Build Prompt Part 2: 9-Stage Quality Review Gates & Multi-Perspective Reasoning */}
              {fullOrchestration && fullOrchestration.reviewStages && (
                <div className="space-y-3 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-amber-300">
                      Multi-Brain Quality Gates (9-Stage Verified Pipeline)
                    </span>
                    <span className="text-slate-400">
                      Confidence: {fullOrchestration.metrics?.confidenceScore || 98.4}% · Tokens: ~{fullOrchestration.metrics?.totalEstimatedTokens || 240}
                    </span>
                  </div>

                  {/* 9 Stages Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] font-mono">
                    {fullOrchestration.reviewStages.map((stg: any) => (
                      <div
                        key={stg.stage}
                        className={`p-2.5 rounded border ${
                          stg.status === 'PASSED'
                            ? 'bg-slate-900/70 border-emerald-900/50 text-slate-300'
                            : stg.status === 'RESOLVED'
                            ? 'bg-slate-900/70 border-indigo-900/50 text-indigo-200'
                            : 'bg-slate-900/70 border-amber-900/50 text-amber-200'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] text-slate-400">{stg.stageName}</span>
                          <span
                            className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                              stg.status === 'PASSED'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                            }`}
                          >
                            {stg.status}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 leading-tight">{stg.summary}</div>
                      </div>
                    ))}
                  </div>

                  {/* Adversarial Critic & Reconciliation */}
                  {fullOrchestration.adversarialChallenge && (
                    <div className="p-3 rounded-lg border border-amber-900/60 bg-amber-950/20 text-xs space-y-1.5">
                      <div className="flex items-center gap-2 font-mono text-[10px] text-amber-300 uppercase font-bold">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                        <span>Adversarial Critic Challenge & Invariant Reconciliation:</span>
                      </div>
                      <div className="text-slate-300 text-[11px]">
                        <span className="text-amber-400 font-semibold">Challenge: </span>
                        {fullOrchestration.adversarialChallenge.challengeStatement}
                      </div>
                      <div className="text-emerald-300 text-[11px]">
                        <span className="text-emerald-400 font-semibold">Reconciliation: </span>
                        {fullOrchestration.adversarialChallenge.reconciliationEvidence}
                      </div>
                    </div>
                  )}

                  {/* Explicit Truthfulness Notice & Limitations */}
                  <div className="p-2.5 rounded bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                    <div className="font-mono text-[9px] uppercase tracking-wider text-slate-500 font-bold">
                      Truthfulness & Explicit Limitations (Part 1.2 & 2.4):
                    </div>
                    <ul className="list-disc pl-4 space-y-0.5 text-[10px]">
                      {(fullOrchestration.finalOutput?.explicitLimitations || [
                        'Does not claim AGI or unmeasured human-level intelligence.',
                        'Grounds all invariant checks in deterministic server-side rules.',
                      ]).map((lim: string, idx: number) => (
                        <li key={idx}>{lim}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* MODAL: REAL AGENT TASK EXECUTION (Audit Section 3) */}
      {isExecuteModalOpen && selectedAgentToExecute && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-indigo-900/60 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Play className="h-4 w-4 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Execute Task with {selectedAgentToExecute.name}</h3>
              </div>
              <button onClick={() => setIsExecuteModalOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteAgentTaskSubmit} className="space-y-3 text-xs">
              <div className="text-slate-300">
                Agent Capability: <span className="text-amber-300">{selectedAgentToExecute.capability}</span>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Task Prompt / Invariant Instruction</label>
                <textarea
                  rows={3}
                  value={executionTaskInput}
                  onChange={(e) => setExecutionTaskInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono text-[11px]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsExecuteModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={isExecutingTask}
                  className="px-4 py-2 font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {isExecutingTask ? 'Executing...' : 'Run Agent Execution'}
                </button>
              </div>
            </form>

            {/* Execution Result Display */}
            {executionResult && (
              <div className="p-4 rounded-xl border border-emerald-900/60 bg-slate-900/60 space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between text-emerald-300 font-bold border-b border-slate-800 pb-1.5">
                  <span>Execution ID: {executionResult.executionId}</span>
                  <span>{executionResult.latencyMs}ms</span>
                </div>
                <div className="text-slate-200">{executionResult.outputSummary}</div>
                <div className="flex items-center justify-between text-slate-400 text-[10px] pt-1">
                  <span>RAM: {executionResult.resourceUsage.memoryMb}MB</span>
                  <span>Tokens: {executionResult.resourceUsage.tokenCount}</span>
                  <span>Cost: ₹{executionResult.resourceUsage.costInr}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: CREATE AI PERSONA (Audit Section 2) */}
      {isCreatePersonaOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-indigo-900/60 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Create New AI Persona</h3>
              <button onClick={() => setIsCreatePersonaOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreatePersonaSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Persona Name</label>
                  <input
                    type="text"
                    placeholder="e.g. PRAVAKTA"
                    value={newPersonaName}
                    onChange={(e) => setNewPersonaName(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono uppercase"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Interaction Style</label>
                  <select
                    value={newPersonaStyle}
                    onChange={(e) => setNewPersonaStyle(e.target.value as any)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  >
                    <option value="Socratic Mentor">Socratic Mentor</option>
                    <option value="Deterministic Systems Engineer">Deterministic Systems Engineer</option>
                    <option value="Empathetic Educator">Empathetic Educator</option>
                    <option value="Executive Strategic Lead">Executive Strategic Lead</option>
                    <option value="Constitutional Security Sentinel">Constitutional Security Sentinel</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Tagline</label>
                <input
                  type="text"
                  placeholder="e.g. Public-Facing Systems Narrator & Evangelist"
                  value={newPersonaTagline}
                  onChange={(e) => setNewPersonaTagline(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Purpose & Scope</label>
                <textarea
                  rows={2}
                  placeholder="Explains technical architecture to community members with high clarity..."
                  value={newPersonaPurpose}
                  onChange={(e) => setNewPersonaPurpose(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">System Instructions / Behavioral Guidelines</label>
                <textarea
                  rows={2}
                  placeholder="Speak clearly, emphasize verifiable proofs, and maintain positive pedagogy..."
                  value={newPersonaInstructions}
                  onChange={(e) => setNewPersonaInstructions(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Underlying Base Model</label>
                <input
                  type="text"
                  value={newPersonaModel}
                  onChange={(e) => setNewPersonaModel(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreatePersonaOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isCreatingPersona}
                  className="px-4 py-2 font-semibold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {isCreatingPersona ? 'Creating...' : 'Register Persona'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DISCOVER GITA MODEL NAME CANDIDATE */}
      {isNamingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-amber-900/60 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Discover & Propose Model Name</h3>
              <button onClick={() => setIsNamingModalOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleGenerateNameCandidate} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Core Sanskrit Teaching Concept</label>
                <input
                  type="text"
                  placeholder="e.g. DHRITI, TITIKSHA, KSHAMA, APARIGRAHA"
                  value={conceptInput}
                  onChange={(e) => setConceptInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 uppercase font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Gita Chapter & Verse</label>
                  <input
                    type="text"
                    placeholder="e.g. Bhagavad Gita 18.33"
                    value={gitaVerseInput}
                    onChange={(e) => setGitaVerseInput(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Sanskrit Script Term</label>
                  <input
                    type="text"
                    placeholder="e.g. धृति (Dhṛti)"
                    value={sanskritInput}
                    onChange={(e) => setSanskritInput(e.target.value)}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">English Translation & Plain Lesson</label>
                <textarea
                  rows={2}
                  placeholder="Unwavering steadfast determination that anchors the mind and actions..."
                  value={translationInput}
                  onChange={(e) => setTranslationInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Intended Model Capability</label>
                <input
                  type="text"
                  value={capabilityInput}
                  onChange={(e) => setCapabilityInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono"
                />
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-800/80 pt-2">
                Registered candidates undergo strict deduplication and are clearly tagged as `CANDIDATE_NAME_ONLY` to
                never misrepresent a name as a trained neural network.
              </p>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNamingModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGeneratingName}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {isGeneratingName ? 'Verifying & Proposing...' : 'Propose Candidate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LINK CANDIDATE TO MODEL PROFILE */}
      {selectedCandidateToLink && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Link Name to Implementation</h3>
              <button
                onClick={() => setSelectedCandidateToLink(null)}
                className="text-slate-400 hover:text-white text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleApproveAndLinkCandidate} className="space-y-3 text-xs">
              <div className="text-slate-300 font-medium">
                Identity: <span className="text-amber-300 font-bold">{selectedCandidateToLink.displayName}</span>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Underlying Technical Type</label>
                <select
                  value={modelTypeToLink}
                  onChange={(e) => setModelTypeToLink(e.target.value as any)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                >
                  <option value="SPECIALIZED_CONFIG">SPECIALIZED_CONFIG (System Profile on Base Model)</option>
                  <option value="FINE_TUNED_MODEL">FINE_TUNED_MODEL (Custom Weights)</option>
                  <option value="BASE_MODEL">BASE_MODEL (Self-Hosted Foundation Model)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Runtime / Service Specification</label>
                <input
                  type="text"
                  placeholder="e.g. Gemini 2.5 Flash with Formal Invariant Prompts"
                  value={modelLinkDesc}
                  onChange={(e) => setModelLinkDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedCandidateToLink(null)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isApproving}
                  className="px-4 py-2 font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {isApproving ? 'Linking...' : 'Approve & Link'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: MULTIPLY AGENT */}
      {isMultiplyModalOpen && selectedParentAgent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-md rounded-2xl border border-indigo-900/60 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Multiply Specialized Agent</h3>
              <button onClick={() => setIsMultiplyModalOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleMultiplyAgentSubmit} className="space-y-3 text-xs">
              <div className="text-slate-300">
                Parent Agent: <span className="text-amber-300 font-bold">{selectedParentAgent.name}</span>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Specialized Agent Display Name</label>
                <input
                  type="text"
                  value={newAgentName}
                  onChange={(e) => setNewAgentName(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 font-mono"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Specialized Scope & Responsibility</label>
                <textarea
                  rows={2}
                  value={newAgentResponsibility}
                  onChange={(e) => setNewAgentResponsibility(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Inherited Permissions (Subset of Parent)</label>
                <div className="space-y-1.5 p-2.5 rounded bg-slate-900 border border-slate-800">
                  {selectedParentAgent.permissionScope.map((perm) => (
                    <label key={perm} className="flex items-center gap-2 cursor-pointer text-[11px] font-mono">
                      <input
                        type="checkbox"
                        checked={newAgentPermissions.includes(perm)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewAgentPermissions([...newAgentPermissions, perm]);
                          } else {
                            setNewAgentPermissions(newAgentPermissions.filter((p) => p !== perm));
                          }
                        }}
                      />
                      <span>{perm}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsMultiplyModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isMultiplying}
                  className="px-4 py-2 font-semibold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {isMultiplying ? 'Synthesizing...' : 'Multiply Agent'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: AGENT VERSION HISTORY */}
      {selectedAgentHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Version Lineage: {selectedAgentHistory.name}</h3>
              <button onClick={() => setSelectedAgentHistory(null)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs max-h-80 overflow-y-auto">
              {agentVersions.length === 0 ? (
                <div className="text-slate-400 font-mono py-4 text-center">
                  Base release v{selectedAgentHistory.version} active. No custom revisions registered.
                </div>
              ) : (
                agentVersions.map((ver) => (
                  <div key={ver.versionId} className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/60 space-y-2">
                    <div className="flex items-center justify-between font-mono">
                      <span className="font-bold text-amber-300">v{ver.versionNumber}</span>
                      <span className="text-slate-500 text-[10px]">{new Date(ver.createdAt).toLocaleDateString()}</span>
                    </div>
                    <p className="text-slate-200">{ver.changeSummary}</p>
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800/80">
                      <span>Eval: {ver.evalScore}%</span>
                      {ver.versionNumber !== selectedAgentHistory.version && (
                        <button
                          onClick={() => handleRollbackAgent(ver.versionNumber)}
                          className="px-2 py-0.5 rounded bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold cursor-pointer"
                        >
                          Rollback to this
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedAgentHistory(null)}
                className="px-4 py-2 text-slate-300 bg-slate-900 hover:bg-slate-800 rounded text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: 100,000 IQ REAL PERSON PERSONA SIMULATION */}
      {simulatingPersona && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="w-full max-w-2xl rounded-2xl border border-amber-500/40 bg-slate-950 p-6 space-y-5 shadow-2xl my-8">
            <div className="flex items-start justify-between border-b border-amber-500/30 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-400 text-slate-950">
                    ⚡ 100,000 IQ SIMULATION
                  </span>
                  <span className="text-xs font-mono text-cyan-300">
                    {simulatingPersona.realPersonInspiration || simulatingPersona.name}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white">{simulatingPersona.name}</h3>
                <p className="text-xs text-amber-200/90 font-mono">{simulatingPersona.tagline}</p>
              </div>
              <button
                onClick={() => {
                  setSimulatingPersona(null);
                  setSimulationPrompt('');
                  setSimulationResult(null);
                  setSimulationError(null);
                }}
                className="text-slate-400 hover:text-white text-xl p-1"
              >
                ✕
              </button>
            </div>

            {/* Cognitive Archetype & Sources */}
            <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/20 space-y-1.5 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-bold text-amber-300">Cognitive Archetype:</span>
                <span className="text-slate-200">{simulatingPersona.cognitiveArchetype || simulatingPersona.purpose}</span>
              </div>
              {simulatingPersona.authenticHistoricalSources && simulatingPersona.authenticHistoricalSources.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap text-[11px]">
                  <span className="font-mono text-slate-400">Authentic Historical Treatises:</span>
                  {simulatingPersona.authenticHistoricalSources.map((src, i) => (
                    <span key={i} className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[10px]">
                      {src}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Simulation Query Form */}
            <form onSubmit={handleSimulatePersonaSubmit} className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-200">
                    Consultation Inquiry to {simulatingPersona.realPersonInspiration || simulatingPersona.name}:
                  </label>
                  <span className="text-[11px] text-slate-400 font-mono">100,000-IQ Cognitive Lens</span>
                </div>

                <textarea
                  rows={3}
                  value={simulationPrompt}
                  onChange={(e) => setSimulationPrompt(e.target.value)}
                  placeholder={`Pose an architectural problem, invariant constraint, or algorithm query to ${simulatingPersona.realPersonInspiration || simulatingPersona.name}...`}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 leading-relaxed font-mono"
                  required
                />

                {/* Quick suggestions */}
                <div className="flex items-center gap-1.5 flex-wrap text-[10px] font-mono">
                  <span className="text-slate-400">Suggestions:</span>
                  {[
                    'Formulate asymptotic invariants under network latency',
                    'Structure minimax game theory against collusive actors',
                    'Kinematic flow and visual harmony for distributed components',
                    'Zero-drift time synchronization across distributed ledgers',
                  ].map((sug, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSimulationPrompt(sug)}
                      className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer"
                    >
                      {sug.slice(0, 36)}...
                    </button>
                  ))}
                </div>
              </div>

              {simulationError && (
                <div className="p-3 rounded-lg bg-red-950/50 border border-red-800 text-xs text-red-300">
                  {simulationError}
                </div>
              )}

              <div className="flex items-center justify-between pt-1">
                <div className="text-[10px] text-slate-500 font-mono italic max-w-sm">
                  Transparency Notice: Pedagogical AI simulation honoring historical intellectual legacy.
                </div>

                <button
                  type="submit"
                  disabled={isSimulating || !simulationPrompt.trim()}
                  className="px-4 py-2 rounded-lg font-mono font-bold text-xs bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center gap-2 cursor-pointer disabled:opacity-50 transition-colors shadow-md shadow-amber-500/20"
                >
                  {isSimulating ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Synthesizing Proof...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" />
                      <span>Execute Simulation</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Simulation Results Section */}
            {simulationResult && (
              <div className="space-y-3 pt-3 border-t border-amber-500/30">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="font-mono font-bold text-emerald-300">
                      Simulation Synthesized ({simulationResult.historicalName || simulatingPersona.name})
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    IQ: {simulationResult.iqBenchmark?.toLocaleString() || '100,000'}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/30 text-xs text-slate-200 space-y-3 leading-relaxed max-h-72 overflow-y-auto whitespace-pre-line font-serif">
                  {simulationResult.response}
                </div>

                {simulationResult.transparencyNotice && (
                  <div className="text-[10px] font-mono text-amber-300/80 bg-amber-950/30 p-2 rounded border border-amber-800/40">
                    ℹ️ {simulationResult.transparencyNotice}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
