import React from 'react';
import { FutureverseIlluminatiEmblem } from './FutureverseIlluminatiEmblem';

export interface FutureverseBrandLogoProps {
  variant?: 'full' | 'compact' | 'emblem-only';
  emblemSize?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'hero' | number;
  animated?: boolean;
  className?: string;
  onClick?: () => void;
  subtitle?: string;
}

export const FutureverseBrandLogo: React.FC<FutureverseBrandLogoProps> = ({
  variant = 'full',
  emblemSize = 'sm',
  animated = true,
  className = '',
  onClick,
  subtitle = 'BUILD • CREATE • COMPUTE • EVOLVE',
}) => {
  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 text-left cursor-pointer select-none group transition-all ${className}`}
      role={onClick ? 'button' : 'banner'}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
    >
      {/* Sacred Geometry Triangle + Eye Emblem */}
      <FutureverseIlluminatiEmblem
        size={emblemSize}
        animated={animated}
        className="transition-transform duration-300 group-hover:scale-105"
      />

      {variant !== 'emblem-only' && (
        <div className="flex flex-col justify-center min-w-0">
          <div className="flex items-center gap-1.5">
            <span
              className="font-black tracking-widest text-white text-base sm:text-lg lg:text-xl fv-chrome-text leading-tight uppercase"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              FUTUREVERSE
            </span>
          </div>
          {variant === 'full' && (
            <span
              className="text-[8.5px] sm:text-[9.5px] font-bold tracking-[0.25em] text-slate-300/90 truncate block uppercase leading-none mt-1"
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              {subtitle}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
