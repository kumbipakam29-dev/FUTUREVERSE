import React, { useState } from 'react';
import { Award, CheckCircle2, Clock, AlertTriangle, ShieldCheck, Plus, ExternalLink, UserCheck } from 'lucide-react';
import { ContributorTask, TaskDifficulty, ContributorProfile } from '../types';
import { api } from '../services/api';
import { ASSETS } from '../assets/images';

interface RewardsViewProps {
  tasks: ContributorTask[];
  onRefresh: () => void;
}

export const RewardsView: React.FC<RewardsViewProps> = ({ tasks, onRefresh }) => {
  const [selectedTaskForSubmission, setSelectedTaskForSubmission] = useState<ContributorTask | null>(null);
  const [submissionUrl, setSubmissionUrl] = useState('');
  const [submissionNotes, setSubmissionNotes] = useState('');
  const [contributorName, setContributorName] = useState('');
  const [contributorAddress, setContributorAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [isReviewerMode, setIsReviewerMode] = useState(false);
  const [reviewDecisionTask, setReviewDecisionTask] = useState<{ task: ContributorTask; submissionId: string } | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);

  // Verified Contributor Profile
  const profile: ContributorProfile = {
    name: 'Elena Rostova',
    handle: 'elena_ai',
    address: '0x71C839...52B',
    role: 'Founding Member',
    foundingMember: true,
    acceptedContributions: 14,
    projectsCreated: 6,
    projectsImproved: 9,
    verifiedBugFixes: 5,
    rewardPoints: 3450,
    badges: ['Founding Architect', 'Security Auditor Level 1', 'Curriculum Synthesizer', 'EIP-1193 Tester'],
  };

  const handleSubmitWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTaskForSubmission || !submissionUrl.trim() || !submissionNotes.trim()) return;

    setIsSubmitting(true);
    try {
      await api.submitTaskWork(selectedTaskForSubmission.id, {
        contributorName: contributorName.trim() || 'Community Contributor',
        contributorAddress: contributorAddress.trim() || '0x71C...39B',
        submissionUrl: submissionUrl.trim(),
        notes: submissionNotes.trim(),
      });
      setSelectedTaskForSubmission(null);
      setSubmissionUrl('');
      setSubmissionNotes('');
      onRefresh();
    } catch (err: any) {
      alert(`Submission failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReviewDecision = async (decision: 'ACCEPT' | 'REJECT') => {
    if (!reviewDecisionTask) return;
    setIsReviewing(true);
    try {
      await api.reviewTaskSubmission(reviewDecisionTask.task.id, {
        submissionId: reviewDecisionTask.submissionId,
        decision,
        reviewNote: reviewNote.trim(),
      });
      setReviewDecisionTask(null);
      setReviewNote('');
      onRefresh();
    } catch (err: any) {
      alert(`Review failed: ${err.message}`);
    } finally {
      setIsReviewing(false);
    }
  };

  const getDifficultyBadge = (difficulty: TaskDifficulty) => {
    switch (difficulty) {
      case 'Starter':
        return 'text-emerald-400 border-emerald-800/80 bg-emerald-950/40';
      case 'Intermediate':
        return 'text-amber-400 border-amber-800/80 bg-amber-950/40';
      case 'Advanced':
        return 'text-purple-400 border-purple-800/80 bg-purple-950/40';
    }
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Contributor Profile Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={ASSETS.avatarElena}
              alt={profile.name}
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full border-2 border-indigo-500/60 object-cover shadow-lg"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white tracking-tight">{profile.name}</h2>
                <span className="text-xs font-mono text-amber-300 px-2 py-0.5 rounded bg-amber-950/50 border border-amber-800/50">
                  {profile.role}
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                @{profile.handle} · {profile.address}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsReviewerMode(!isReviewerMode)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded border transition-colors cursor-pointer ${
                isReviewerMode
                  ? 'border-indigo-600 bg-indigo-950 text-indigo-200'
                  : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>{isReviewerMode ? 'Reviewer Mode Active' : 'Switch to Reviewer Mode'}</span>
            </button>
          </div>
        </div>

        {/* Real Quantitative Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-slate-800/80 pt-6">
          <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/40">
            <div className="text-xs text-slate-400 font-medium">Accepted Contributions</div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums mt-1">
              {profile.acceptedContributions}
            </div>
          </div>
          <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-950/60">
            <div className="text-xs text-slate-400 font-medium">Projects Created</div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums mt-1">
              {profile.projectsCreated}
            </div>
          </div>
          <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-900/40">
            <div className="text-xs text-slate-400 font-medium">Verified Bug Fixes</div>
            <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums mt-1">
              {profile.verifiedBugFixes}
            </div>
          </div>
          <div className="p-3.5 rounded-lg border border-slate-800/80 bg-slate-950/60">
            <div className="text-xs text-slate-400 font-medium">Ecosystem Rep Points</div>
            <div className="text-2xl font-bold font-mono text-indigo-400 tabular-nums mt-1">
              {profile.rewardPoints}
            </div>
          </div>
        </div>

        {/* Verified Badges */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <span className="text-xs text-slate-400 mr-2">Verified Badges:</span>
          {profile.badges.map((b) => (
            <span
              key={b}
              className="text-xs text-slate-300 font-mono px-2.5 py-1 rounded bg-slate-900 border border-slate-800"
            >
              ✓ {b}
            </span>
          ))}
        </div>
      </div>

      {/* Verified Task Bounties Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <div className="text-xs font-mono uppercase text-indigo-400">Verifiable Bounties</div>
            <h3 className="text-xl font-bold text-white tracking-tight mt-1">
              Contributor Tasks & Rewards Board
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Complete specific engineering, UI/UX, testing, or documentation tasks with verified acceptance criteria to earn recognized rewards on YAGYX Chain.
            </p>
          </div>

          <div className="text-xs font-mono text-slate-400 bg-slate-900 px-3 py-1.5 rounded border border-slate-800 self-start sm:self-auto">
            Review: Available → Submitted → Under Review → Approved
          </div>
        </div>

        {/* Task Cards */}
        <div className="space-y-4">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-4 hover:border-slate-700 transition-all shadow-sm"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className="text-indigo-400">{task.category}</span>
                  <span>·</span>
                  <span className={`px-2 py-0.5 rounded border text-[11px] ${getDifficultyBadge(task.difficulty)}`}>
                    {task.difficulty}
                  </span>
                  <span>·</span>
                  <span className="text-slate-400">Created {new Date(task.createdAt).toLocaleDateString()}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-800/60 px-2.5 py-1 rounded">
                    Reward: {task.rewardAmount}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="text-base font-bold text-white">{task.title}</h4>
                <div className="text-xs text-slate-400 mt-1">
                  Type: <span className="text-slate-300">{task.rewardType}</span>
                </div>
              </div>

              {/* Requirements & Acceptance Criteria */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-950/60 p-4 rounded-lg border border-slate-800/80">
                <div className="space-y-1.5">
                  <div className="font-semibold text-slate-300">Task Requirements:</div>
                  <ul className="space-y-1 text-slate-400 list-disc list-inside leading-relaxed">
                    {task.requirements.map((req, i) => (
                      <li key={i}>{req}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1.5">
                  <div className="font-semibold text-slate-300">Acceptance Criteria:</div>
                  <ul className="space-y-1 text-slate-400 list-disc list-inside leading-relaxed">
                    {task.acceptanceCriteria.map((crit, i) => (
                      <li key={i}>{crit}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Existing Submissions List */}
              {task.submissions.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <div className="text-xs font-semibold text-slate-400">
                    Existing Submissions ({task.submissions.length}):
                  </div>
                  {task.submissions.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-3 rounded border border-slate-800 bg-slate-950/70 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-semibold text-slate-200">
                          {sub.contributorName} ({sub.contributorAddress})
                        </div>
                        <p className="text-slate-400 text-[11px] mt-0.5">{sub.notes}</p>
                        <a
                          href={sub.submissionUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-indigo-400 hover:underline text-[11px] inline-flex items-center gap-1 mt-1"
                        >
                          <span>Review Proof URL</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                            sub.status === 'ACCEPTED'
                              ? 'border-emerald-800 text-emerald-300 bg-emerald-950/50'
                              : sub.status === 'REJECTED'
                              ? 'border-rose-800 text-rose-300 bg-rose-950/50'
                              : 'border-amber-800 text-amber-300 bg-amber-950/50'
                          }`}
                        >
                          {sub.status}
                        </span>

                        {isReviewerMode && sub.status === 'PENDING' && (
                          <button
                            onClick={() => setReviewDecisionTask({ task, submissionId: sub.id })}
                            className="px-2 py-1 text-[11px] font-mono bg-indigo-900/60 hover:bg-indigo-800 text-indigo-200 rounded border border-indigo-700 cursor-pointer"
                          >
                            Review Submission
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Action */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setSelectedTaskForSubmission(task)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer"
                >
                  Submit Proof of Work
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submission Modal */}
      {selectedTaskForSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Submit Proof of Work</h3>
              <button
                onClick={() => setSelectedTaskForSubmission(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitWork} className="space-y-4">
              <div className="text-xs text-slate-300 font-semibold">
                Task: {selectedTaskForSubmission.title}
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Public Proof / PR / Repository URL</label>
                <input
                  type="url"
                  placeholder="https://github.com/..."
                  value={submissionUrl}
                  onChange={(e) => setSubmissionUrl(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Contributor Name</label>
                  <input
                    type="text"
                    value={contributorName}
                    onChange={(e) => setContributorName(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-slate-400">YAGYX Address (For Reward)</label>
                  <input
                    type="text"
                    value={contributorAddress}
                    onChange={(e) => setContributorAddress(e.target.value)}
                    placeholder="0x..."
                    className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-400">Verification Notes</label>
                <textarea
                  rows={3}
                  value={submissionNotes}
                  onChange={(e) => setSubmissionNotes(e.target.value)}
                  placeholder="Explain how your solution fulfills the stated acceptance criteria..."
                  className="w-full px-3 py-2 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 leading-relaxed"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedTaskForSubmission(null)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-300 hover:bg-amber-200 rounded transition-colors cursor-pointer"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit for Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reviewer Action Modal */}
      {reviewDecisionTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Review Task Proof</h3>
              <button
                onClick={() => setReviewDecisionTask(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400">Review Notes / Audit Feedback</label>
                <textarea
                  rows={3}
                  value={reviewNote}
                  onChange={(e) => setReviewNote(e.target.value)}
                  placeholder="Detail whether acceptance criteria were completely met..."
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => handleReviewDecision('REJECT')}
                  disabled={isReviewing}
                  className="px-3.5 py-1.5 font-semibold text-rose-300 bg-rose-950/70 border border-rose-800 rounded hover:bg-rose-900 transition-colors cursor-pointer"
                >
                  Request Revision
                </button>
                <button
                  onClick={() => handleReviewDecision('ACCEPT')}
                  disabled={isReviewing}
                  className="px-3.5 py-1.5 font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors cursor-pointer"
                >
                  Approve Reward
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
