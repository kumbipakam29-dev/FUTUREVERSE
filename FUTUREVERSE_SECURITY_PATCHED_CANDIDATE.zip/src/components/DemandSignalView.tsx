import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Activity,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Lightbulb,
  FlaskConical,
  Compass,
  ArrowUpRight,
  ShieldCheck,
  RefreshCw,
  Plus,
  Send,
} from 'lucide-react';
import { api } from '../services/api';

export const DemandSignalView: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'opportunities' | 'signals' | 'experiments'>('opportunities');
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [experiments, setExperiments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // New Opportunity Modal
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [problemInput, setProblemInput] = useState('');
  const [segmentInput, setSegmentInput] = useState('Autonomous Web3 & AI Developers');
  const [workaroundInput, setWorkaroundInput] = useState('');
  const [frequencyInput, setFrequencyInput] = useState<'DAILY' | 'WEEKLY' | 'HOURLY'>('DAILY');
  const [submitting, setSubmitting] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [oppRes, evRes, expRes] = await Promise.all([
        api.getOpportunities(),
        api.getSignalEvents({ limit: 40 }),
        api.getGrowthExperiments(),
      ]);
      setOpportunities(oppRes.opportunities || []);
      setEvents(evRes.events || []);
      setExperiments(expRes.experiments || []);
    } catch (err) {
      console.error('Failed to load demand intelligence data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmitOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!problemInput.trim()) return;

    setSubmitting(true);
    try {
      await api.addOpportunity({
        targetSegment: segmentInput,
        problemDescription: problemInput.trim(),
        currentWorkaround: workaroundInput.trim() || 'Manual process',
        frequency: frequencyInput,
        evidenceLevel: 'LEVEL_2_DIRECT_USER_FEEDBACK',
        severityScore: 80,
      });
      alert('Community problem submitted to Demand-Signal prioritization queue!');
      setIsSubmitModalOpen(false);
      setProblemInput('');
      setWorkaroundInput('');
      loadData();
    } catch (err: any) {
      alert(`Error submitting problem: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 pb-20 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="border-b border-slate-800 pb-5 space-y-2">
        <div className="flex items-center gap-2 text-xs font-mono uppercase text-indigo-400">
          <span>DEMAND-SIGNAL INTELLIGENCE & EXPERIMENTS</span>
          <span>·</span>
          <span>PARTS 4, 5 & 10</span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              FUTUREVERSE DEMAND-SIGNAL & OPPORTUNITY ENGINE
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed mt-1">
              Measurable engine detecting genuine user problems, customer discovery evidence levels (0–5),
              6-factor opportunity prioritization, and falsifiable growth experiments.
            </p>
          </div>
          <button
            onClick={() => setIsSubmitModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded-lg flex items-center gap-2 cursor-pointer transition-colors shrink-0 self-start sm:self-auto"
          >
            <Plus className="h-4 w-4" />
            <span>Submit User Problem</span>
          </button>
        </div>

        {/* 6-Factor Formula Declaration Banner */}
        <div className="p-3 rounded-lg border border-indigo-900/40 bg-indigo-950/20 text-xs font-mono text-slate-300 flex flex-col md:flex-row md:items-center justify-between gap-2 mt-3">
          <div className="flex items-center gap-2">
            <Compass className="h-4 w-4 text-indigo-400 shrink-0" />
            <span>
              Scoring Model: <strong className="text-indigo-300">0.25P + 0.20I + 0.15F + 0.15R + 0.15V + 0.10Q</strong>
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            P: Problem · I: Intent · F: Feedback · R: Retention · V: Value · Q: Evidence Quality
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('opportunities')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'opportunities'
              ? 'bg-indigo-500 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Lightbulb className="h-3.5 w-3.5" />
          <span>Prioritized Opportunities ({opportunities.length})</span>
        </button>
        <button
          onClick={() => setActiveSubTab('experiments')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'experiments'
              ? 'bg-indigo-500 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <FlaskConical className="h-3.5 w-3.5" />
          <span>Falsifiable Experiments ({experiments.length})</span>
        </button>
        <button
          onClick={() => setActiveSubTab('signals')}
          className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
            activeSubTab === 'signals'
              ? 'bg-indigo-500 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Activity className="h-3.5 w-3.5" />
          <span>Product Signal Feed ({events.length})</span>
        </button>
      </div>

      {loading ? (
        <div className="py-20 text-center font-mono text-xs text-slate-400">
          Loading demand telemetry & opportunity models...
        </div>
      ) : (
        <>
          {/* TAB 1: OPPORTUNITIES */}
          {activeSubTab === 'opportunities' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                {opportunities.map((opp) => (
                  <div
                    key={opp.id}
                    className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-slate-700 transition-all space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold">
                            {opp.targetSegment}
                          </span>
                          <span className="text-xs font-mono text-amber-300 px-2 py-0.5 rounded bg-amber-950/60 border border-amber-900/60">
                            {opp.evidenceLevel}
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-white mt-1.5">{opp.problemDescription}</h3>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xl font-bold font-mono text-emerald-400">
                          {opp.opportunityScore?.totalScore || 80}/100
                        </div>
                        <div className="text-[10px] font-mono text-slate-400">
                          Confidence: {opp.opportunityScore?.confidence || 85}%
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-lg border border-slate-800/60">
                        <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <HelpCircle className="h-3.5 w-3.5 text-indigo-400" />
                          <span>Current Workaround & Alternatives:</span>
                        </div>
                        <p className="text-slate-400">{opp.currentWorkaround}</p>
                        <div className="text-[11px] text-slate-500">
                          Competing: {opp.competingAlternatives?.join(', ') || 'Manual scripts'}
                        </div>
                      </div>

                      <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-lg border border-slate-800/60">
                        <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                          <span>Recommended Product Action (Part 4.4):</span>
                        </div>
                        <p className="text-emerald-300 font-mono text-[11px]">
                          {opp.recommendedAction?.action || 'Expose verifiable widget'}
                        </p>
                        <div className="text-[10px] text-slate-400">
                          Success Criteria: {opp.recommendedAction?.successCriteria}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-slate-400 pt-1">
                      <div>
                        Effort: ~{opp.estimatedImplementationEffortDays}d · OpCost: ₹{opp.operatingCostsInrMonthly}/mo
                      </div>
                      <div className="text-indigo-400">
                        Next Exp: {opp.nextValidationExperiment}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: EXPERIMENTS */}
          {activeSubTab === 'experiments' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {experiments.map((exp) => (
                  <div
                    key={exp.id}
                    className="p-5 rounded-xl border border-slate-800 bg-slate-900/60 space-y-3"
                  >
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">{exp.channel}</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                        {exp.status}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white">{exp.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{exp.hypothesis}</p>

                    <div className="p-3 rounded bg-slate-950 border border-slate-800/80 space-y-1.5 text-xs font-mono">
                      <div className="text-emerald-300">
                        <strong>Primary Metric: </strong>
                        {exp.primaryMetric} (Target: {exp.successThreshold})
                      </div>
                      <div className="text-amber-300">
                        <strong>Guardrail: </strong>
                        {exp.guardrailMetric}
                      </div>
                      {exp.measuredOutcomes && (
                        <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-300">
                          Measured: {exp.measuredOutcomes.primaryMetricValue}% (Sample: {exp.measuredOutcomes.participants})
                          <div className="text-slate-400 italic mt-0.5">
                            "{exp.measuredOutcomes.conclusiveSummary}"
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PRODUCT SIGNAL FEED */}
          {activeSubTab === 'signals' && (
            <div className="space-y-4">
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300 font-bold">Verified Event Stream (Zero Test Bleed)</span>
                  <button
                    onClick={loadData}
                    className="flex items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="divide-y divide-slate-800/60 max-h-96 overflow-y-auto">
                  {events.length === 0 ? (
                    <div className="p-8 text-center text-xs font-mono text-slate-400">
                      No live events recorded yet. Perform an action to view real telemetry stream.
                    </div>
                  ) : (
                    events.map((evt) => (
                      <div key={evt.eventId} className="p-3.5 flex items-center justify-between gap-4 text-xs font-mono hover:bg-slate-800/30">
                        <div className="flex items-center gap-2.5">
                          <div className="h-2 w-2 rounded-full bg-emerald-400 shrink-0" />
                          <span className="text-indigo-300 font-bold">{evt.eventType}</span>
                          <span className="text-slate-400 text-[11px]">Subject: {evt.subjectId}</span>
                        </div>
                        <div className="text-slate-400 text-[10px] shrink-0">
                          {new Date(evt.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* MODAL: SUBMIT OPPORTUNITY */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-indigo-900/60 bg-slate-950 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Submit Real Customer Problem</h3>
              <button onClick={() => setIsSubmitModalOpen(false)} className="text-slate-400 hover:text-white text-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitOpportunity} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Target User Segment</label>
                <input
                  type="text"
                  value={segmentInput}
                  onChange={(e) => setSegmentInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Problem Description</label>
                <textarea
                  rows={3}
                  placeholder="What friction or limitation is genuinely hindering the user?"
                  value={problemInput}
                  onChange={(e) => setProblemInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Current Workaround</label>
                <input
                  type="text"
                  placeholder="How do users solve this today?"
                  value={workaroundInput}
                  onChange={(e) => setWorkaroundInput(e.target.value)}
                  className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 font-semibold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded cursor-pointer disabled:opacity-50"
                >
                  {submitting ? 'Submitting...' : 'Record Opportunity'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
