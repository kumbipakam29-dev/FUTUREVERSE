import React, { useState } from 'react';
import { Play, RotateCcw, CheckCircle2, AlertCircle, ArrowRight, Sparkles } from 'lucide-react';
import { PrototypeConfig } from '../types';

interface InteractiveRunnerProps {
  prototype: PrototypeConfig;
  projectTitle: string;
}

export const InteractiveRunner: React.FC<InteractiveRunnerProps> = ({ prototype, projectTitle }) => {
  // Initialize state with default values from interactiveElements
  const [formState, setFormState] = useState<Record<string, any>>(() => {
    const initial: Record<string, any> = {};
    prototype.interactiveElements?.forEach((elem) => {
      initial[elem.id] = elem.defaultValue;
    });
    return initial;
  });

  const [hasSimulated, setHasSimulated] = useState(true);

  const handleInputChange = (id: string, value: any) => {
    setFormState((prev) => ({ ...prev, [id]: value }));
  };

  const handleReset = () => {
    const initial: Record<string, any> = {};
    prototype.interactiveElements?.forEach((elem) => {
      initial[elem.id] = elem.defaultValue;
    });
    setFormState(initial);
  };

  // Dedicated specialized calculations for the 4 core interactive starter experiences
  // 1. Career Planner
  const calculateCareer = () => {
    const role = formState.targetRole || 'AI Systems Engineer';
    const hours = Number(formState.weeklyHours) || 16;
    const level = formState.currentLevel || 'Intermediate (Some Projects)';

    let totalCurriculumHours = 400;
    if (level.includes('Beginner')) totalCurriculumHours = 600;
    if (level.includes('Advanced')) totalCurriculumHours = 250;

    const weeks = Math.max(4, Math.round(totalCurriculumHours / hours));

    const milestones = [
      {
        phase: 'Phase 1: Foundations & Core Architecture',
        duration: `${Math.round(weeks * 0.3)} weeks`,
        focus: role.includes('AI')
          ? 'Vector Embeddings, Model Context Engineering & TypeScript SDK'
          : role.includes('Smart Contract')
          ? 'Solidity, EVM Memory, YAGYX Chain ID 13370 RPC Standards'
          : 'Core System Primitives & Modular State Architecture',
      },
      {
        phase: 'Phase 2: Full-Stack Synthesis & Testing',
        duration: `${Math.round(weeks * 0.4)} weeks`,
        focus: 'Asynchronous event streaming, edge isolation & zero-trust auth',
      },
      {
        phase: 'Phase 3: Production Hardening & Capstone Release',
        duration: `${Math.round(weeks * 0.3)} weeks`,
        focus: 'Benchmark latency, security threat modeling & community publishing',
      },
    ];

    const capstone = role.includes('AI')
      ? 'An autonomous interactive simulation agent with real-time feedback loops.'
      : role.includes('Smart Contract')
      ? 'An auditable milestone-based bounty escrow contract on YAGYX Chain (13370).'
      : 'A distributed high-throughput collaboration workspace.';

    return { weeks, milestones, capstone, totalCurriculumHours };
  };

  // 2. Scenario Simulator (Treasury / Runway)
  const calculateRunway = () => {
    const treasury = Number(formState.startingTreasury) || 150000;
    const burn = Number(formState.monthlyBurn) || 12000;
    const inflow = Number(formState.organicInflow) || 4500;
    const growth = Number(formState.growthRate) || 15;

    const netMonthlyBurn = Math.max(0, burn - inflow);
    const months = netMonthlyBurn > 0 ? (treasury / netMonthlyBurn).toFixed(1) : 'Sustainable (Indefinite)';
    const resilienceScore = Math.min(100, Math.round((Number(months) / 18) * 100));

    let strategy = 'Healthy Runway (>12 months). Prioritize high-impact developer bounties.';
    if (typeof months === 'string' && Number(months) < 6) {
      strategy = 'Critical Burn Warning (<6 months). Implement reward task milestones and streamline non-core operations.';
    } else if (typeof months === 'string' && Number(months) < 12) {
      strategy = 'Moderate Runway (6-12 months). Diversify ecosystem sponsorships and prioritize community co-building.';
    }

    return { months, netMonthlyBurn, resilienceScore, strategy };
  };

  // 3. Product Planner
  const calculateArchitecture = () => {
    const scale = formState.architectureScale || 'Emerging Community (1k-50k users)';
    const storage = formState.storageParadigm || 'Relational (PostgreSQL / SQL)';
    const security = formState.securityLevel || 'Sensitive User Records (GDPR/Financial)';

    const stack = {
      frontend: 'React 19 SPA + Vite + Tailwind CSS (Strict zero-pill design)',
      backend: scale.includes('Global') ? 'Express.js microservices + Redis cache' : 'Modular Node.js / Express.js',
      database: storage,
      compliance: security.includes('Mission Critical')
        ? 'EIP-712 typed signing + automated smart contract invariants audit'
        : 'AES-256 data encryption at rest + JWT session isolation',
    };

    const sprints = [
      { sprint: 'Sprint 1', deliverable: 'Data model definitions, auth boundaries & seed fixtures' },
      { sprint: 'Sprint 2', deliverable: 'Interactive engine & backend validation logic' },
      { sprint: 'Sprint 3', deliverable: 'Production deployment, audit verification & release' },
    ];

    return { stack, sprints };
  };

  // 4. Community Solver
  const calculateCommunitySolver = () => {
    const domain = formState.problemDomain || 'Open Source Code Maintenance';
    const urgency = formState.complexityLevel || 'Moderate (Requires Architecture Review)';
    const bounty = Number(formState.contributorPool) || 1500;

    const leadBounty = Math.round(bounty * 0.6);
    const peerReviewBounty = Math.round(bounty * 0.25);
    const docBounty = Math.round(bounty * 0.15);

    const workstreams = [
      { role: 'Core Architect / Solver', allocation: `${leadBounty} YAGYX`, task: 'Produce verified code solution and reproducible test suite' },
      { role: 'Peer Code Reviewers (2x)', allocation: `${peerReviewBounty} YAGYX`, task: 'Run boundary checks, security audits & reproduction steps' },
      { role: 'Documentation & Release', allocation: `${docBounty} YAGYX`, task: 'Write changelog, migration notes, and user tutorial' },
    ];

    return { workstreams, leadBounty, peerReviewBounty, docBounty };
  };

  // 5. Generic / AI Generated Custom Prototype
  const calculateCustom = () => {
    const numericValues = Object.values(formState).filter((v) => typeof v === 'number');
    const avg = numericValues.length > 0 ? numericValues.reduce((a, b) => a + b, 0) / numericValues.length : 72;
    const score = Math.min(99, Math.max(30, Math.round(avg)));

    return {
      score,
      milestone: 'Adaptive parameter matrix calculated. Output is synchronized with configured constraints.',
      safeguard: 'Zero privileged runtime execution; state kept in sandboxed reactive store.',
    };
  };

  const careerData = prototype.type === 'career_planner' ? calculateCareer() : null;
  const runwayData = prototype.type === 'scenario_simulator' ? calculateRunway() : null;
  const archData = prototype.type === 'product_roadmap' ? calculateArchitecture() : null;
  const solverData = prototype.type === 'community_solver' ? calculateCommunitySolver() : null;
  const customData = prototype.type === 'custom_widget' ? calculateCustom() : null;

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-5 sm:p-6 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-indigo-400">Interactive Prototype Sandbox</span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Live Client Execution</span>
          </div>
          <h3 className="text-base sm:text-lg font-bold text-white mt-1">
            {prototype.headline || projectTitle}
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 rounded border border-slate-700/70 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Defaults</span>
          </button>
        </div>
      </div>

      {/* Grid: Controls on Left, Live Output on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-6">
        {/* Controls Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Configurable Parameters
          </div>

          {prototype.interactiveElements?.map((element) => {
            const val = formState[element.id];

            return (
              <div key={element.id} className="space-y-1.5 rounded-lg border border-slate-800/80 bg-slate-950/60 p-3.5">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor={element.id} className="text-xs font-medium text-slate-200">
                    {element.label}
                  </label>
                  {element.type === 'slider' && (
                    <span className="text-xs font-mono text-indigo-300 tabular-nums">
                      {val}
                    </span>
                  )}
                </div>

                {element.description && (
                  <p className="text-[11px] text-slate-400 leading-snug">{element.description}</p>
                )}

                {element.type === 'select' && (
                  <select
                    id={element.id}
                    value={val}
                    onChange={(e) => handleInputChange(element.id, e.target.value)}
                    className="w-full mt-1 px-3 py-1.5 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    {element.options?.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                )}

                {element.type === 'slider' && (
                  <input
                    id={element.id}
                    type="range"
                    min={element.min ?? 0}
                    max={element.max ?? 100}
                    step={element.step ?? 1}
                    value={val}
                    onChange={(e) => handleInputChange(element.id, Number(e.target.value))}
                    className="w-full mt-1 accent-indigo-500 cursor-pointer"
                  />
                )}

                {element.type === 'text' && (
                  <input
                    id={element.id}
                    type="text"
                    value={val || ''}
                    onChange={(e) => handleInputChange(element.id, e.target.value)}
                    className="w-full mt-1 px-3 py-1.5 text-xs rounded bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                )}
              </div>
            );
          })}

          {prototype.formulaSummary && (
            <div className="text-[11px] text-slate-400 font-mono bg-slate-950/40 p-2.5 rounded border border-slate-800/60">
              Formula: {prototype.formulaSummary}
            </div>
          )}
        </div>

        {/* Live Output Column */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4 rounded-xl border border-indigo-950/60 bg-gradient-to-b from-indigo-950/20 via-slate-950/80 to-slate-950/90 p-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5" />
                Live Reactive Simulation
              </span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                Active Model
              </span>
            </div>

            {/* 1. Career Plan Results */}
            {careerData && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60">
                    <div className="text-[11px] text-slate-400">Total Study Commitment</div>
                    <div className="text-xl font-bold font-mono text-white tabular-nums mt-0.5">
                      {careerData.totalCurriculumHours} hrs
                    </div>
                  </div>
                  <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60">
                    <div className="text-[11px] text-slate-400">Estimated Timeline</div>
                    <div className="text-xl font-bold font-mono text-indigo-400 tabular-nums mt-0.5">
                      ~{careerData.weeks} weeks
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-semibold text-slate-300">Phase Breakdown</div>
                  {careerData.milestones.map((m, idx) => (
                    <div key={idx} className="p-2.5 rounded border border-slate-800 bg-slate-950/60 text-xs">
                      <div className="flex justify-between items-center text-slate-300 font-medium">
                        <span>{m.phase}</span>
                        <span className="font-mono text-indigo-300">{m.duration}</span>
                      </div>
                      <div className="text-slate-400 text-[11px] mt-1">{m.focus}</div>
                    </div>
                  ))}
                </div>

                <div className="p-3 rounded border border-amber-900/40 bg-amber-950/20 text-xs">
                  <div className="font-semibold text-amber-200">Recommended Capstone Project:</div>
                  <div className="text-slate-300 mt-1 leading-relaxed">{careerData.capstone}</div>
                </div>
              </div>
            )}

            {/* 2. Runway Simulator Results */}
            {runwayData && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60">
                    <div className="text-[11px] text-slate-400">Net Monthly Deficit</div>
                    <div className="text-xl font-bold font-mono text-white tabular-nums mt-0.5">
                      ${runwayData.netMonthlyBurn.toLocaleString()}/mo
                    </div>
                  </div>
                  <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60">
                    <div className="text-[11px] text-slate-400">Projected Viable Runway</div>
                    <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums mt-0.5">
                      {runwayData.months} {typeof runwayData.months === 'string' && runwayData.months.includes('Sustainable') ? '' : 'months'}
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/60">
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="text-slate-400">Resilience Stress Index:</span>
                    <span className="font-mono font-bold text-white tabular-nums">{runwayData.resilienceScore}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        runwayData.resilienceScore > 70
                          ? 'bg-emerald-500'
                          : runwayData.resilienceScore > 40
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, runwayData.resilienceScore)}%` }}
                    />
                  </div>
                </div>

                <div className="p-3 rounded border border-slate-800 bg-slate-900/60 text-xs">
                  <div className="font-semibold text-slate-200">Capital Strategy Recommendation:</div>
                  <div className="text-slate-300 mt-1 leading-relaxed">{runwayData.strategy}</div>
                </div>
              </div>
            )}

            {/* 3. Architecture Planner Results */}
            {archData && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/60 space-y-2 text-xs">
                  <div className="font-semibold text-indigo-300">Target Architecture Topology</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="text-slate-400">Frontend:</span>
                      <p className="text-slate-200 font-medium">{archData.stack.frontend}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Backend:</span>
                      <p className="text-slate-200 font-medium">{archData.stack.backend}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Database:</span>
                      <p className="text-slate-200 font-medium">{archData.stack.database}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Security Posture:</span>
                      <p className="text-slate-200 font-medium">{archData.stack.compliance}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-semibold text-slate-300">Phase Milestones</div>
                  {archData.sprints.map((s, idx) => (
                    <div key={idx} className="p-2.5 rounded border border-slate-800 bg-slate-900/60 text-xs flex justify-between items-center">
                      <span className="font-mono text-indigo-400">{s.sprint}</span>
                      <span className="text-slate-300">{s.deliverable}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 4. Community Solver Results */}
            {solverData && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/60 text-xs">
                  <div className="font-semibold text-indigo-300 mb-2">Bounty Allocation Matrix</div>
                  <div className="space-y-2">
                    {solverData.workstreams.map((w, idx) => (
                      <div key={idx} className="p-2 rounded border border-slate-800/80 bg-slate-900/80">
                        <div className="flex justify-between items-center text-slate-200 font-medium text-xs">
                          <span>{w.role}</span>
                          <span className="font-mono text-emerald-400 font-semibold">{w.allocation}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">{w.task}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded border border-slate-800 bg-slate-900/60 text-xs">
                  <span className="font-semibold text-slate-200">Attestation Flow:</span>
                  <p className="text-slate-300 text-[11px] mt-1">
                    Work submitted to Evolution Board → Audited by 2 community reviewers → Tokens distributed via YAGYX escrow.
                  </p>
                </div>
              </div>
            )}

            {/* 5. Custom / AI Prototype Results */}
            {customData && (
              <div className="space-y-4">
                <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60">
                  <div className="text-[11px] text-slate-400">Dynamic Efficiency Index</div>
                  <div className="text-2xl font-bold font-mono text-indigo-400 tabular-nums mt-0.5">
                    {customData.score} / 100
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-800 bg-slate-950/60 text-xs">
                  <div className="font-semibold text-slate-300 mb-1">Generated Output State</div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{customData.milestone}</p>
                </div>

                <div className="p-3 rounded border border-slate-800 bg-slate-900/60 text-xs">
                  <div className="font-semibold text-slate-300 mb-1">Security Isolation</div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{customData.safeguard}</p>
                </div>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <span>Deterministic state machine</span>
            <span>Zero untrusted script injection</span>
          </div>
        </div>
      </div>
    </div>
  );
};
