export type ProjectCategory = 
  | 'AI Agents' 
  | 'EdTech & Careers' 
  | 'Web3 & FinTech' 
  | 'Creative Tools' 
  | 'Community Systems' 
  | 'Productivity';

export type ProjectType = 
  | 'Working Application' 
  | 'Interactive Prototype' 
  | 'Simulation' 
  | 'Concept';

export type ProjectVisibility = 'draft' | 'published';

export interface ProjectAuthor {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  verified: boolean;
  foundingMember: boolean;
  address?: string;
}

export interface ProjectFeature {
  title: string;
  description: string;
  priority: 'core' | 'extended' | 'future';
}

export interface UserFlowStep {
  step: number;
  title: string;
  action: string;
  outcome: string;
}

export interface ProjectSpecification {
  targetAudience: string;
  problemStatement: string;
  keyFeatures: ProjectFeature[];
  userFlow: UserFlowStep[];
  architecture: {
    frontend: string;
    backend: string;
    dataModel: string;
    securityNotes: string;
  };
}

export interface InteractiveElement {
  id: string;
  label: string;
  type: 'select' | 'slider' | 'text' | 'checkbox' | 'radio';
  options?: string[];
  min?: number;
  max?: number;
  step?: number;
  defaultValue: any;
  description?: string;
}

export interface PrototypeConfig {
  type: 'career_planner' | 'scenario_simulator' | 'product_roadmap' | 'community_solver' | 'custom_widget';
  headline: string;
  interactiveElements: InteractiveElement[];
  formulaSummary?: string;
  outputSections: {
    title: string;
    metricLabel?: string;
    calculationKey?: string;
  }[];
}

export interface ProjectFeedback {
  id: string;
  author: string;
  avatar?: string;
  type: 'feedback' | 'suggestion' | 'bug' | string;
  content: string;
  createdAt: string;
  upvotes: number;
  upvotedBy?: string[];
  status?: 'APPROVED' | 'PENDING' | 'FLAGGED';
  moderatedBy?: string;
  category?: string;
  rating?: number;
  authorName?: string;
  authorAddress?: string;
  isFoundingMember?: boolean;
}

export interface Project {
  id: string;
  title: string;
  tagline: string;
  description: string;
  category: ProjectCategory;
  type: ProjectType;
  visibility: ProjectVisibility;
  version: string;
  author: ProjectAuthor;
  createdAt: string;
  updatedAt: string;
  stars: number;
  forks: number;
  tags: string[];
  specification: ProjectSpecification;
  prototype: PrototypeConfig;
  feedback: ProjectFeedback[];
  aiGenerated: boolean;
  modelUsed?: string;
  algorithmTier?: 'standard' | '100000iq' | '1000000iq' | '1000k' | '1000kiq' | string;
  iqBenchmark?: number;
  mathematicalInvariants?: {
    formalProofStatement: string;
    primaryEquation: string;
    invariantBounds: string[];
    complexityClass: string;
  };
  polymathCouncilReview?: Array<{
    personaId: string;
    personaName: string;
    historicalName: string;
    icon?: string;
    verdict: 'APPROVED' | 'REFINED' | 'STRESSED' | string;
    cognitivePerspective: string;
    mathematicalProofOrFormula: string;
    concreteRecommendation: string;
  }>;
  transparencyNotice?: string;
  primaryPersona?: any;
  contributingPersonas?: string[];
  logoUrl?: string;
  status?: 'Working Application' | 'Interactive Prototype' | 'Simulation' | 'In Development' | 'Archived' | string;
}

export type EvolutionCategory = 
  | 'Engineering' 
  | 'UI/UX' 
  | 'Testing' 
  | 'Documentation' 
  | 'Accessibility' 
  | 'Security';

export type EvolutionStatus = 
  | 'SUBMITTED' 
  | 'UNDER REVIEW' 
  | 'SELECTED' 
  | 'BUILDING' 
  | 'TESTING' 
  | 'RELEASED' 
  | 'DECLINED' 
  | 'DUPLICATE' 
  | 'ON HOLD';

export interface EvolutionItem {
  id: string;
  title: string;
  category: EvolutionCategory;
  description: string;
  proposer: {
    name: string;
    address?: string;
    foundingMember?: boolean;
  };
  status: EvolutionStatus;
  votes: number;
  createdAt: string;
  updatedAt: string;
  reviewNotes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  userVoted?: boolean;
}

export type TaskDifficulty = 'Starter' | 'Intermediate' | 'Advanced';

export type TaskStatus = 'AVAILABLE' | 'SUBMITTED' | 'UNDER_REVIEW' | 'ACCEPTED' | 'REWARD_APPROVED';

export interface TaskSubmission {
  id: string;
  contributorName: string;
  contributorAddress?: string;
  submissionUrl: string;
  notes: string;
  submittedAt: string;
  status: 'PENDING' | 'ACCEPTED' | 'APPROVED' | 'REJECTED';
  reviewNote?: string;
}

export interface ContributorTask {
  id: string;
  title: string;
  category: EvolutionCategory;
  difficulty: TaskDifficulty;
  requirements: string[];
  acceptanceCriteria: string[];
  rewardType: string;
  rewardAmount: string;
  status: TaskStatus;
  submissions: TaskSubmission[];
  createdAt: string;
}

export interface ContributorProfile {
  name: string;
  handle: string;
  address?: string;
  role: 'Explorer' | 'Builder' | 'Reviewer' | 'Founding Member';
  foundingMember: boolean;
  acceptedContributions: number;
  projectsCreated: number;
  projectsImproved: number;
  verifiedBugFixes: number;
  rewardPoints: number;
  badges: string[];
}

export interface YagyxNetworkInfo {
  chainId: number;
  chainIdHex: string;
  networkName: string;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
  tokens: {
    symbol: string;
    name: string;
    role: string;
    status: string;
    referencePrice: string;
    paymentPriority: number;
    verifiedContract?: string;
  }[];
  rpcStatus: string;
  explorerStatus: string;
  paymentPriorityRules: string[];
}

export interface YagyxLedgerRecord {
  orderId: string;
  userId: string;
  tier: string;
  region: string;
  targetDurationDays: number;
  chainId: number;
  selectedAsset: 'YAGYX' | 'YGO' | 'YUSD' | 'YINR';
  isNative: boolean;
  tokenContractAddress?: string;
  expectedRecipient: string;
  baseUnitsRequired: string;
  humanAmountRequired: number;
  referenceCurrency: string;
  referenceAmount: number;
  state: string;
  confirmations: number;
  txHash?: string;
  senderAddress?: string;
  createdAt: string;
  updatedAt: string;
}

export interface YagyxRpcProbeResult {
  status: 'ONLINE_VERIFIED' | 'ONLINE_MISMATCH' | 'UNREACHABLE_HTTP' | 'OFFLINE';
  targetUrl: string;
  latencyMs: number;
  returnedChainIdHex?: string;
  returnedChainId?: number | null;
  isExpectedChain: boolean;
  error?: string;
  message: string;
  httpStatus?: number;
}

export interface YagyxSecurityFinding {
  id: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFORMATIONAL';
  category: string;
  title: string;
  status: string;
  remediation: string;
}

export interface YagyxSecurityReport {
  auditSubject: string;
  auditDate: string;
  auditor: string;
  complianceStandard: string;
  findings: YagyxSecurityFinding[];
  canonicalStewards: { name: string; role: string }[];
}

// --- COMMON AI PROVIDER ARCHITECTURE TYPES ---
export interface AIModelDefinition {
  id: string;
  provider: string;
  displayName: string;
  contextWindowTokens: number;
  costPer1kTokensInr: number;
  costPer1kTokensUsd: number;
  tier: 'FAST_ECONOMICAL' | 'DEEP_REASONING' | 'DETERMINISTIC_OFFLINE';
  isAvailable: boolean;
  requiresPaidKey: boolean;
}

export interface AIProviderStatus {
  primaryProvider: string;
  operationalStatus: 'OPERATIONAL' | 'DEGRADED' | 'OFFLINE_FALLBACK';
  apiKeyConfigured: boolean;
  activeModel: string;
  totalRequests: number;
  totalTokensProcessed: number;
  totalEstimatedCostInr: number;
  verifiedModels: AIModelDefinition[];
  lastError: string | null;
}

// --- REAL DEEP RESEARCH TYPES (Phase 3) ---
export interface ResearchSource {
  id: string;
  citationNumber: number;
  title: string;
  type: 'WORKSPACE_SPEC' | 'FINANCIAL_LEDGER' | 'SOURCE_CODE' | 'CANONICAL_TEXT' | 'WEB_EVM_SPEC';
  originPathOrUrl: string;
  verifiedExcerpt: string;
  relevanceScore: number;
  credibilityTier: 'PRIMARY_AUTHORITATIVE' | 'SECONDARY_DOCUMENTED' | 'UNVERIFIED_CLAIM';
  retrievalTimestamp: string;
}

export interface ResearchSubtopicAnalysis {
  subtopicTitle: string;
  keyFindings: string;
  supportingCitations: number[];
}

export interface DeepResearchDossier {
  id: string;
  query: string;
  scope: 'ALL' | 'WORKSPACE_FILES' | 'WEB_AND_EVM';
  status: 'COMPLETED' | 'IN_PROGRESS' | 'FAILED';
  executiveSummary: string;
  clarifiedObjectives: string[];
  subtopicAnalyses: ResearchSubtopicAnalysis[];
  evidenceMatrix: ResearchSource[];
  conflictingEvidenceAndTradeoffs: string[];
  unsupportedClaimsAndGaps: string[];
  limitationsAndUncertainties: string[];
  metrics: {
    totalSourcesRetrieved: number;
    primarySourceCount: number;
    latencyMs: number;
    tokensEstimated: number;
    providerUsed: string;
  };
  createdAt: string;
  saved: boolean;
}

// --- AUTONOMOUS APP BUILDER TYPES (Phase 4) ---
export type BuilderStageId =
  | 'REQUEST'
  | 'REQUIREMENT_ANALYSIS'
  | 'IMPLEMENTATION_PLAN'
  | 'FILE_CHANGES'
  | 'DEPENDENCY_VALIDATION'
  | 'BUILD'
  | 'AUTOMATED_TESTS'
  | 'SECURITY_CHECKS'
  | 'PREVIEW'
  | 'USER_REVIEW'
  | 'APPROVED_RELEASE';

export interface BuilderStageRecord {
  stage: BuilderStageId;
  label: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED';
  summary: string;
  details?: any;
  timestamp: string;
}

export interface AppBuilderSession {
  sessionId: string;
  prompt: string;
  currentStage: BuilderStageId;
  stages: BuilderStageRecord[];
  requirementAnalysis?: {
    functionalRequirements: string[];
    technicalConstraints: string[];
    userStories: string[];
    targetCategory: string;
  };
  implementationPlan?: {
    milestones: string[];
    targetFiles: string[];
    estimatedComplexity: string;
  };
  fileChanges?: Array<{
    filePath: string;
    action: 'CREATE' | 'MODIFY';
    summary: string;
    codeSnippet: string;
  }>;
  dependencyValidation?: {
    allowedDependencies: string[];
    newDependenciesRequested: string[];
    securityVerdict: 'CLEAN' | 'REJECTED';
  };
  buildStatus?: {
    syntaxCheckPassed: boolean;
    typeCheckPassed: boolean;
    errors: string[];
  };
  automatedTests?: Array<{
    testName: string;
    assertion: string;
    status: 'PASS' | 'FAIL';
  }>;
  securityChecks?: Array<{
    checkName: string;
    status: 'PASSED' | 'FLAGGED';
    notes: string;
  }>;
  generatedProject?: Partial<Project>;
  releasedProjectId?: string;
  createdAt: string;
  updatedAt: string;
}

// --- 30-DAY MYSTERY LAUNCH TYPES ---
export interface LaunchCampaignStage {
  dayRange: string;
  title: string;
  teaser: string;
  status: 'ACTIVE' | 'UPCOMING' | 'COMPLETED';
}

export interface EarlyAccessRegistration {
  id: string;
  email: string;
  handle: string;
  registeredAt: string;
  verified: boolean;
}

export interface LaunchCampaign {
  startTime: string;
  endTime: string;
  totalDays: number;
  currentDay: number;
  isRevealed: boolean;
  revealedAt?: string;
  stages: LaunchCampaignStage[];
  registeredCount: number;
  registrations: EarlyAccessRegistration[];
  day30CoreReveal: {
    headline: string;
    visionDocument: string;
    ecosystemBlueprint: string;
    unlockedCapabilities: string[];
  };
}

// --- COMPUTE MARKETPLACE & 1% COMMISSION TYPES ---
export type WorkloadType = 'AI_INFERENCE' | 'DATA_SYNTHESIS' | 'GRAPH_TRAVERSAL' | 'VERIFICATION_PROOF';
export type DeviceTier = 'ANDROID' | 'LAPTOP_PC' | 'GPU_WORKSTATION' | 'SERVER_CLUSTER';

export interface ComputeJob {
  id: string;
  customerId: string;
  customerName: string;
  title: string;
  workloadType: WorkloadType;
  deviceTier: DeviceTier;
  grossAmountInr: number;
  commissionRate: number; // 0.01 (1%)
  commissionAmountInr: number;
  providerSettlementInr: number;
  providerId?: string;
  providerName?: string;
  status: 'OPEN' | 'ASSIGNED' | 'EXECUTING' | 'VERIFYING' | 'SETTLED' | 'DISPUTED';
  resultPayload?: string;
  verificationMethod: string;
  createdAt: string;
  settledAt?: string;
}

export interface ComputeProvider {
  id: string;
  ownerName: string;
  deviceType: DeviceTier;
  deviceModel: string;
  batteryThermalSafeguardActive: boolean;
  isOptedIn: boolean;
  totalCompletedJobs: number;
  earnedInr: number;
  rewardTokensEarned: {
    YGO: number;
    YAGYX: number;
  };
  reputationScore: number;
}

// --- FUTUREVERSE SOCIAL HUB TYPES ---
export type PublishingMode = 'MANUAL' | 'AI_ASSISTED' | 'AUTOPILOT';
export type SocialPlatform = 'TELEGRAM' | 'WHATSAPP' | 'INSTAGRAM' | 'TIKTOK' | 'FACEBOOK' | 'X';

export interface ConnectedSocialPlatform {
  platform: SocialPlatform;
  connected: boolean;
  accountHandle?: string;
  permissionScopes: string[];
  lastSync?: string;
}

export interface OfficialChannel {
  id: string;
  userId: string;
  channelName: string;
  handle: string;
  avatar: string;
  bio: string;
  subscribersCount: number;
  postsCount?: number;
  publishingMode: PublishingMode;
  connectedPlatforms: ConnectedSocialPlatform[];
  createdAt: string;
}

export interface SocialPost {
  id: string;
  channelId: string;
  author: string;
  content: string;
  mediaUrl?: string;
  likes: number;
  commentsCount: number;
  publishedAt: string;
  agentAttribution?: string;
  syndicatedPlatforms: SocialPlatform[];
}

export interface SocialAgent {
  id: string;
  role: 'Strategy Agent' | 'Creator Agent' | 'Distribution Agent' | 'Scheduling Agent' | 'Publishing Agent' | 'Community Agent' | 'Analytics Agent' | 'Safety Guardian AI';
  scope: string;
  status: 'IDLE' | 'ACTIVE' | 'SUPERVISED';
  lastAction: string;
  lastActionTimestamp: string;
}

// --- BATWAL'S VERSE AI ECOSYSTEM TYPES ---
export type VerseModuleId = 
  | 'SARATHI' 
  | 'VIVEKA' 
  | 'BUDDHI' 
  | 'DRISHTI' 
  | 'VAANI' 
  | 'JNANA' 
  | 'SMRITI' 
  | 'KARMA' 
  | 'DHARMA' 
  | 'YOGA';

export interface VerseModel {
  id: string;
  name: string;
  family: string;
  capability: 'LLM' | 'Vision' | 'Reasoning' | 'Language' | 'Multimodal' | 'Code' | 'Embedding' | 'Audio' | 'Video' | 'Classification';
  parameters: string;
  license: string;
  benchmarkScore: string;
  status: 'REGISTERED' | 'VERIFIED' | 'COMMUNITY_LISTED' | 'HOSTED_DEMO';
  orchestratorModule: VerseModuleId;
}

export type AgentStatus = 'ACTIVE' | 'EVALUATING' | 'PAUSED' | 'DEPRECATED' | 'EXECUTING' | 'FAILED';

export interface VerseAgent {
  id: string;
  name: string;
  version: string;
  capability: string;
  permissionScope: string[];
  toolAccess: string[];
  status: AgentStatus;
  evalScore: number;
  testPassed?: boolean;
  executionState?: 'IDLE' | 'QUEUED' | 'EXECUTING' | 'COMPLETED' | 'FAILED';
  totalTasksExecuted?: number;
  lastExecutedAt?: string;
  permissionScopes?: string[];
  currentVersion?: string;
  parentAgentId?: string;
}

export type PersonaStyle = 
  | 'Socratic Mentor' 
  | 'Deterministic Systems Engineer' 
  | 'Empathetic Educator' 
  | 'Executive Strategic Lead' 
  | 'Constitutional Security Sentinel' 
  | 'Creative Innovation Catalyst'
  | 'Mathematical & First-Principles Sage'
  | 'Universal Polymath Polyglot';

export interface VersePersona {
  id: string;
  name: string;
  tagline: string;
  purpose: string;
  interactionStyle: PersonaStyle;
  systemInstructions: string;
  associatedBaseModel: string;
  associatedAgentId?: string;
  permissionScope: string[];
  limitations: string[];
  version: string;
  status: 'ACTIVE' | 'TESTING' | 'DISABLED';
  evalScore: number;
  testPassed: boolean;
  totalInteractions: number;
  createdAt: string;
  updatedAt: string;
  cognitiveArchetype?: string;
  realPersonInspiration?: string;
  iqBenchmarkTarget?: number;
  isHistoricalPolymathPersona?: boolean;
  isTrainedModel?: boolean;
  simulationTransparencyNotice?: string;
  authenticHistoricalSources?: string[];
  author?: string;
  authorName?: string;
  evaluationResults?: Array<{
    metricName: string;
    score: number;
    benchmarkDataset?: string;
    evaluatedAt?: string;
  }>;
}

export interface AgentTaskExecution {
  executionId: string;
  agentId: string;
  agentVersion: string;
  taskQuery: string;
  state: 'QUEUED' | 'EXECUTING' | 'COMPLETED' | 'FAILED';
  startedAt: string;
  completedAt?: string;
  outputSummary?: string;
  latencyMs?: number;
  error?: string;
  resourceUsage: {
    memoryMb: number;
    tokenCount: number;
    costInr: number;
  };
  authorizedActor: string;
}

export interface SarathiRoutingResult {
  taskQuery: string;
  selectedModel: VerseModel;
  selectedAgent?: VerseAgent;
  reasoningSummary: string;
  estimatedLatencyMs: number;
  estimatedCostInr: number;
  routingSubsystem: VerseModuleId;
}

// --- OWNERSHIP & PERMANENT AUTHORITY FOR DHAVAL CHANDRASHEKHAR BATWAL ---
export interface OwnershipRegistry {
  owner: string; // Dhaval Chandrashekhar Batwal
  coOwner: string; // Hemangini Chandrashwkhar Batwal
  coOperationalOwner: string; // Jayshriben Chandrashekhar Batwal
  ownerEmail?: string; // aibabayaga0@gmail.com
}

export interface PermanentAuthorityProfile {
  userId: string;
  canonicalName: string;
  email?: string;
  currentDesignation: string; // e.g. 'Owner' | 'Super Admin' | 'Director' | 'Founder' | 'Chairman'
  protectedAuthority: boolean; // Immutable permanent capability flag
  effectivePermissions: string[];
  antiLockoutActive: boolean;
  designationHistory: {
    previousDesignation: string;
    newDesignation: string;
    changedAt: string;
    actor: string;
    antiLockoutPreserved: boolean;
  }[];
}

export interface AuditLogEvent {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  details: string;
  outcome: 'SUCCESS' | 'BLOCKED' | 'FLAGGED';
}

// --- MEMBERSHIP CHECKOUT & PAYMENT ORDER ---
export interface MembershipOrder {
  id: string;
  userId: string;
  tier: 'Free Explorer' | 'Founding Member' | 'Ecosystem Organization';
  region: 'India' | 'Global';
  priceDisplay: string;
  amountInr: number;
  amountUsd: number;
  selectedAsset: 'YGO' | 'YAGYX' | 'YINR' | 'YUSD';
  assetAmountRequired: number;
  platformFeeInr: number;
  status: 'PENDING' | 'CONFIRMED' | 'FAILED';
  createdAt: string;
  confirmedAt?: string;
  txHash?: string;
}

export type MembershipLifecycleState =
  | 'USER_NOT_AUTHENTICATED'
  | 'WALLET_NOT_CONNECTED'
  | 'WRONG_NETWORK'
  | 'CHECKOUT_INVALID'
  | 'PAYMENT_NOT_INITIATED'
  | 'TRANSACTION_SUBMITTED'
  | 'TRANSACTION_PENDING'
  | 'TRANSACTION_FAILED'
  | 'TRANSACTION_CONFIRMED_ON_CHAIN'
  | 'BACKEND_VERIFIED'
  | 'ENTITLEMENT_RECORDED'
  | 'MEMBERSHIP_ACTIVE';

// --- SECTION 11: INFINITE MEANINGFUL MODEL NAMING ENGINE TYPES ---
export interface ModelNamingRecord {
  id: string;
  displayName: string; // e.g. "BATWAL'S VERSE KARMAYOGA"
  normalizedName: string; // "batwals verse karmayoga"
  sanskritTerm: string; // e.g. "कर्मयोग (Karmayoga)"
  gitaChapterVerse: string; // e.g. "Bhagavad Gita 2.47"
  sanskritSourceText: string;
  transliteration: string;
  englishTranslation: string;
  plainLanguageExplanation: string;
  positiveLesson: string;
  intendedCapability: string;
  verificationStatus: 'VERIFIED' | 'PENDING_VERIFICATION';
  reviewerRecord: string;
  approvalStatus: 'APPROVED' | 'PROPOSED' | 'REJECTED';
  underlyingModelType: 'CANDIDATE_NAME_ONLY' | 'SPECIALIZED_CONFIG' | 'FINE_TUNED_MODEL' | 'BASE_MODEL';
  underlyingModelLink?: string;
  createdAt: string;
  name?: string;
  status?: string;
  meaning?: string;
  sanskritRoot?: string;
  gitaTeachingRef?: string;
  linkedModelProfile?: string;
  chapter?: string;
  shloka?: string;
}

// --- SECTION 5.3: AUTHORITATIVE 30-DAY CAMPAIGN STATUS ---
export type CampaignLifecycleStatus = 'NOT_SCHEDULED' | 'SCHEDULED' | 'ACTIVE' | 'REVEALED' | 'PAUSED';

export interface AuthoritativeCampaignState {
  status: CampaignLifecycleStatus;
  scheduledStartTimestamp: string | null;
  scheduledRevealTimestamp: string | null;
  authoritativeTimezone: string;
  campaignVersion: number;
  serverCurrentTime: string;
  remainingMs: number;
  daysRemaining: number;
  hoursRemaining: number;
  minutesRemaining: number;
  secondsRemaining: number;
  stateDescription: string;
  totalDays: number;
  currentDay: number;
  registeredCount: number;
  isRevealed: boolean;
  stages: LaunchCampaignStage[];
  day30CoreReveal?: {
    headline: string;
    visionDocument: string;
    ecosystemBlueprint: string;
    unlockedCapabilities: string[];
  };
}

// --- SECTION 12 & 15: AGENT MULTIPLICATION & VERSION RECORD ---
export interface AgentVersionRecord {
  versionId: string;
  agentId: string;
  versionNumber: string;
  parentVersion?: string;
  instructions: string;
  permissionScope: string[];
  toolAccess: string[];
  evalScore: number;
  changeSummary: string;
  createdAt: string;
  releasedBy: string;
  status: 'CANDIDATE' | 'APPROVED' | 'DEPRECATED';
}

