import { useState, useEffect, useRef, useCallback } from 'react';

// Web Speech API interface declarations for TypeScript compatibility
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

export interface UseSpeechRecognitionOptions {
  lang?: string;
  continuous?: boolean;
  interimResults?: boolean;
  soundCue?: boolean;
}

export interface UseSpeechRecognitionReturn {
  isSupported: boolean;
  isListening: boolean;
  transcript: string;
  interimTranscript: string;
  error: string | null;
  startListening: (options?: { lang?: string }) => void;
  stopListening: () => void;
  toggleListening: () => void;
  resetTranscript: () => void;
  setLanguage: (lang: string) => void;
  currentLanguage: string;
}

const SUPPORTED_LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'en-GB', label: 'English (UK)' },
  { code: 'es-ES', label: 'Español' },
  { code: 'fr-FR', label: 'Français' },
  { code: 'de-DE', label: 'Deutsch' },
  { code: 'ja-JP', label: '日本語' },
  { code: 'hi-IN', label: 'हिन्दी' },
  { code: 'zh-CN', label: '中文 (Mandarin)' },
];

export { SUPPORTED_LANGUAGES };

export const useSpeechRecognition = (
  options: UseSpeechRecognitionOptions = {}
): UseSpeechRecognitionReturn => {
  const {
    lang = 'en-US',
    continuous = true,
    interimResults = true,
    soundCue = true,
  } = options;

  const [isSupported, setIsSupported] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState<string>(lang);

  const recognitionRef = useRef<any>(null);
  const shouldListenRef = useRef<boolean>(false);

  // Audio cues using HTML5 AudioContext
  const playCue = useCallback((type: 'start' | 'stop' | 'error') => {
    if (!soundCue || typeof window === 'undefined') return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(0.03, ctx.currentTime);

      if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === 'stop') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(740, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(370, ctx.currentTime + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === 'error') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(260, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(180, ctx.currentTime + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      }
    } catch {
      // AudioContext unavailable or autoplay restricted
    }
  }, [soundCue]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        setIsSupported(true);
      } else {
        setIsSupported(false);
      }
    }
  }, []);

  const resetTranscript = useCallback(() => {
    setTranscript('');
    setInterimTranscript('');
  }, []);

  const stopListening = useCallback(() => {
    shouldListenRef.current = false;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Already stopped
      }
    }
    setIsListening(false);
    setInterimTranscript('');
    playCue('stop');
  }, [playCue]);

  const startListening = useCallback(
    (opts?: { lang?: string }) => {
      if (typeof window === 'undefined') return;

      const SpeechRecognition =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;

      if (!SpeechRecognition) {
        setError('Web Speech API is not supported in this browser. Please use Google Chrome, Microsoft Edge, or Safari.');
        playCue('error');
        return;
      }

      setError(null);

      // Clean up previous instance if any
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }

      const activeLang = opts?.lang || currentLanguage || 'en-US';

      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = continuous;
        recognition.interimResults = interimResults;
        recognition.lang = activeLang;
        recognition.maxAlternatives = 1;

        recognition.onstart = () => {
          setIsListening(true);
          shouldListenRef.current = true;
          setError(null);
          playCue('start');
        };

        recognition.onresult = (event: SpeechRecognitionEvent) => {
          let currentInterim = '';
          let currentFinal = '';

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const item = event.results[i];
            const text = item[0].transcript;
            if (item.isFinal) {
              currentFinal += text;
            } else {
              currentInterim += text;
            }
          }

          if (currentFinal) {
            setTranscript((prev) => {
              const trimmedPrev = prev.trim();
              const trimmedFinal = currentFinal.trim();
              if (!trimmedPrev) return trimmedFinal;
              return `${trimmedPrev} ${trimmedFinal}`;
            });
            setInterimTranscript('');
          } else {
            setInterimTranscript(currentInterim);
          }
        };

        recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
          console.warn('[Web Speech API] Error encountered:', event.error, event.message);

          if (event.error === 'no-speech') {
            // No speech detected, not fatal
            return;
          }

          if (event.error === 'not-allowed') {
            setError('Microphone access denied. Please click the camera/mic icon in your browser address bar to grant microphone permissions.');
            setIsListening(false);
            shouldListenRef.current = false;
            playCue('error');
            return;
          }

          if (event.error === 'network') {
            setError('Network error during speech recognition. Ensure internet access is active.');
            setIsListening(false);
            shouldListenRef.current = false;
            playCue('error');
            return;
          }

          if (event.error === 'aborted') {
            // User aborted or system reset, ignore
            return;
          }

          setError(`Voice input error: ${event.error}. You can still type directly.`);
          setIsListening(false);
          shouldListenRef.current = false;
          playCue('error');
        };

        recognition.onend = () => {
          // If continuous listening is desired and user did not stop intentionally
          if (shouldListenRef.current) {
            try {
              recognition.start();
              return;
            } catch {
              // Failed to restart, mark as idle
            }
          }
          setIsListening(false);
          setInterimTranscript('');
        };

        recognitionRef.current = recognition;
        recognition.start();
      } catch (err: any) {
        console.error('Failed to initialize SpeechRecognition:', err);
        setError(err.message || 'Failed to start microphone.');
        setIsListening(false);
        shouldListenRef.current = false;
        playCue('error');
      }
    },
    [continuous, currentLanguage, interimResults, playCue]
  );

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  const setLanguage = useCallback((newLang: string) => {
    setCurrentLanguage(newLang);
    if (isListening && recognitionRef.current) {
      // Restart with new language
      stopListening();
      setTimeout(() => {
        startListening({ lang: newLang });
      }, 150);
    }
  }, [isListening, startListening, stopListening]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      shouldListenRef.current = false;
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  return {
    isSupported,
    isListening,
    transcript,
    interimTranscript,
    error,
    startListening,
    stopListening,
    toggleListening,
    resetTranscript,
    setLanguage,
    currentLanguage,
  };
};
