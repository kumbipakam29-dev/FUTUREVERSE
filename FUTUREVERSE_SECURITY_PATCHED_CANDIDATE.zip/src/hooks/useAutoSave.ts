import { useState, useEffect, useRef, useCallback } from 'react';

export interface AutoSavePayload<T> {
  data: T;
  timestamp: number;
  version: number;
}

export interface AutoSaveOptions<T> {
  key: string;
  data: T;
  intervalMs?: number; // Defaults to 30000 ms (30 seconds)
  enabled?: boolean;
  onSave?: (savedAt: Date) => void;
  isValidToSave?: (data: T) => boolean;
}

export interface UseAutoSaveReturn<T> {
  lastSaved: Date | null;
  isSaving: boolean;
  hasUnsavedChanges: boolean;
  secondsUntilNextSave: number;
  saveNow: () => boolean;
  clearSavedData: () => void;
  loadSavedData: () => { data: T; timestamp: number } | null;
}

/**
 * useAutoSave hook
 * Persists data to localStorage every 30 seconds (configurable) to prevent data loss.
 * Includes visual status indicators, countdown timers, beforeunload protection, and dirty checks.
 */
export function useAutoSave<T>({
  key,
  data,
  intervalMs = 30000,
  enabled = true,
  onSave,
  isValidToSave,
}: AutoSaveOptions<T>): UseAutoSaveReturn<T> {
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [secondsUntilNextSave, setSecondsUntilNextSave] = useState<number>(Math.round(intervalMs / 1000));

  // Keep references to latest data and options
  const dataRef = useRef<T>(data);
  dataRef.current = data;

  const onSaveRef = useRef(onSave);
  onSaveRef.current = onSave;

  const isValidToSaveRef = useRef(isValidToSave);
  isValidToSaveRef.current = isValidToSave;

  // Track the serialized representation of what was last saved to detect dirty state
  const lastSavedStringRef = useRef<string>('');
  const currentIntervalRef = useRef<number>(Math.round(intervalMs / 1000));

  // Load initially stored timestamp if present
  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed: AutoSavePayload<T> = JSON.parse(raw);
        if (parsed && parsed.timestamp) {
          setLastSaved(new Date(parsed.timestamp));
        }
      }
    } catch {
      // Ignore initial parse errors
    }
  }, [key]);

  // Execute the actual write to localStorage
  const performSave = useCallback((): boolean => {
    if (!enabled) return false;

    const currentData = dataRef.current;
    if (isValidToSaveRef.current && !isValidToSaveRef.current(currentData)) {
      return false;
    }

    try {
      setIsSaving(true);
      const serialized = JSON.stringify(currentData);

      // Avoid writing if nothing has changed
      if (serialized === lastSavedStringRef.current) {
        setHasUnsavedChanges(false);
        setIsSaving(false);
        return false;
      }

      const payload: AutoSavePayload<T> = {
        data: currentData,
        timestamp: Date.now(),
        version: 1,
      };

      localStorage.setItem(key, JSON.stringify(payload));
      lastSavedStringRef.current = serialized;

      const now = new Date();
      setLastSaved(now);
      setHasUnsavedChanges(false);

      if (onSaveRef.current) {
        onSaveRef.current(now);
      }

      return true;
    } catch (err) {
      console.warn(`[useAutoSave] Failed to persist data to localStorage for key "${key}":`, err);
      return false;
    } finally {
      setIsSaving(false);
    }
  }, [key, enabled]);

  // Dirty check: when data changes, compare with lastSavedStringRef
  useEffect(() => {
    if (!enabled) return;

    try {
      const currentSerialized = JSON.stringify(data);
      if (lastSavedStringRef.current === '') {
        // First initialization check: if matches localStorage payload, mark clean
        const raw = localStorage.getItem(key);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (JSON.stringify(parsed.data) === currentSerialized) {
            lastSavedStringRef.current = currentSerialized;
            setHasUnsavedChanges(false);
            return;
          }
        }
      }

      if (currentSerialized !== lastSavedStringRef.current) {
        setHasUnsavedChanges(true);
      }
    } catch {
      // In case serialization fails
    }
  }, [data, enabled, key]);

  // 30-second Auto-save Interval + 1-second countdown tick
  useEffect(() => {
    if (!enabled) return;

    const intervalSeconds = Math.round(intervalMs / 1000);
    currentIntervalRef.current = intervalSeconds;
    setSecondsUntilNextSave(intervalSeconds);

    const timer = setInterval(() => {
      setSecondsUntilNextSave((prev) => {
        if (prev <= 1) {
          // 30-second mark reached: trigger auto-save if there are unsaved changes or active content
          performSave();
          return intervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [intervalMs, enabled, performSave]);

  // Save before unload to guarantee zero data loss on unexpected tab close
  useEffect(() => {
    if (!enabled) return;

    const handleBeforeUnload = () => {
      performSave();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [enabled, performSave]);

  // Manual immediate save trigger
  const saveNow = useCallback((): boolean => {
    const success = performSave();
    const intervalSeconds = Math.round(intervalMs / 1000);
    setSecondsUntilNextSave(intervalSeconds);
    return success;
  }, [performSave, intervalMs]);

  // Clear persisted data
  const clearSavedData = useCallback(() => {
    try {
      localStorage.removeItem(key);
      lastSavedStringRef.current = '';
      setLastSaved(null);
      setHasUnsavedChanges(false);
    } catch (err) {
      console.warn(`[useAutoSave] Failed to clear localStorage key "${key}":`, err);
    }
  }, [key]);

  // Retrieve raw stored payload
  const loadSavedData = useCallback((): { data: T; timestamp: number } | null => {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return null;
      const parsed: AutoSavePayload<T> = JSON.parse(raw);
      if (parsed && parsed.data) {
        return {
          data: parsed.data,
          timestamp: parsed.timestamp || Date.now(),
        };
      }
      return null;
    } catch (err) {
      console.warn(`[useAutoSave] Failed to read localStorage key "${key}":`, err);
      return null;
    }
  }, [key]);

  return {
    lastSaved,
    isSaving,
    hasUnsavedChanges,
    secondsUntilNextSave,
    saveNow,
    clearSavedData,
    loadSavedData,
  };
}
