import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DiscoveryView } from './components/DiscoveryView';
import { ExploreView } from './components/ExploreView';
import { CreationEngineView } from './components/CreationEngineView';
import { WorkspaceView } from './components/WorkspaceView';
import { EvolutionView } from './components/EvolutionView';
import { RewardsView } from './components/RewardsView';
import { YagyxHubView } from './components/YagyxHubView';
import { MembershipView } from './components/MembershipView';
import { LaunchCampaignView } from './components/LaunchCampaignView';
import { ComputeMarketplaceView } from './components/ComputeMarketplaceView';
import { SocialHubView } from './components/SocialHubView';
import { VerseAiView } from './components/VerseAiView';
import { DemandSignalView } from './components/DemandSignalView';
import { OwnershipAuthorityModal } from './components/OwnershipAuthorityModal';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { CreativeStudioHub } from './components/CreativeStudioHub';
import { Project, EvolutionItem, ContributorTask } from './types';
import { api } from './services/api';
import { Web3Service, WalletState, YAGYX_CHAIN_ID } from './services/web3';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('discovery');
  const [projects, setProjects] = useState<Project[]>([]);
  const [evolutionItems, setEvolutionItems] = useState<EvolutionItem[]>([]);
  const [tasks, setTasks] = useState<ContributorTask[]>([]);
  const [loading, setLoading] = useState(true);

  // Active modal project
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Prefilled prompt for creation engine
  const [creationPrompt, setCreationPrompt] = useState<string>('');

  // Ownership & Permanent Authority modal state
  const [isAuthorityModalOpen, setIsAuthorityModalOpen] = useState(false);

  // Web3 Wallet state
  const [walletState, setWalletState] = useState<WalletState>({
    isInstalled: false,
    isConnected: false,
    address: null,
    chainId: null,
    isCorrectNetwork: false,
    balance: null,
    error: null,
  });

  // Load backend data
  const loadData = async () => {
    try {
      const [projRes, evoRes, taskRes] = await Promise.all([
        api.getProjects(),
        api.getEvolutionItems(),
        api.getContributorTasks(),
      ]);
      setProjects(projRes.projects);
      setEvolutionItems(evoRes.items);
      setTasks(taskRes.tasks);
    } catch (err) {
      console.error('Error fetching backend data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Web3 provider inspection & account listeners
  useEffect(() => {
    const hasProvider = Web3Service.hasProvider();
    setWalletState((prev) => ({ ...prev, isInstalled: hasProvider }));

    if (hasProvider) {
      Web3Service.getConnectedAccount().then(async (account) => {
        if (account) {
          const chainId = await Web3Service.getChainId();
          const balance = await Web3Service.getNativeBalance(account);
          setWalletState({
            isInstalled: true,
            isConnected: true,
            address: account,
            chainId,
            isCorrectNetwork: chainId === YAGYX_CHAIN_ID,
            balance,
            error: null,
          });
        }
      });

      const unhookAccounts = Web3Service.onAccountsChanged(async (accounts) => {
        if (accounts.length > 0) {
          const chainId = await Web3Service.getChainId();
          const balance = await Web3Service.getNativeBalance(accounts[0]);
          setWalletState((prev) => ({
            ...prev,
            isConnected: true,
            address: accounts[0],
            chainId,
            isCorrectNetwork: chainId === YAGYX_CHAIN_ID,
            balance,
          }));
        } else {
          setWalletState((prev) => ({
            ...prev,
            isConnected: false,
            address: null,
            balance: null,
          }));
        }
      });

      const unhookChain = Web3Service.onChainChanged((chainIdHex) => {
        const chainId = parseInt(chainIdHex, 16);
        setWalletState((prev) => ({
          ...prev,
          chainId,
          isCorrectNetwork: chainId === YAGYX_CHAIN_ID,
        }));
      });

      return () => {
        unhookAccounts();
        unhookChain();
      };
    }
  }, []);

  const handleConnectWallet = async () => {
    try {
      const res = await Web3Service.connectWallet();
      const balance = await Web3Service.getNativeBalance(res.address);
      setWalletState({
        isInstalled: true,
        isConnected: true,
        address: res.address,
        chainId: res.chainId,
        isCorrectNetwork: res.chainId === YAGYX_CHAIN_ID,
        balance,
        error: null,
      });
    } catch (err: any) {
      setWalletState((prev) => ({
        ...prev,
        error: err.message,
      }));
      alert(err.message);
    }
  };

  const handleStartCreationWithPrompt = (promptText?: string) => {
    setCreationPrompt(promptText || '');
    setCurrentTab('creation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleForkProject = async (projectToFork: Project) => {
    try {
      const forkedProject: Partial<Project> = {
        title: `${projectToFork.title} (Fork)`,
        tagline: projectToFork.tagline,
        description: projectToFork.description,
        category: projectToFork.category,
        type: projectToFork.type,
        visibility: 'draft',
        version: '1.0.0',
        author: {
          id: 'usr-forker',
          name: 'Current Builder',
          handle: 'builder_anon',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
          verified: false,
          foundingMember: false,
        },
        specification: projectToFork.specification,
        prototype: projectToFork.prototype,
        tags: [...projectToFork.tags, 'fork'],
      };

      const res = await api.createProject(forkedProject);
      setProjects((prev) => [res.project, ...prev]);
      setSelectedProject(null);
      setCurrentTab('workspace');
      alert(`Forked "${projectToFork.title}" successfully into your workspace!`);
    } catch (err: any) {
      alert(`Fork failed: ${err.message}`);
    }
  };

  const handleProjectSaved = (newProject: Project) => {
    setProjects((prev) => {
      const existing = prev.findIndex((p) => p.id === newProject.id);
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing] = newProject;
        return updated;
      }
      return [newProject, ...prev];
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Bar Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        walletState={walletState}
        onConnectWallet={handleConnectWallet}
        onOpenYagyxModal={() => setCurrentTab('yagyx')}
        onOpenAuthorityModal={() => setIsAuthorityModalOpen(true)}
      />

      {/* Main View Area with Auto-screen adjustment */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {loading ? (
          <div className="py-24 text-center text-xs font-mono text-slate-400">
            Initializing FUTUREVERSE 2.0 Engine & Ecosystem...
          </div>
        ) : (
          <>
            {currentTab === 'discovery' && (
              <DiscoveryView
                projects={projects}
                onOpenProject={(proj) => setSelectedProject(proj)}
                onStartCreation={handleStartCreationWithPrompt}
                onExploreMore={() => setCurrentTab('explore')}
                onOpenYagyx={() => setCurrentTab('yagyx')}
                onOpenStudios={() => setCurrentTab('studios')}
              />
            )}

            {currentTab === 'launch' && (
              <LaunchCampaignView
                onExploreCreations={() => setCurrentTab('explore')}
                onOpenMembership={() => setCurrentTab('membership')}
              />
            )}

            {currentTab === 'creation' && (
              <CreationEngineView
                initialPrompt={creationPrompt}
                onProjectSaved={handleProjectSaved}
                onOpenProject={(proj) => setSelectedProject(proj)}
              />
            )}

            {currentTab === 'compute' && <ComputeMarketplaceView />}

            {currentTab === 'social' && <SocialHubView />}

            {currentTab === 'verse' && <VerseAiView />}

            {currentTab === 'signals' && <DemandSignalView />}

            {currentTab === 'explore' && (
              <ExploreView
                projects={projects}
                onOpenProject={(proj) => setSelectedProject(proj)}
                onForkProject={handleForkProject}
                onCreateNew={() => handleStartCreationWithPrompt()}
              />
            )}

            {currentTab === 'workspace' && (
              <WorkspaceView
                projects={projects}
                onOpenProject={(proj) => setSelectedProject(proj)}
                onCreateNew={() => handleStartCreationWithPrompt()}
                onRefreshProjects={loadData}
              />
            )}

            {currentTab === 'evolution' && (
              <EvolutionView items={evolutionItems} onRefresh={loadData} />
            )}

            {currentTab === 'rewards' && (
              <RewardsView tasks={tasks} onRefresh={loadData} />
            )}

            {currentTab === 'yagyx' && (
              <YagyxHubView
                walletState={walletState}
                onConnectWallet={handleConnectWallet}
                onRefreshWallet={() => {
                  if (walletState.address) {
                    Web3Service.getNativeBalance(walletState.address).then((bal) => {
                      setWalletState((prev) => ({ ...prev, balance: bal }));
                    });
                  }
                }}
              />
            )}

            {currentTab === 'membership' && (
              <MembershipView
                onStartCreation={() => handleStartCreationWithPrompt()}
                walletState={walletState}
                onConnectWallet={handleConnectWallet}
              />
            )}

            {currentTab === 'studios' && (
              <CreativeStudioHub onStartCreation={handleStartCreationWithPrompt} />
            )}
          </>
        )}
      </main>

      {/* Project Detail & Interactive Sandbox Modal */}
      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
          onForkProject={handleForkProject}
        />
      )}

      {/* Ownership & Permanent Authority Modal (Section 12) */}
      {isAuthorityModalOpen && (
        <OwnershipAuthorityModal onClose={() => setIsAuthorityModalOpen(false)} />
      )}

      {/* Footer */}
      <Footer
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </div>
  );
}
