export const ASSETS = {
  // Visual scene images (served statically from public/assets/images/ and mirrored in dist)
  heroCreationCanvas: '/assets/images/hero_creation_canvas_1791613081866.jpg',
  avatarElena: '/assets/images/avatar_founder_elena_1791613095368.jpg',
  interactiveSimulationHub: '/assets/images/interactive_simulation_hub_1791613110482.jpg',
  communityEvolutionBoard: '/assets/images/community_evolution_board_1791613125845.jpg',

  // Ecosystem Vector Logos & Illuminati Brand Kit
  futureverseLogo: '/logos/futureverse-wordmark-neon.svg',
  futureverseIcon: '/logos/futureverse-icon.svg',
  futureverseEmblem: '/logos/futureverse-emblem.svg',
  futureverseWordmarkNeon: '/logos/futureverse-wordmark-neon.svg',
  futureverseWordmarkGold: '/logos/futureverse-wordmark-gold.svg',
  futureverseWordmarkMono: '/logos/futureverse-wordmark-mono.svg',
  batwalsVerseAiHub: '/logos/batwals-verse-ai-hub.svg',
  yagyxLogo: '/logos/yagyx-logo.svg',

  // App Icons
  appIcons: {
    neon: '/icons/app-icon-neon.svg',
    gold: '/icons/app-icon-gold.svg',
    mono: '/icons/app-icon-mono.svg',
  },

  // Status Badges
  badges: {
    workingApplication: '/badges/working-application.svg',
    interactivePrototype: '/badges/interactive-prototype.svg',
    simulation: '/badges/simulation.svg',
    inDevelopment: '/badges/in-development.svg',
    archived: '/badges/archived.svg',
  },
};

export type ProjectLifecycleStatus =
  | 'Working Application'
  | 'Interactive Prototype'
  | 'Simulation'
  | 'In Development'
  | 'Archived'
  | 'published'
  | 'draft'
  | 'archived'
  | string;

/**
 * Maps actual project status and type data to the corresponding official SVG badge asset.
 */
export function getStatusBadgeAsset(status?: string, type?: string): { src: string; alt: string; label: string } {
  const normStatus = (status || '').toLowerCase().trim();
  const normType = (type || '').toLowerCase().trim();

  // Working Application check
  if (
    normStatus === 'working application' ||
    normStatus === 'active' ||
    normStatus === 'production' ||
    normStatus === 'live' ||
    normType === 'working application'
  ) {
    return {
      src: ASSETS.badges.workingApplication,
      alt: 'Working Application',
      label: 'Working Application',
    };
  }

  // Interactive Prototype check
  if (
    normStatus === 'interactive prototype' ||
    normType === 'interactive prototype' ||
    normType === 'prototype' ||
    normStatus === 'published'
  ) {
    return {
      src: ASSETS.badges.interactivePrototype,
      alt: 'Interactive Prototype',
      label: 'Interactive Prototype',
    };
  }

  // Simulation check
  if (
    normStatus === 'simulation' ||
    normType === 'simulation' ||
    normType === 'ai_simulation' ||
    normStatus === 'testing'
  ) {
    return {
      src: ASSETS.badges.simulation,
      alt: 'Simulation',
      label: 'Simulation',
    };
  }

  // Archived check
  if (normStatus === 'archived' || normStatus === 'deprecated') {
    return {
      src: ASSETS.badges.archived,
      alt: 'Archived',
      label: 'Archived',
    };
  }

  // Default: In Development / Draft
  return {
    src: ASSETS.badges.inDevelopment,
    alt: 'In Development',
    label: 'In Development',
  };
}

/**
 * Project-specific vector logo mappings with FUTUREVERSE icon as strict verified fallback.
 */
export const PROJECT_LOGOS: Record<string, string> = {
  'career & learning path navigator': '/logos/projects/career-navigator.svg',
  'decentralized compute mesh simulator': '/logos/projects/compute-mesh.svg',
  'community problem-solving engine': '/logos/projects/community-engine.svg',
  'decentralized audit oracle': '/logos/projects/audit-oracle.svg',
  'idea-to-product architecture planner': '/logos/projects/product-planner.svg',
  'future-planning & impact simulator': '/logos/projects/impact-simulator.svg',
};

/**
 * Resolves a project logo with guaranteed fallback to the official FUTUREVERSE icon.
 */
export function getProjectLogo(title?: string, customLogoUrl?: string): string {
  if (customLogoUrl && customLogoUrl.trim()) return customLogoUrl.trim();
  if (title) {
    const norm = title.toLowerCase().trim();
    for (const [key, path] of Object.entries(PROJECT_LOGOS)) {
      if (norm.includes(key) || key.includes(norm)) {
        return path;
      }
    }
  }
  return ASSETS.futureverseIcon;
}
