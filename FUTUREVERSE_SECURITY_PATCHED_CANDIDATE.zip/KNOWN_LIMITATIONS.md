# KNOWN LIMITATIONS & EXTERNAL INFRASTRUCTURE NOTES

**Project:** FUTUREVERSE × BATWAL’S VERSE AI HUB × YAGYX CHAIN  
**Release:** FUTUREVERSE v3.1  
**Timestamp:** 2026-10-22  

---

## 1. External Media Generation Providers (Creative Studios)
- **Status:** `NOT_CONNECTED`
- **Scope:** Music Studio, Image Studio, Video Studio, Voice Studio, Animation Studio, 3D Studio, Podcast Studio, POD Design Studio.
- **Details:** The Creative Studios Hub implements complete brief creation, style parameters, prompt drafting, local asset library persistence, and hand-off to the Creation Engine. However, direct external third-party generation APIs (such as ElevenLabs, Runway Gen-3, Suno, Midjourney) require proprietary developer API keys, billing accounts, and custom vendor endpoints not bundled with this standalone archive.
- **Handling:** All studio cards display explicit `NOT_CONNECTED` status badges to avoid misleading users into expecting real-time binary rendering without configured vendor credentials.

---

## 2. Gemini API Quotas & Deterministic Fallback
- **Status:** `CONNECTED` with Graceful Fallback
- **Scope:** Verse AI Specialist Roles, 1000k IQ Algorithm, Autonomous App Builder.
- **Details:** The backend integrates `@google/genai` TypeScript SDK using `gemini-3.8-flash` and `gemini-2.5-pro`. When running on Google AI Studio's free tier, API quotas (e.g. 20 requests/day per model) may be exhausted.
- **Handling:** `aiProviderService.ts` and `superIqAlgorithmEngine.ts` implement deterministic offline fallback synthesis (`verse-deterministic-engine`) that produces mathematically sound outputs with Turing decidability, Shannon entropy invariants, and explicit degraded service notices.

---

## 3. YAGYX JSON-RPC Gateway
- **Status:** `OPERATIONAL` (Chain ID: `13370` / `0x343a`)
- **Scope:** Web3 Wallet Connection, Membership Orders, Vault Settlement.
- **Details:** The default JSON-RPC URL (`https://rpc.yagyx.network`) connects to the YAGYX chain. If an external network outage occurs, the built-in RPC probe (`/api/yagyx/rpc-probe`) reports latency and connection errors gracefully.
- **Handling:** Membership orders and vault addresses (`0x71C836376510343a000000000000000000013370`) enforce on-chain transaction hash verification and reject reused transaction hashes to prevent replay attacks.

---

## 4. Google Cloud Run Deployment
- **Status:** `CONTAINER OPERATIONAL` (Internal Port 8080/3000: HTTP 200 OK)
- **Scope:** Shared Preview URL (`ais-pre-*.run.app`).
- **Details:** The shared URL returns `HTTP 404` until the project owner triggers the deployment workflow via the Google AI Studio console by clicking the **"Deploy"** or **"Share"** button. This creates the production container revision and routes public ingress traffic.
