# DEFECT REGISTER: AUDIT, REPRODUCTION & REMEDIATION

**Project:** FUTUREVERSE × BATWAL'S VERSE AI HUB × YAGYX CHAIN  
**Classification Standard:** P0 (Critical/Financial/Security), P1 (Broken Journey), P2 (Major Visual/Responsive), P3 (Minor Usability)  

---

| ID | Severity | Component | Reproduction | Root Cause | Proposed Fix | Test | Status |
|---|---|---|---|---|---|---|---|
| **DEF-001** | **P2** | `Navbar.tsx` | Viewport 320px–390px had `scrollWidth = 407px` | Static `max-w-[190px]` logo + fixed action button padding on mobile | Scale logo to `max-w-[120px]` on small mobile, reduce header padding to `px-2.5` | `node test/visual_forensic_audit.cjs` | **RESOLVED** |
| **DEF-002** | **P2** | `Navbar.tsx` | Viewport 1280px & 1440px had `scrollWidth = 1475px` | 7 lengthy link labels + `gap-6` exceeded desktop container width | Shortened labels to concise terms, reduced nav gap to `gap-3 2xl:gap-5`, added `overflow-x-hidden` | `node test/visual_forensic_audit.cjs` | **RESOLVED** |
| **DEF-003** | **P2** | `ProjectCard.tsx` | Viewport 768px had `scrollWidth = 780px` | Long project titles without `min-w-0` pushed 168px status badge outside viewport | Added `min-w-0 flex-1`, `truncate` on title, and `max-w-[45%]` on status badge container | `node test/visual_forensic_audit.cjs` | **RESOLVED** |
| **DEF-004** | **P2** | `ProjectCard.tsx` | Fallback icon did not immediately paint on broken image URL | Native `error` event did not update DOM element before React re-render | Enhanced `onError` handler with immediate `e.currentTarget.src = ASSETS.futureverseIcon` | Fallback verification in Playwright | **RESOLVED** |
| **DEF-005** | **P1** | `server.ts` | Remote RPC query on `rpc.yagyx.network` threw unhandled promise rejection if DNS failed | Remote RPC host `rpc.yagyx.network` is Pre-Genesis and not resolving in public DNS | Wrapped fetch in 4-second AbortController timeout and catch block that queues pending transactions gracefully | Simulated RPC payment test in test suite | **RESOLVED** |
| **DEF-006** | **P1** | `server.ts` | Floating-point subtraction on compute settlement (e.g. `1337.50 - 13.38`) | Direct subtraction in floating point space caused IEEE 754 precision drift | Enforced `Math.round((gross - commission) * 100) / 100` | Automated Test 2.4 & 11.2 | **RESOLVED** |
| **DEF-007** | **P2** | `WorkspaceView.tsx` | Build error on map return closure | Missing closing parenthesis for JSX `return (` in `WorkspaceView.tsx` | Restored proper `); })}` syntax | `tsc --noEmit` & `npm run build` | **RESOLVED** |
